package com.moknight.nexoraedu

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Release 35: paid-content access. ONE place decides "may this student see this lesson?".
 *
 * NOT DONE YET (needs the server): today the answer comes from the local store, so it only hides the content in the app.
 * TODO(server): replace [canView] with a call to the server (`GET /access?lesson=<id>`) and make the server refuse to hand out
 * the video (YouTube id / file URL) to a student who has no grant. Grants must then be written by the server only:
 * by the teacher (cash / free) or by the payment webhook (online). Keep the same function signature so no screen changes.
 */
object Access {
    fun price(c: Context, l: Lesson): Int = l.price
    fun coursePrice(c: Context, l: Lesson): Int = Store.chapters(c).firstOrNull { it.id == l.chapterId }?.price ?: 0

    private fun granted(c: Context, email: String, target: String) =
        Store.grants(c).any { it.email == email && it.target == target }

    fun isPaid(c: Context, l: Lesson) = l.price > 0 || coursePrice(c, l) > 0

    /** Teacher / admin preview: pass email = null (always allowed). */
    fun canView(c: Context, email: String?, l: Lesson): Boolean {
        if (email == null || !isPaid(c, l)) return true
        return granted(c, email, "l:" + l.id) || (l.chapterId.isNotEmpty() && granted(c, email, "c:" + l.chapterId))
    }
}

/**
 * Electronic payment (skeleton). Not built: needs a payment provider and the server.
 * TODO(payments): pick ONE provider (e-wallet or gateway, e.g. Paymob / Fawry / wallet API), then:
 *  1. server creates an order (target, amount, student) and returns the provider's checkout URL / token;
 *  2. the app opens it (Custom Tab / WebView) and waits;
 *  3. the provider calls the SERVER webhook; the server verifies the signature and writes the grant (mode "online");
 *  4. the app re-asks the server (see [Access.canView]) and opens the content automatically.
 * The app must never trust "payment done" from the screen itself.
 */
object Payments {
    /** Returns false while no provider is connected (the screen then shows the "soon" message). */
    @Suppress("UNUSED_PARAMETER")
    fun start(c: Context, target: String, amount: Int, email: String, onPaid: () -> Unit): Boolean = false
}

/** Imports a YouTube video's title and thumbnail through oEmbed (no API key). Runs on a background thread; null if offline. */
object YtMeta {
    class Info(val title: String, val thumb: String)

    fun thumbUrl(yt: String) = "https://i.ytimg.com/vi/$yt/hqdefault.jpg"

    fun fetch(yt: String, done: (Info?) -> Unit) {
        Thread {
            val r: Info? = try {
                val u = URL("https://www.youtube.com/oembed?format=json&url=" + java.net.URLEncoder.encode("https://youtu.be/$yt", "UTF-8"))
                val cn = u.openConnection() as HttpURLConnection
                cn.connectTimeout = 6000; cn.readTimeout = 6000
                if (cn.responseCode != 200) null else {
                    val o = JSONObject(cn.inputStream.bufferedReader().readText())
                    Info(o.optString("title"), o.optString("thumbnail_url", thumbUrl(yt)))
                }
            } catch (e: Exception) { null }
            done(r)
        }.start()
    }
}
