package com.moknight.nexoraedu

import android.Manifest
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

/**
 * Release 54: admin control (server side is server/supabase/004_admin_control.sql).
 *  - the FIRST admin is the MAIN admin; an admin removes teachers, only the main admin removes another admin;
 *  - the main admin is told (in the app and with a phone notification) each time a teacher or an admin signs up / signs in;
 *  - a removed account is signed out and its local account is wiped the next time the app is opened with internet.
 * The server decides everything. The app only asks and shows. Callbacks run on the main thread; the *Sync functions must be called from a worker thread.
 */
object AdminControl {
    private val main = Handler(Looper.getMainLooper())
    private fun prefs(c: Context) = c.getSharedPreferences("admin_control", Context.MODE_PRIVATE)

    class Status(val role: String, val main: Boolean, val removed: Boolean)
    class Staff(val id: String, val role: String, val name: String, val email: String, val main: Boolean, val removed: Boolean, val at: Long)
    /** [kind] = signup | signin | removed; [role] = teacher | admin. */
    class Event(val id: Long, val kind: String, val role: String, val userId: String, val name: String, val email: String, val at: Long)

    /** Cached answer of the server: true only for the main admin who is signed in on this phone. */
    fun isMain(c: Context) = prefs(c).getBoolean("main", false)

    private fun parseAt(s: String): Long = runCatching {
        val f = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US)
        f.timeZone = java.util.TimeZone.getTimeZone("UTC")
        f.parse(s.take(19))!!.time
    }.getOrDefault(0L)

    // ------------------------------------------------------------------ server calls (worker thread)

    fun statusSync(c: Context): Status? {
        val r = Remote.api(c, "POST", "/rest/v1/rpc/my_status", "{}")
        if (r.first != 200) return null
        return runCatching {
            val o = JSONObject(r.second)
            Status(o.optString("role"), o.optBoolean("main"), o.optBoolean("removed"))
        }.getOrNull()
    }

    /** Release 57: answer of register_admin. [reason] = "" | "code" (missing / wrong / used / expired) | "locked" (5 wrong tries, wait an hour). */
    class AdminReg(val ok: Boolean, val main: Boolean, val reason: String)

    /**
     * Becomes admin on the server. The first admin ever = main admin (no code); every other one needs a one-time code from the main admin ([code], XXXXXX-YYYYYY).
     * Answers null when the server refused / no network.
     */
    fun registerAdminSync(c: Context, code: String = ""): AdminReg? {
        val r = Remote.api(c, "POST", "/rest/v1/rpc/register_admin", JSONObject().put("p_code", code).toString())
        if (r.first != 200) return null
        val reg = runCatching {
            val o = JSONObject(r.second)
            AdminReg(o.optBoolean("ok"), o.optBoolean("main"), o.optString("reason"))
        }.getOrNull() ?: return null
        if (reg.ok) prefs(c).edit().putBoolean("main", reg.main).apply()
        return reg
    }

    /** Main admin only: a new one-time activation code (shown once). Null = refused / no network. */
    fun newCodeSync(c: Context): String? {
        val r = Remote.api(c, "POST", "/rest/v1/rpc/new_admin_code", "{}")
        if (r.first != 200) return null
        return r.second.trim().trim('"').ifEmpty { null }
    }

    fun logEntrySync(c: Context, kind: String) {
        Remote.api(c, "POST", "/rest/v1/rpc/log_entry", JSONObject().put("p_kind", kind).toString())
    }

    fun staffSync(c: Context): List<Staff>? {
        val r = Remote.api(c, "POST", "/rest/v1/rpc/staff_list", "{}")
        if (r.first != 200) return null
        return runCatching {
            val a = JSONArray(r.second)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                Staff(o.optString("id"), o.optString("role"), o.optString("name"), o.optString("email"),
                    o.optBoolean("main"), o.optBoolean("removed"), parseAt(o.optString("at")))
            }
        }.getOrNull()
    }

    /** Unread alerts, newest first. The server returns rows only to the main admin (anyone else gets an empty list). */
    fun eventsSync(c: Context): List<Event>? {
        val r = Remote.api(c, "GET", "/rest/v1/security_events?seen=eq.false&kind=neq.removed&order=id.desc&limit=50&select=id,kind,role,user_id,name,email,at", null)
        if (r.first != 200) return null
        return runCatching {
            val a = JSONArray(r.second)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                Event(o.optLong("id"), o.optString("kind"), o.optString("role"), o.optString("user_id"),
                    o.optString("name"), o.optString("email"), parseAt(o.optString("at")))
            }
        }.getOrNull()
    }

    // ------------------------------------------------------------------ server calls (callbacks on the main thread)

    private fun bg(work: () -> Unit) { Thread { work() }.start() }

    fun staff(c: Context, done: (List<Staff>?) -> Unit) = bg { val l = staffSync(c); main.post { done(l) } }

    fun events(c: Context, done: (List<Event>?) -> Unit) = bg { val l = eventsSync(c); main.post { done(l) } }

    /** false = refused or no network (the server refuses: yourself, the main admin, an admin when you are not the main admin). */
    fun remove(c: Context, userId: String, done: (Boolean) -> Unit) = bg {
        val r = Remote.api(c, "POST", "/rest/v1/rpc/remove_account", JSONObject().put("p_user", userId).put("p_reason", "").toString())
        val ok = r.first == 200 && r.second.trim() == "true"
        main.post { done(ok) }
    }

    /**
     * Release 75, admin only: removes a STUDENT on the server (rpc remove_student, file 006): the account loses every right at once and the
     * student's own phone signs out the next time it opens with internet. [done] gets the HTTP code: 200 removed (or not on the server),
     * -1 / 0 = no network, 401 / 403 = this account is not a real admin on the server (the caller then only deletes the local copy).
     */
    fun removeStudent(c: Context, email: String, done: (Int) -> Unit) = bg {
        val code = runCatching {
            Remote.api(c, "POST", "/rest/v1/rpc/remove_student", JSONObject().put("p_email", email).put("p_reason", "").toString()).first
        }.getOrDefault(-1)
        main.post { done(code) }
    }

    /** Release 57: [done] gets the code, or null when refused / no network. */
    fun newCode(c: Context, done: (String?) -> Unit) = bg { val code = newCodeSync(c); main.post { done(code) } }

    /** Release 57: sign-up of an admin account (called by [ServerSync.register]); [done] runs on the main thread. */
    fun registerAdmin(c: Context, code: String, done: (AdminReg?) -> Unit) = bg { val r = registerAdminSync(c, code); main.post { done(r) } }

    fun markSeen(c: Context, done: () -> Unit) = bg {
        Remote.api(c, "POST", "/rest/v1/rpc/mark_events_seen", "{}")
        main.post { done() }
    }

    /** Called by [ServerSync] right after a teacher / admin is signed in on the server. [kind] = "signup" | "signin". Silent. */
    fun entered(c: Context, role: String, kind: String) {
        if (role != "teacher" && role != "admin") return
        val ctx = c.applicationContext
        bg {
            if (role == "admin") registerAdminSync(ctx)   // the first admin ever becomes the main admin here
            logEntrySync(ctx, kind)
        }
    }

    // ------------------------------------------------------------------ removed account

    /**
     * Call from onResume of a teacher / admin screen. Asks the server who this account is: removed -> signed out and its local
     * account wiped; main admin -> alerts are scheduled and any new ones are shown as phone notifications. No internet: nothing happens.
     */
    fun guard(a: Activity) {
        val s = Store.session(a) ?: return
        val role = s.first
        if (role != "teacher" && role != "admin" && role != "student") return   // release 75: a removed student is signed out too
        if (!Remote.enabled || !ServerSync.mirrored(a, s.second)) return
        val ctx = a.applicationContext
        Thread {
            val st = statusSync(ctx) ?: return@Thread
            if (st.removed) { main.post { wipe(a, role, s.second) }; return@Thread }
            val isMain = role == "admin" && st.main
            prefs(ctx).edit().putBoolean("main", isMain).apply()
            if (isMain) {
                main.post { askNotifications(a) }
                schedule(ctx)
                eventsSync(ctx)?.let { notifyNew(ctx, it) }
            }
        }.start()
    }

    private fun wipe(a: Activity, role: String, email: String) {
        if (a.isFinishing) return
        Store.clearSession(a)
        if (role == "teacher") Store.deleteTeacher(a) else if (role == "student") Store.deleteStudent(a, email) else Store.deleteAdmin(a)   // release 75: student
        ServerSync.signOut(a)
        Toast.makeText(a, R.string.acct_removed, Toast.LENGTH_LONG).show()
        a.startActivity(Intent(a, LoginActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        a.finish()
    }

    /** Sign-out / removal: stop the alerts and forget everything about them. */
    fun reset(c: Context) {
        cancel(c)
        prefs(c).edit().remove("main").apply()   // "last_event" stays, so an alert already shown is not shown again after the next sign-in
    }

    // ------------------------------------------------------------------ phone notifications (no Firebase: a periodic job asks the server)

    private const val JOB_ID = 54001
    private const val CHANNEL = "security"

    private fun askNotifications(a: Activity) {
        if (Build.VERSION.SDK_INT < 33) return
        if (a.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return
        if (prefs(a).getBoolean("asked", false)) return
        prefs(a).edit().putBoolean("asked", true).apply()
        a.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 54)
    }

    fun schedule(c: Context) {
        val js = c.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
        if (js.allPendingJobs.any { it.id == JOB_ID }) return
        val job = JobInfo.Builder(JOB_ID, ComponentName(c, AlertJob::class.java))
            .setPeriodic(15 * 60 * 1000L)            // 15 minutes is the shortest period Android allows
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
            .setPersisted(true)
            .build()
        js.schedule(job)
    }

    fun cancel(c: Context) {
        (c.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler).cancel(JOB_ID)
    }

    /** Shows one notification for the alerts that are newer than the last one already shown. */
    fun notifyNew(c: Context, list: List<Event>) {
        val last = prefs(c).getLong("last_event", 0L)
        val fresh = list.filter { it.id > last }
        if (fresh.isEmpty()) return
        if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        prefs(c).edit().putLong("last_event", fresh.maxOf { it.id }).apply()   // only after the permission is there, so nothing is lost
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val lc = Prefs.wrap(c)   // the language chosen inside the app
        nm.createNotificationChannel(NotificationChannel(CHANNEL, lc.getString(R.string.notif_channel), NotificationManager.IMPORTANCE_HIGH))
        val text = if (fresh.size == 1) alertText(lc, fresh[0]) else lc.getString(R.string.notif_many, fresh.size)
        val open = PendingIntent.getActivity(c, 0, Intent(c, SplashActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = android.app.Notification.Builder(c, CHANNEL)
            .setSmallIcon(R.drawable.ic_flask)
            .setContentTitle(lc.getString(R.string.notif_title))
            .setContentText(text)
            .setStyle(android.app.Notification.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(54, n)
    }

    /** "<who> signed in as a teacher" etc. */
    fun alertText(c: Context, e: Event): String {
        val who = e.name.ifEmpty { e.email }
        val id = when {
            e.role == "admin" && e.kind == "signup" -> R.string.alert_signup_admin
            e.role == "admin" -> R.string.alert_signin_admin
            e.kind == "signup" -> R.string.alert_signup_teacher
            else -> R.string.alert_signin_teacher
        }
        return c.getString(id, who)
    }
}

/** Runs about every 15 minutes while the main admin is signed in on this phone (scheduled by [AdminControl.schedule]). */
class AlertJob : JobService() {
    override fun onStartJob(params: JobParameters): Boolean {
        val c = applicationContext
        if (!AdminControl.isMain(c) || !Remote.signedIn(c)) return false
        Thread {
            AdminControl.eventsSync(c)?.let { AdminControl.notifyNew(c, it) }
            jobFinished(params, false)
        }.start()
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean = true
}
