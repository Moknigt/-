package com.moknight.nexoraedu

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout

open class BaseActivity : Activity() {
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Prefs.wrap(newBase))
    }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Sfx.init(this)
        Accents.apply(this)
        val light = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        val d = window.decorView
        d.systemUiVisibility = if (Prefs.dark(this)) d.systemUiVisibility and light.inv()
        else d.systemUiVisibility or light
    }

    /** Screens with their own full-bleed content (video, PDF) turn the glowing background off. */
    protected open val aurora: Boolean get() = true

    override fun setContentView(layoutResID: Int) {
        setContentView(layoutInflater.inflate(layoutResID, null))
    }

    override fun setContentView(view: View) {
        super.setContentView(wrapAurora(view))
    }

    override fun setContentView(view: View, params: ViewGroup.LayoutParams?) {
        super.setContentView(wrapAurora(view))
    }

    private fun wrapAurora(v: View): View {
        if (!aurora) return v
        return FrameLayout(this).apply {
            addView(AuroraView(this@BaseActivity), FrameLayout.LayoutParams(MATCH, MATCH))
            addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
        }
    }

    fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
