package com.moknight.nexoraedu

import android.animation.ObjectAnimator
import android.app.Dialog
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/** Phone verification settings. The OTP screen and everything that depends on it stays hidden while [PhoneOtpEnabled] is false. */
object OtpConfig {
    /** Master switch (release 64: ON). false = [OtpView.show] does nothing and sign-up works exactly as before. Also off while no server is set (Remote.enabled). */
    val PhoneOtpEnabled = true
    const val CODE_LENGTH = 6
    const val RESEND_SECONDS = 60
}

/**
 * The code entry screen (a glass bottom sheet): [OtpConfig.CODE_LENGTH] boxes, a wrong-code state, and a resend link that counts down for real.
 * It does not send or check anything itself: [send] starts a request (the student then writes first on WhatsApp; called once when the sheet opens,
 * and again on "new request"), [openWa] reopens the WhatsApp chat of the current request, [verify] decides
 * if the code is right. Both answer later with an [OtpResult] (they use the network).
 * [show] returns false (and shows nothing) while [OtpConfig.PhoneOtpEnabled] is false or there is no server.
 */
class OtpView(
    private val a: BaseActivity,
    private val phone: String,
    private val send: ((Int) -> Unit) -> Unit,
    private val openWa: () -> Unit,
    private val verify: (String, (Int) -> Unit) -> Unit,
    private val onVerified: () -> Unit,
    private val onCancel: () -> Unit = {}
) {
    private val ticker = Handler(Looper.getMainLooper())
    private var left = OtpConfig.RESEND_SECONDS
    private var verified = false
    private var wrong = false
    private var checking = false
    private lateinit var input: EditText
    private lateinit var boxes: List<TextView>
    private lateinit var boxRow: LinearLayout
    private lateinit var message: TextView
    private lateinit var resend: TextView
    private lateinit var go: TextView

    private val tick = object : Runnable {
        override fun run() {
            if (left > 0) left--
            paintResend()
            if (left > 0) ticker.postDelayed(this, 1000)
        }
    }

    fun show(): Boolean {
        if (!OtpConfig.PhoneOtpEnabled || !Remote.enabled || a.isFinishing) return false
        val d = Dialog(a, R.style.SheetDialog)
        val root = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LOCALE
            setBackgroundResource(R.drawable.sheet_bg)
            setPadding(a.dp(20), a.dp(20), a.dp(20), a.dp(14))
        }
        root.addView(a.label(a.getString(R.string.otp_title), 18f, R.color.tx, true))
        root.addView(a.label(a.getString(R.string.otp_sub, phone), 13f, R.color.mut, false, 4))

        // the digits always run left to right, also in Arabic
        boxRow = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER
            layoutParams = a.lp(top = 22)
        }
        boxes = List(OtpConfig.CODE_LENGTH) {
            TextView(a).apply {
                gravity = Gravity.CENTER
                textSize = 22f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(a.color(R.color.tx))
                layoutParams = LinearLayout.LayoutParams(0, a.dp(54), 1f).apply {
                    if (it > 0) marginStart = a.dp(8)
                }
            }.also { boxRow.addView(it) }
        }
        root.addView(boxRow)

        // one real (invisible) input: it keeps the keyboard, paste and the code in one place; the boxes only show it
        input = EditText(a).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            filters = arrayOf(InputFilter.LengthFilter(OtpConfig.CODE_LENGTH))
            background = null
            alpha = 0f
            isCursorVisible = false
            layoutParams = LinearLayout.LayoutParams(a.dp(1), a.dp(1))
            importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
        }
        root.addView(input)
        boxRow.setOnClickListener { focusInput() }
        boxes.forEach { it.setOnClickListener { focusInput() } }
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, af: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (wrong) { wrong = false; setMessage(null) }
                paintBoxes()
            }
        })

        message = TextView(a).apply {
            textSize = 13f
            gravity = Gravity.CENTER
            visibility = View.GONE
            layoutParams = a.lp(top = 14)
        }
        root.addView(message)

        go = a.primary(a.getString(R.string.otp_verify), 18) { submit() }
        root.addView(go)

        root.addView(a.link(a.getString(R.string.otp_open_wa), 0, 10) { openWa() }.also { it.setTextColor(a.accent()) })

        resend = a.link("", R.color.mut, 4) { if (left == 0) doResend() }
        root.addView(resend)

        walkPress(root)
        d.setContentView(root)
        d.window?.apply {
            setGravity(Gravity.BOTTOM)
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        }
        d.setOnDismissListener {
            ticker.removeCallbacks(tick)
            if (!verified) onCancel()
        }
        blurBehind(d)
        d.show()
        sheetIn(root, a.resources.displayMetrics.density)

        paintBoxes()
        paintResend()
        ticker.postDelayed(tick, 1000)
        input.post { focusInput() }
        dialog = d
        requestCode(first = true)
        return true
    }

    private var dialog: Dialog? = null

    fun dismiss() { dialog?.dismiss() }

    private fun focusInput() {
        input.requestFocus()
        val imm = a.getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager
        imm?.showSoftInput(input, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
    }

    /** Boxes show the typed digits; the next empty box is outlined in the accent colour, all boxes turn red after a wrong code. */
    private fun paintBoxes() {
        val code = input.text.toString()
        boxes.forEachIndexed { i, b ->
            b.text = code.getOrNull(i)?.toString() ?: ""
            val stroke = when {
                wrong -> R.color.err
                i == code.length.coerceAtMost(OtpConfig.CODE_LENGTH - 1) && input.hasFocus() -> 0
                else -> R.color.bd
            }
            b.background = GradientDrawable().apply {
                cornerRadius = a.dp(14).toFloat()
                setColor(a.color(R.color.field))
                setStroke(a.dp(if (stroke == R.color.bd) 1 else 2), if (stroke == 0) a.accent() else a.color(stroke))
            }
        }
        val full = code.length == OtpConfig.CODE_LENGTH
        go.alpha = if (full) 1f else 0.45f
    }

    private fun paintResend() {
        if (left > 0) {
            resend.setText(a.getString(R.string.otp_resend_in, "%02d:%02d".format(left / 60, left % 60)))
            resend.setTextColor(a.color(R.color.mut))
        } else {
            resend.setText(R.string.otp_resend)
            resend.setTextColor(a.accent())
        }
    }

    private fun setMessage(text: String?, error: Boolean = false) {
        message.visibility = if (text == null) View.GONE else View.VISIBLE
        message.text = text ?: ""
        message.setTextColor(a.color(if (error) R.color.err else R.color.mut))
    }

    private fun submit() {
        val code = input.text.toString()
        if (code.length < OtpConfig.CODE_LENGTH || checking) return
        checking = true
        go.alpha = 0.45f
        verify(code) check@{ res ->
            checking = false
            if (dialog?.isShowing != true) return@check
            if (res == OtpResult.OK) {
                verified = true
                Sfx.play(Sfx.S.SUCCESS)
                dialog?.dismiss()
                onVerified()
            } else {
                wrong = res == OtpResult.WRONG
                Sfx.play(Sfx.S.ERROR)
                setMessage(a.getString(when (res) {
                    OtpResult.WRONG -> R.string.otp_err_wrong
                    OtpResult.NET -> R.string.otp_err_net
                    OtpResult.EXPIRED -> R.string.otp_err_expired
                    OtpResult.LOCKED -> R.string.otp_err_locked
                    OtpResult.WAITING -> R.string.otp_err_waiting
                    else -> R.string.otp_err_send
                }), true)
                paintBoxes()
                ObjectAnimator.ofFloat(boxRow, "translationX", 0f, -16f, 16f, -10f, 10f, -5f, 0f).setDuration(360).start()
            }
        }
    }

    /** Asks the server for a code. [first] = the sheet just opened (no "sent again" line, nothing to clear). */
    private fun requestCode(first: Boolean) {
        send ask@{ res ->
            if (dialog?.isShowing != true) return@ask
            when (res) {
                OtpResult.OK -> if (!first) setMessage(a.getString(R.string.otp_sent_again))
                OtpResult.SOON -> setMessage(a.getString(R.string.otp_err_soon), true)
                OtpResult.LIMIT -> setMessage(a.getString(R.string.otp_err_limit), true)
                OtpResult.NET -> { setMessage(a.getString(R.string.otp_err_net), true); left = 0; paintResend() }
                else -> { setMessage(a.getString(R.string.otp_err_send), true); left = 0; paintResend() }   // failed: resend is open at once
            }
        }
    }

    private fun doResend() {
        wrong = false
        input.setText("")
        left = OtpConfig.RESEND_SECONDS
        setMessage(null)
        paintResend()
        ticker.removeCallbacks(tick)
        ticker.postDelayed(tick, 1000)
        paintBoxes()
        requestCode(first = false)
    }
}
