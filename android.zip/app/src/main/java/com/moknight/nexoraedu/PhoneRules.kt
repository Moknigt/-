package com.moknight.nexoraedu

/**
 * Phone number rules used by the sign-up screen (student only).
 * Accepted: Egyptian mobile `01[0125]xxxxxxxx` (also written `+20 1xxxxxxxxx` / `0020 1xxxxxxxxx`) or any international
 * number `+` followed by 8 to 15 digits. Arabic-Indic digits, spaces, dashes, dots and brackets are fine.
 * Same rules, same names on iPhone (`PhoneRules.swift`) and Windows (`PhoneRules.cs`).
 */
object PhoneRules {
    private val egLocal = Regex("^01[0125][0-9]{8}$")
    private val intl = Regex("^\\+[1-9][0-9]{7,14}$")

    /** Digits turned to 0-9, separators removed, `00` -> `+`, Egyptian `+20` -> `0`. */
    fun clean(raw: String): String {
        val sb = StringBuilder()
        for (ch in raw.trim()) {
            when (ch) {
                in '٠'..'٩' -> sb.append('0' + (ch - '٠'))
                in '۰'..'۹' -> sb.append('0' + (ch - '۰'))
                in '0'..'9', '+' -> sb.append(ch)
                else -> {} // spaces, - . ( ) and anything else are dropped
            }
        }
        var s = sb.toString()
        if (s.startsWith("00")) s = "+" + s.substring(2)
        if (s.startsWith("+201") && s.length == 13) s = "0" + s.substring(3)
        return s
    }

    /** The number to store, or null when it is not valid. */
    fun normalize(raw: String): String? {
        val s = clean(raw)
        return if (egLocal.matches(s) || intl.matches(s)) s else null
    }

    /** String resource of the message to show under the field, or null when the number is fine. */
    fun error(raw: String): Int? = when {
        raw.isBlank() -> R.string.err_phone_required
        normalize(raw) == null -> R.string.err_phone_invalid
        else -> null
    }
}

/** Answers of [PhoneVerifier] (and what [OtpView] shows for each). */
object OtpResult {
    const val OK = 0
    const val WRONG = 1
    const val NET = 2
    const val EXPIRED = 3
    const val LOCKED = 4
    const val SOON = 5
    const val LIMIT = 6
    const val FAIL = 7      // the server is not set up / server error
    const val WAITING = 8   // the student's WhatsApp message has not arrived yet
}

/**
 * Release 64: the phone check through WhatsApp, the STUDENT writes first (free). [send] asks the server for a short reference and opens WhatsApp with
 * a ready message that contains it; the server (wa-webhook) checks that the SENDER number is the typed number and answers with the 6-digit code in
 * the same chat; [check] sends the typed code to the server. The app never sees the right code. See server/supabase/OTP_SETUP.md.
 * After a right code the server gives a one-time token that [Remote.signUp] sends with the account. Every callback runs on the main thread.
 */
object PhoneVerifier {
    private val main = android.os.Handler(android.os.Looper.getMainLooper())
    private var tokenPhone = ""
    private var token = ""
    private var waNumber = ""
    private var waRef = ""

    /** The token earned for exactly this phone, or "". */
    fun tokenFor(phone: String): String = if (phone.isNotEmpty() && phone == tokenPhone) token else ""

    fun clear() { tokenPhone = ""; token = ""; waNumber = ""; waRef = "" }

    private fun reason(r: String) = when (r) {
        "wrong" -> OtpResult.WRONG
        "expired" -> OtpResult.EXPIRED
        "locked" -> OtpResult.LOCKED
        "too_soon" -> OtpResult.SOON
        "limit" -> OtpResult.LIMIT
        "waiting" -> OtpResult.WAITING
        else -> OtpResult.FAIL
    }

    /** Opens WhatsApp with the ready message of the LAST [send] (nothing happens before one succeeded). */
    fun openWhatsApp(c: android.content.Context) {
        if (waNumber.isEmpty() || waRef.isEmpty()) return
        val text = c.getString(R.string.otp_wa_message, waRef)
        val uri = android.net.Uri.parse("https://wa.me/" + waNumber + "?text=" + android.net.Uri.encode(text))
        try { c.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, uri).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
    }

    /** New request for [phone]: on OK WhatsApp is opened at once with the ready message. */
    fun send(c: android.content.Context, phone: String, done: (Int) -> Unit) {
        Thread {
            val r = Remote.fn("otp-start", org.json.JSONObject().put("phone", phone))
            var res = OtpResult.FAIL
            if (r.first == -1) res = OtpResult.NET
            else runCatching {
                val o = org.json.JSONObject(r.second)
                if (r.first == 200 && o.optBoolean("ok")) { waRef = o.optString("ref"); waNumber = o.optString("wa"); res = OtpResult.OK }
                else res = reason(o.optString("error"))
            }
            main.post { if (res == OtpResult.OK) openWhatsApp(c); done(res) }
        }.start()
    }

    /** Checks the typed [code]. OK also stores the token for [tokenFor]. */
    fun check(phone: String, code: String, done: (Int) -> Unit) {
        Thread {
            val r = Remote.fn("otp-verify", org.json.JSONObject().put("phone", phone).put("code", code))
            var res = OtpResult.FAIL
            if (r.first == -1) res = OtpResult.NET
            else if (r.first == 200) runCatching {
                val o = org.json.JSONObject(r.second)
                if (o.optBoolean("ok")) { tokenPhone = phone; token = o.optString("token"); res = OtpResult.OK }
                else res = reason(o.optString("reason"))
            }
            main.post { done(res) }
        }.start()
    }
}
