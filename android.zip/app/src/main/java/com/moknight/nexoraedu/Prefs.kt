package com.moknight.nexoraedu

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

/** App-level settings: language and theme. Applied to every Activity through [wrap]. */
object Prefs {
    private const val FILE = "nexora_settings"

    fun ar(c: Context): Boolean = c.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean("ar", true)
    fun dark(c: Context): Boolean = c.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean("dark", true)
    fun setAr(c: Context, v: Boolean) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean("ar", v).apply()
    fun setDark(c: Context, v: Boolean) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean("dark", v).apply()

    fun accent(c: Context): String = c.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString("accent", Accents.DEFAULT) ?: Accents.DEFAULT
    fun setAccent(c: Context, v: String) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString("accent", v).apply()

    fun wrap(base: Context): Context {
        val loc = Locale(if (ar(base)) "ar" else "en")
        Locale.setDefault(loc)
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(loc)
        cfg.setLayoutDirection(loc) // Arabic = right-to-left, English = left-to-right
        val night = if (dark(base)) Configuration.UI_MODE_NIGHT_YES else Configuration.UI_MODE_NIGHT_NO
        cfg.uiMode = (cfg.uiMode and Configuration.UI_MODE_NIGHT_MASK.inv()) or night
        return base.createConfigurationContext(cfg)
    }
}
