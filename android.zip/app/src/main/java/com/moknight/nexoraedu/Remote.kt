package com.moknight.nexoraedu

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Release 37, step 1 of 3: talks to Supabase (see server/supabase/001_accounts.sql and SERVER_SPEC.md).
 * NOT wired to any screen yet: today [Access.canView] still decides locally. Every callback runs on the main thread.
 * Fill the two constants below with the values from Supabase -> Project Settings -> API (the anon key is public by design).
 * Empty = no server, [enabled] is false and nothing here is called.
 */
object Remote {
    /** e.g. https://abcd1234.supabase.co (no trailing slash) */
    const val BASE_URL = "https://xgwfxzbutkkauxilcpzf.supabase.co"
    const val ANON_KEY = "sb_publishable_WTL6TvHBsZblJoqt8Xjbjg_vNZVLD5f"
    val enabled: Boolean get() = BASE_URL.isNotEmpty() && ANON_KEY.isNotEmpty()

    class AccessResult(val allowed: Boolean, val reason: String, val price: Int)
    /** [src] = "yt" or "up". For "up" the file is at [storageId]/[storageKey] (step 3). */
    class Source(val src: String, val ytId: String, val storageId: String?, val storageKey: String?)

    private val main = Handler(Looper.getMainLooper())
    private fun prefs(c: Context) = c.getSharedPreferences("remote", Context.MODE_PRIVATE)
    fun signedIn(c: Context) = prefs(c).getString("jwt", "").orEmpty().isNotEmpty()
    fun userId(c: Context) = prefs(c).getString("uid", "").orEmpty()
    fun signOut(c: Context) { prefs(c).edit().clear().apply() }

    private fun http(method: String, path: String, body: String?, token: String?, extra: Map<String, String> = emptyMap()): Pair<Int, String> =
        try {
            val cn = URL(BASE_URL + path).openConnection() as HttpURLConnection
            if (method == "PATCH") patchMethod(cn) else cn.requestMethod = method
            cn.connectTimeout = 8000; cn.readTimeout = 8000
            cn.setRequestProperty("apikey", ANON_KEY)
            cn.setRequestProperty("Authorization", "Bearer " + (token ?: ANON_KEY))
            cn.setRequestProperty("Content-Type", "application/json")
            extra.forEach { (k, v) -> cn.setRequestProperty(k, v) }
            if (body != null) { cn.doOutput = true; cn.outputStream.use { it.write(body.toByteArray()) } }
            val code = cn.responseCode
            val text = (if (code in 200..299) cn.inputStream else cn.errorStream)?.bufferedReader()?.readText().orEmpty()
            Pair(code, text)
        } catch (e: Exception) { Pair(-1, "") }

    /** Release 64: calls an Edge Function without a user token (the phone code is asked BEFORE the account exists). Runs on the calling (background) thread. */
    internal fun fn(name: String, body: JSONObject): Pair<Int, String> = http("POST", "/functions/v1/$name", body.toString(), null)

    private fun saveSession(c: Context, o: JSONObject) {
        prefs(c).edit().putString("jwt", o.optString("access_token")).putString("rt", o.optString("refresh_token"))
            .putString("uid", o.optJSONObject("user")?.optString("id").orEmpty()).apply()
    }

    private fun refresh(c: Context): Boolean {
        val rt = prefs(c).getString("rt", "").orEmpty()
        if (rt.isEmpty()) return false
        val r = http("POST", "/auth/v1/token?grant_type=refresh_token", JSONObject().put("refresh_token", rt).toString(), null)
        if (r.first != 200) return false
        saveSession(c, JSONObject(r.second)); return true
    }

    /** Signed-in call; tries once to refresh an expired token. */
    internal fun api(c: Context, method: String, path: String, body: String?, extra: Map<String, String> = emptyMap()): Pair<Int, String> {
        var r = http(method, path, body, prefs(c).getString("jwt", ""), extra)
        if (r.first == 401 && refresh(c)) r = http(method, path, body, prefs(c).getString("jwt", ""), extra)
        return r
    }

    private fun bg(work: () -> Unit) { Thread { work() }.start() }

    /** Student / teacher sign-in. true = signed in. */
    fun signIn(c: Context, email: String, password: String, done: (Boolean) -> Unit) = bg {
        val r = http("POST", "/auth/v1/token?grant_type=password", JSONObject().put("email", email).put("password", password).toString(), null)
        val ok = r.first == 200
        if (ok) saveSession(c, JSONObject(r.second))
        main.post { done(ok) }
    }

    /** New STUDENT account. The role is always "student" on the server. true = created (turn OFF "Confirm email" in Supabase, or students must confirm first). */
    fun signUp(c: Context, email: String, password: String, name: String, phone: String, grade: String, done: (Boolean) -> Unit) = bg {
        val data = JSONObject().put("full_name", name).put("phone", phone).put("grade", grade)
        PhoneVerifier.tokenFor(phone).takeIf { it.isNotEmpty() }?.let { data.put("phone_token", it) }   // release 64: proof that this phone got the WhatsApp code
        val r = http("POST", "/auth/v1/signup", JSONObject().put("email", email).put("password", password).put("data", data).toString(), null)
        val ok = r.first == 200
        if (ok) { val o = JSONObject(r.second); if (o.has("access_token")) saveSession(c, o) }
        main.post { done(ok) }
    }

    /** Turns the signed-in account into a teacher with a registration code (works once, on any device). */
    fun claimTeacher(c: Context, code: String, done: (Boolean) -> Unit) = bg {
        val r = api(c, "POST", "/rest/v1/rpc/claim_teacher", JSONObject().put("p_code", code).toString())
        val ok = r.first == 200 && r.second.trim() == "true"
        main.post { done(ok) }
    }

    /** Server decision for one lesson (uuid). null = network error: show retry, never open. */
    fun access(c: Context, lessonId: String, done: (AccessResult?) -> Unit) = bg {
        val r = api(c, "POST", "/rest/v1/rpc/access_lesson", JSONObject().put("p_lesson", lessonId).toString())
        val res = if (r.first == 200) JSONObject(r.second).let { AccessResult(it.optBoolean("allowed"), it.optString("reason"), it.optInt("price")) } else null
        main.post { done(res) }
    }

    /** The ONLY way the player gets the video source. null = locked or network error. */
    fun playSource(c: Context, lessonId: String, done: (Source?) -> Unit) = bg {
        val r = api(c, "POST", "/rest/v1/rpc/play_source", JSONObject().put("p_lesson", lessonId).toString())
        val res = if (r.first == 200) JSONObject(r.second).let {
            Source(it.optString("src"), it.optString("ytId"), it.optString("storageId").takeIf { s -> s.isNotEmpty() && s != "null" }, it.optString("storageKey").takeIf { s -> s.isNotEmpty() && s != "null" })
        } else null
        main.post { done(res) }
    }

    /** Teacher: open for a student (cash / free). [student] = profile uuid, [target] = "l:<lesson uuid>" or "c:<chapter uuid>". */
    fun grant(c: Context, student: String, target: String, mode: String, done: (Boolean) -> Unit) = bg {
        val body = JSONObject().put("p_student", student).put("p_type", if (target.startsWith("c:")) "chapter" else "lesson")
            .put("p_target", target.substring(2)).put("p_mode", mode).toString()
        val r = api(c, "POST", "/rest/v1/rpc/teacher_grant", body)
        main.post { done(r.first == 200) }
    }

    /** Teacher: close a grant (the log line stays). */
    fun revoke(c: Context, grantId: String, done: (Boolean) -> Unit) = bg {
        val r = api(c, "POST", "/rest/v1/rpc/teacher_revoke", JSONObject().put("p_grant", grantId).toString())
        main.post { done(r.first == 200 && r.second.trim() == "true") }
    }

    /** Teacher: delete a video (the server refuses anyone else; 0 rows = refused). */
    fun deleteVideo(c: Context, lessonId: String, done: (Boolean) -> Unit) = bg {
        val r = api(c, "DELETE", "/rest/v1/lessons?id=eq.$lessonId", null, mapOf("Prefer" to "return=representation"))
        val ok = r.first in 200..299 && runCatching { JSONArray(r.second).length() > 0 }.getOrDefault(false)
        main.post { done(ok) }
    }

    // ------------------------------------------------------------------ Release 42, step 3 part 3: storages (upload, play link, storage list)
    // The app knows NO R2 key, endpoint, bucket or size cap. The server decides and answers with a reason.

    /** HttpURLConnection refuses "PATCH"; this sets it anyway (also on the https delegate). */
    private fun patchMethod(cn: HttpURLConnection) {
        try { cn.requestMethod = "PATCH" } catch (e: java.net.ProtocolException) {
            val f = HttpURLConnection::class.java.getDeclaredField("method"); f.isAccessible = true; f.set(cn, "PATCH")
            try {
                val d = cn.javaClass.getDeclaredField("delegate"); d.isAccessible = true
                (d.get(cn) as? HttpURLConnection)?.let { f.set(it, "PATCH") }
            } catch (_: Exception) {}
        }
    }

    /** Why an upload did not finish; each one has its own ar + en message. */
    enum class UploadError(val msg: Int) {
        FULL(R.string.up_err_full), OFF(R.string.up_err_off), TOO_BIG(R.string.up_err_big), FAILED(R.string.up_err_fail)
    }

    sealed class UploadResult {
        class Ok(val sizeBytes: Long) : UploadResult()
        object Cancelled : UploadResult()
        class Fail(val error: UploadError) : UploadResult()
    }

    /** Keep it to be able to cancel; the worker thread then stops the transfer and frees the reserved space on the server. */
    class UploadHandle {
        @Volatile var cancelled = false
        @Volatile internal var conn: HttpURLConnection? = null
        fun cancel() { cancelled = true; try { conn?.disconnect() } catch (_: Exception) {} }
    }

    private fun reasonOf(text: String): String = runCatching { JSONObject(text).optString("error") }.getOrDefault("")

    private fun uploadError(r: String) = when (r) {
        "full" -> UploadError.FULL
        "not_allowed", "storage_not_configured" -> UploadError.OFF
        "bad_size", "too_large" -> UploadError.TOO_BIG
        else -> UploadError.FAILED
    }

    private fun cancelReservation(c: Context, id: String) {
        api(c, "POST", "/functions/v1/upload-complete", JSONObject().put("reservationId", id).put("cancel", true).toString())
    }

    /** PUT of the whole file to the presigned link; the length is fixed to the reserved size. */
    private fun putFile(h: UploadHandle, link: String, file: java.io.File, size: Long, progress: (Int) -> Unit): Boolean = try {
        val cn = URL(link).openConnection() as HttpURLConnection
        h.conn = cn
        cn.requestMethod = "PUT"; cn.doOutput = true
        cn.setFixedLengthStreamingMode(size)
        cn.connectTimeout = 15000; cn.readTimeout = 600000
        cn.outputStream.use { out ->
            file.inputStream().use { inp ->
                val buf = ByteArray(64 * 1024)
                var sent = 0L
                var last = -1
                while (true) {
                    if (h.cancelled) throw java.io.IOException("cancelled")
                    val n = inp.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n); sent += n
                    val p = (sent * 100 / size).toInt()
                    if (p != last) { last = p; main.post { progress(p) } }
                }
            }
        }
        val code = cn.responseCode
        cn.disconnect()
        code in 200..299
    } catch (e: Exception) { false }

    private fun runUpload(c: Context, h: UploadHandle, lessonId: String, file: java.io.File, progress: (Int) -> Unit): UploadResult {
        val size = file.length()
        if (size <= 0) return UploadResult.Fail(UploadError.FAILED)
        val body = JSONObject().put("lessonId", lessonId).put("sizeBytes", size)
        val ext = file.extension.lowercase()
        if (ext.isNotEmpty()) body.put("ext", ext)
        val r = api(c, "POST", "/functions/v1/upload-url", body.toString())
        if (r.first != 200) return UploadResult.Fail(uploadError(reasonOf(r.second)))
        val o = runCatching { JSONObject(r.second) }.getOrNull() ?: return UploadResult.Fail(UploadError.FAILED)
        val rid = o.optString("reservationId"); val link = o.optString("uploadUrl")
        if (rid.isEmpty() || link.isEmpty()) return UploadResult.Fail(UploadError.FAILED)
        if (h.cancelled) { cancelReservation(c, rid); return UploadResult.Cancelled }
        val ok = putFile(h, link, file, size, progress)
        if (h.cancelled) { cancelReservation(c, rid); return UploadResult.Cancelled }
        if (!ok) { cancelReservation(c, rid); return UploadResult.Fail(UploadError.FAILED) }
        var tries = 3
        while (true) {   // the file is already in the bucket: a network problem or 502 is retried
            val q = api(c, "POST", "/functions/v1/upload-complete", JSONObject().put("reservationId", rid).toString())
            val j = if (q.first == 200) runCatching { JSONObject(q.second) }.getOrNull() else null
            if (j != null && j.optBoolean("ok")) return UploadResult.Ok(j.optLong("sizeBytes"))
            if ((q.first == -1 || q.first == 502) && tries > 1) { tries--; Thread.sleep(2000); continue }
            return UploadResult.Fail(uploadError(reasonOf(q.second)))
        }
    }

    /** upload-url (the server reserves the exact size) -> PUT the file -> upload-complete (the server checks the real size). [progress] 0..100; callbacks on the main thread. */
    fun uploadVideo(c: Context, lessonId: String, file: java.io.File, progress: (Int) -> Unit, done: (UploadResult) -> Unit): UploadHandle {
        val h = UploadHandle()
        bg {
            val res = try { runUpload(c, h, lessonId, file, progress) } catch (e: Exception) { UploadResult.Fail(UploadError.FAILED) }
            main.post { done(res) }
        }
        return h
    }

    // ---- play link

    class PlayLink(val src: String, val url: String, val ytId: String, val expiresIn: Int)
    enum class PlayProblem(val msg: Int) { LOCKED(R.string.pl_err_locked), NO_FILE(R.string.pl_err_nofile), FAILED(R.string.pl_err_fail) }
    /** Exactly one of [link] / [problem] is set. */
    class PlayResult(val link: PlayLink?, val problem: PlayProblem?)

    /** The ONLY way to get a playable address: "up" gives a temporary link (about 3 h, ask again when it ends), "yt" gives the YouTube id. */
    fun playUrl(c: Context, lessonId: String, done: (PlayResult) -> Unit) = bg {
        val r = api(c, "POST", "/functions/v1/play-url", JSONObject().put("lessonId", lessonId).toString())
        val res = when (r.first) {
            200 -> runCatching { JSONObject(r.second) }.getOrNull()?.let {
                PlayResult(PlayLink(it.optString("src"), it.optString("url"), it.optString("ytId"), it.optInt("expiresIn")), null)
            } ?: PlayResult(null, PlayProblem.FAILED)
            403 -> PlayResult(null, PlayProblem.LOCKED)
            404 -> PlayResult(null, PlayProblem.NO_FILE)
            else -> PlayResult(null, PlayProblem.FAILED)
        }
        main.post { done(res) }
    }

    // ---- storage list (read only; the admin edits name / limit / on-off / order)

    class StorageInfo(val id: String, val name: String, val limitBytes: Long, val usedBytes: Long, val reservedBytes: Long, val active: Boolean, val sortOrder: Int) {
        /** (used + reserved) / limit, 0..1 for the bar. */
        val fraction: Double get() = if (limitBytes > 0) minOf(1.0, (usedBytes + reservedBytes).toDouble() / limitBytes) else 0.0
    }

    /** null = network error / not allowed. Teacher and admin only (the server decides). */
    fun storages(c: Context, done: (List<StorageInfo>?) -> Unit) = bg {
        val r = api(c, "GET", "/rest/v1/storages?select=id,name,limit_bytes,used_bytes,reserved_bytes,active,sort_order&order=sort_order", null)
        val list = if (r.first == 200) runCatching {
            val a = JSONArray(r.second)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                StorageInfo(o.optString("id"), o.optString("name"), o.optLong("limit_bytes"), o.optLong("used_bytes"),
                    o.optLong("reserved_bytes"), o.optBoolean("active"), o.optInt("sort_order"))
            }
        }.getOrNull() else null
        main.post { done(list) }
    }

    /** Admin only. The server refuses a limit above its own cap (false); the app never knows that number. */
    fun updateStorage(c: Context, s: StorageInfo, done: (Boolean) -> Unit) = bg {
        val body = JSONObject().put("name", s.name).put("limit_bytes", s.limitBytes).put("active", s.active).put("sort_order", s.sortOrder).toString()
        val r = api(c, "PATCH", "/rest/v1/storages?id=eq." + s.id, body, mapOf("Prefer" to "return=representation"))
        val ok = r.first in 200..299 && runCatching { JSONArray(r.second).length() > 0 }.getOrDefault(false)
        main.post { done(ok) }
    }
}

/**
 * Electronic payment (Paymob), release 38 = step 2 of 3. NOT wired to any screen yet; [Payments.start] still returns false.
 * Flow: [createOrder] (the SERVER decides the price) -> [open] the Paymob page in the browser -> [pollStatus] until "paid"
 * -> ask [Remote.access] again and open the content. Paying itself is never trusted from the screen: only the server webhook marks an order paid.
 * createOrder gives null when it fails or when the content is already open (then just call [Remote.access]).
 * Callbacks run on the main thread. Status values: pending, paid, failed, refunded, mismatch, missing.
 */
object PaymentFlow {
    class Order(val id: String, val amount: Int, val checkoutUrl: String)
    private val main = Handler(Looper.getMainLooper())

    /** [target] = "l:<lesson uuid>" or "c:<chapter uuid>". */
    fun createOrder(c: Context, target: String, done: (Order?) -> Unit) {
        Thread {
            val body = JSONObject().put("target_type", if (target.startsWith("c:")) "chapter" else "lesson").put("target_id", target.substring(2)).toString()
            val r = Remote.api(c, "POST", "/functions/v1/create-order", body)
            val o = if (r.first == 200) JSONObject(r.second).let { Order(it.optString("orderId"), it.optInt("amount"), it.optString("checkoutUrl")) } else null
            main.post { done(o) }
        }.start()
    }

    /** Opens the Paymob checkout page in the browser. No card data is ever typed inside the app. */
    fun open(c: Context, o: Order) {
        c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(o.checkoutUrl)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** One check (also call it when the app comes back to the foreground). */
    fun statusOnce(c: Context, orderId: String, done: (String) -> Unit) {
        Thread {
            val r = Remote.api(c, "POST", "/rest/v1/rpc/order_status", JSONObject().put("p_order", orderId).toString())
            val st = if (r.first == 200) r.second.trim().trim('"') else "pending"
            main.post { done(st) }
        }.start()
    }

    /** Checks every 3 s (up to about 10 minutes) until the status is not "pending"; gives "pending" if time ran out. */
    fun pollStatus(c: Context, orderId: String, done: (String) -> Unit) {
        Thread {
            var st = "pending"
            var n = 0
            while (n < 200 && st == "pending") {
                val r = Remote.api(c, "POST", "/rest/v1/rpc/order_status", JSONObject().put("p_order", orderId).toString())
                if (r.first == 200) st = r.second.trim().trim('"')
                if (st == "pending") { Thread.sleep(3000); n++ }
            }
            main.post { done(st) }
        }.start()
    }
}
