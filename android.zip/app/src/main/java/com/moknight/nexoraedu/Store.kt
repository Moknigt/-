package com.moknight.nexoraedu

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.UUID

data class Student(
    var name: String,
    var phone: String,
    var email: String,
    var pw: String,
    var grade: String,
    var code: String = "",
    var active: Boolean = false
)

/** Local data store (SharedPreferences + JSON). Passwords are stored as SHA-256 hashes. */
object Store {
    private fun sp(c: Context) = c.getSharedPreferences("nexora_data", Context.MODE_PRIVATE)

    fun hash(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

    // ---- classes ----
    private val defaultGrades = listOf("الصف الأول الثانوي", "الصف الثاني الثانوي", "الصف الثالث الثانوي")

    /** The three fixed classes a student can pick when signing up (stored values; the labels shown come from strings). */
    val FIXED_GRADES: List<String> get() = defaultGrades

    fun grades(c: Context): MutableList<String> {
        val s = sp(c).getString("grades", null) ?: return defaultGrades.toMutableList()
        val a = JSONArray(s)
        return MutableList(a.length()) { a.getString(it) }
    }

    fun saveGrades(c: Context, g: List<String>) {
        sp(c).edit().putString("grades", JSONArray(g).toString()).apply()
    }

    // ---- students ----
    fun students(c: Context): MutableList<Student> {
        val s = sp(c).getString("students", null) ?: return mutableListOf()
        val a = JSONArray(s)
        return MutableList(a.length()) {
            val o = a.getJSONObject(it)
            Student(
                o.optString("n"), o.optString("p"), o.optString("e"), o.optString("pw"),
                o.optString("g"), o.optString("c"), o.optBoolean("act")
            )
        }
    }

    fun saveStudents(c: Context, list: List<Student>) {
        stuKey = null // release 65: the cached class of the signed-in student may have changed
        val a = JSONArray()
        list.forEach {
            a.put(
                JSONObject().put("n", it.name).put("p", it.phone).put("e", it.email)
                    .put("pw", it.pw).put("g", it.grade).put("c", it.code).put("act", it.active)
            )
        }
        sp(c).edit().putString("students", a.toString()).apply()
    }

    fun findStudent(c: Context, email: String): Student? = students(c).firstOrNull { it.email == email }

    // ---- teacher account (email, password hash) ----
    fun teacher(c: Context): Pair<String, String>? {
        val e = sp(c).getString("t_email", null) ?: return null
        val p = sp(c).getString("t_pw", null) ?: return null
        return e to p
    }

    fun setTeacher(c: Context, email: String, password: String, phone: String = "", name: String = "") {
        val e = sp(c).edit().putString("t_email", email).putString("t_pw", hash(password))
        if (phone.isNotEmpty()) e.putString("t_phone", phone) else e.remove("t_phone")
        if (name.isNotEmpty()) e.putString("t_name", name) else e.remove("t_name")
        e.apply()
    }

    /** The teacher's full name (entered at sign-up); empty when the account has none. */
    fun teacherName(c: Context): String = sp(c).getString("t_name", "")?.trim() ?: ""

    fun deleteTeacher(c: Context) {
        sp(c).edit().remove("t_email").remove("t_pw").remove("t_phone").remove("t_name").apply()
    }

    // ---- admin account (own keys, separate from the teacher) ----
    fun admin(c: Context): Pair<String, String>? {
        val e = sp(c).getString("a_email", null) ?: return null
        val p = sp(c).getString("a_pw", null) ?: return null
        return e to p
    }

    fun setAdmin(c: Context, email: String, password: String) {
        sp(c).edit().putString("a_email", email).putString("a_pw", hash(password)).apply()
    }

    /** Release 54: the admin was removed on the server; the local admin account goes too. */
    fun deleteAdmin(c: Context) {
        sp(c).edit().remove("a_email").remove("a_pw").apply()
    }

    // ---- session ----
    fun session(c: Context): Pair<String, String>? {
        val r = sp(c).getString("s_role", null) ?: return null
        val e = sp(c).getString("s_email", null) ?: return null
        return r to e
    }

    fun setSession(c: Context, role: String, email: String) {
        sp(c).edit().putString("s_role", role).putString("s_email", email).apply()
    }

    fun clearSession(c: Context) {
        sp(c).edit().remove("s_role").remove("s_email").apply()
    }

    fun setStudentActive(c: Context, email: String, on: Boolean) {
        saveStudents(c, students(c).onEach { if (it.email == email) it.active = on })
    }

    /** Makes a new 10-character code (no look-alikes: no O/0, I/1) that no other student has, saves it and returns it. */
    fun newStudentCode(c: Context, email: String): String {
        val all = students(c)
        val used = all.map { it.code }.toSet()
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        var code: String
        do {
            code = String(CharArray(10) { chars[java.security.SecureRandom().nextInt(chars.length)] })
        } while (code in used)
        all.forEach { if (it.email == email) it.code = code }
        saveStudents(c, all)
        return code
    }

    fun deleteStudent(c: Context, email: String) {
        saveStudents(c, students(c).filter { it.email != email })
        saveResults(c, results(c).filter { it.email != email })
        val subs = submissions(c)
        subs.filter { it.email == email && it.photo.isNotEmpty() }.forEach { photoFile(c, it.photo).delete() }
        saveSubmissions(c, subs.filter { it.email != email })
        avatarFile(c, email).delete()
        draftPhoto(c, email).delete()
        sp(c).edit().remove("fav:$email").remove("notes:$email").remove("hist:$email").apply()
    }

    // ---- small JSON helpers ----
    fun newId(): String = UUID.randomUUID().toString().replace("-", "").take(12)

    private fun <T> load(c: Context, key: String, f: (JSONObject) -> T): MutableList<T> {
        val s = sp(c).getString(key, null) ?: return mutableListOf()
        val a = JSONArray(s)
        return MutableList(a.length()) { f(a.getJSONObject(it)) }
    }

    private fun <T> save(c: Context, key: String, l: List<T>, f: (T) -> JSONObject) {
        val a = JSONArray()
        l.forEach { a.put(f(it)) }
        sp(c).edit().putString(key, a.toString()).apply()
    }

    private fun strings(a: JSONArray?): List<String> = if (a == null) emptyList() else List(a.length()) { a.getString(it) }

    // ---- release 65: classes. Every piece of content belongs to one class (Store.FIXED_GRADES). ----
    // A student only ever reads his own class (plus old items that belong to "" = every class).
    // The teacher reads one class while [teacherGrade] is set (the class screen), or everything when it is null.
    // All the old functions below (chapters(), saveLessons() ...) keep their signature: they filter / merge by themselves.

    /** Teacher / admin only: the class opened on the teacher's class screen. null = no filter. */
    @Volatile var teacherGrade: String? = null

    private var stuKey: String? = null
    private var stuGrade: String = ""

    /** The class of the signed-in student (cached until the students list is saved again). */
    private fun studentGradeOf(c: Context, email: String): String {
        if (stuKey != email) { stuGrade = findStudent(c, email)?.grade.orEmpty(); stuKey = email }
        return stuGrade
    }

    /** What the current session may see: null = everything, otherwise a test for one item's class. */
    private fun visibleTest(c: Context): ((String) -> Boolean)? {
        val s = session(c)
        if (s?.first == "student") {
            val g = studentGradeOf(c, s.second)
            return { it.isEmpty() || it == g }
        }
        val t = teacherGrade ?: return null
        return { it == t }
    }

    private class Kind<T>(
        val key: String, val rd: (JSONObject) -> T, val wr: (T) -> JSONObject,
        val gradeOf: (T) -> String, val setGrade: (T, String) -> Unit
    )

    private val kChapter = Kind<Chapter>("chapters",
        { Chapter(it.optString("i"), it.optString("t"), it.optInt("pr", 0), it.optString("gr")) },
        { JSONObject().put("i", it.id).put("t", it.title).put("pr", it.price).put("gr", it.grade) },
        { it.grade }, { x, g -> x.grade = g })

    private val kLesson = Kind<Lesson>("lessons",
        { Lesson(it.optString("i"), it.optString("c"), it.optString("t"), it.optString("y"), it.optLong("a"), it.optBoolean("p", true),
            it.optString("s", "yt"), it.optInt("pr", 0), it.optString("th"), it.optString("gr")) },
        { JSONObject().put("i", it.id).put("c", it.chapterId).put("t", it.title).put("y", it.yt).put("a", it.at).put("p", it.published)
            .put("s", it.src).put("pr", it.price).put("th", it.thumb).put("gr", it.grade) },
        { it.grade }, { x, g -> x.grade = g })

    private val kDoc = Kind<Doc>("docs",
        { Doc(it.optString("i"), it.optString("t"), it.optString("k"), it.optLong("a"), it.optString("gr")) },
        { JSONObject().put("i", it.id).put("t", it.title).put("k", it.kind).put("a", it.at).put("gr", it.grade) },
        { it.grade }, { x, g -> x.grade = g })

    private val kQuestion = Kind<Question>("questions",
        { Question(it.optString("i"), it.optString("t"), it.optString("c"), strings(it.optJSONArray("o")), it.optInt("a"), it.optString("gr")) },
        { JSONObject().put("i", it.id).put("t", it.text).put("c", it.chapter).put("o", JSONArray(it.options)).put("a", it.answer).put("gr", it.grade) },
        { it.grade }, { x, g -> x.grade = g })

    private val kExam = Kind<Exam>("exams",
        { Exam(it.optString("i"), it.optString("t"), it.optBoolean("o"), strings(it.optJSONArray("q")), it.optLong("a"), it.optString("gr")) },
        { JSONObject().put("i", it.id).put("t", it.title).put("o", it.official).put("q", JSONArray(it.qids)).put("a", it.at).put("gr", it.grade) },
        { it.grade }, { x, g -> x.grade = g })

    private val kHomework = Kind<Homework>("homework",
        { Homework(it.optString("i"), it.optString("t"), it.optString("n"), it.optLong("a"), it.optString("gr")) },
        { JSONObject().put("i", it.id).put("t", it.title).put("n", it.note).put("a", it.at).put("gr", it.grade) },
        { it.grade }, { x, g -> x.grade = g })

    private val kAnn = Kind<Announcement>("ann",
        { Announcement(it.optString("i"), it.optString("t"), it.optString("x"), it.optLong("a"), it.optString("gr")) },
        { JSONObject().put("i", it.id).put("t", it.title).put("x", it.text).put("a", it.at).put("gr", it.grade) },
        { it.grade }, { x, g -> x.grade = g })

    /** Once: content made before release 65 has no class; it goes to the first class so the teacher can manage it. */
    private fun migrateGrades(c: Context) {
        if (sp(c).getBoolean("gr_done", false)) return
        val first = defaultGrades[0]
        fun <T> stamp(k: Kind<T>) {
            val l = load(c, k.key, k.rd)
            if (l.isEmpty()) return
            l.forEach { if (k.gradeOf(it).isEmpty()) k.setGrade(it, first) }
            save(c, k.key, l, k.wr)
        }
        stamp(kChapter); stamp(kLesson); stamp(kDoc); stamp(kQuestion); stamp(kExam); stamp(kHomework); stamp(kAnn)
        sp(c).edit().putBoolean("gr_done", true).apply()
    }

    private fun <T> loadK(c: Context, k: Kind<T>): MutableList<T> {
        migrateGrades(c)
        val all = load(c, k.key, k.rd)
        val vis = visibleTest(c) ?: return all
        return all.filter { vis(k.gradeOf(it)) }.toMutableList()
    }

    private fun <T> saveK(c: Context, k: Kind<T>, l: List<T>) {
        migrateGrades(c)
        val vis = visibleTest(c)
        if (vis == null) return save(c, k.key, l, k.wr)
        val t = teacherGrade
        if (t != null && session(c)?.first != "student") l.forEach { if (k.gradeOf(it).isEmpty()) k.setGrade(it, t) } // new items get the open class
        val others = load(c, k.key, k.rd).filter { !vis(k.gradeOf(it)) }
        save(c, k.key, others + l, k.wr)
    }

    // ---- chapters ----
    fun chapters(c: Context) = loadK(c, kChapter)
    fun saveChapters(c: Context, l: List<Chapter>) = saveK(c, kChapter, l)

    // ---- lessons / videos ----
    fun lessons(c: Context) = loadK(c, kLesson)

    fun saveLessons(c: Context, l: List<Lesson>) = saveK(c, kLesson, l)

    /** Uploaded video file (src == "up"). Kept until the teacher deletes the video. No expiry. */
    fun videoFile(c: Context, id: String) = File(File(c.filesDir, "videos").apply { mkdirs() }, "$id.mp4")

    /** Whether the lesson has something to play (YouTube id or an uploaded file). */
    fun hasVideo(c: Context, l: Lesson) = if (l.src == "up") videoFile(c, l.id).exists() else l.yt.isNotEmpty()

    // ---- grants (who may see paid content). Written by the teacher (cash / free) or by the payment gateway (online). ----
    fun grants(c: Context) = load(c, "grants") { Grant(it.optString("t"), it.optString("e"), it.optString("m"), it.optString("b"), it.optLong("a")) }
    fun saveGrants(c: Context, l: List<Grant>) =
        save(c, "grants", l) { JSONObject().put("t", it.target).put("e", it.email).put("m", it.mode).put("b", it.by).put("a", it.at) }

    /** Opens [target] for [email]. Every call is logged (who opened it, for whom, when). */
    fun grant(c: Context, target: String, email: String, mode: String, by: String) {
        if (grants(c).any { it.target == target && it.email == email }) return
        val g = Grant(target, email, mode, by)
        saveGrants(c, grants(c) + g)
        save(c, "glog", glog(c) + g) { JSONObject().put("t", it.target).put("e", it.email).put("m", it.mode).put("b", it.by).put("a", it.at) } // never removed
    }

    /** Permanent log of every opening (who opened it, for whom, when). Revoking a grant does not delete its log line. */
    fun glog(c: Context) = load(c, "glog") { Grant(it.optString("t"), it.optString("e"), it.optString("m"), it.optString("b"), it.optLong("a")) }
    fun revoke(c: Context, target: String, email: String) =
        saveGrants(c, grants(c).filterNot { it.target == target && it.email == email })

    fun lesson(c: Context, id: String): Lesson? = lessons(c).firstOrNull { it.id == id }

    /** Only what students may see: hidden lessons are left out. */
    fun publishedLessons(c: Context) = lessons(c).filter { it.published }
    fun publishedLesson(c: Context, id: String): Lesson? = lesson(c, id)?.takeIf { it.published }

    // ---- announcements (teacher -> students) ----
    fun announcements(c: Context) = loadK(c, kAnn)
    fun saveAnnouncements(c: Context, l: List<Announcement>) = saveK(c, kAnn, l)

    fun deleteChapter(c: Context, id: String) {
        saveChapters(c, chapters(c).filter { it.id != id })
        lessons(c).filter { it.chapterId == id }.forEach { videoFile(c, it.id).delete() }
        saveLessons(c, lessons(c).filter { it.chapterId != id })
        saveGrants(c, grants(c).filterNot { it.target == "c:$id" })
    }

    // ---- books and files (PDF) ----
    fun docs(c: Context) = loadK(c, kDoc)
    fun saveDocs(c: Context, l: List<Doc>) = saveK(c, kDoc, l)
    fun doc(c: Context, id: String): Doc? = docs(c).firstOrNull { it.id == id }

    fun deleteDoc(c: Context, id: String) {
        saveDocs(c, docs(c).filter { it.id != id })
        docFile(c, id).delete()
    }

    fun docFile(c: Context, id: String) = File(File(c.filesDir, "docs").apply { mkdirs() }, "$id.pdf")
    fun photoFile(c: Context, name: String) = File(File(c.filesDir, "hw").apply { mkdirs() }, name)

    /** The homework photo a student picked but has not sent yet (one file per student, overwritten; it becomes the real photo when the answer is sent). */
    fun draftPhoto(c: Context, email: String) = photoFile(c, "draft_" + email.replace(Regex("[^A-Za-z0-9._-]"), "_") + ".jpg")

    /** The student's profile photo: filesDir/avatars/<email with every char outside A-Z a-z 0-9 . _ - replaced by _>.jpg (may not exist). */
    fun avatarFile(c: Context, email: String) =
        File(File(c.filesDir, "avatars").apply { mkdirs() }, email.replace(Regex("[^A-Za-z0-9._-]"), "_") + ".jpg")

    fun copyUri(c: Context, uri: Uri, dst: File): Boolean = try {
        c.contentResolver.openInputStream(uri)!!.use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
        true
    } catch (e: Exception) {
        dst.delete(); false
    }

    /** Saves a picked photo as a downscaled JPEG ([max] px, 1280 by default) with its EXIF rotation applied. */
    fun savePhoto(c: Context, uri: Uri, dst: File, max: Int = 1280): Boolean = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2000) sample *= 2
        val bmp = c.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        }!!
        val deg = try {
            c.contentResolver.openInputStream(uri)?.use {
                when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        } catch (e: Exception) { 0f }
        val k = minOf(1f, max.toFloat() / maxOf(bmp.width, bmp.height))
        val m = Matrix().apply { postScale(k, k); postRotate(deg) }
        val out = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        dst.outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 82, it) }
        true
    } catch (e: Exception) {
        dst.delete(); false
    }

    // ---- question bank ----
    fun questions(c: Context) = loadK(c, kQuestion)

    fun saveQuestions(c: Context, l: List<Question>) = saveK(c, kQuestion, l)

    fun question(c: Context, id: String): Question? = questions(c).firstOrNull { it.id == id }

    /** Deletes a question and takes it out of every exam that used it. */
    fun deleteQuestion(c: Context, id: String) {
        saveQuestions(c, questions(c).filter { it.id != id })
        saveExams(c, exams(c).onEach { e -> e.qids = e.qids.filter { it != id } })
    }

    // ---- exams and results ----
    fun exams(c: Context) = loadK(c, kExam)

    fun saveExams(c: Context, l: List<Exam>) = saveK(c, kExam, l)

    fun exam(c: Context, id: String): Exam? = exams(c).firstOrNull { it.id == id }

    fun results(c: Context) = load(c, "results") {
        Result(it.optString("x"), it.optString("e"), it.optInt("s"), it.optInt("c"), it.optInt("n"), it.optLong("a"))
    }

    fun saveResults(c: Context, l: List<Result>) = save(c, "results", l) {
        JSONObject().put("x", it.examId).put("e", it.email).put("s", it.score).put("c", it.correct).put("n", it.total).put("a", it.at)
    }

    fun addResult(c: Context, r: Result) = saveResults(c, results(c) + r)

    /** The latest result of a student in an exam, or null if never taken. */
    fun lastResult(c: Context, email: String, examId: String): Result? =
        results(c).filter { it.email == email && it.examId == examId }.maxByOrNull { it.at }

    fun deleteExam(c: Context, id: String) {
        saveExams(c, exams(c).filter { it.id != id })
        saveResults(c, results(c).filter { it.examId != id })
    }

    /** Average of a student's latest score in every official exam (null if none taken). */
    fun officialAverage(c: Context, email: String): Int? {
        val official = exams(c).filter { it.official }
        val scores = official.mapNotNull { lastResult(c, email, it.id)?.score }
        return if (scores.isEmpty()) null else scores.sum() / scores.size
    }

    // ---- homework and submissions ----
    fun homework(c: Context) = loadK(c, kHomework)
    fun saveHomework(c: Context, l: List<Homework>) = saveK(c, kHomework, l)
    fun homeworkById(c: Context, id: String): Homework? = homework(c).firstOrNull { it.id == id }

    fun submissions(c: Context) = load(c, "subs") {
        Submission(it.optString("h"), it.optString("e"), it.optString("t"), it.optString("p"), it.optInt("g", -1), it.optString("n"), it.optLong("a"))
    }

    fun saveSubmissions(c: Context, l: List<Submission>) = save(c, "subs", l) {
        JSONObject().put("h", it.hwId).put("e", it.email).put("t", it.text).put("p", it.photo).put("g", it.grade).put("n", it.note).put("a", it.at)
    }

    fun submission(c: Context, hwId: String, email: String): Submission? =
        submissions(c).firstOrNull { it.hwId == hwId && it.email == email }

    fun putSubmission(c: Context, s: Submission) {
        saveSubmissions(c, submissions(c).filter { !(it.hwId == s.hwId && it.email == s.email) } + s)
    }

    fun deleteHomework(c: Context, id: String) {
        val subs = submissions(c)
        subs.filter { it.hwId == id && it.photo.isNotEmpty() }.forEach { photoFile(c, it.photo).delete() }
        saveSubmissions(c, subs.filter { it.hwId != id })
        saveHomework(c, homework(c).filter { it.id != id })
    }

    /** Average of every student's official-exam average (null while nobody has taken an official exam). */
    fun teacherOfficialAverage(c: Context): Int? {
        val g = teacherGrade // release 65: inside a class screen only that class's students count
        val v = students(c).filter { g == null || it.grade == g }.mapNotNull { officialAverage(c, it.email) }
        return if (v.isEmpty()) null else v.sum() / v.size
    }

    fun ungraded(c: Context): Int {
        if (teacherGrade == null) return submissions(c).count { it.grade < 0 }
        val mine = homework(c).map { it.id }.toSet() // release 65: only the open class's homework
        return submissions(c).count { it.grade < 0 && it.hwId in mine }
    }

    // ---- per-student: favorites, notes, watch history ----
    val collections = listOf("fav", "later", "imp")

    fun favList(c: Context, email: String, coll: String): MutableList<String> {
        val s = sp(c).getString("fav:$email", null) ?: return mutableListOf()
        return strings(JSONObject(s).optJSONArray(coll)).toMutableList()
    }

    fun isIn(c: Context, email: String, coll: String, key: String) = favList(c, email, coll).contains(key)

    fun toggleIn(c: Context, email: String, coll: String, key: String) {
        val o = JSONObject(sp(c).getString("fav:$email", null) ?: "{}")
        val l = favList(c, email, coll)
        if (!l.remove(key)) l.add(0, key)
        o.put(coll, JSONArray(l))
        sp(c).edit().putString("fav:$email", o.toString()).apply()
    }

    fun notes(c: Context, email: String): MutableList<Note> = load(c, "notes:$email") { Note(it.optString("t"), it.optString("d")) }
    fun saveNotes(c: Context, email: String, l: List<Note>) = save(c, "notes:$email", l) { JSONObject().put("t", it.text).put("d", it.date) }

    /** Lesson ids, newest first, no duplicates. */
    fun history(c: Context, email: String): List<String> = strings(JSONArray(sp(c).getString("hist:$email", null) ?: "[]"))

    fun addHistory(c: Context, email: String, lessonId: String) {
        val l = (listOf(lessonId) + history(c, email).filter { it != lessonId }).take(200)
        sp(c).edit().putString("hist:$email", JSONArray(l).toString()).apply()
    }

    fun clearHistory(c: Context, email: String) = sp(c).edit().remove("hist:$email").apply()

    /** (watched lessons, all lessons) for a student. */
    fun progress(c: Context, email: String): Pair<Int, Int> {
        val g = findStudent(c, email)?.grade.orEmpty() // release 65: a student's progress counts his own class's lessons
        val all = load(c, kLesson.key, kLesson.rd).filter { it.published && (it.grade.isEmpty() || it.grade == g) }
        val seen = history(c, email).toSet()
        return all.count { it.id in seen } to all.size
    }

    fun percent(p: Pair<Int, Int>): Int = if (p.second == 0) 0 else p.first * 100 / p.second
}
