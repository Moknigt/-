package com.moknight.nexoraedu

import android.app.Dialog
import android.content.ClipData
import android.widget.EditText
import android.content.ClipboardManager
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.net.Uri
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class TeacherActivity : ShellActivity() {
    private var email = ""

    override fun ready(): Boolean {
        val s = Store.session(this)
        val t = Store.teacher(this)
        if (s?.first != "teacher" || t == null) return false
        email = t.first
        Store.teacherGrade = null   // release 65: always start outside a class screen
        return true
    }

    override fun hello() = R.string.welcome_teacher
    override fun displayName() = Store.teacherName(this).ifEmpty { email.substringBefore("@") }

    /** Students tab state (kept while the teacher moves around). */
    private var query = ""
    private var gradeSel = 0   // 0 = all classes, otherwise the index in Store.grades() + 1
    private var statusSel = 0  // 0 = all, 1 = active, 2 = not active

    override fun buildTabs() = listOf(
        Tab(R.string.tab_home, R.drawable.ic_home) { Store.teacherGrade = null; home() },
        Tab(R.string.tab_students, R.drawable.ic_users) { Store.teacherGrade = null; studentsTab() },
        Tab(R.string.tab_content, R.drawable.ic_folder) { Store.teacherGrade = null; content() },
        Tab(R.string.tab_tests, R.drawable.ic_exam) { Store.teacherGrade = null; examsTab() },
        Tab(R.string.tab_profile, R.drawable.ic_user) { Store.teacherGrade = null; profile() }
    )

    // ------------------------------------------------------------------ release 65: one place per class

    private var gradeSec = 0   // inside a class screen: 0 = content, 1 = exams / questions / homework

    private fun gradeLabel(g: String): String {
        val i = Store.FIXED_GRADES.indexOf(g)
        return if (i < 0) g else getString(listOf(R.string.grade_1_short, R.string.grade_2_short, R.string.grade_3_short)[i])
    }

    private fun openGrade(g: String) {
        gradeSec = 0
        Store.teacherGrade = g
        show { gradeScreen(g) }
    }

    /** Runs [action] inside a class: straight away when a class is open, otherwise after asking which class. */
    private fun forGrade(action: () -> Unit) {
        if (Store.teacherGrade != null) return action()
        actionSheet(getString(R.string.pick_grade_for), Store.FIXED_GRADES.map { g -> Act(gradeLabel(g)) { openGrade(g); action() } })
    }

    private fun chev(): ImageView = ImageView(this).apply {
        setImageResource(R.drawable.ic_chev)
        imageTintList = resources.getColorStateList(R.color.mut, theme)
        if (resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL) rotation = 180f
        layoutParams = LinearLayout.LayoutParams(dp(20), dp(20))
    }

    /** One class: everything the teacher manages for it. Students of other classes never see any of it. */
    private fun gradeScreen(g: String) {
        Store.teacherGrade = g   // set again on every redraw / return from a sub-screen
        addTop(gradeLabel(g))
        val mine = Store.students(this).filter { it.grade == g }
        val active = mine.count { it.active }
        addStatGridText(listOf(active.toString() to R.string.stat_active, (mine.size - active).toString() to R.string.stat_inactive))
        body.addView(chipRow(listOf(getString(R.string.tab_content), getString(R.string.tab_tests)), gradeSec, 8) { gradeSec = it; refresh() })
        if (gradeSec == 0) content() else examsTab()
    }

    /** The 5th tab (same as iPhone and Windows): role + email, as it was in the old header screen. */
    private fun profile() {
        addTop(getString(R.string.tab_profile))
        addCard(getString(R.string.role_teacher_label), displayName(), null)
        addCard(getString(R.string.email_label), email, null)
    }

    // ------------------------------------------------------------------ tabs

    private fun home() {
        val all = Store.students(this)
        val active = all.count { it.active }
        val avg = Store.teacherOfficialAverage(this)
        heading(getString(R.string.sec_classes))
        Store.FIXED_GRADES.forEach { g ->
            addRow(R.drawable.ic_grade, gradeLabel(g), getString(R.string.students_count, all.count { it.grade == g }), listOf(chev())) { openGrade(g) }
        }
        heading(getString(R.string.sec_overview))
        addStatGridText(
            listOf(
                active.toString() to R.string.stat_active,
                (all.size - active).toString() to R.string.stat_inactive,
                (avg?.let { "$it%" } ?: "-") to R.string.ex_official_avg,
                Store.ungraded(this).toString() to R.string.hw_ungraded,
                Store.lessons(this).size.toString() to R.string.stat_lessons,
                Store.exams(this).size.toString() to R.string.ex_exams
            )
        )
        heading(getString(R.string.sec_quick))
        addTiles(
            listOf(
                TileSpec(R.drawable.ic_play, R.string.act_lesson) { forGrade { addLessonSheet() } },
                TileSpec(R.drawable.ic_exam, R.string.act_exam) { forGrade { addExamSheet() } },
                TileSpec(R.drawable.ic_note, R.string.act_homework) { forGrade { addHomeworkSheet() } },
                TileSpec(R.drawable.ic_check, R.string.act_activate, all.size - active) {
                    statusSel = 2; gradeSel = 0; query = ""   // opens the students tab on "not active"
                    select(1)
                },
                TileSpec(R.drawable.ic_grade, R.string.act_classes) { show { classesScreen() } }
            )
        )
    }

    private fun contentActions() = listOf(
        TileSpec(R.drawable.ic_folder, R.string.act_chapter) { forGrade { addChapterSheet() } },
        TileSpec(R.drawable.ic_play, R.string.act_lesson) { forGrade { addLessonSheet() } },
        TileSpec(R.drawable.ic_play, R.string.act_video) { forGrade { addVideoSheet() } },
        TileSpec(R.drawable.ic_book, R.string.act_book) { forGrade { addDocSheet("book") } },
        TileSpec(R.drawable.ic_note, R.string.act_file) { forGrade { addDocSheet("file") } }
    )

    private fun trash(onYes: () -> Unit, name: String, warn: Int = R.string.confirm_delete) =
        iconBtn(R.drawable.ic_trash, R.color.mut) { confirm(getString(warn, name)) { onYes(); refresh() } }

    // ------------------------------------------------------------------ students tab

    private fun studentsTab() {
        if (Store.students(this).isEmpty()) {
            addEmpty(R.drawable.ic_users, R.string.empty_students, R.string.empty_students_sub)
            return
        }
        val grades = Store.grades(this)
        if (gradeSel > grades.size) gradeSel = 0
        val search = field(getString(R.string.hint_search_name), top = 4)
        search.setText(query)
        body.addView(search)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        fun fill() {
            list.removeAllViews()
            val q = query.trim().lowercase()
            val grade = grades.getOrNull(gradeSel - 1)
            val shown = Store.students(this).filter { s ->
                (grade == null || s.grade == grade) &&
                    (statusSel == 0 || (statusSel == 1) == s.active) &&
                    (q.isEmpty() || s.name.lowercase().contains(q))
            }.sortedWith(compareBy({ it.active }, { it.name.lowercase() })) // not active first
            if (shown.isEmpty()) {
                val v = layoutInflater.inflate(R.layout.item_empty, list, false)
                v.findViewById<ImageView>(R.id.emptyIcon).setImageResource(R.drawable.ic_users)
                v.findViewById<TextView>(R.id.emptyTitle).setText(R.string.empty_search)
                v.findViewById<TextView>(R.id.emptySub).setText(R.string.empty_search_sub)
                list.addView(v)
            } else shown.forEach { s -> list.addView(studentCard(s) { fill() }) }
        }

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { query = s?.toString() ?: ""; fill() }
        })
        body.addView(singleChoice(listOf(getString(R.string.all)) + grades, gradeSel, 10) { gradeSel = it; fill() })
        body.addView(singleChoice(listOf(getString(R.string.all), getString(R.string.stu_active), getString(R.string.stu_inactive)), statusSel, 8) { statusSel = it; fill() })
        body.addView(list)
        fill()
    }

    /** One student: tap = profile; switch = active; code with copy / new code; delete after a confirmation. */
    private fun studentCard(s: Student, changed: () -> Unit): View {
        val v = card(s.grade, s.name, s.email) as LinearLayout
        v.setOnClickListener { show { studentProfile(s.email) } }
        v.addView(activeRow(s) { if (statusSel != 0) v.postDelayed({ changed() }, 280) })
        v.addView(codeRow(s, changed, changed))
        return v
    }

    private fun activeRow(s: Student, after: () -> Unit): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutParams = lp(top = 12) }
        val st = label(getString(if (s.active) R.string.stu_active else R.string.stu_inactive), 14f, if (s.active) R.color.tx else R.color.mut, true)
        st.layoutParams = lp(w = 0, weight = 1f)
        row.addView(st)
        row.addView(glassSwitch(s.active) { on ->
            Store.setStudentActive(this, s.email, on)
            s.active = on
            st.setText(if (on) R.string.stu_active else R.string.stu_inactive)
            st.setTextColor(color(if (on) R.color.tx else R.color.mut))
            after()
        })
        return row
    }

    private fun copyCode(code: String) {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("code", code))
        toast(R.string.stu_copied)
    }

    /** Code chip (tap = copy, or create it the first time), copy button, new code (asks first) and delete (asks first). */
    private fun codeRow(s: Student, changed: () -> Unit, onDeleted: () -> Unit): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutParams = lp(top = 10) }
        if (s.code.isEmpty()) {
            row.addView(chip(getString(R.string.stu_code_new), false) { Store.newStudentCode(this, s.email); changed() })
        } else {
            row.addView(chip(s.code, false) { copyCode(s.code) }.apply {
                typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
                textDirection = View.TEXT_DIRECTION_LTR
            })
            row.addView(iconBtn(R.drawable.ic_copy, R.color.mut) { copyCode(s.code) })
            row.addView(link(getString(R.string.stu_code_regen)) {
                confirm(getString(R.string.stu_regen_confirm), R.string.stu_code_regen) { Store.newStudentCode(this, s.email); changed() }
            })
        }
        row.addView(View(this), lp(w = 0, weight = 1f))
        row.addView(iconBtn(R.drawable.ic_trash, R.color.mut) {
            confirm(getString(R.string.confirm_delete_student, s.name)) { Store.deleteStudent(this, s.email); onDeleted() }
        })
        return row
    }

    /** A student's own page: results, submissions and progress. */
    private fun studentProfile(email: String) {
        val s = Store.findStudent(this, email) ?: return back()
        addTop(s.name)
        val c = card(s.grade, s.name, s.email) as LinearLayout
        c.addView(ltrText(if (s.phone.isEmpty()) getString(R.string.acc_no_phone) else s.phone, 13f).apply { layoutParams = lp(top = 4) })
        c.addView(activeRow(s) {})
        c.addView(codeRow(s, { refresh() }, { back() }))
        body.addView(c)

        val p = Store.progress(this, email)
        val pct = Store.percent(p)
        val prog = card(getString(R.string.study_progress), "$pct%", getString(R.string.lessons_done_of, p.first, p.second)) as LinearLayout
        prog.addView(bar(pct, 12))
        body.addView(prog)

        val results = Store.results(this).filter { it.email == email }.sortedByDescending { it.at }
        val subs = Store.submissions(this).filter { it.email == email }.sortedByDescending { it.at }
        val avg = Store.officialAverage(this, email)
        addStatGridText(
            listOf(
                (avg?.let { "$it%" } ?: "-") to R.string.ex_official_avg,
                results.map { it.examId }.toSet().size.toString() to R.string.prof_exams_taken,
                subs.size.toString() to R.string.prof_hw_sent,
                subs.count { it.grade >= 0 }.toString() to R.string.prof_hw_graded
            )
        )

        heading(getString(R.string.paid_content))
        body.addView(primary(getString(R.string.grant_open), 8) { grantSheet(email) })
        Store.grants(this).filter { it.email == email }.forEach { g ->
            addRow(R.drawable.ic_key, targetName(g.target), modeName(g.mode)) {
                confirm(getString(R.string.grant_revoke), R.string.grant_revoke) { Store.revoke(this, g.target, email); refresh() }
            }
        }
        val glog = Store.glog(this).filter { it.email == email }.sortedByDescending { it.at }
        if (glog.isNotEmpty()) {
            heading(getString(R.string.grant_log))
            glog.forEach { g -> addRow(R.drawable.ic_hist, targetName(g.target), getString(R.string.grant_log_row, modeName(g.mode), g.by, dateText(g.at))) }
        }

        heading(getString(R.string.prof_results))
        if (results.isEmpty()) body.addView(label(getString(R.string.prof_no_results), 13f, R.color.mut, top = 8))
        results.forEach { r ->
            val title = Store.exam(this, r.examId)?.title ?: ""
            addRow(R.drawable.ic_exam, title, "${r.score}%  •  ${r.correct}/${r.total}  •  ${dateText(r.at)}")
        }

        heading(getString(R.string.prof_submissions))
        if (subs.isEmpty()) body.addView(label(getString(R.string.prof_no_subs), 13f, R.color.mut, top = 8))
        subs.forEach { sb ->
            val h = Store.homeworkById(this, sb.hwId) ?: return@forEach
            val st = if (sb.grade >= 0) getString(R.string.hw_status_graded, sb.grade) else getString(R.string.hw_status_sent)
            addRow(R.drawable.ic_note, h.title, st + "  •  " + dateText(sb.at)) { show { homeworkAnswers(h) } }
        }
    }

    // ------------------------------------------------------------------ content tab

    private class Act(val label: String, val color: Int = 0, val action: () -> Unit)

    /** A list of full-width actions in a sheet (edit, move, publish, delete...). */
    private fun actionSheet(title: String, acts: List<Act>) {
        sheet(title) { c, d ->
            acts.forEach { a ->
                c.addView(label(a.label, 15f, if (a.color == 0) R.color.tx else a.color, true).apply {
                    setBackgroundResource(R.drawable.field_bg)
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(16), 0, dp(16), 0)
                    layoutParams = lp(h = dp(50), top = 8)
                    setOnClickListener { d.dismiss(); a.action() }
                })
            }
            c.addView(link(getString(R.string.cancel), top = 6) { d.dismiss() })
        }
    }

    private fun manageBtn(onClick: () -> Unit) = iconBtn(R.drawable.ic_pencil, R.color.mut, onClick)

    private fun <T> swapAt(l: MutableList<T>, a: Int, b: Int) { val t = l[a]; l[a] = l[b]; l[b] = t }

    private fun moveActs(idx: Int, n: Int, move: (Int) -> Unit): List<Act> = buildList {
        if (idx > 0) add(Act(getString(R.string.act_move_up)) { move(-1) })
        if (idx < n - 1) add(Act(getString(R.string.act_move_down)) { move(1) })
    }

    private fun content() {
        addTiles(
            contentActions() + listOf(
                TileSpec(R.drawable.ic_grade, R.string.act_classes) { show { classesScreen() } },
                TileSpec(R.drawable.ic_note, R.string.act_announce) { forGrade { addAnnouncementSheet() } }
            )
        )
        val anns = Store.announcements(this).sortedByDescending { it.at }
        if (anns.isNotEmpty()) {
            heading(getString(R.string.ann_title))
            anns.forEach { a ->
                addRow(
                    R.drawable.ic_note, a.title, cut(a.text, 60).ifEmpty { dateText(a.at) },
                    listOf(
                        manageBtn { addAnnouncementSheet(a) },
                        trash({ Store.saveAnnouncements(this, Store.announcements(this).filter { it.id != a.id }) }, a.title)
                    )
                ) { addAnnouncementSheet(a) }
            }
        }
        val chapters = Store.chapters(this)
        val lessons = Store.lessons(this)
        val docs = Store.docs(this)
        if (chapters.isEmpty() && lessons.isEmpty() && docs.isEmpty()) {
            if (anns.isEmpty()) addEmpty(R.drawable.ic_folder, R.string.empty_content, R.string.empty_content_sub)
            return
        }
        val videos = lessons.filter { it.chapterId.isEmpty() }
        if (videos.isNotEmpty()) {
            heading(getString(R.string.videos))
            videos.forEachIndexed { i, l -> lessonRow(l, i, videos.size) }
        }
        if (chapters.isNotEmpty()) heading(getString(R.string.chapters_title))
        chapters.forEachIndexed { ci, ch ->
            val ls = lessons.filter { it.chapterId == ch.id }
            addRow(
                R.drawable.ic_folder, ch.title, getString(R.string.lessons_count, ls.size),
                listOf(manageBtn { chapterActions(ch, ci, chapters.size) })
            ) { chapterActions(ch, ci, chapters.size) }
            ls.forEachIndexed { li, l -> lessonRow(l, li, ls.size) }
        }
        val books = docs.filter { it.kind == "book" }
        if (books.isNotEmpty()) {
            heading(getString(R.string.books_title))
            books.forEachIndexed { i, d -> docRow(d, i, books.size) }
        }
        val files = docs.filter { it.kind == "file" }
        if (files.isNotEmpty()) {
            heading(getString(R.string.files_title))
            files.forEachIndexed { i, d -> docRow(d, i, files.size) }
        }
    }

    private fun lessonRow(l: Lesson, idx: Int, n: Int) {
        val sub = getString(if (!Store.hasVideo(this, l)) R.string.no_video_yet else if (l.src == "up") R.string.lesson_video_upload else R.string.lesson_video_label) +
            "  •  " + (if (l.price > 0) getString(R.string.price_egp, l.price) else getString(R.string.free)) +
            "  •  " + getString(if (l.published) R.string.lesson_published else R.string.lesson_hidden)
        val sw = glassSwitch(l.published) { on ->
            Store.saveLessons(this, Store.lessons(this).onEach { if (it.id == l.id) it.published = on })
            l.published = on
            window.decorView.postDelayed({ refresh() }, 260) // let the switch finish, then redraw the row
        }
        val v = itemRow(R.drawable.ic_play, l.title, sub, listOf(sw, manageBtn { lessonActions(l, idx, n) })) { lessonActions(l, idx, n) }
        if (!l.published) v.alpha = 0.6f
        body.addView(v)
    }

    private fun docRow(d: Doc, idx: Int, n: Int) = addRow(
        if (d.kind == "book") R.drawable.ic_book else R.drawable.ic_note, d.title, dateText(d.at),
        listOf(manageBtn { docActions(d, idx, n) })
    ) { docActions(d, idx, n) }

    private fun chapterActions(ch: Chapter, idx: Int, n: Int) {
        actionSheet(
            ch.title,
            listOf(Act(getString(R.string.course_price) + if (ch.price > 0) " • " + getString(R.string.price_egp, ch.price) else "") { coursePriceSheet(ch) }, Act(getString(R.string.act_rename)) {
                renameSheet(getString(R.string.rename_chapter), ch.title) { t ->
                    Store.saveChapters(this, Store.chapters(this).onEach { if (it.id == ch.id) it.title = t })
                }
            }) + moveActs(idx, n) { dir ->
                val l = Store.chapters(this).toMutableList()
                val i = l.indexOfFirst { it.id == ch.id }
                if (i >= 0 && i + dir in l.indices) { swapAt(l, i, i + dir); Store.saveChapters(this, l); refresh() }
            } + Act(getString(R.string.delete), R.color.err) {
                confirm(getString(R.string.confirm_delete_chapter, ch.title)) { Store.deleteChapter(this, ch.id); refresh() }
            }
        )
    }

    private fun lessonActions(l: Lesson, idx: Int, n: Int) {
        val acts = ArrayList<Act>()
        if (Store.hasVideo(this, l)) acts.add(Act(getString(R.string.act_preview)) { openVideo(l) })
        acts.add(Act(getString(R.string.act_edit)) { editLessonSheet(l) })
        acts.add(Act(getString(if (l.published) R.string.act_hide else R.string.act_publish)) {
            Store.saveLessons(this, Store.lessons(this).onEach { if (it.id == l.id) it.published = !l.published })
            refresh()
        })
        acts.addAll(moveActs(idx, n) { dir ->
            val all = Store.lessons(this).toMutableList()
            val same = all.indices.filter { all[it].chapterId == l.chapterId }
            val pos = same.indexOfFirst { all[it].id == l.id }
            if (pos >= 0 && pos + dir in same.indices) { swapAt(all, same[pos], same[pos + dir]); Store.saveLessons(this, all); refresh() }
        })
        acts.add(Act(getString(R.string.delete), R.color.err) {
            confirm(getString(R.string.confirm_delete, l.title)) {
                Store.videoFile(this, l.id).delete()
                Store.saveGrants(this, Store.grants(this).filterNot { it.target == "l:${l.id}" })
                Store.saveLessons(this, Store.lessons(this).filter { it.id != l.id }); refresh()
            }
        })
        actionSheet(l.title, acts)
    }

    private fun docActions(d: Doc, idx: Int, n: Int) {
        actionSheet(
            d.title,
            listOf(
                Act(getString(R.string.act_open)) { openDoc(d) },
                Act(getString(R.string.act_rename)) {
                    renameSheet(getString(R.string.rename_doc), d.title) { t ->
                        Store.saveDocs(this, Store.docs(this).onEach { if (it.id == d.id) it.title = t })
                    }
                }
            ) + moveActs(idx, n) { dir ->
                val all = Store.docs(this).toMutableList()
                val same = all.indices.filter { all[it].kind == d.kind }
                val pos = same.indexOfFirst { all[it].id == d.id }
                if (pos >= 0 && pos + dir in same.indices) { swapAt(all, same[pos], same[pos + dir]); Store.saveDocs(this, all); refresh() }
            } + Act(getString(R.string.delete), R.color.err) {
                confirm(getString(R.string.confirm_delete, d.title)) { Store.deleteDoc(this, d.id); refresh() }
            }
        )
    }

    private fun renameSheet(title: String, current: String, onSave: (String) -> Unit) {
        sheet(title) { c, d ->
            val f = field(getString(R.string.hint_title))
            f.setText(current)
            c.addView(f)
            c.addView(primary(getString(R.string.btn_save), 16) {
                val t = f.text.toString().trim()
                if (t.isEmpty()) return@primary toast(R.string.err_title)
                onSave(t)
                d.dismiss(); refresh()
            })
            c.addView(link(getString(R.string.cancel)) { d.dismiss() })
        }
    }

    private fun editLessonSheet(l: Lesson) {
        val chapters = Store.chapters(this)
        sheet(getString(R.string.edit_lesson)) { c, d ->
            val title = field(getString(R.string.hint_title))
            title.setText(l.title)
            val url = field(getString(if (l.chapterId.isEmpty()) R.string.hint_youtube else R.string.hint_youtube_optional), ltr = true)
            if (l.yt.isNotEmpty()) url.setText("https://youtu.be/" + l.yt)
            val pf = VForm()
            var sel = chapters.indexOfFirst { it.id == l.chapterId }.coerceAtLeast(0)
            c.addView(title)
            if (l.chapterId.isNotEmpty() && chapters.isNotEmpty()) {
                c.addView(label(getString(R.string.pick_chapter), 13f, R.color.mut, top = 14))
                c.addView(singleChoice(chapters.map { it.title }, sel, 8) { sel = it })
            }
            if (l.src == "yt") c.addView(url)
            priceForm(c, pf, l.price)
            c.addView(primary(getString(R.string.btn_save), 16) {
                val t = title.text.toString().trim()
                if (t.isEmpty()) return@primary toast(R.string.err_title)
                val price = priceOf(pf) ?: return@primary toast(R.string.err_price)
                if (l.src == "up") {
                    Store.saveLessons(this, Store.lessons(this).onEach { if (it.id == l.id) { it.title = t; it.price = price } })
                    d.dismiss(); refresh(); return@primary
                }
                val raw = url.text.toString().trim()
                val yt = if (raw.isEmpty()) "" else youtubeId(raw)
                if (raw.isNotEmpty() && yt.isEmpty()) return@primary toast(R.string.err_bad_link)
                if (l.chapterId.isEmpty() && yt.isEmpty()) return@primary toast(R.string.err_bad_link) // a stand-alone video needs its link
                val ch = if (l.chapterId.isNotEmpty() && chapters.isNotEmpty()) chapters[sel].id else l.chapterId
                Store.saveLessons(this, Store.lessons(this).onEach { if (it.id == l.id) { it.title = t; it.yt = yt; it.chapterId = ch; it.price = price } })
                d.dismiss(); refresh()
            })
            c.addView(link(getString(R.string.cancel)) { d.dismiss() })
        }
    }

    // ---- classes
    private fun classesScreen() {
        addTop(getString(R.string.classes_title))
        body.addView(primary(getString(R.string.act_grade), 8) { addGradeSheet() })
        val grades = Store.grades(this)
        val students = Store.students(this)
        if (grades.isEmpty()) body.addView(label(getString(R.string.no_grades), 13f, R.color.mut, top = 16))
        grades.forEach { g ->
            addRow(
                R.drawable.ic_grade, g, getString(R.string.students_count, students.count { it.grade == g }),
                listOf(trash({ Store.saveGrades(this, Store.grades(this).filter { it != g }) }, g, R.string.confirm_delete_grade))
            )
        }
        addNote(getString(R.string.classes_note))
    }

    private fun addGradeSheet() {
        sheet(getString(R.string.act_grade)) { c, d ->
            val name = field(getString(R.string.hint_grade))
            c.addView(name)
            c.addView(primary(getString(R.string.add), 16) {
                val n = name.text.toString().trim()
                if (n.isEmpty()) return@primary toast(R.string.err_title)
                val all = Store.grades(this)
                if (all.any { it == n }) return@primary toast(R.string.err_grade_exists)
                Store.saveGrades(this, all + n)
                d.dismiss(); refresh()
            })
            c.addView(link(getString(R.string.cancel)) { d.dismiss() })
        }
    }

    // ---- announcements
    /** New announcement, or (existing != null) edit one: the date it was posted stays. */
    private fun addAnnouncementSheet(existing: Announcement? = null) {
        sheet(getString(if (existing == null) R.string.act_announce else R.string.act_edit)) { c, d ->
            val title = field(getString(R.string.hint_title))
            val text = field(getString(R.string.hint_ann_text), lines = 3)
            if (existing != null) { title.setText(existing.title); text.setText(existing.text) }
            c.addView(title)
            c.addView(text)
            c.addView(primary(getString(if (existing == null) R.string.add else R.string.btn_save), 16) {
                val t = title.text.toString().trim()
                if (t.isEmpty()) return@primary toast(R.string.err_title)
                val msg = text.text.toString().trim()
                if (existing == null) {
                    Store.saveAnnouncements(this, Store.announcements(this) + Announcement(Store.newId(), t, msg))
                } else {
                    Store.saveAnnouncements(this, Store.announcements(this).onEach { if (it.id == existing.id) { it.title = t; it.text = msg } })
                }
                d.dismiss(); refresh()
            })
            c.addView(link(getString(R.string.cancel)) { d.dismiss() })
        }
    }

    // ------------------------------------------------------------------ add sheets

    private fun addChapterSheet() {
        sheet(getString(R.string.act_chapter)) { c, d ->
            val title = field(getString(R.string.hint_title))
            c.addView(title)
            c.addView(primary(getString(R.string.add), 16) {
                val t = title.text.toString().trim()
                if (t.isEmpty()) return@primary toast(R.string.err_title)
                Store.saveChapters(this, Store.chapters(this) + Chapter(Store.newId(), t))
                d.dismiss(); refresh()
            })
            c.addView(link(getString(R.string.cancel)) { d.dismiss() })
        }
    }

    // ---- release 35: video source (YouTube link / upload) + price ----
    private class VForm { var src = 0; var uri: Uri? = null; var paid = false; var price: EditText? = null; var url: EditText? = null; var thumb = ""; var lastYt = "" }
    private var vBusy = false

    /** "YouTube link / Upload video" chips + the link field or the file picker. A pasted link imports the title + thumbnail. */
    private fun sourceForm(c: LinearLayout, f: VForm, title: EditText, optionalLink: Boolean) {
        val url = field(getString(if (optionalLink) R.string.hint_youtube_optional else R.string.hint_youtube), ltr = true)
        val chosen = label("", 13f, R.color.mut, top = 4)
        val pickBtn = link(getString(R.string.choose_video), top = 8) {
            pick("video/*") { u -> f.uri = u; chosen.text = getString(R.string.video_selected); chosen.drawTick(accent()) }
        }
        f.url = url
        fun show() {
            url.visibility = if (f.src == 0) View.VISIBLE else View.GONE
            pickBtn.visibility = if (f.src == 1) View.VISIBLE else View.GONE
            chosen.visibility = pickBtn.visibility
        }
        url.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(x: CharSequence?, a: Int, b: Int, n: Int) {}
            override fun onTextChanged(x: CharSequence?, a: Int, b: Int, n: Int) {}
            override fun afterTextChanged(x: Editable?) {
                val id = youtubeId(x.toString())
                if (id.isEmpty() || id == f.lastYt) return
                f.lastYt = id
                YtMeta.fetch(id) { info ->
                    runOnUiThread {
                        if (info == null) toast(R.string.yt_import_fail) else {
                            f.thumb = info.thumb
                            if (title.text.isNullOrBlank()) title.setText(info.title)
                            toast(R.string.yt_imported)
                        }
                    }
                }
            }
        })
        c.addView(singleChoice(listOf(getString(R.string.src_youtube), getString(R.string.src_upload)), 0, 12) { f.src = it; show() })
        c.addView(url); c.addView(pickBtn); c.addView(chosen)
        show()
    }

    /** "Free / Paid" chips + the price field. */
    private fun priceForm(c: LinearLayout, f: VForm, current: Int, top: Int = 10) {
        val pf = field(getString(R.string.price_hint), ltr = true, number = true)
        if (current > 0) pf.setText(current.toString())
        f.paid = current > 0; f.price = pf
        pf.visibility = if (f.paid) View.VISIBLE else View.GONE
        c.addView(singleChoice(listOf(getString(R.string.free), getString(R.string.paid)), if (f.paid) 1 else 0, top) {
            f.paid = it == 1; pf.visibility = if (f.paid) View.VISIBLE else View.GONE
        })
        c.addView(pf)
    }

    /** 0 = free, > 0 = the price, null = paid but the number is missing. */
    private fun priceOf(f: VForm): Int? {
        if (!f.paid) return 0
        val n = f.price?.text?.toString()?.trim()?.toIntOrNull()
        return if (n != null && n > 0) n else null
    }

    private fun submitLesson(f: VForm, chapterId: String, t: String, d: Dialog) {
        if (t.isEmpty()) return toast(R.string.err_title)
        val price = priceOf(f) ?: return toast(R.string.err_price)
        if (f.src == 1) {
            val u = f.uri ?: return toast(R.string.err_pick_video)
            if (vBusy) return
            vBusy = true; toast(R.string.saving)
            val id = Store.newId()
            Thread { // TODO(server): upload to the platform server (resumable, with progress) instead of copying locally
                val ok = Store.copyUri(this, u, Store.videoFile(this, id))
                runOnUiThread {
                    vBusy = false
                    if (ok) {
                        Store.saveLessons(this, Store.lessons(this) + Lesson(id, chapterId, t, "", src = "up", price = price))
                        d.dismiss(); refresh()
                    } else toast(R.string.err_copy)
                }
            }.start()
            return
        }
        val raw = f.url!!.text.toString().trim()
        val yt = if (raw.isEmpty()) "" else youtubeId(raw)
        if ((raw.isNotEmpty() && yt.isEmpty()) || (chapterId.isEmpty() && yt.isEmpty())) return toast(R.string.err_bad_link)
        Store.saveLessons(this, Store.lessons(this) + Lesson(Store.newId(), chapterId, t, yt, price = price, thumb = f.thumb))
        d.dismiss(); refresh()
    }

    private fun addLessonSheet() {
        val chapters = Store.chapters(this)
        if (chapters.isEmpty()) return toast(R.string.err_add_chapter_first)
        sheet(getString(R.string.act_lesson)) { c, d ->
            var sel = 0
            val f = VForm()
            val title = field(getString(R.string.hint_title))
            c.addView(title)
            c.addView(label(getString(R.string.pick_chapter), 13f, R.color.mut, top = 14))
            c.addView(singleChoice(chapters.map { it.title }, 0, 8) { sel = it })
            sourceForm(c, f, title, optionalLink = true)
            priceForm(c, f, 0)
            c.addView(primary(getString(R.string.add), 16) { submitLesson(f, chapters[sel].id, title.text.toString().trim(), d) })
            c.addView(link(getString(R.string.cancel)) { d.dismiss() })
        }
    }

    private fun addVideoSheet() {
        sheet(getString(R.string.act_video)) { c, d ->
            val f = VForm()
            val title = field(getString(R.string.hint_title))
            c.addView(title)
            sourceForm(c, f, title, optionalLink = false)
            priceForm(c, f, 0)
            c.addView(primary(getString(R.string.add), 16) { submitLesson(f, "", title.text.toString().trim(), d) })
            c.addView(link(getString(R.string.cancel)) { d.dismiss() })
        }
    }

    /** Course (chapter) price. */
    private fun coursePriceSheet(ch: Chapter) {
        sheet(getString(R.string.course_price)) { c, d ->
            val f = VForm()
            priceForm(c, f, ch.price, top = 12)
            c.addView(primary(getString(R.string.btn_save), 16) {
                val price = priceOf(f) ?: return@primary toast(R.string.err_price)
                Store.saveChapters(this, Store.chapters(this).onEach { if (it.id == ch.id) it.price = price })
                d.dismiss(); refresh()
            })
            c.addView(link(getString(R.string.cancel)) { d.dismiss() })
        }
    }

    // ---- release 35: opening paid content for a student (cash / free). Every opening is logged. ----
    private fun targetName(t: String): String =
        if (t.startsWith("c:")) getString(R.string.course_tag, Store.chapters(this).firstOrNull { it.id == t.drop(2) }?.title ?: "?")
        else Store.lesson(this, t.drop(2))?.title ?: "?"

    private fun modeName(m: String) = getString(when (m) { "online" -> R.string.grant_mode_online; "cash" -> R.string.grant_mode_cash; else -> R.string.grant_mode_free })

    private fun grantSheet(email: String) {
        val have = Store.grants(this).filter { it.email == email }.map { it.target }.toSet()
        val items = Store.chapters(this).filter { it.price > 0 && "c:${it.id}" !in have }
            .map { "c:${it.id}" to getString(R.string.course_tag, it.title) + " • " + getString(R.string.price_egp, it.price) } +
            Store.lessons(this).filter { it.price > 0 && "l:${it.id}" !in have }
                .map { "l:${it.id}" to it.title + " • " + getString(R.string.price_egp, it.price) }
        if (items.isEmpty()) return toast(R.string.grant_none)
        actionSheet(getString(R.string.grant_open), items.map { (t, name) ->
            Act(name) {
                actionSheet(name, listOf(
                    Act(getString(R.string.grant_cash)) { doGrant(email, t, "cash") },
                    Act(getString(R.string.grant_free)) { doGrant(email, t, "free") }
                ))
            }
        })
    }

    private fun doGrant(email: String, target: String, mode: String) {
        Store.grant(this, target, email, mode, Store.teacher(this)?.first ?: "teacher")
        toast(R.string.grant_done); refresh()
    }

    private fun addDocSheet(kind: String) {
        sheet(getString(if (kind == "book") R.string.act_book else R.string.act_file)) { c, d ->
            var uri: Uri? = null
            var busy = false
            val title = field(getString(R.string.hint_title))
            val chosen = label("", 13f, R.color.mut, top = 4)
            c.addView(title)
            c.addView(link(getString(R.string.choose_pdf), top = 8) {
                pick("application/pdf") { u -> uri = u; chosen.text = getString(R.string.pdf_selected); chosen.drawTick(accent()) }
            })
            c.addView(chosen)
            c.addView(primary(getString(R.string.add), 12) {
                val t = title.text.toString().trim()
                val u = uri
                if (t.isEmpty()) return@primary toast(R.string.err_title)
                if (u == null) return@primary toast(R.string.err_pick_pdf)
                if (busy) return@primary
                busy = true
                toast(R.string.saving)
                val id = Store.newId()
                Thread {
                    val ok = Store.copyUri(this, u, Store.docFile(this, id))
                    runOnUiThread {
                        busy = false
                        if (ok) {
                            Store.saveDocs(this, Store.docs(this) + Doc(id, t, kind))
                            d.dismiss(); refresh()
                        } else toast(R.string.err_copy)
                    }
                }.start()
            })
            c.addView(link(getString(R.string.cancel)) { d.dismiss() })
        }
    }

    // ------------------------------------------------------------------ exams tab: exams / question bank / homework

    private var exTab = "exams"

    private fun cut(s: String, n: Int) = if (s.length <= n) s else s.take(n).trimEnd() + "…"

    private fun examsTab() {
        val tags = listOf("exams", "questions", "homework")
        val names = listOf(R.string.ex_exams, R.string.ex_questions, R.string.ex_homework).map { getString(it) }
        body.addView(chipRow(names, tags.indexOf(exTab), 0) { exTab = tags[it]; refresh() })
        val addLabel = when (exTab) {
            "questions" -> R.string.ex_add_question
            "homework" -> R.string.ex_add_homework
            else -> R.string.ex_add_exam
        }
        body.addView(primary(getString(addLabel), 14) {
            forGrade {
                when (exTab) {
                    "questions" -> addQuestionSheet()
                    "homework" -> addHomeworkSheet()
                    else -> addExamSheet()
                }
            }
        })
        when (exTab) {
            "questions" -> questionsSection()
            "homework" -> homeworkSection()
            else -> examsSection()
        }
    }

    // ---- question bank

    private fun questionsSection() {
        val list = Store.questions(this)
        if (list.isEmpty()) return addEmpty(R.drawable.ic_note, R.string.ex_empty_questions, R.string.ex_empty_questions_sub)
        val chapters = Store.chapters(this)
        list.forEach { q ->
            var sub = getString(R.string.ex_right_answer) + ": " + cut(q.options.getOrNull(q.answer).orEmpty(), 40)
            chapters.firstOrNull { it.id == q.chapter }?.let { sub += "  •  " + it.title }
            addRow(
                R.drawable.ic_note, cut(q.text, 80), sub,
                listOf(trash({ Store.deleteQuestion(this, q.id) }, "", R.string.ex_confirm_delete_question))
            )
        }
    }

    private fun addQuestionSheet() {
        sheet(getString(R.string.ex_add_question)) { c, d ->
            val chapters = Store.chapters(this)
            val text = field(getString(R.string.ex_question_text), lines = 3)
            c.addView(text)
            var chapter = ""
            if (chapters.isNotEmpty()) {
                c.addView(label(getString(R.string.ex_chapter_optional), 13f, R.color.mut, top = 14))
                c.addView(singleChoice(listOf(getString(R.string.ex_no_chapter)) + chapters.map { it.title }, 0, 8) {
                    chapter = if (it == 0) "" else chapters[it - 1].id
                })
            }
            val opts = (1..4).map { field(getString(R.string.ex_option_n, it)) }
            opts.forEach { c.addView(it) }
            c.addView(label(getString(R.string.ex_correct), 13f, R.color.mut, top = 14))
            var right = 0
            c.addView(singleChoice((1..4).map { it.toString() }, 0, 8) { right = it })
            c.addView(primary(getString(R.string.add), 16) {
                val qt = text.text.toString().trim()
                if (qt.isEmpty()) return@primary toast(R.string.ex_err_question)
                val filled = opts.indices.filter { opts[it].text.toString().trim().isNotEmpty() }
                if (filled.size < 2) return@primary toast(R.string.ex_err_options)
                val at = filled.indexOf(right)   // position of the right option once the empty ones are dropped
                if (at < 0) return@primary toast(R.string.ex_err_correct)
                Store.saveQuestions(
                    this,
                    Store.questions(this) + Question(Store.newId(), qt, chapter, filled.map { opts[it].text.toString().trim() }, at)
                )
                d.dismiss(); refresh()
            })
            c.addView(link(getString(R.string.cancel)) { d.dismiss() })
        }
    }

    // ---- exams

    private fun examsSection() {
        val list = Store.exams(this)
        if (list.isEmpty()) return addEmpty(R.drawable.ic_exam, R.string.empty_exams, R.string.empty_exams_sub)
        list.sortedByDescending { it.at }.forEach { e ->
            val sub = getString(if (e.official) R.string.ex_official else R.string.ex_training) + "  •  " +
                getString(R.string.ex_questions_count, e.qids.size) + "  •  " + dateText(e.at)
            addRow(
                R.drawable.ic_exam, e.title, sub,
                listOf(trash({ Store.deleteExam(this, e.id) }, e.title, R.string.ex_confirm_delete_exam))
            ) { examResultsSheet(e) }
        }
    }

    private fun addExamSheet() {
        val bank = Store.questions(this)
        if (bank.isEmpty()) return toast(R.string.ex_err_add_questions_first)
        sheet(getString(R.string.ex_add_exam)) { c, d ->
            val title = field(getString(R.string.hint_title))
            c.addView(title)
            var official = false
            c.addView(singleChoice(listOf(getString(R.string.ex_training), getString(R.string.ex_official)), 0, 12) { official = it == 1 })
            c.addView(label(getString(R.string.ex_pick_questions), 13f, R.color.mut, top = 14))
            val boxes = bank.map { q ->
                CheckBox(this).apply {
                    text = cut(q.text, 70)
                    textSize = 14f
                    setTextColor(color(R.color.tx))
                    buttonTintList = ColorStateList.valueOf(accent())
                    layoutParams = lp(top = 4)
                }.also { c.addView(it) }
            }
            c.addView(primary(getString(R.string.add), 16) {
                val t = title.text.toString().trim()
                if (t.isEmpty()) return@primary toast(R.string.err_title)
                val ids = bank.filterIndexed { i, _ -> boxes[i].isChecked }.map { it.id }
                if (ids.isEmpty()) return@primary toast(R.string.ex_err_no_questions)
                Store.saveExams(this, Store.exams(this) + Exam(Store.newId(), t, official, ids))
                d.dismiss(); refresh()
            })
            c.addView(link(getString(R.string.cancel)) { d.dismiss() })
        }
    }

    /** The latest result of every student who took the exam, best first. */
    private fun examResultsSheet(e: Exam) {
        sheet(e.title) { c, d ->
            val rows = Store.students(this)
                .mapNotNull { s -> Store.lastResult(this, s.email, e.id)?.let { s to it } }
                .sortedByDescending { it.second.score }
            if (rows.isEmpty()) c.addView(label(getString(R.string.ex_no_results), 13f, R.color.mut, top = 10))
            rows.forEach { (s, r) ->
                val line = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    layoutParams = lp(top = 10)
                }
                val who = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = lp(w = 0, weight = 1f) }
                who.addView(label(s.name, 15f, R.color.tx, true))
                who.addView(label(getString(R.string.ex_result_line, r.correct, r.total) + "  •  " + dateText(r.at), 12f, R.color.mut))
                line.addView(who)
                line.addView(label("${r.score}%", 18f, R.color.tx, true).apply { setTextColor(accent()); layoutParams = lp(w = WRAP) })
                c.addView(line)
            }
            c.addView(link(getString(R.string.close), top = 8) { d.dismiss() })
        }
    }

    // ---- homework

    private fun homeworkSection() {
        val list = Store.homework(this)
        if (list.isEmpty()) return addEmpty(R.drawable.ic_pencil, R.string.ex_empty_hw, R.string.ex_empty_hw_teacher_sub)
        val subs = Store.submissions(this)
        list.sortedByDescending { it.at }.forEach { h ->
            val mine = subs.filter { it.hwId == h.id }
            var sub = getString(R.string.hw_submissions) + ": " + mine.size
            val open = mine.count { it.grade < 0 }
            if (open > 0) sub += "  •  " + getString(R.string.hw_ungraded) + ": " + open
            addRow(
                R.drawable.ic_pencil, h.title, sub,
                listOf(trash({ Store.deleteHomework(this, h.id) }, h.title, R.string.ex_confirm_delete_hw))
            ) { show { homeworkAnswers(h) } }
        }
    }

    private fun addHomeworkSheet() {
        sheet(getString(R.string.ex_add_homework)) { c, d ->
            val title = field(getString(R.string.hw_hint_title))
            val note = field(getString(R.string.hw_hint_note), lines = 3)
            c.addView(title)
            c.addView(note)
            c.addView(primary(getString(R.string.add), 16) {
                val t = title.text.toString().trim()
                if (t.isEmpty()) return@primary toast(R.string.err_title)
                Store.saveHomework(this, Store.homework(this) + Homework(Store.newId(), t, note.text.toString().trim()))
                d.dismiss(); refresh()
            })
            c.addView(link(getString(R.string.cancel)) { d.dismiss() })
        }
    }

    /** The students' answers to one homework (sub-screen): text, photo, status, and a button to grade. */
    private fun homeworkAnswers(h: Homework) {
        val subs = Store.submissions(this).filter { it.hwId == h.id }.sortedBy { it.at }
        addTop(h.title, subs.size)
        if (h.note.isNotEmpty()) addCard(getString(R.string.hw_note), h.note, null)
        if (subs.isEmpty()) body.addView(label(getString(R.string.hw_no_submissions), 13f, R.color.mut, top = 16))
        subs.forEach { body.addView(submissionCard(h, it)) }
    }

    private fun submissionCard(h: Homework, s: Submission): View {
        val name = Store.findStudent(this, s.email)?.name ?: s.email
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.card_glass)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            layoutParams = lp(top = 12)
        }
        box.addView(label(name, 16f, R.color.tx, true))
        box.addView(ltrText(s.email + "  •  " + dateText(s.at), 12f))
        if (s.text.isNotEmpty()) box.addView(label(s.text, 14f, R.color.tx, top = 10))
        if (s.photo.isNotEmpty()) {
            val bmp = decodeScaled(Store.photoFile(this, s.photo), 1024)
            if (bmp != null) box.addView(ImageView(this).apply {
                setImageBitmap(bmp)
                adjustViewBounds = true
                maxHeight = dp(320)
                layoutParams = lp(top = 10)
            }) else box.addView(label(getString(R.string.hw_photo_missing), 12f, R.color.mut, top = 10))
        }
        val graded = s.grade >= 0
        box.addView(
            label(if (graded) getString(R.string.hw_status_graded, s.grade) else getString(R.string.hw_status_sent), 14f, R.color.tx, true, top = 10)
                .apply { setTextColor(if (graded) accent() else color(R.color.gold)) }
        )
        if (graded && s.note.isNotEmpty()) box.addView(label(getString(R.string.hw_teacher_note) + ": " + s.note, 12f, R.color.mut, top = 2))
        box.addView(link(getString(R.string.hw_save_grade), top = 6) { gradeSheet(h, s) })
        return box
    }

    private fun gradeSheet(h: Homework, s: Submission) {
        sheet(getString(R.string.hw_save_grade)) { c, d ->
            val g = field(getString(R.string.hw_grade_label), number = true, ltr = true)
            if (s.grade >= 0) g.setText(s.grade.toString())
            val note = field(getString(R.string.hw_grade_note), lines = 3)
            note.setText(s.note)
            c.addView(g)
            c.addView(note)
            c.addView(primary(getString(R.string.hw_save_grade), 16) {
                val n = g.text.toString().trim().toIntOrNull()
                if (n == null || n < 0 || n > 10) return@primary toast(R.string.hw_err_grade)
                Store.putSubmission(this, Submission(s.hwId, s.email, s.text, s.photo, n, note.text.toString().trim(), s.at))
                d.dismiss(); refresh()   // redraws the answers with the new grade
            })
            c.addView(link(getString(R.string.cancel)) { d.dismiss() })
        }
    }
}
