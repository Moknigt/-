package com.moknight.nexoraedu

import android.content.Context
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Teacher registration code: nobody can create a teacher account without one. A code is 6 random characters + 6 signature
 * characters (HMAC-SHA256 of the first 6 with [SECRET]), written XXXXXX-YYYYYY. It is checked offline (no server).
 * Each code works once per device. Make codes with `tools/gen_teacher_codes.py`; [SECRET] must be the same in all four places
 * (that script, here, iPhone `TeacherCode.swift`, Windows `TeacherCode.cs`). Changing it cancels every code made before.
 */
object TeacherCode {
    private const val SECRET = "rw54cHkLy7Gk_H53ezFrTLXwEuivdc7f"
    private const val ALPHA = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    private const val KEY = "t_used_codes"

    enum class Result { OK, EMPTY, INVALID, USED }

    private fun signature(serial: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(SECRET.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        val b = mac.doFinal("teacher:$serial".toByteArray(Charsets.UTF_8))
        var n = 0L
        for (i in 0..4) n = (n shl 8) or (b[i].toLong() and 0xFF)
        return (0..5).map { ALPHA[((n shr (35 - 5 * it)) and 31L).toInt()] }.joinToString("")
    }

    /** Only the code characters, upper case: spaces, dashes and typos like lower case are forgiven. */
    private fun clean(raw: String) = raw.uppercase().filter { it in ALPHA }

    private fun used(c: Context) =
        c.getSharedPreferences("nexora_data", Context.MODE_PRIVATE).getString(KEY, "")!!.split(",").filter { it.isNotEmpty() }.toMutableSet()

    fun verify(c: Context, raw: String): Result {
        if (raw.isBlank()) return Result.EMPTY
        val s = clean(raw)
        if (s.length != 12 || signature(s.substring(0, 6)) != s.substring(6)) return Result.INVALID
        return if (s.substring(0, 6) in used(c)) Result.USED else Result.OK
    }

    /** Call once the teacher account is really created. */
    fun markUsed(c: Context, raw: String) {
        val s = clean(raw)
        if (s.length != 12) return
        val u = used(c).apply { add(s.substring(0, 6)) }
        c.getSharedPreferences("nexora_data", Context.MODE_PRIVATE).edit().putString(KEY, u.joinToString(",")).apply()
    }

    fun errorRes(r: Result): Int? = when (r) {
        Result.OK -> null
        Result.EMPTY -> R.string.err_tcode_required
        Result.INVALID -> R.string.err_tcode_invalid
        Result.USED -> R.string.err_tcode_used
    }
}
