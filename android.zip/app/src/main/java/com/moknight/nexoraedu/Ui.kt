package com.moknight.nexoraedu

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import java.io.File

/** The one switch used everywhere (activate a student, publish a lesson): accent thumb + soft track. */
fun BaseActivity.glassSwitch(on: Boolean, onChange: (Boolean) -> Unit): android.widget.Switch =
    android.widget.Switch(this).apply {
        isChecked = on
        val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        thumbTintList = android.content.res.ColorStateList(st, intArrayOf(accent(), color(R.color.mut)))
        trackTintList = android.content.res.ColorStateList(st, intArrayOf((accent() and 0x00FFFFFF) or 0x66000000, color(R.color.bd)))
        setOnCheckedChangeListener { _, v -> Sfx.play(if (v) Sfx.S.ON else Sfx.S.OFF); onChange(v) }
    }

/* Small programmatic view builders shared by every screen (same look as the XML layouts). */

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun BaseActivity.color(id: Int): Int = resources.getColor(id, theme)

fun BaseActivity.accent(): Int {
    val v = TypedValue()
    theme.resolveAttribute(R.attr.p1, v, true)
    return v.data
}

fun BaseActivity.accent2(): Int {
    val v = TypedValue()
    theme.resolveAttribute(R.attr.p2, v, true)
    return v.data
}

/** Margins are in dp; [w] and [h] are raw pixels or MATCH/WRAP. */
fun BaseActivity.lp(w: Int = MATCH, h: Int = WRAP, top: Int = 0, bottom: Int = 0, start: Int = 0, end: Int = 0, weight: Float = 0f) =
    LinearLayout.LayoutParams(w, h, weight).apply {
        topMargin = dp(top); bottomMargin = dp(bottom); marginStart = dp(start); marginEnd = dp(end)
    }

fun BaseActivity.label(s: CharSequence, sp: Float = 14f, c: Int = R.color.tx, bold: Boolean = false, top: Int = 0): TextView =
    TextView(this).apply {
        text = s
        textSize = sp
        setTextColor(color(c))
        if (bold) typeface = Typeface.DEFAULT_BOLD
        layoutParams = lp(top = top)
    }

/** Full-width gradient button. */
fun BaseActivity.primary(s: CharSequence, top: Int = 14, onClick: () -> Unit): TextView =
    TextView(this).apply {
        text = s
        gravity = Gravity.CENTER
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(color(R.color.white))
        setBackgroundResource(R.drawable.btn_primary)
        layoutParams = lp(h = dp(50), top = top)
        glowView(this, accent(), 6f)
        setOnClickListener { onClick() }
    }

/** Centered text button in the accent color (or [c]). */
fun BaseActivity.link(s: CharSequence, c: Int = 0, top: Int = 0, onClick: () -> Unit): TextView =
    TextView(this).apply {
        text = s
        gravity = Gravity.CENTER
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (c == 0) accent() else color(c))
        setPadding(dp(12), dp(10), dp(12), dp(10))
        layoutParams = lp(w = WRAP, top = top)
        setOnClickListener { onClick() }
    }

fun BaseActivity.chip(s: CharSequence, on: Boolean, onClick: () -> Unit): TextView =
    TextView(this).apply {
        text = s
        textSize = 13f
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(16), 0, dp(16), 0)
        setTextColor(resources.getColorStateList(R.color.seg_text, theme))
        setBackgroundResource(R.drawable.chip_item)
        isSelected = on
        layoutParams = LinearLayout.LayoutParams(WRAP, dp(38)).apply { marginEnd = dp(8) }
        setOnClickListener { onClick() }
    }

fun BaseActivity.chipRow(labels: List<String>, sel: Int, top: Int = 12, onSel: (Int) -> Unit): View {
    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    labels.forEachIndexed { i, l -> row.addView(chip(l, i == sel) { onSel(i) }) }
    return HorizontalScrollView(this).apply {
        isHorizontalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        layoutParams = lp(top = top)
        addView(row)
    }
}

fun BaseActivity.field(h: CharSequence, lines: Int = 1, top: Int = 10, ltr: Boolean = false, number: Boolean = false): EditText =
    EditText(this).apply {
        this.hint = h
        textSize = 15f
        setTextColor(color(R.color.tx))
        setHintTextColor(color(R.color.mut))
        setBackgroundResource(R.drawable.field_bg)
        setPadding(dp(14), dp(12), dp(14), dp(12))
        minHeight = dp(52)
        if (number) inputType = InputType.TYPE_CLASS_NUMBER
        else if (lines > 1) {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            minLines = lines
            gravity = Gravity.TOP or Gravity.START
        } else {
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine()
        }
        if (ltr) {
            textDirection = View.TEXT_DIRECTION_LTR
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        }
        layoutParams = lp(top = top)
    }

fun BaseActivity.bar(pct: Int, top: Int = 8): ProgressBar =
    ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
        max = 100
        progress = pct.coerceIn(0, 100)
        progressDrawable = resources.getDrawable(R.drawable.progress_bar, theme)
        layoutParams = lp(h = dp(8), top = top)
    }

fun BaseActivity.badge(s: CharSequence, c: Int = R.color.mut): TextView =
    TextView(this).apply {
        text = s
        textSize = 11f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(color(c))
        setBackgroundResource(R.drawable.badge_bg)
        setPadding(dp(10), dp(4), dp(10), dp(4))
    }

/** Square icon button; the tint is a color or color-state-list resource. */
fun BaseActivity.iconBtn(icon: Int, tint: Int, onClick: () -> Unit): ImageView =
    ImageView(this).apply {
        setImageResource(icon)
        imageTintList = resources.getColorStateList(tint, theme)
        setPadding(dp(9), dp(9), dp(9), dp(9))
        layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
        setOnClickListener { onClick() }
    }

/** LTR text (emails, phones, codes) that still aligns to the start of an RTL screen. */
fun BaseActivity.ltrText(s: CharSequence, sp: Float = 13f, c: Int = R.color.mut, mono: Boolean = false): TextView =
    label(s, sp, c).apply {
        textDirection = View.TEXT_DIRECTION_LTR
        textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        if (mono) typeface = Typeface.MONOSPACE
    }

fun dateText(t: Long): String =
    java.text.SimpleDateFormat("yyyy/MM/dd", java.util.Locale.ENGLISH).format(java.util.Date(t))

/** Decodes a photo file scaled down so it fits [max] px. */
fun decodeScaled(f: File, max: Int): Bitmap? {
    if (!f.exists()) return null
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(f.path, o)
    var s = 1
    while (maxOf(o.outWidth, o.outHeight) / s > max) s *= 2
    return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
}

fun youtubeId(url: String): String {
    val u = url.trim()
    val m = Regex("(?:youtu\\.be/|v=|embed/|shorts/|live/)([\\w-]{11})").find(u) ?: Regex("^([\\w-]{11})$").find(u)
    return m?.groupValues?.get(1) ?: ""
}

/** A row of chips where exactly one is selected; [onSel] gets the index. */
fun BaseActivity.singleChoice(labels: List<String>, sel: Int = 0, top: Int = 12, onSel: (Int) -> Unit): View {
    val chips = ArrayList<TextView>()
    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    labels.forEachIndexed { i, l ->
        val c = chip(l, i == sel) {
            onSel(i)
            chips.forEachIndexed { j, v -> v.isSelected = j == i }
        }
        chips.add(c)
        row.addView(c)
    }
    return HorizontalScrollView(this).apply {
        isHorizontalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        layoutParams = lp(top = top)
        addView(row)
    }
}
