package com.moknight.nexoraedu

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.MediaController
import android.widget.VideoView

/**
 * Player for a video file uploaded to the platform (release 35). SKELETON: plain VideoView + system controls.
 * TODO: the same custom controls as [VideoActivity] (skip 5/10/15/30 s, speed 0.5x-2x, resume position, full screen, error + retry).
 * TODO(server): stream from the server URL (HTTPS, protected) instead of the local file.
 */
class UploadVideoActivity : BaseActivity() {
    override val aurora: Boolean get() = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val v = VideoView(this)
        val mc = MediaController(this).also { it.setAnchorView(v) }
        v.setMediaController(mc)
        setContentView(FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(v, FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER))
        })
        val id = (intent.getStringExtra("id") ?: "").filter { it.isLetterOrDigit() }
        val f = Store.videoFile(this, id)
        if (!f.exists()) { finish(); return }
        v.setVideoPath(f.absolutePath)
        v.setOnPreparedListener { it.start() }
    }
}
