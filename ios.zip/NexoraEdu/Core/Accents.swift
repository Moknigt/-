import SwiftUI

/// Accent themes (same ids and colours as Android `Accents.kt` / `colors.xml` th_<id>_1 / _2).
/// "nexora" = the normal colours of each side (student teal/blue, teacher purple, admin gold/orange).
struct Accent: Identifiable {
    let id: String
    let nameKey: String
    let c1: UInt32
    let c2: UInt32
}

enum Accents {
    static let defaultId = "nexora"

    /// Every theme except the default one.
    static let custom: [Accent] = [
        Accent(id: "ocean", nameKey: "th_ocean", c1: 0x0EA5E9, c2: 0x2563EB),
        Accent(id: "emerald", nameKey: "th_emerald", c1: 0x22C55E, c2: 0x0F766E),
        Accent(id: "sunset", nameKey: "th_sunset", c1: 0xF97316, c2: 0xEF4444),
        Accent(id: "rose", nameKey: "th_rose", c1: 0xF43F5E, c2: 0xEC4899),
        Accent(id: "violet", nameKey: "th_violet", c1: 0x8B5CF6, c2: 0x6366F1),
        Accent(id: "gold", nameKey: "th_gold", c1: 0xF59E0B, c2: 0xD97706),
        Accent(id: "crimson", nameKey: "th_crimson", c1: 0xDC2626, c2: 0x9F1239),
        Accent(id: "aurora", nameKey: "th_aurora", c1: 0x06B6D4, c2: 0x8B5CF6),
        Accent(id: "candy", nameKey: "th_candy", c1: 0xF472B6, c2: 0xA78BFA),
        Accent(id: "lime", nameKey: "th_lime", c1: 0x84CC16, c2: 0x16A34A),
        Accent(id: "slate", nameKey: "th_slate", c1: 0x64748B, c2: 0x334155),
    ]

    static func find(_ id: String) -> Accent? { custom.first { $0.id == id } }
}
