import Foundation
import UIKit
import UserNotifications
import BackgroundTasks

/// Release 55 (same as Android `AdminControl.kt`, release 54; server side = server/supabase/004_admin_control.sql).
///  - the FIRST admin is the MAIN admin; an admin removes teachers, only the main admin removes another admin;
///  - the main admin is told (in the app and with a phone notification) each time a teacher or an admin signs up / signs in;
///  - a removed account is signed out and its local account is wiped the next time the app is opened with internet.
/// The server decides everything. The app only asks and shows. Every callback runs on the main thread.
enum AdminControl {
    struct Status { let role: String; let main: Bool; let removed: Bool }
    struct Staff: Identifiable { let id: String; let role: String; let name: String; let email: String; let main: Bool; let removed: Bool; let at: Date }
    /// `kind` = signup | signin | removed; `role` = teacher | admin.
    struct Event: Identifiable { let id: Int; let kind: String; let role: String; let userId: String; let name: String; let email: String; let at: Date }

    private static let d = UserDefaults.standard
    private static let mainKey = "admincontrol.main"
    private static let lastKey = "admincontrol.last_event"
    private static let askedKey = "admincontrol.asked"
    static let taskId = "com.moknight.nexoraedu.alerts"

    /// Cached answer of the server: true only for the main admin who is signed in on this phone.
    static var isMain: Bool { d.bool(forKey: mainKey) }

    private static var ar: Bool { (d.object(forKey: "pref_ar") as? Bool) ?? true }

    private static func object(_ data: Data) -> [String: Any]? { (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] }
    private static func array(_ data: Data) -> [[String: Any]]? { (try? JSONSerialization.jsonObject(with: data)) as? [[String: Any]] }

    private static func parse(_ s: String) -> Date {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX"); f.timeZone = TimeZone(identifier: "UTC"); f.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        return f.date(from: String(s.prefix(19))) ?? Date(timeIntervalSince1970: 0)
    }

    // MARK: server calls

    static func status(done: @escaping (Status?) -> Void) {
        Remote.api("POST", "/rest/v1/rpc/my_status", body: [:]) { c, data in
            guard c == 200, let o = object(data) else { done(nil); return }
            done(Status(role: o["role"] as? String ?? "", main: o["main"] as? Bool ?? false, removed: o["removed"] as? Bool ?? false))
        }
    }

    /// Release 57: answer of register_admin. `reason` = "" | "code" (missing / wrong / used / expired) | "locked" (5 wrong tries, wait an hour).
    struct AdminReg { let ok: Bool; let main: Bool; let reason: String }

    /// Becomes admin on the server. The first admin ever = main admin (no code); every other one needs a one-time code from the main admin
    /// (`code`, XXXXXX-YYYYYY). Answers nil when the server refused / no network.
    static func registerAdmin(code: String = "", done: @escaping (AdminReg?) -> Void) {
        Remote.api("POST", "/rest/v1/rpc/register_admin", body: ["p_code": code]) { c, data in
            guard c == 200, let o = object(data) else { done(nil); return }
            let r = AdminReg(ok: o["ok"] as? Bool ?? false, main: o["main"] as? Bool ?? false, reason: o["reason"] as? String ?? "")
            if r.ok { d.set(r.main, forKey: mainKey) }
            done(r)
        }
    }

    /// Release 57: main admin only. A new one-time activation code (shown once). Answers nil when refused / no network.
    static func newCode(done: @escaping (String?) -> Void) {
        Remote.api("POST", "/rest/v1/rpc/new_admin_code", body: [:]) { c, data in
            guard c == 200 else { done(nil); return }
            let t = (String(data: data, encoding: .utf8) ?? "").trimmingCharacters(in: CharacterSet(charactersIn: "\" \n\r\t"))
            done(t.isEmpty ? nil : t)
        }
    }

    static func logEntry(kind: String) {
        Remote.api("POST", "/rest/v1/rpc/log_entry", body: ["p_kind": kind]) { _, _ in }
    }

    /// Called by `ServerSync` right after a teacher / admin is signed in on the server. `kind` = "signup" | "signin". Silent.
    static func entered(role: String, kind: String) {
        guard role == "teacher" || role == "admin" else { return }
        if role == "admin" { registerAdmin { _ in logEntry(kind: kind) } }   // the first admin ever becomes the main admin here
        else { logEntry(kind: kind) }
    }

    static func staff(done: @escaping ([Staff]?) -> Void) {
        Remote.api("POST", "/rest/v1/rpc/staff_list", body: [:]) { c, data in
            guard c == 200, let a = array(data) else { done(nil); return }
            done(a.map {
                Staff(id: $0["id"] as? String ?? "", role: $0["role"] as? String ?? "", name: $0["name"] as? String ?? "",
                      email: $0["email"] as? String ?? "", main: $0["main"] as? Bool ?? false, removed: $0["removed"] as? Bool ?? false,
                      at: parse($0["at"] as? String ?? ""))
            })
        }
    }

    /// Unread alerts, newest first. The server returns rows only to the main admin (anyone else gets an empty list).
    static func events(done: @escaping ([Event]?) -> Void) {
        Remote.api("GET", "/rest/v1/security_events?seen=eq.false&kind=neq.removed&order=id.desc&limit=50&select=id,kind,role,user_id,name,email,at", body: nil) { c, data in
            guard c == 200, let a = array(data) else { done(nil); return }
            done(a.map {
                Event(id: $0["id"] as? Int ?? 0, kind: $0["kind"] as? String ?? "", role: $0["role"] as? String ?? "",
                      userId: $0["user_id"] as? String ?? "", name: $0["name"] as? String ?? "", email: $0["email"] as? String ?? "",
                      at: parse($0["at"] as? String ?? ""))
            })
        }
    }

    /// false = refused or no network (the server refuses: yourself, the main admin, an admin when you are not the main admin).
    static func remove(_ userId: String, done: @escaping (Bool) -> Void) {
        Remote.api("POST", "/rest/v1/rpc/remove_account", body: ["p_user": userId, "p_reason": ""]) { c, data in
            done(c == 200 && (String(data: data, encoding: .utf8) ?? "").trimmingCharacters(in: .whitespacesAndNewlines) == "true")
        }
    }

    static func markSeen(done: @escaping () -> Void) {
        Remote.api("POST", "/rest/v1/rpc/mark_events_seen", body: [:]) { _, _ in done() }
    }

    // MARK: removed account

    /// Call when the app opens / comes back to the front. Asks the server who this account is: removed -> signed out and its local
    /// account wiped; main admin -> alerts are scheduled and any new ones become phone notifications. No internet: nothing happens.
    static func check(_ store: Store) {
        guard let s = store.session, s.role == "teacher" || s.role == "admin", Remote.enabled, ServerSync.mirrored(s.email) else { return }
        status { st in
            guard let st = st else { return }
            if st.removed { wipe(store, role: s.role); return }
            let isMain = s.role == "admin" && st.main
            d.set(isMain, forKey: mainKey)
            if isMain {
                askNotifications()
                scheduleBackground()
                events { if let l = $0 { notifyNew(l) } }
            }
        }
    }

    private static func wipe(_ store: Store, role: String) {
        store.clearSession()
        if role == "teacher" { store.deleteTeacher() } else { store.deleteAdmin() }
        ServerSync.signOut()
        let text = L10n.tr("acct_removed", ar: ar)
        let ok = L10n.tr("close", ar: ar)
        var vc = UIApplication.shared.connectedScenes.compactMap { ($0 as? UIWindowScene)?.keyWindow }.first?.rootViewController
        while let p = vc?.presentedViewController { vc = p }
        let a = UIAlertController(title: nil, message: text, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: ok, style: .default))
        vc?.present(a, animated: true)
    }

    /// Sign-out / removal: stop the alerts. The last alert already shown is kept, so it is not shown again after the next sign-in.
    static func reset() {
        BGTaskScheduler.shared.cancel(taskRequestWithIdentifier: taskId)
        d.removeObject(forKey: mainKey)
    }

    // MARK: phone notifications (no push server: local notifications from a background refresh + a check each time the app opens)

    static func askNotifications() {
        guard !d.bool(forKey: askedKey) else { return }
        d.set(true, forKey: askedKey)
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { _, _ in }
    }

    static func alertText(_ e: Event, ar: Bool) -> String {
        let who = e.name.isEmpty ? e.email : e.name
        let key = e.role == "admin" ? (e.kind == "signup" ? "alert_signup_admin" : "alert_signin_admin")
                                    : (e.kind == "signup" ? "alert_signup_teacher" : "alert_signin_teacher")
        return String(format: L10n.tr(key, ar: ar), who)
    }

    /// One notification for the alerts newer than the last one already shown.
    static func notifyNew(_ list: [Event]) {
        let last = d.integer(forKey: lastKey)
        let fresh = list.filter { $0.id > last }
        guard let newest = fresh.map({ $0.id }).max() else { return }
        let center = UNUserNotificationCenter.current()
        center.getNotificationSettings { s in
            guard s.authorizationStatus == .authorized || s.authorizationStatus == .provisional else { return }   // not shown = not marked, nothing is lost
            d.set(newest, forKey: lastKey)
            let c = UNMutableNotificationContent()
            c.title = L10n.tr("notif_title", ar: ar)
            c.body = fresh.count == 1 ? alertText(fresh[0], ar: ar) : String(format: L10n.tr("notif_many", ar: ar), fresh.count)
            c.sound = .default
            center.add(UNNotificationRequest(identifier: "security-\(newest)", content: c, trigger: nil))
        }
    }

    /// Must be called once while the app starts (before it finishes launching).
    static func registerBackground() {
        BGTaskScheduler.shared.register(forTaskWithIdentifier: taskId, using: nil) { task in
            scheduleBackground()   // the next round
            guard isMain, Remote.signedIn else { task.setTaskCompleted(success: true); return }
            events { l in
                if let l = l { notifyNew(l) }
                task.setTaskCompleted(success: l != nil)
            }
        }
    }

    /// iOS decides when this really runs (often every few hours, less when the phone is idle): it is not a 15-minute timer.
    static func scheduleBackground() {
        guard isMain else { return }
        let r = BGAppRefreshTaskRequest(identifier: taskId)
        r.earliestBeginDate = Date(timeIntervalSinceNow: 15 * 60)
        try? BGTaskScheduler.shared.submit(r)
    }
}
