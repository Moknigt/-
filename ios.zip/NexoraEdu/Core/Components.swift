import SwiftUI

/// Full-width gradient button.
struct PrimaryButton: View {
    @Environment(\.theme) private var th
    let title: String
    var height: CGFloat = 50
    var fontSize: CGFloat = 15
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: fontSize, weight: .bold))
                .foregroundColor(Color.white)
                .frame(maxWidth: .infinity, minHeight: height)
                .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(th.gradient))
        }
        .buttonStyle(.plain).sfxTap()
    }
}

/// Centered text button in the accent color (or `color`).
struct LinkButton: View {
    @Environment(\.theme) private var th
    let title: String
    var color: Color? = nil
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 14, weight: .bold))
                .foregroundColor(color ?? th.p1)
                .padding(.horizontal, 12)
                .padding(.vertical, 10)
        }
        .buttonStyle(.plain).sfxTap()
    }
}

/// A rounded input row: icon on the start side, content (text field...) after it.
struct FieldRow<Content: View>: View {
    @Environment(\.theme) private var th
    let icon: String
    let content: Content

    init(icon: String, @ViewBuilder content: () -> Content) {
        self.icon = icon
        self.content = content()
    }

    var body: some View {
        HStack(spacing: 0) {
            Image(systemName: icon)
                .font(.system(size: 17))
                .foregroundColor(th.mut)
                .frame(width: 22, height: 22)
            content
                .padding(.horizontal, 10)
        }
        .padding(.leading, 12)
        .padding(.trailing, 6)
        .frame(height: 52)
        .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(th.field))
        .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(th.bd, lineWidth: 1))
    }
}

/// Two-or-more option switch (student / teacher, dark / light, Arabic / English).
struct SegmentedPills: View {
    @Environment(\.theme) private var th
    let options: [String]
    let selected: Int
    let onSelect: (Int) -> Void

    var body: some View {
        HStack(spacing: 0) {
            ForEach(options.indices, id: \.self) { i in
                Button {
                    if i != selected { Sfx.shared.play(.tab) }
                    onSelect(i)
                } label: {
                    Text(options[i])
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(i == selected ? Color.white : th.tx)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .background(
                            RoundedRectangle(cornerRadius: 13, style: .continuous)
                                .fill(i == selected ? AnyShapeStyle(th.gradient) : AnyShapeStyle(Color.clear))
                        )
                }
                .buttonStyle(.plain).sfxTap()
            }
        }
        .padding(3)
        .frame(height: 46)
        .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(th.field))
        .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(th.bd, lineWidth: 1))
    }
}

/// Horizontal shake used when a login attempt fails (bump `animatableData` inside withAnimation).
struct Shake: GeometryEffect {
    var amount: CGFloat = 12
    var shakes: CGFloat = 3
    var animatableData: CGFloat

    func effectValue(size: CGSize) -> ProjectionTransform {
        let phase: CGFloat = animatableData * CGFloat.pi * shakes * 2
        return ProjectionTransform(CGAffineTransform(translationX: amount * sin(phase), y: 0))
    }
}
