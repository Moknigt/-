import SwiftUI

/// The NEXORA flask logo, drawn from the same 64x64 vector as the Android `ic_flask.xml`.
struct FlaskMark: View {
    private static let rim: Path = {
        var p = Path()
        p.move(to: CGPoint(x: 24, y: 9))
        p.addLine(to: CGPoint(x: 40, y: 9))
        return p
    }()

    private static let glass: Path = {
        var p = Path()
        p.move(to: CGPoint(x: 28, y: 9))
        p.addLine(to: CGPoint(x: 28, y: 24))
        p.addLine(to: CGPoint(x: 12.5, y: 51.5))
        p.addQuadCurve(to: CGPoint(x: 16, y: 57), control: CGPoint(x: 9.5, y: 57))
        p.addLine(to: CGPoint(x: 48, y: 57))
        p.addQuadCurve(to: CGPoint(x: 51.5, y: 51.5), control: CGPoint(x: 54.5, y: 57))
        p.addLine(to: CGPoint(x: 36, y: 24))
        p.addLine(to: CGPoint(x: 36, y: 9))
        return p
    }()

    private static let wave: Path = {
        var p = Path()
        p.move(to: CGPoint(x: 18, y: 42))
        p.addQuadCurve(to: CGPoint(x: 32, y: 42), control: CGPoint(x: 25, y: 38))
        p.addQuadCurve(to: CGPoint(x: 46, y: 42), control: CGPoint(x: 39, y: 46))
        return p
    }()

    private static func orbit(_ degrees: CGFloat) -> Path {
        let e = Path(ellipseIn: CGRect(x: 23.5, y: 46, width: 17, height: 6))
        let t = CGAffineTransform(translationX: 32, y: 49)
            .rotated(by: degrees * .pi / 180)
            .translatedBy(x: -32, y: -49)
        return e.applying(t)
    }

    private static func circle(_ x: CGFloat, _ y: CGFloat, _ r: CGFloat) -> Path {
        Path(ellipseIn: CGRect(x: x - r, y: y - r, width: r * 2, height: r * 2))
    }

    private func line(_ p: Path, _ width: CGFloat, _ s: CGFloat) -> some View {
        p.applying(CGAffineTransform(scaleX: s, y: s))
            .stroke(Color.white, style: StrokeStyle(lineWidth: width * s, lineCap: .round, lineJoin: .round))
    }

    var body: some View {
        GeometryReader { geo in
            let s = min(geo.size.width, geo.size.height) / 64
            ZStack {
                line(FlaskMark.rim, 2.3, s)
                line(FlaskMark.glass, 2.3, s)
                line(FlaskMark.wave, 2.3, s)
                line(FlaskMark.orbit(-30), 1.6, s)
                line(FlaskMark.orbit(30), 1.6, s)
                FlaskMark.circle(32, 49, 2.4)
                    .applying(CGAffineTransform(scaleX: s, y: s))
                    .fill(Color(hex: 0xF5C451))
                line(FlaskMark.circle(32, 19, 1.7), 1.5, s)
                line(FlaskMark.circle(33.5, 14, 1.1), 1.3, s)
            }
            .frame(width: geo.size.width, height: geo.size.height)
        }
        .aspectRatio(1, contentMode: .fit)
    }
}
