import Foundation

// Models mirror the Android data classes. The JSON keys are the same short keys the Android Store uses.

extension KeyedDecodingContainer {
    /// Reads a value, falling back to [def] when the key is missing or has the wrong type.
    func val<T: Decodable>(_ key: Key, _ def: T) -> T {
        (try? decodeIfPresent(T.self, forKey: key)) ?? def
    }
}

/// A chapter (باب) groups lessons.
struct Chapter: Codable, Identifiable, Equatable {
    var id: String
    var title: String
    /// Course price in EGP, 0 = free (Android key `pr`).
    var price: Int
    /// Release 66: the class this belongs to (one of Store.defaultGrades). "" = for every class (Android key `gr`).
    var grade: String
    enum CodingKeys: String, CodingKey { case id = "i", title = "t", price = "pr", grade = "gr" }
    init(id: String, title: String, price: Int = 0, grade: String = "") { self.id = id; self.title = title; self.price = price; self.grade = grade }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = c.val(.id, ""); title = c.val(.title, ""); price = c.val(.price, 0); grade = c.val(.grade, "")
    }
}

/// A lesson. `chapterId` is empty for a standalone YouTube video. `yt` is the 11-char YouTube id (may be empty).
struct Lesson: Codable, Identifiable, Equatable {
    var id: String
    var chapterId: String
    var title: String
    var yt: String
    var at: Int64
    /// false = hidden from the students (Android `published`, key `p`; old data without it stays visible).
    var published: Bool
    /// "yt" = YouTube link, "up" = video file uploaded to the platform (Documents/videos/<id>.mp4). Android key `s`.
    var src: String
    /// Price in EGP, 0 = free (key `pr`).
    var price: Int
    /// Thumbnail URL imported from YouTube (key `th`, may be empty).
    var thumb: String
    /// Release 66: the class (key `gr`), "" = every class.
    var grade: String
    enum CodingKeys: String, CodingKey { case id = "i", chapterId = "c", title = "t", yt = "y", at = "a", published = "p", src = "s", price = "pr", thumb = "th", grade = "gr" }
    init(id: String, chapterId: String, title: String, yt: String, at: Int64 = Util.nowMillis(), published: Bool = true,
         src: String = "yt", price: Int = 0, thumb: String = "", grade: String = "") {
        self.id = id; self.chapterId = chapterId; self.title = title; self.yt = yt; self.at = at; self.published = published
        self.src = src; self.price = price; self.thumb = thumb; self.grade = grade
    }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = c.val(.id, ""); chapterId = c.val(.chapterId, ""); title = c.val(.title, "")
        yt = c.val(.yt, ""); at = c.val(.at, Int64(0)); published = c.val(.published, true)
        src = c.val(.src, "yt"); price = c.val(.price, 0); thumb = c.val(.thumb, ""); grade = c.val(.grade, "")
    }
}

/// A PDF stored in the app's private storage (Documents/docs/<id>.pdf). `kind` is "book" or "file".
struct Doc: Codable, Identifiable, Equatable {
    var id: String
    var title: String
    var kind: String
    var at: Int64
    var grade: String   // release 66
    enum CodingKeys: String, CodingKey { case id = "i", title = "t", kind = "k", at = "a", grade = "gr" }
    init(id: String, title: String, kind: String, at: Int64 = Util.nowMillis(), grade: String = "") {
        self.id = id; self.title = title; self.kind = kind; self.at = at; self.grade = grade
    }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = c.val(.id, ""); title = c.val(.title, ""); kind = c.val(.kind, "file"); at = c.val(.at, Int64(0)); grade = c.val(.grade, "")
    }
}

/// Multiple-choice question in the teacher's question bank.
struct Question: Codable, Identifiable, Equatable {
    var id: String
    var text: String
    var chapter: String
    var options: [String]
    var answer: Int
    var grade: String   // release 66
    enum CodingKeys: String, CodingKey { case id = "i", text = "t", chapter = "c", options = "o", answer = "a", grade = "gr" }
    init(id: String, text: String, chapter: String, options: [String], answer: Int, grade: String = "") {
        self.id = id; self.text = text; self.chapter = chapter; self.options = options; self.answer = answer; self.grade = grade
    }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = c.val(.id, ""); text = c.val(.text, ""); chapter = c.val(.chapter, "")
        options = c.val(.options, [String]()); answer = c.val(.answer, 0); grade = c.val(.grade, "")
    }
}

struct Exam: Codable, Identifiable, Equatable {
    var id: String
    var title: String
    var official: Bool
    var qids: [String]
    var at: Int64
    var grade: String   // release 66
    enum CodingKeys: String, CodingKey { case id = "i", title = "t", official = "o", qids = "q", at = "a", grade = "gr" }
    init(id: String, title: String, official: Bool, qids: [String], at: Int64 = Util.nowMillis(), grade: String = "") {
        self.id = id; self.title = title; self.official = official; self.qids = qids; self.at = at; self.grade = grade
    }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = c.val(.id, ""); title = c.val(.title, ""); official = c.val(.official, false)
        qids = c.val(.qids, [String]()); at = c.val(.at, Int64(0)); grade = c.val(.grade, "")
    }
}

/// A student's result in an exam (called `Result` on Android; renamed to avoid clashing with Swift.Result).
struct ExamResult: Codable, Equatable {
    var examId: String
    var email: String
    var score: Int
    var correct: Int
    var total: Int
    var at: Int64
    enum CodingKeys: String, CodingKey { case examId = "x", email = "e", score = "s", correct = "c", total = "n", at = "a" }
    init(examId: String, email: String, score: Int, correct: Int, total: Int, at: Int64 = Util.nowMillis()) {
        self.examId = examId; self.email = email; self.score = score
        self.correct = correct; self.total = total; self.at = at
    }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        examId = c.val(.examId, ""); email = c.val(.email, ""); score = c.val(.score, 0)
        correct = c.val(.correct, 0); total = c.val(.total, 0); at = c.val(.at, Int64(0))
    }
}

struct Homework: Codable, Identifiable, Equatable {
    var id: String
    var title: String
    var note: String
    var at: Int64
    var grade: String   // release 66
    enum CodingKeys: String, CodingKey { case id = "i", title = "t", note = "n", at = "a", grade = "gr" }
    init(id: String, title: String, note: String, at: Int64 = Util.nowMillis(), grade: String = "") {
        self.id = id; self.title = title; self.note = note; self.at = at; self.grade = grade
    }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = c.val(.id, ""); title = c.val(.title, ""); note = c.val(.note, ""); at = c.val(.at, Int64(0)); grade = c.val(.grade, "")
    }
}

/// A student's answer to a homework. `photo` is the file name in Documents/hw (empty = no photo).
/// `grade` is -1 until graded (out of 10).
struct Submission: Codable, Identifiable, Equatable {
    var hwId: String
    var email: String
    var text: String
    var photo: String
    var grade: Int
    var note: String
    var at: Int64
    var id: String { hwId + "|" + email }
    enum CodingKeys: String, CodingKey { case hwId = "h", email = "e", text = "t", photo = "p", grade = "g", note = "n", at = "a" }
    init(hwId: String, email: String, text: String, photo: String, grade: Int = -1, note: String = "", at: Int64 = Util.nowMillis()) {
        self.hwId = hwId; self.email = email; self.text = text; self.photo = photo
        self.grade = grade; self.note = note; self.at = at
    }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        hwId = c.val(.hwId, ""); email = c.val(.email, ""); text = c.val(.text, ""); photo = c.val(.photo, "")
        grade = c.val(.grade, -1); note = c.val(.note, ""); at = c.val(.at, Int64(0))
    }
}

struct Note: Codable, Equatable {
    var text: String
    var date: String
    enum CodingKeys: String, CodingKey { case text = "t", date = "d" }
    init(text: String, date: String) { self.text = text; self.date = date }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        text = c.val(.text, ""); date = c.val(.date, "")
    }
}

struct Student: Codable, Identifiable, Equatable {
    var name: String
    var phone: String
    var email: String
    var pw: String
    var grade: String
    var code: String
    var active: Bool
    var id: String { email }
    enum CodingKeys: String, CodingKey { case name = "n", phone = "p", email = "e", pw = "pw", grade = "g", code = "c", active = "act" }
    init(name: String, phone: String, email: String, pw: String, grade: String, code: String = "", active: Bool = false) {
        self.name = name; self.phone = phone; self.email = email; self.pw = pw
        self.grade = grade; self.code = code; self.active = active
    }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        name = c.val(.name, ""); phone = c.val(.phone, ""); email = c.val(.email, ""); pw = c.val(.pw, "")
        grade = c.val(.grade, ""); code = c.val(.code, ""); active = c.val(.active, false)
    }
}

/// The single teacher account (email + SHA-256 of the password).
struct TeacherAccount: Codable, Equatable {
    var email: String
    var pw: String
    /// Full name typed at sign-up (Android `t_name`). Empty for old accounts: the part of the email before the @ is shown.
    var name: String = ""
    /// Phone typed at sign-up (Android `t_phone`). Required for a new teacher account; empty for old accounts.
    var phone: String = ""

    init(email: String, pw: String, name: String = "", phone: String = "") { self.email = email; self.pw = pw; self.name = name; self.phone = phone }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        email = c.val(.email, ""); pw = c.val(.pw, ""); name = c.val(.name, ""); phone = c.val(.phone, "")
    }
    enum CodingKeys: String, CodingKey { case email, pw, name, phone }

    /// Android `Store.teacherName().ifEmpty { email.substringBefore("@") }`.
    var displayName: String {
        let n = name.trimmingCharacters(in: .whitespacesAndNewlines)
        return n.isEmpty ? (email.components(separatedBy: "@").first ?? email) : n
    }
}

/// A teacher announcement shown to the students on their home (Android `Announcement`, key `ann`).
struct Announcement: Codable, Identifiable, Equatable {
    var id: String
    var title: String
    var text: String
    var at: Int64
    var grade: String   // release 66
    enum CodingKeys: String, CodingKey { case id = "i", title = "t", text = "x", at = "a", grade = "gr" }
    init(id: String, title: String, text: String, at: Int64 = Util.nowMillis(), grade: String = "") {
        self.id = id; self.title = title; self.text = text; self.at = at; self.grade = grade
    }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = c.val(.id, ""); title = c.val(.title, ""); text = c.val(.text, ""); at = c.val(.at, Int64(0)); grade = c.val(.grade, "")
    }
}

/// The single admin account (email + SHA-256 of the password). Stored under its own key, apart from the teacher.
struct AdminAccount: Codable, Equatable {
    var email: String
    var pw: String
}

/// Who is signed in: role is "teacher", "student" or "admin".
struct Session: Codable, Equatable {
    var role: String
    var email: String
}

/// Access to paid content. `target` is "l:<lessonId>" or "c:<chapterId>"; `mode` is "online", "cash" (teacher took cash) or "free" (teacher gift).
struct Grant: Codable, Equatable {
    var target: String
    var email: String
    var mode: String
    var by: String
    var at: Int64
    enum CodingKeys: String, CodingKey { case target = "t", email = "e", mode = "m", by = "b", at = "a" }
    init(target: String, email: String, mode: String, by: String, at: Int64 = Util.nowMillis()) {
        self.target = target; self.email = email; self.mode = mode; self.by = by; self.at = at
    }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        target = c.val(.target, ""); email = c.val(.email, ""); mode = c.val(.mode, "free"); by = c.val(.by, ""); at = c.val(.at, Int64(0))
    }
}
