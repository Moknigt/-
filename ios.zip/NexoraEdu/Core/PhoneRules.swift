import Foundation
import UIKit

/// Phone number rules used by the sign-up screen (student only).
/// Accepted: Egyptian mobile `01[0125]xxxxxxxx` (also written `+20 1xxxxxxxxx` / `0020 1xxxxxxxxx`) or any international
/// number `+` followed by 8 to 15 digits. Arabic-Indic digits, spaces, dashes, dots and brackets are fine.
/// Same rules, same names on Android (`PhoneRules.kt`) and Windows (`PhoneRules.cs`).
enum PhoneRules {
    /// Digits turned to 0-9, separators removed, `00` -> `+`, Egyptian `+20` -> `0`.
    static func clean(_ raw: String) -> String {
        var out = ""
        for u in raw.trimmingCharacters(in: .whitespacesAndNewlines).unicodeScalars {
            switch u.value {
            case 0x0660...0x0669: out.append(Character(UnicodeScalar(0x30 + (u.value - 0x0660))!))
            case 0x06F0...0x06F9: out.append(Character(UnicodeScalar(0x30 + (u.value - 0x06F0))!))
            case 0x30...0x39, 0x2B: out.append(Character(u))
            default: break // spaces, - . ( ) and anything else are dropped
            }
        }
        if out.hasPrefix("00") { out = "+" + out.dropFirst(2) }
        if out.hasPrefix("+201") && out.count == 13 { out = "0" + out.dropFirst(3) }
        return out
    }

    private static func allDigits(_ s: Substring) -> Bool { !s.isEmpty && s.allSatisfy { $0 >= "0" && $0 <= "9" } }

    /// The number to store, or nil when it is not valid.
    static func normalize(_ raw: String) -> String? {
        let s = clean(raw)
        if s.count == 11, s.hasPrefix("01"), allDigits(Substring(s)), "0125".contains(s[s.index(s.startIndex, offsetBy: 2)]) { return s }
        if s.hasPrefix("+") {
            let rest = s.dropFirst()
            if allDigits(rest), (8...15).contains(rest.count), rest.first != "0" { return s }
        }
        return nil
    }

    /// Localizable key of the message to show under the field, or nil when the number is fine.
    static func errorKey(_ raw: String) -> String? {
        if raw.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return "err_phone_required" }
        return normalize(raw) == nil ? "err_phone_invalid" : nil
    }
}

/// Answers of `PhoneVerifier` (and what `OtpView` shows for each).
enum OtpResult { case ok, wrong, net, expired, locked, soon, limit, fail, waiting }

/// Release 64: the phone check through WhatsApp, the STUDENT writes first (free). `send` asks the server for a short reference and opens WhatsApp
/// with a ready message that contains it; the server (wa-webhook) checks that the SENDER number is the typed number and answers with the 6-digit
/// code in the same chat; `check` sends the typed code to the server. The app never sees the right code. See server/supabase/OTP_SETUP.md.
/// After a right code the server gives a one-time token that `Remote.signUp` sends with the account. Every callback runs on the main thread.
enum PhoneVerifier {
    private static var tokenPhone = ""
    private static var token = ""
    private static var waNumber = ""
    private static var waRef = ""

    /// The token earned for exactly this phone, or "".
    static func tokenFor(_ phone: String) -> String { (!phone.isEmpty && phone == tokenPhone) ? token : "" }

    static func clear() { tokenPhone = ""; token = ""; waNumber = ""; waRef = "" }

    private static func reason(_ r: String) -> OtpResult {
        switch r {
        case "wrong": return .wrong
        case "expired": return .expired
        case "locked": return .locked
        case "too_soon": return .soon
        case "limit": return .limit
        case "waiting": return .waiting
        default: return .fail
        }
    }

    /// Opens WhatsApp with the ready message of the LAST `send` (nothing happens before one succeeded).
    static func openWhatsApp(ar: Bool) {
        guard !waNumber.isEmpty, !waRef.isEmpty else { return }
        let text = String(format: L10n.tr("otp_wa_message", ar: ar), locale: Locale(identifier: "en_US"), waRef)
        var c = URLComponents(string: "https://wa.me/" + waNumber)
        c?.queryItems = [URLQueryItem(name: "text", value: text)]
        if let url = c?.url { UIApplication.shared.open(url) }
    }

    /// New request for `phone`: on .ok WhatsApp is opened at once with the ready message.
    static func send(_ phone: String, ar: Bool, done: @escaping (OtpResult) -> Void) {
        Remote.fn("otp-start", body: ["phone": phone]) { code, o in
            if code == -1 { done(.net); return }
            if code == 200, (o["ok"] as? Bool) == true {
                waRef = o["ref"] as? String ?? ""
                waNumber = o["wa"] as? String ?? ""
                openWhatsApp(ar: ar)
                done(.ok)
            } else {
                done(reason(o["error"] as? String ?? ""))
            }
        }
    }

    /// Checks the typed `code`. .ok also stores the token for `tokenFor`.
    static func check(_ phone: String, code: String, done: @escaping (OtpResult) -> Void) {
        Remote.fn("otp-verify", body: ["phone": phone, "code": code]) { c, o in
            if c == -1 { done(.net); return }
            guard c == 200 else { done(.fail); return }
            if (o["ok"] as? Bool) == true {
                tokenPhone = phone; token = o["token"] as? String ?? ""
                done(.ok)
            } else {
                done(reason(o["reason"] as? String ?? ""))
            }
        }
    }
}
