import Foundation

/// Phone number rules used by the sign-up screen (student only).
/// Accepted: Egyptian mobile `01[0125]xxxxxxxx` (also written `+20 1xxxxxxxxx` / `0020 1xxxxxxxxx`) or any international
/// number `+` followed by 8 to 15 digits. Arabic-Indic digits, spaces, dashes, dots and brackets are fine.
/// Same rules, same names on Android (`PhoneRules.kt`) and Windows (`PhoneRules.cs`).
enum PhoneRules {
    /// Digits turned to 0-9, separators removed, `00` -> `+`, Egyptian `+20` -> `0`.
    static func clean(_ raw: String) -> String {
        var out = ""
        for u in raw.trimmingCharacters(in: .whitespacesAndNewlines).unicodeScalars {
            switch u.value {
            case 0x0660...0x0669: out.append(Character(UnicodeScalar(0x30 + (u.value - 0x0660))!))
            case 0x06F0...0x06F9: out.append(Character(UnicodeScalar(0x30 + (u.value - 0x06F0))!))
            case 0x30...0x39, 0x2B: out.append(Character(u))
            default: break // spaces, - . ( ) and anything else are dropped
            }
        }
        if out.hasPrefix("00") { out = "+" + out.dropFirst(2) }
        if out.hasPrefix("+201") && out.count == 13 { out = "0" + out.dropFirst(3) }
        return out
    }

    private static func allDigits(_ s: Substring) -> Bool { !s.isEmpty && s.allSatisfy { $0 >= "0" && $0 <= "9" } }

    /// The number to store, or nil when it is not valid.
    static func normalize(_ raw: String) -> String? {
        let s = clean(raw)
        if s.count == 11, s.hasPrefix("01"), allDigits(Substring(s)), "0125".contains(s[s.index(s.startIndex, offsetBy: 2)]) { return s }
        if s.hasPrefix("+") {
            let rest = s.dropFirst()
            if allDigits(rest), (8...15).contains(rest.count), rest.first != "0" { return s }
        }
        return nil
    }

    /// Localizable key of the message to show under the field, or nil when the number is fine.
    static func errorKey(_ raw: String) -> String? {
        if raw.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return "err_phone_required" }
        return normalize(raw) == nil ? "err_phone_invalid" : nil
    }
}

/// Sending and checking the SMS code. There is no server in the app yet, so this is the one place to connect it.
/// Only called while `OtpConfig.PhoneOtpEnabled` is true; until a real backend is wired `check` never accepts a code.
enum PhoneVerifier {
    static func send(_ phone: String) { /* TODO: call the SMS backend */ }
    static func check(_ phone: String, code: String) -> Bool { false }
}
