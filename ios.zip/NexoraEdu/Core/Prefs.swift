import SwiftUI

/// Looks strings up in ar.lproj / en.lproj directly, so the language can change while the app is running.
enum L10n {
    static func bundle(ar: Bool) -> Bundle {
        let code = ar ? "ar" : "en"
        if let p = Bundle.main.path(forResource: code, ofType: "lproj"), let b = Bundle(path: p) { return b }
        return Bundle.main
    }

    static func tr(_ key: String, ar: Bool) -> String {
        let s = bundle(ar: ar).localizedString(forKey: key, value: nil, table: nil)
        if s != key { return s }
        // Missing in the chosen language: fall back to Arabic, then to the key itself.
        return bundle(ar: true).localizedString(forKey: key, value: key, table: nil)
    }
}

/// App-level settings: language and theme (same two switches as the Android settings sheet).
final class Prefs: ObservableObject {
    @Published var ar: Bool {
        didSet { UserDefaults.standard.set(ar, forKey: "pref_ar") }
    }
    @Published var dark: Bool {
        didSet { UserDefaults.standard.set(dark, forKey: "pref_dark") }
    }

    @Published var accent: String {
        didSet { UserDefaults.standard.set(accent, forKey: "pref_accent") }
    }

    init() {
        let d = UserDefaults.standard
        ar = (d.object(forKey: "pref_ar") as? Bool) ?? true
        dark = (d.object(forKey: "pref_dark") as? Bool) ?? true
        accent = d.string(forKey: "pref_accent") ?? Accents.defaultId
    }

    func t(_ key: String) -> String {
        L10n.tr(key, ar: ar)
    }

    /// Same as `t` for strings that contain %ld / %@ placeholders.
    func tf(_ key: String, _ args: CVarArg...) -> String {
        String(format: L10n.tr(key, ar: ar), locale: Locale(identifier: "en_US"), arguments: args)
    }
}
