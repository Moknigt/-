import Foundation
import UIKit

/// Release 37, step 1 of 3: talks to Supabase (see server/supabase/001_accounts.sql and SERVER_SPEC.md).
/// NOT wired to any screen yet: today `Access.canView` still decides locally. Every callback runs on the main thread.
/// Fill the two constants with the values from Supabase -> Project Settings -> API (the anon key is public by design).
enum Remote {
    /// e.g. https://abcd1234.supabase.co (no trailing slash)
    static let baseURL = "https://xgwfxzbutkkauxilcpzf.supabase.co"
    static let anonKey = "sb_publishable_WTL6TvHBsZblJoqt8Xjbjg_vNZVLD5f"
    static var enabled: Bool { !baseURL.isEmpty && !anonKey.isEmpty }

    struct AccessResult { let allowed: Bool; let reason: String; let price: Int }
    /// `src` = "yt" or "up". For "up" the file is at storageId/storageKey (step 3).
    struct Source { let src: String; let ytId: String; let storageId: String?; let storageKey: String? }

    private static let d = UserDefaults.standard
    static var signedIn: Bool { !(d.string(forKey: "remote.jwt") ?? "").isEmpty }
    static var userId: String { d.string(forKey: "remote.uid") ?? "" }
    static func signOut() { ["remote.jwt", "remote.rt", "remote.uid"].forEach { d.removeObject(forKey: $0) } }

    private static func http(_ method: String, _ path: String, body: [String: Any]?, token: String?, extra: [String: String] = [:], done: @escaping (Int, Data) -> Void) {
        guard let url = URL(string: baseURL + path) else { done(-1, Data()); return }
        var r = URLRequest(url: url); r.httpMethod = method; r.timeoutInterval = 8
        r.setValue(anonKey, forHTTPHeaderField: "apikey")
        r.setValue("Bearer " + (token ?? anonKey), forHTTPHeaderField: "Authorization")
        r.setValue("application/json", forHTTPHeaderField: "Content-Type")
        for (k, v) in extra { r.setValue(v, forHTTPHeaderField: k) }
        if let b = body { r.httpBody = try? JSONSerialization.data(withJSONObject: b) }
        URLSession.shared.dataTask(with: r) { data, resp, _ in
            let code = (resp as? HTTPURLResponse)?.statusCode ?? -1
            DispatchQueue.main.async { done(code, data ?? Data()) }
        }.resume()
    }

    /// Release 64: calls an Edge Function without a user token (the phone code is asked BEFORE the account exists). Answers (HTTP code, JSON object); code -1 = no network.
    static func fn(_ name: String, body: [String: Any], done: @escaping (Int, [String: Any]) -> Void) {
        http("POST", "/functions/v1/" + name, body: body, token: nil) { code, data in done(code, obj(data) ?? [:]) }
    }

    private static func obj(_ data: Data) -> [String: Any]? { (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] }
    private static func text(_ data: Data) -> String { (String(data: data, encoding: .utf8) ?? "").trimmingCharacters(in: .whitespacesAndNewlines) }

    private static func save(_ o: [String: Any]) {
        d.set(o["access_token"] as? String ?? "", forKey: "remote.jwt")
        d.set(o["refresh_token"] as? String ?? "", forKey: "remote.rt")
        d.set((o["user"] as? [String: Any])?["id"] as? String ?? "", forKey: "remote.uid")
    }

    /// Signed-in call; tries once to refresh an expired token.
    static func api(_ method: String, _ path: String, body: [String: Any]?, extra: [String: String] = [:], done: @escaping (Int, Data) -> Void) {
        http(method, path, body: body, token: d.string(forKey: "remote.jwt"), extra: extra) { code, data in
            guard code == 401, let rt = d.string(forKey: "remote.rt"), !rt.isEmpty else { done(code, data); return }
            http("POST", "/auth/v1/token?grant_type=refresh_token", body: ["refresh_token": rt], token: nil) { c2, d2 in
                guard c2 == 200, let o = obj(d2) else { done(code, data); return }
                save(o)
                http(method, path, body: body, token: d.string(forKey: "remote.jwt"), extra: extra, done: done)
            }
        }
    }

    /// Student / teacher sign-in. true = signed in.
    static func signIn(email: String, password: String, done: @escaping (Bool) -> Void) {
        http("POST", "/auth/v1/token?grant_type=password", body: ["email": email, "password": password], token: nil) { code, data in
            if code == 200, let o = obj(data) { save(o); done(true) } else { done(false) }
        }
    }

    /// New STUDENT account. The role is always "student" on the server. true = created (turn OFF "Confirm email" in Supabase, or students must confirm first).
    static func signUp(email: String, password: String, name: String, phone: String, grade: String, done: @escaping (Bool) -> Void) {
        var meta: [String: Any] = ["full_name": name, "phone": phone, "grade": grade]
        let tok = PhoneVerifier.tokenFor(phone)
        if !tok.isEmpty { meta["phone_token"] = tok }   // release 64: proof that this phone got the WhatsApp code
        let body: [String: Any] = ["email": email, "password": password, "data": meta]
        http("POST", "/auth/v1/signup", body: body, token: nil) { code, data in
            if code == 200, let o = obj(data), o["access_token"] != nil { save(o) }
            done(code == 200)
        }
    }

    /// Turns the signed-in account into a teacher with a registration code (works once, on any device).
    static func claimTeacher(code: String, done: @escaping (Bool) -> Void) {
        api("POST", "/rest/v1/rpc/claim_teacher", body: ["p_code": code]) { c, data in done(c == 200 && text(data) == "true") }
    }

    /// Server decision for one lesson (uuid). nil = network error: show retry, never open.
    static func access(lessonId: String, done: @escaping (AccessResult?) -> Void) {
        api("POST", "/rest/v1/rpc/access_lesson", body: ["p_lesson": lessonId]) { c, data in
            guard c == 200, let o = obj(data) else { done(nil); return }
            done(AccessResult(allowed: o["allowed"] as? Bool ?? false, reason: o["reason"] as? String ?? "", price: o["price"] as? Int ?? 0))
        }
    }

    /// The ONLY way the player gets the video source. nil = locked or network error.
    static func playSource(lessonId: String, done: @escaping (Source?) -> Void) {
        api("POST", "/rest/v1/rpc/play_source", body: ["p_lesson": lessonId]) { c, data in
            guard c == 200, let o = obj(data) else { done(nil); return }
            done(Source(src: o["src"] as? String ?? "", ytId: o["ytId"] as? String ?? "", storageId: o["storageId"] as? String, storageKey: o["storageKey"] as? String))
        }
    }

    /// Teacher: open for a student (cash / free). `student` = profile uuid, `target` = "l:<lesson uuid>" or "c:<chapter uuid>".
    static func grant(student: String, target: String, mode: String, done: @escaping (Bool) -> Void) {
        let body: [String: Any] = ["p_student": student, "p_type": target.hasPrefix("c:") ? "chapter" : "lesson", "p_target": String(target.dropFirst(2)), "p_mode": mode]
        api("POST", "/rest/v1/rpc/teacher_grant", body: body) { c, _ in done(c == 200) }
    }

    /// Teacher: close a grant (the log line stays).
    static func revoke(grantId: String, done: @escaping (Bool) -> Void) {
        api("POST", "/rest/v1/rpc/teacher_revoke", body: ["p_grant": grantId]) { c, data in done(c == 200 && text(data) == "true") }
    }

    /// Teacher: delete a video (the server refuses anyone else; 0 rows = refused).
    static func deleteVideo(lessonId: String, done: @escaping (Bool) -> Void) {
        api("DELETE", "/rest/v1/lessons?id=eq." + lessonId, body: nil, extra: ["Prefer": "return=representation"]) { c, data in
            let rows = (try? JSONSerialization.jsonObject(with: data)) as? [Any] ?? []
            done((200...299).contains(c) && !rows.isEmpty)
        }
    }
}

/// Electronic payment (Paymob), release 38 = step 2 of 3. NOT wired to any screen yet; `Payments.start` still returns false.
/// Flow: `createOrder` (the SERVER decides the price) -> `open` the Paymob page in Safari -> `pollStatus` until "paid"
/// -> ask `Remote.access` again and open the content. Paying is never trusted from the screen: only the server webhook marks an order paid.
/// createOrder gives nil when it fails or when the content is already open (then just call `Remote.access`).
/// Status values: pending, paid, failed, refunded, mismatch, missing.
enum PaymentFlow {
    struct Order { let id: String; let amount: Int; let checkoutUrl: String }

    /// `target` = "l:<lesson uuid>" or "c:<chapter uuid>".
    static func createOrder(target: String, done: @escaping (Order?) -> Void) {
        let body: [String: Any] = ["target_type": target.hasPrefix("c:") ? "chapter" : "lesson", "target_id": String(target.dropFirst(2))]
        Remote.api("POST", "/functions/v1/create-order", body: body) { code, data in
            guard code == 200, let o = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] else { done(nil); return }
            done(Order(id: o["orderId"] as? String ?? "", amount: o["amount"] as? Int ?? 0, checkoutUrl: o["checkoutUrl"] as? String ?? ""))
        }
    }

    /// Opens the Paymob checkout page in Safari. No card data is ever typed inside the app.
    static func open(_ o: Order) { if let u = URL(string: o.checkoutUrl) { UIApplication.shared.open(u) } }

    /// One check (also call it when the app returns to the foreground).
    static func statusOnce(orderId: String, done: @escaping (String) -> Void) {
        Remote.api("POST", "/rest/v1/rpc/order_status", body: ["p_order": orderId]) { code, data in
            let t = (String(data: data, encoding: .utf8) ?? "").trimmingCharacters(in: CharacterSet(charactersIn: "\" \n"))
            done(code == 200 ? t : "pending")
        }
    }

    /// Checks every 3 s (up to about 10 minutes) until the status is not "pending"; gives "pending" if time ran out.
    static func pollStatus(orderId: String, tries: Int = 200, done: @escaping (String) -> Void) {
        statusOnce(orderId: orderId) { st in
            if st != "pending" || tries <= 1 { done(st); return }
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) { pollStatus(orderId: orderId, tries: tries - 1, done: done) }
        }
    }
}

// MARK: - Release 41, step 3 part 3: storages (upload, play link, storage list)
// The apps know NO R2 key, endpoint or bucket. The only limits they ever see come from the server answers below.
extension Remote {
    /// Why an upload did not finish. Each one has its own ar + en message (see `message`).
    enum UploadError: String {
        case full      // every storage is full            -> up_err_full
        case off       // storage switched off / not set up -> up_err_off
        case tooBig    // file over the server limit        -> up_err_big
        case failed    // anything else (network, expired)   -> up_err_fail

        var messageKey: String {
            switch self {
            case .full: return "up_err_full"
            case .off: return "up_err_off"
            case .tooBig: return "up_err_big"
            case .failed: return "up_err_fail"
            }
        }
    }

    enum UploadResult { case ok(Int64); case cancelled; case fail(UploadError) }

    /// Keep it to be able to cancel. `cancel()` stops the transfer and frees the reserved space on the server.
    final class UploadHandle {
        fileprivate var task: URLSessionUploadTask?
        fileprivate var reservationId: String?
        fileprivate(set) var cancelled = false
        func cancel() {
            cancelled = true
            task?.cancel()
            if task == nil, let r = reservationId { Remote.cancelReservation(r) }   // before the PUT started
        }
    }

    private final class ProgressDelegate: NSObject, URLSessionTaskDelegate {
        let onProgress: (Double) -> Void
        init(_ p: @escaping (Double) -> Void) { onProgress = p }
        func urlSession(_ s: URLSession, task: URLSessionTask, didSendBodyData b: Int64, totalBytesSent sent: Int64, totalBytesExpectedToSend total: Int64) {
            guard total > 0 else { return }
            let f = Double(sent) / Double(total)
            DispatchQueue.main.async { self.onProgress(min(1, max(0, f))) }
        }
    }

    private static func reason(_ data: Data) -> String { obj(data)?["error"] as? String ?? "" }

    private static func uploadError(_ r: String) -> UploadError {
        switch r {
        case "full": return .full
        case "not_allowed", "storage_not_configured": return .off
        case "bad_size", "too_large": return .tooBig
        default: return .failed
        }
    }

    fileprivate static func cancelReservation(_ id: String) {
        api("POST", "/functions/v1/upload-complete", body: ["reservationId": id, "cancel": true]) { _, _ in }
    }

    /// 1) upload-url (the server reserves the exact size) 2) PUT the file to the link 3) upload-complete (the server checks the real size).
    /// `progress` 0...1 on the main thread. The result is on the main thread.
    @discardableResult
    static func uploadVideo(lessonId: String, file: URL, progress: @escaping (Double) -> Void, done: @escaping (UploadResult) -> Void) -> UploadHandle {
        let h = UploadHandle()
        let size = ((try? FileManager.default.attributesOfItem(atPath: file.path))?[.size] as? NSNumber)?.int64Value ?? 0
        guard size > 0 else { DispatchQueue.main.async { done(.fail(.failed)) }; return h }
        let ext = file.pathExtension.lowercased()
        var body: [String: Any] = ["lessonId": lessonId, "sizeBytes": size]
        if !ext.isEmpty { body["ext"] = ext }

        api("POST", "/functions/v1/upload-url", body: body) { code, data in
            guard code == 200, let o = obj(data), let rid = o["reservationId"] as? String,
                  let link = o["uploadUrl"] as? String, let url = URL(string: link) else {
                done(.fail(uploadError(reason(data)))); return
            }
            h.reservationId = rid
            if h.cancelled { cancelReservation(rid); done(.cancelled); return }

            var r = URLRequest(url: url); r.httpMethod = "PUT"; r.timeoutInterval = 600
            r.setValue(String(size), forHTTPHeaderField: "Content-Length")   // must equal the reserved size
            let cfg = URLSessionConfiguration.default; cfg.timeoutIntervalForResource = 3600
            let session = URLSession(configuration: cfg, delegate: ProgressDelegate(progress), delegateQueue: nil)
            let t = session.uploadTask(with: r, fromFile: file) { _, resp, err in
                session.finishTasksAndInvalidate()
                let ok = err == nil && (200...299).contains((resp as? HTTPURLResponse)?.statusCode ?? -1)
                DispatchQueue.main.async {
                    h.task = nil
                    if h.cancelled { cancelReservation(rid); done(.cancelled); return }
                    if !ok { cancelReservation(rid); done(.fail(.failed)); return }
                    complete(rid, tries: 3, done: done)
                }
            }
            h.task = t
            t.resume()
        }
        return h
    }

    /// upload-complete; a network problem or 502 (storage_unreachable) is retried, the file is already safe in the bucket.
    private static func complete(_ rid: String, tries: Int, done: @escaping (UploadResult) -> Void) {
        api("POST", "/functions/v1/upload-complete", body: ["reservationId": rid]) { code, data in
            if code == 200, let o = obj(data), o["ok"] as? Bool == true {
                done(.ok((o["sizeBytes"] as? NSNumber)?.int64Value ?? 0)); return
            }
            if (code == -1 || code == 502) && tries > 1 {
                DispatchQueue.main.asyncAfter(deadline: .now() + 2) { complete(rid, tries: tries - 1, done: done) }
                return
            }
            done(.fail(uploadError(reason(data))))
        }
    }

    // MARK: Play link

    struct PlayLink { let src: String; let url: String; let ytId: String; let expiresIn: Int }
    enum PlayResult { case link(PlayLink); case locked; case noFile; case failed }

    /// Message key (ar + en) for a play problem; nil when there is a link.
    static func playMessageKey(_ r: PlayResult) -> String? {
        switch r {
        case .link: return nil
        case .locked: return "pl_err_locked"
        case .noFile: return "pl_err_nofile"
        case .failed: return "pl_err_fail"
        }
    }

    /// The ONLY way to get a playable address: "up" gives a temporary link (about 3 h, ask again when it ends), "yt" gives the YouTube id.
    static func playUrl(lessonId: String, done: @escaping (PlayResult) -> Void) {
        api("POST", "/functions/v1/play-url", body: ["lessonId": lessonId]) { code, data in
            switch code {
            case 200:
                guard let o = obj(data), let s = o["src"] as? String else { done(.failed); return }
                done(.link(PlayLink(src: s, url: o["url"] as? String ?? "", ytId: o["ytId"] as? String ?? "", expiresIn: o["expiresIn"] as? Int ?? 0)))
            case 403: done(.locked)
            case 404: done(.noFile)
            default: done(.failed)
            }
        }
    }

    // MARK: Storage list (read only; the admin edits name / limit / on-off / order)

    struct StorageInfo {
        let id: String
        var name: String
        var limitBytes: Int64
        let usedBytes: Int64
        let reservedBytes: Int64
        var active: Bool
        var sortOrder: Int
        /// (used + reserved) / limit, 0...1 for the bar.
        var fraction: Double { limitBytes > 0 ? min(1, Double(usedBytes + reservedBytes) / Double(limitBytes)) : 0 }
    }

    private static func num(_ v: Any?) -> Int64 { (v as? NSNumber)?.int64Value ?? 0 }

    /// nil = network error / not allowed. Teacher and admin only (the server decides).
    static func storages(done: @escaping ([StorageInfo]?) -> Void) {
        api("GET", "/rest/v1/storages?select=id,name,limit_bytes,used_bytes,reserved_bytes,active,sort_order&order=sort_order", body: nil) { code, data in
            guard code == 200, let rows = (try? JSONSerialization.jsonObject(with: data)) as? [[String: Any]] else { done(nil); return }
            done(rows.map {
                StorageInfo(id: "\($0["id"] ?? "")", name: $0["name"] as? String ?? "", limitBytes: num($0["limit_bytes"]),
                            usedBytes: num($0["used_bytes"]), reservedBytes: num($0["reserved_bytes"]),
                            active: $0["active"] as? Bool ?? false, sortOrder: Int(num($0["sort_order"])))
            })
        }
    }

    /// Admin only. The server refuses a limit above its own cap (false); the app never knows that number.
    static func updateStorage(_ s: StorageInfo, done: @escaping (Bool) -> Void) {
        let body: [String: Any] = ["name": s.name, "limit_bytes": s.limitBytes, "active": s.active, "sort_order": s.sortOrder]
        api("PATCH", "/rest/v1/storages?id=eq." + s.id, body: body, extra: ["Prefer": "return=representation"]) { c, data in
            let rows = (try? JSONSerialization.jsonObject(with: data)) as? [Any] ?? []
            done((200...299).contains(c) && !rows.isEmpty)
        }
    }
}
