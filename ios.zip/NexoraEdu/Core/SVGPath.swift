import SwiftUI

/// One <path> of an Android vector icon (24x24 viewport).
struct IconPart {
    let d: String
    let fill: Bool
    let stroke: CGFloat      // 0 = no stroke
    let cap: Bool            // round line cap
    let join: Bool           // round line join

    init(_ d: String, fill: Bool, stroke: CGFloat, cap: Bool, join: Bool) {
        self.d = d; self.fill = fill; self.stroke = stroke; self.cap = cap; self.join = join
    }
}

/// All app icons, drawn from the same path data as the Android `ic_*.xml` files (see Icons.swift, generated).
enum Icons {
    private static var cache: [String: Path] = [:]

    static func path(_ d: String) -> Path {
        if let p = cache[d] { return p }
        let p = SVGPath.parse(d)
        cache[d] = p
        return p
    }
}

/// Parser for the SVG path syntax used by Android vector drawables (M L H V C S Q T A Z, absolute and relative).
enum SVGPath {
    private struct Reader {
        let s: [Character]
        var i = 0

        init(_ text: String) { s = Array(text) }

        mutating func skipSeparators() {
            while i < s.count, s[i] == " " || s[i] == "," || s[i] == "\n" || s[i] == "\t" { i += 1 }
        }

        var atEnd: Bool { mutating get { skipSeparators(); return i >= s.count } }

        /// The next character when it is a command letter.
        mutating func command() -> Character? {
            skipSeparators()
            guard i < s.count, s[i].isLetter else { return nil }
            let c = s[i]; i += 1
            return c
        }

        mutating func number() -> CGFloat? {
            skipSeparators()
            guard i < s.count else { return nil }
            var j = i
            if s[j] == "-" || s[j] == "+" { j += 1 }
            var digits = 0
            while j < s.count, s[j].isNumber { j += 1; digits += 1 }
            if j < s.count, s[j] == "." {
                j += 1
                while j < s.count, s[j].isNumber { j += 1; digits += 1 }
            }
            guard digits > 0 else { return nil }
            if j < s.count, s[j] == "e" || s[j] == "E" {
                var k = j + 1
                if k < s.count, s[k] == "-" || s[k] == "+" { k += 1 }
                if k < s.count, s[k].isNumber {
                    while k < s.count, s[k].isNumber { k += 1 }
                    j = k
                }
            }
            let text = String(s[i..<j])
            i = j
            return Double(text).map { CGFloat($0) }
        }

        mutating func numbers(_ n: Int) -> [CGFloat]? {
            var r: [CGFloat] = []
            for _ in 0..<n {
                guard let v = number() else { return nil }
                r.append(v)
            }
            return r
        }
    }

    static func parse(_ d: String) -> Path {
        var path = Path()
        var sc = Reader(d)
        var cur = CGPoint.zero
        var start = CGPoint.zero
        var lastCtrl: CGPoint? = nil      // last cubic control point (for S)
        var lastQuad: CGPoint? = nil      // last quadratic control point (for T)
        var cmd: Character = "M"

        while !sc.atEnd {
            if let c = sc.command() { cmd = c }
            let rel = cmd.isLowercase
            let ox = rel ? cur.x : 0
            let oy = rel ? cur.y : 0
            var newCubic: CGPoint? = nil
            var newQuad: CGPoint? = nil

            switch cmd {
            case "M", "m":
                guard let v = sc.numbers(2) else { return path }
                cur = CGPoint(x: ox + v[0], y: oy + v[1])
                start = cur
                path.move(to: cur)
                cmd = rel ? "l" : "L"      // extra pairs after a moveto are implicit lineto
            case "L", "l":
                guard let v = sc.numbers(2) else { return path }
                cur = CGPoint(x: ox + v[0], y: oy + v[1])
                path.addLine(to: cur)
            case "H", "h":
                guard let v = sc.number() else { return path }
                cur = CGPoint(x: ox + v, y: cur.y)
                path.addLine(to: cur)
            case "V", "v":
                guard let v = sc.number() else { return path }
                cur = CGPoint(x: cur.x, y: oy + v)
                path.addLine(to: cur)
            case "C", "c":
                guard let v = sc.numbers(6) else { return path }
                let c1 = CGPoint(x: ox + v[0], y: oy + v[1])
                let c2 = CGPoint(x: ox + v[2], y: oy + v[3])
                let p = CGPoint(x: ox + v[4], y: oy + v[5])
                path.addCurve(to: p, control1: c1, control2: c2)
                newCubic = c2
                cur = p
            case "S", "s":
                guard let v = sc.numbers(4) else { return path }
                let c1 = lastCtrl.map { CGPoint(x: 2 * cur.x - $0.x, y: 2 * cur.y - $0.y) } ?? cur
                let c2 = CGPoint(x: ox + v[0], y: oy + v[1])
                let p = CGPoint(x: ox + v[2], y: oy + v[3])
                path.addCurve(to: p, control1: c1, control2: c2)
                newCubic = c2
                cur = p
            case "Q", "q":
                guard let v = sc.numbers(4) else { return path }
                let c = CGPoint(x: ox + v[0], y: oy + v[1])
                let p = CGPoint(x: ox + v[2], y: oy + v[3])
                path.addQuadCurve(to: p, control: c)
                newQuad = c
                cur = p
            case "T", "t":
                guard let v = sc.numbers(2) else { return path }
                let c = lastQuad.map { CGPoint(x: 2 * cur.x - $0.x, y: 2 * cur.y - $0.y) } ?? cur
                let p = CGPoint(x: ox + v[0], y: oy + v[1])
                path.addQuadCurve(to: p, control: c)
                newQuad = c
                cur = p
            case "A", "a":
                guard let v = sc.numbers(7) else { return path }
                let p = CGPoint(x: ox + v[5], y: oy + v[6])
                addArc(&path, from: cur, rx: v[0], ry: v[1], rotation: v[2], large: v[3] != 0, sweep: v[4] != 0, to: p)
                cur = p
            case "Z", "z":
                path.closeSubpath()
                cur = start
                cmd = "M"      // anything after a closepath must start with its own command
            default:
                return path
            }
            lastCtrl = newCubic
            lastQuad = newQuad
        }
        return path
    }

    /// SVG elliptical arc -> cubic Bezier segments (SVG spec, appendix F.6).
    private static func addArc(_ path: inout Path, from p0: CGPoint, rx rx0: CGFloat, ry ry0: CGFloat,
                               rotation: CGFloat, large: Bool, sweep: Bool, to p1: CGPoint) {
        var rx = abs(rx0), ry = abs(ry0)
        if rx == 0 || ry == 0 || (p0.x == p1.x && p0.y == p1.y) {
            path.addLine(to: p1)
            return
        }
        let phi = rotation * .pi / 180
        let cosP = cos(phi), sinP = sin(phi)
        let dx = (p0.x - p1.x) / 2, dy = (p0.y - p1.y) / 2
        let x1p = cosP * dx + sinP * dy
        let y1p = -sinP * dx + cosP * dy

        let lambda = (x1p * x1p) / (rx * rx) + (y1p * y1p) / (ry * ry)
        if lambda > 1 {
            let s = lambda.squareRoot()
            rx *= s; ry *= s
        }

        let num = rx * rx * ry * ry - rx * rx * y1p * y1p - ry * ry * x1p * x1p
        let den = rx * rx * y1p * y1p + ry * ry * x1p * x1p
        var coef = den == 0 ? 0 : (max(0, num / den)).squareRoot()
        if large == sweep { coef = -coef }
        let cxp = coef * rx * y1p / ry
        let cyp = -coef * ry * x1p / rx
        let cx = cosP * cxp - sinP * cyp + (p0.x + p1.x) / 2
        let cy = sinP * cxp + cosP * cyp + (p0.y + p1.y) / 2

        func angle(_ ux: CGFloat, _ uy: CGFloat, _ vx: CGFloat, _ vy: CGFloat) -> CGFloat {
            let dot = ux * vx + uy * vy
            let len = (ux * ux + uy * uy).squareRoot() * (vx * vx + vy * vy).squareRoot()
            var a = acos(max(-1, min(1, dot / len)))
            if ux * vy - uy * vx < 0 { a = -a }
            return a
        }
        let theta1 = angle(1, 0, (x1p - cxp) / rx, (y1p - cyp) / ry)
        var delta = angle((x1p - cxp) / rx, (y1p - cyp) / ry, (-x1p - cxp) / rx, (-y1p - cyp) / ry)
        if !sweep && delta > 0 { delta -= 2 * .pi }
        if sweep && delta < 0 { delta += 2 * .pi }

        let segments = max(1, Int((abs(delta) / (.pi / 2)).rounded(.up)))
        let step = delta / CGFloat(segments)
        let t = 4.0 / 3.0 * tan(step / 4)

        func point(_ th: CGFloat) -> CGPoint {
            CGPoint(x: cx + rx * cos(th) * cosP - ry * sin(th) * sinP,
                    y: cy + rx * cos(th) * sinP + ry * sin(th) * cosP)
        }
        func deriv(_ th: CGFloat) -> CGPoint {
            CGPoint(x: -rx * sin(th) * cosP - ry * cos(th) * sinP,
                    y: -rx * sin(th) * sinP + ry * cos(th) * cosP)
        }

        var a = theta1
        for _ in 0..<segments {
            let b = a + step
            let pa = point(a), pb = point(b)
            let da = deriv(a), db = deriv(b)
            path.addCurve(to: pb,
                          control1: CGPoint(x: pa.x + t * da.x, y: pa.y + t * da.y),
                          control2: CGPoint(x: pb.x - t * db.x, y: pb.y - t * db.y))
            a = b
        }
    }
}

/// An app icon by name (`"home"`, `"heart_on"`...), drawn in `color` inside a square of `size` points.
struct Icon: View {
    let name: String
    var size: CGFloat = 24
    var color: Color

    init(_ name: String, size: CGFloat = 24, color: Color) {
        self.name = name; self.size = size; self.color = color
    }

    var body: some View {
        let parts = Icons.data[name] ?? []
        let s = size / 24
        ZStack {
            ForEach(parts.indices, id: \.self) { i in
                let part = parts[i]
                let p = Icons.path(part.d).applying(CGAffineTransform(scaleX: s, y: s))
                ZStack {
                    if part.fill { p.fill(color) }
                    if part.stroke > 0 {
                        p.stroke(color, style: StrokeStyle(lineWidth: part.stroke * s,
                                                           lineCap: part.cap ? .round : .butt,
                                                           lineJoin: part.join ? .round : .miter))
                    }
                }
            }
        }
        .frame(width: size, height: size, alignment: .topLeading)
    }
}
