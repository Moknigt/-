import Foundation

/// Release 52: first wiring step (same as Android `ServerSync.kt`). The local login / sign-up stays exactly as it was and decides
/// whether the user gets in. Right after it succeeds, the account is mirrored to Supabase in the background:
/// sign in -> if the account does not exist there yet, sign up -> (teacher with a code) claim the teacher code.
/// Silent on purpose: no new screen, no new string, never blocks; a server that is not ready (SQL not run, offline) changes nothing.
/// Existing users are mirrored the next time they type their password (it is needed and never stored).
enum ServerSync {
    private static let d = UserDefaults.standard

    /// true = the server session belongs to this email.
    static func mirrored(_ email: String) -> Bool { Remote.signedIn && d.string(forKey: "serversync.email") == email }

    /// Teacher codes are written XXXXXX-YYYYYY on the server; the user may type them with spaces, dashes or lower case.
    private static func serverCode(_ raw: String) -> String {
        let alpha = Set("ABCDEFGHJKLMNPQRSTUVWXYZ23456789")
        let s = raw.uppercased().filter { alpha.contains($0) }
        guard s.count == 12 else { return raw.trimmingCharacters(in: .whitespacesAndNewlines) }
        return String(s.prefix(6)) + "-" + String(s.suffix(6))
    }

    /// [role] = "student" | "teacher" | "admin". [code] = the teacher code typed at sign-up (empty otherwise).
    static func mirror(role: String, email: String, pass: String, store: Store, code: String = "") {
        guard Remote.enabled else { return }
        if mirrored(email) && code.isEmpty { AdminControl.entered(role: role, kind: "signin"); return }   // release 55: already linked, only tell the main admin
        let st = role == "student" ? store.findStudent(email) : nil
        let name = role == "teacher" ? (store.teacher?.name ?? "") : (st?.name ?? "")
        let phone = st?.phone ?? ""
        let grade = st?.grade ?? ""
        let ready = {
            d.set(email, forKey: "serversync.email")
            // TODO(server): the teacher code is only claimed here; if the server was not ready then, promote the teacher by hand (see SQL notes).
            if role == "teacher" && !code.isEmpty { Remote.claimTeacher(code: serverCode(code)) { ok in if ok { AdminControl.entered(role: role, kind: "signup") } } }
            else { AdminControl.entered(role: role, kind: "signin") }   // release 55: admin -> becomes admin on the server (first = main), teacher -> alert to the main admin
        }
        Remote.signIn(email: email, password: pass) { ok in
            if ok { ready() }
            else {   // release 57: an admin gets a (limited) account on the server too; the activation code makes it admin
                Remote.signUp(email: email, password: pass, name: name, phone: phone, grade: grade) { made in
                    if made && Remote.signedIn { ready() }
                }
            }
        }
    }

    /// Release 53: creating an account works ONLY online. The server must accept it first; the local account is created by the caller
    /// only when [done] gets nil. Otherwise it gets a string key: "err_need_net" (no internet / server refused) or "err_tcode_invalid"
    /// (teacher code unknown to the server). Without a server configured it answers nil at once.
    static func register(role: String, email: String, pass: String, name: String, phone: String, grade: String, code: String, done: @escaping (String?) -> Void) {
        guard Remote.enabled else { done(nil); return }
        Remote.signOut()
        let after = {
            d.set(email, forKey: "serversync.email")
            if role == "teacher" {
                Remote.claimTeacher(code: serverCode(code)) { ok in
                    if ok { AdminControl.entered(role: "teacher", kind: "signup") }   // release 55: alert to the main admin
                    done(ok ? nil : "err_tcode_invalid")
                }
            }
            else if role == "admin" {   // release 57: first admin = main (no code), the others need the one-time code
                AdminControl.registerAdmin(code: serverCode(code)) { r in
                    guard let r = r else { done("err_need_net"); return }
                    done(r.ok ? nil : (r.reason == "locked" ? "err_admin_locked" : "err_admin_code"))
                }
            }
            else { done(nil) }
        }
        Remote.signUp(email: email, password: pass, name: name, phone: phone, grade: grade) { made in
            if made && Remote.signedIn { after() }
            else { Remote.signIn(email: email, password: pass) { ok in if ok { after() } else { done("err_need_net") } } } // already on the server (e.g. a retry)
        }
    }

    static func signOut() { AdminControl.reset(); Remote.signOut(); d.removeObject(forKey: "serversync.email") }
}
