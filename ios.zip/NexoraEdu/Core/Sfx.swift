import AVFoundation
import SwiftUI

/// Short interface sounds: Resources/Sfx/sfx_*.wav, the same 18 files, names and volumes as the Android app
/// (made by tools/make_sfx.py inside android.zip).
/// - Uses the "ambient" audio session: it follows the silent switch and never stops the user's music.
/// - A plain tap is skipped when a more specific sound (success, error, sheet...) plays at the same moment.
final class Sfx {
    static let shared = Sfx()

    enum S: String, CaseIterable {
        case tap, tab, select, on, off, open, close, notice, success, error, delete, locked, play, pause, skip, pass, fail, splash

        var vol: Float {
            switch self {
            case .tap: return 0.45
            case .tab: return 0.55
            case .select: return 0.5
            case .on, .off: return 0.55
            case .open: return 0.5
            case .close: return 0.4
            case .notice: return 0.55
            case .success: return 0.7
            case .error: return 0.75
            case .delete: return 0.7
            case .locked: return 0.7
            case .play, .pause, .skip: return 0.5
            case .pass: return 0.75
            case .fail: return 0.7
            case .splash: return 0.8
            }
        }
    }

    private var players: [S: AVAudioPlayer] = [:]
    private var lastPlayed: [S: TimeInterval] = [:]
    private var lastAction: TimeInterval = 0
    private var started = false

    private var now: TimeInterval { ProcessInfo.processInfo.systemUptime }

    /// Safe to call many times: loads the sounds only once.
    func start() {
        if started { return }
        started = true
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.ambient, mode: .default, options: [])
        try? session.setActive(true)
        for s in S.allCases {
            guard let url = Bundle.main.url(forResource: "sfx_" + s.rawValue, withExtension: "wav"),
                  let p = try? AVAudioPlayer(contentsOf: url) else { continue }
            p.volume = s.vol
            p.prepareToPlay()
            players[s] = p
        }
    }

    func play(_ s: S) {
        let t = now
        if s != .tap { lastAction = t }
        if t - (lastPlayed[s] ?? 0) < 0.045 { return }   // the same sound twice in a blink
        lastPlayed[s] = t
        start()
        guard let p = players[s] else { return }
        p.currentTime = 0
        p.play()
    }

    func stop(_ s: S) { players[s]?.stop() }

    /// The video player switches the audio session to "playback"; when it closes the sounds go back to "ambient" (silent switch respected).
    func restoreSession() {
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.ambient, mode: .default, options: [])
        try? session.setActive(true)
    }

    /// Plain tap: waits a moment so a more specific sound (played by the action itself) can replace it.
    func tap() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.035) { [weak self] in
            guard let self = self else { return }
            if self.now - self.lastAction > 0.15 { self.play(.tap) }
        }
    }

    /// Text of a string (either language) -> its key in Localizable.strings; nil when it is not a plain string.
    private lazy var keyByText: [String: String] = {
        var m: [String: String] = [:]
        for code in ["ar", "en"] {
            guard let p = Bundle.main.path(forResource: "Localizable", ofType: "strings", inDirectory: nil, forLocalization: code),
                  let d = NSDictionary(contentsOfFile: p) as? [String: String] else { continue }
            for (k, v) in d { m[v] = k }
        }
        return m
    }()

    func key(of text: String) -> String? { keyByText[text] }

    /// The sound that fits a toast message, taken from the name of its string (err_*, *_saved, *_copied...). Same rule as Android.
    func forToast(_ text: String) {
        let n = key(of: text) ?? ""
        let bad = n.hasPrefix("err_") || n.contains("_err") || n.hasSuffix("_fail") || n.hasSuffix("_bad_limit")
            || n == "grant_none" || n == "ex_empty_questions"
        let good = n.hasSuffix("_saved") || n.hasSuffix("_done") || n.hasSuffix("_copied") || n.hasSuffix("_changed")
            || n.hasSuffix("_imported") || n == "pw_changed"
        play(bad ? .error : (good ? .success : .notice))
    }
}

extension View {
    /// Plain tap sound on a real tap (not on a scroll or a drag), added next to the button's own action.
    func sfxTap() -> some View {
        simultaneousGesture(TapGesture().onEnded { Sfx.shared.tap() })
    }
}

extension Binding where Value == Bool {
    /// A switch bound through this plays the on / off sound; only the user's own toggle goes through `set`.
    func sfx() -> Binding<Bool> {
        Binding<Bool>(get: { self.wrappedValue }, set: { v in
            Sfx.shared.play(v ? .on : .off)
            self.wrappedValue = v
        })
    }
}
