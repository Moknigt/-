import SwiftUI

// The common screen frame of the Android ShellActivity: header, scrolling body, bottom tabs,
// bottom sheets, settings sheet and toast. Used by the student side now and the teacher side in part 3.

// MARK: - Sheets and toast controller

/// Owns the bottom sheet and the toast of one shell. Views reach it with `@EnvironmentObject var ui: ShellUI`.
final class ShellUI: ObservableObject {
    struct SheetItem: Identifiable {
        let id = UUID()
        let title: String
        let trailing: (() -> AnyView)?
        let content: () -> AnyView
    }

    @Published var sheet: SheetItem? = nil
    @Published var toastText: String? = nil
    /// The full-screen settings page (profile, language, appearance, colours).
    @Published var settingsOpen = false
    private var toastToken = 0

    /// Bottom sheet with a title; [content] fills it (same as `sheet(title) { ... }` on Android).
    func present<V: View>(_ title: String, @ViewBuilder _ content: @escaping () -> V) {
        Sfx.shared.play(.open)
        sheet = SheetItem(title: title, trailing: nil, content: { AnyView(content()) })
    }

    /// Same, with a view at the end of the title row (the palette icon of the settings sheet).
    func present<V: View, T: View>(_ title: String, @ViewBuilder trailing: @escaping () -> T, @ViewBuilder _ content: @escaping () -> V) {
        Sfx.shared.play(.open)
        sheet = SheetItem(title: title, trailing: { AnyView(trailing()) }, content: { AnyView(content()) })
    }

    func openSettings() {
        Sfx.shared.play(.open)
        withAnimation(.easeOut(duration: 0.32)) { settingsOpen = true }
    }

    func closeSettings() {
        Sfx.shared.play(.close)
        withAnimation(.easeOut(duration: 0.26)) { settingsOpen = false }
    }

    func dismiss() {
        if sheet != nil { Sfx.shared.play(.close) }
        sheet = nil
    }

    /// Confirmation sheet: the message is the title, a gradient "yes" button and a "cancel" link.
    func confirm(_ message: String, yes: String, cancel: String, onYes: @escaping () -> Void) {
        present(message) { ConfirmBody(yes: yes, cancel: cancel, onYes: onYes) }
    }

    /// Short message at the bottom (Android Toast).
    func toast(_ text: String) {
        Sfx.shared.forToast(text)
        toastToken += 1
        let token = toastToken
        toastText = text
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.2) { [weak self] in
            guard let self = self, self.toastToken == token else { return }
            self.toastText = nil
        }
    }
}

private struct TopRounded: Shape {
    var radius: CGFloat

    func path(in rect: CGRect) -> Path {
        Path(UIBezierPath(roundedRect: rect,
                          byRoundingCorners: [.topLeft, .topRight],
                          cornerRadii: CGSize(width: radius, height: radius)).cgPath)
    }
}

private struct HeightKey: PreferenceKey {
    static var defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) { value = max(value, nextValue()) }
}

/// Wraps its content when it fits and scrolls when it does not (like a ScrollView with wrap_content height).
struct WrapScroll<Content: View>: View {
    @State private var h: CGFloat = 0
    let maxHeight: CGFloat
    let content: Content

    init(maxHeight: CGFloat, @ViewBuilder content: () -> Content) {
        self.maxHeight = maxHeight
        self.content = content()
    }

    var body: some View {
        ScrollView(showsIndicators: false) {
            content
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(GeometryReader { g in
                    Color.clear.preference(key: HeightKey.self, value: g.size.height)
                })
        }
        .scrollDismissesKeyboard(.interactively)
        .onPreferenceChange(HeightKey.self) { h = $0 }
        .frame(height: min(h, maxHeight))
    }
}

/// `sheet_bg` panel: 28 top corners, 20 padding (12 at the bottom), title in 18 bold.
private struct SheetPanel: View {
    @Environment(\.theme) private var th
    let title: String
    var trailing: AnyView? = nil
    let content: AnyView
    /// Height that is free for the sheet (it shrinks when the keyboard is open).
    let avail: CGFloat

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(spacing: 0) {
                Text(title)
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(th.tx)
                    .frame(maxWidth: .infinity, alignment: .leading)
                if let t = trailing { t }
            }
            WrapScroll(maxHeight: max(min(UIScreen.main.bounds.height * 0.6, avail - 100), 120)) { content }
        }
        .padding(.horizontal, 20)
        .padding(.top, 20)
        .padding(.bottom, 12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            TopRounded(radius: 28).fill(th.sheet)
                .overlay(TopRounded(radius: 28).stroke(th.bd, lineWidth: 1))
                .ignoresSafeArea(edges: .bottom)
        )
    }
}

private struct SheetOverlay: View {
    @ObservedObject var ui: ShellUI

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .bottom) {
                if let s = ui.sheet {
                    Color.black.opacity(0.6)
                        .ignoresSafeArea()
                        .onTapGesture { ui.dismiss() }
                        .transition(.opacity)
                    SheetPanel(title: s.title, trailing: s.trailing?(), content: s.content(), avail: geo.size.height)
                        .transition(.move(edge: .bottom))
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
            .animation(.easeOut(duration: 0.22), value: ui.sheet?.id)
        }
        // Nothing to catch touches while no sheet is open.
        .allowsHitTesting(ui.sheet != nil)
    }
}

private struct ToastOverlay: View {
    @ObservedObject var ui: ShellUI

    var body: some View {
        VStack {
            Spacer()
            if let t = ui.toastText {
                Text(t)
                    .font(.system(size: 14))
                    .foregroundColor(Color.white)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 18)
                    .padding(.vertical, 10)
                    .background(Capsule().fill(Color(hex: 0x2B2F3A, opacity: 0.96)))
                    .padding(.horizontal, 24)
                    .padding(.bottom, 84)
                    .transition(.opacity)
            }
        }
        .allowsHitTesting(false)
        .animation(.easeInOut(duration: 0.2), value: ui.toastText)
    }
}

/// Body of the confirmation sheet.
struct ConfirmBody: View {
    @EnvironmentObject private var ui: ShellUI
    let yes: String
    let cancel: String
    let onYes: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            PrimaryButton(title: yes, height: 50) {
                ui.dismiss()
                if Sfx.shared.key(of: yes) == "delete" { Sfx.shared.play(.delete) }
                onYes()
            }
            .padding(.top, 18)
            StartLink(title: cancel) { ui.dismiss() }
        }
    }
}

// MARK: - Settings screen (full screen: profile card, language, appearance, colours)

struct SettingsScreen: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @ObservedObject var ui: ShellUI
    @Environment(\.theme) private var th
    let name: String
    let sub: String
    let avatarEmail: String?

    private var base: Theme { Theme(dark: th.dark, teacher: false, admin: false) }

    private var cells: [(id: String, name: String, c1: Color, c2: Color)] {
        var c: [(id: String, name: String, c1: Color, c2: Color)] = [(id: Accents.defaultId, name: prefs.t("th_nexora"), c1: base.p1, c2: base.p2)]
        for a in Accents.custom { c.append((id: a.id, name: prefs.t(a.nameKey), c1: Color(hex: a.c1), c2: Color(hex: a.c2))) }
        return c
    }

    var body: some View {
        ZStack {
            AppBackground()
            GlassAurora(strength: 0.5).ignoresSafeArea()
            VStack(spacing: 0) {
                TopBar(title: prefs.t("settings")) { ui.closeSettings() }
                    .padding(.horizontal, 20).padding(.top, 8).padding(.bottom, 4)
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 0) {
                        HStack(spacing: 14) {
                            AvatarView(email: avatarEmail, name: name, size: 56)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(name).font(.system(size: 18, weight: .bold)).foregroundColor(th.tx).lineLimit(1)
                                Text(sub).font(.system(size: 13)).foregroundColor(th.mut)
                            }
                            Spacer(minLength: 0)
                        }
                        .padding(16).frame(maxWidth: .infinity).glassCard(24)

                        label(prefs.t("language"), top: 26)
                        SegmentedPills(options: [prefs.t("lang_ar"), prefs.t("lang_en")], selected: prefs.ar ? 0 : 1) { i in
                            let wantAr = (i == 0)
                            guard wantAr != prefs.ar else { return }
                            prefs.ar = wantAr
                        }
                        .padding(14).glassCard(24)

                        label(prefs.t("appearance"), top: 22)
                        SegmentedPills(options: [prefs.t("dark"), prefs.t("light")], selected: prefs.dark ? 0 : 1) { i in
                            let wantDark = (i == 0)
                            guard wantDark != prefs.dark else { return }
                            prefs.dark = wantDark
                        }
                        .padding(14).glassCard(24)

                        label(prefs.t("th_title"), top: 22)
                        colors

                        PrimaryButton(title: prefs.t("logout"), height: 54, fontSize: 16) {
                            ui.settingsOpen = false
                            store.clearSession()
                            ServerSync.signOut()
                        }
                        .padding(.top, 32)
                    }
                    .padding(.horizontal, 20).padding(.bottom, 40)
                }
            }
        }
    }

    private func label(_ t: String, top: CGFloat) -> some View {
        Text(t).font(.system(size: 13, weight: .bold)).foregroundColor(th.mut).padding(.top, top).padding(.bottom, 10)
    }

    /// A live preview bar with the chosen name, then round gradient swatches (4 per row).
    private var colors: some View {
        let all = cells
        let cur = all.first { $0.id == prefs.accent } ?? all[0]
        return VStack(spacing: 14) {
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .fill(LinearGradient(colors: [cur.c1, cur.c2], startPoint: .leading, endPoint: .trailing))
                .frame(height: 64)
                .overlay(Text(cur.name).font(.system(size: 18, weight: .bold)).foregroundColor(.white)
                    .shadow(color: Color.black.opacity(0.4), radius: 3, y: 1))
            VStack(spacing: 12) {
                ForEach(Array(stride(from: 0, to: all.count, by: 4)), id: \.self) { start in
                    HStack(spacing: 0) {
                        ForEach(0..<4, id: \.self) { k in
                            if start + k < all.count { swatch(all[start + k]) } else { Color.clear.frame(maxWidth: .infinity, minHeight: 58) }
                        }
                    }
                }
            }
        }
        .padding(14).glassCard(24)
        .animation(.easeInOut(duration: 0.25), value: prefs.accent)
    }

    private func swatch(_ c: (id: String, name: String, c1: Color, c2: Color)) -> some View {
        let on = prefs.accent == c.id
        return Button {
            if !on { prefs.accent = c.id }
        } label: {
            ZStack {
                Circle().fill(LinearGradient(colors: [c.c1, c.c2], startPoint: .topLeading, endPoint: .bottomTrailing)).frame(width: 50, height: 50)
                Circle().stroke(th.tx, lineWidth: 3).frame(width: 58, height: 58).opacity(on ? 1 : 0)
                Image(systemName: "checkmark").font(.system(size: 16, weight: .bold)).foregroundColor(.white).opacity(on ? 1 : 0)
            }
            .frame(maxWidth: .infinity, minHeight: 62)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain).sfxTap()
    }
}

// MARK: - Frame

struct ShellTab {
    let labelKey: String
    let icon: String
}

/// Header (avatar, greeting, settings), scrolling body, bottom tabs. The body is rebuilt by the owner;
/// changing [screenKey] starts the new screen at the top, while the same key keeps the scroll position.
struct ShellFrame<Content: View>: View {
    @EnvironmentObject private var prefs: Prefs
    @Environment(\.theme) private var th
    @ObservedObject var ui: ShellUI
    let helloKey: String
    let name: String
    let tabs: [ShellTab]
    let selected: Int
    let screenKey: String
    var avatarEmail: String? = nil
    var onBack: (() -> Void)? = nil
    let onSelect: (Int) -> Void
    let onSettings: () -> Void
    let content: Content

    init(ui: ShellUI, helloKey: String, name: String, tabs: [ShellTab], selected: Int, screenKey: String,
         avatarEmail: String? = nil, onBack: (() -> Void)? = nil, onSelect: @escaping (Int) -> Void, onSettings: @escaping () -> Void,
         @ViewBuilder content: () -> Content) {
        self.ui = ui
        self.helloKey = helloKey
        self.name = name
        self.tabs = tabs
        self.selected = selected
        self.screenKey = screenKey
        self.avatarEmail = avatarEmail
        self.onBack = onBack
        self.onSelect = onSelect
        self.onSettings = onSettings
        self.content = content()
    }

    var body: some View {
        ZStack {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 0) { content }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 16)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .id(screenKey)
            .scrollDismissesKeyboard(.interactively)
            .overlay(alignment: .leading) { edgeSwipe }
            // Both capsules float over the content (same frosted look, almost opaque): the body scrolls under them,
            // so nothing is cut off under the header any more.
            .safeAreaInset(edge: .top, spacing: 0) { header }
            // The bottom capsule is not part of the settings screen: it fades out while settings are open.
            .safeAreaInset(edge: .bottom, spacing: 0) {
                nav
                    .opacity(ui.settingsOpen ? 0 : 1)
                    .offset(y: ui.settingsOpen ? 30 : 0)
                    .allowsHitTesting(!ui.settingsOpen)
            }
            // The header / tabs do not jump up with the keyboard; the sheet below is what moves.
            .ignoresSafeArea(.keyboard, edges: .bottom)
            if ui.settingsOpen {
                SettingsScreen(ui: ui, name: name, sub: prefs.t(helloKey), avatarEmail: avatarEmail)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                    .zIndex(5)
            }
            SheetOverlay(ui: ui)
            // After the sheet, so a message raised inside a sheet (empty title, bad link...) is drawn above it.
            ToastOverlay(ui: ui)
        }
        .environmentObject(ui)
    }

    private var header: some View {
        HStack(spacing: 0) {
            AvatarView(email: avatarEmail, name: name, size: 40)
            VStack(alignment: .leading, spacing: 0) {
                Text(prefs.t(helloKey)).font(.system(size: 11)).foregroundColor(th.mut)
                Text(name).font(.system(size: 14, weight: .bold)).foregroundColor(th.tx).lineLimit(1)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.leading, 10)
            Button(action: onSettings) {
                Icon("gear", size: 20, color: th.tx)
                    .frame(width: 40, height: 40)
                    .background(Circle().fill(LinearGradient(colors: [th.glassHi, th.glassLo], startPoint: .topLeading, endPoint: .bottomTrailing)))
                    .overlay(Circle().stroke(th.bd, lineWidth: 1))
            }
            .buttonStyle(.plain).sfxTap()
            .accessibilityLabel(prefs.t("settings"))
        }
        .padding(.horizontal, 8)
        .frame(height: 56)
        .background(Capsule().fill(th.sheet.opacity(0.97)))
        .overlay(Capsule().stroke(th.bd, lineWidth: 1))
        .shadow(color: Color.black.opacity(0.18), radius: 10, y: 4)
        .padding(.horizontal, 20)
        .padding(.top, 8)
        .padding(.bottom, 10)
    }

    private var nav: some View {
        HStack(spacing: 0) {
            ForEach(tabs.indices, id: \.self) { i in
                let tint = (i == selected) ? th.p1 : th.mut
                Button {
                    if i != selected { Sfx.shared.play(.tab) }
                    onSelect(i)
                } label: {
                    VStack(spacing: 0) {
                        Icon(tabs[i].icon, size: 24, color: tint)
                        Text(prefs.t(tabs[i].labelKey))
                            .font(.system(size: 11))
                            .foregroundColor(tint)
                            .lineLimit(1)
                            .padding(.top, 2)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain).sfxTap()
            }
        }
        .padding(.horizontal, 10)
        .frame(height: 68)
        .background(Capsule().fill(th.sheet.opacity(0.97)))
        .overlay(Capsule().stroke(th.bd, lineWidth: 1))
        .shadow(color: Color.black.opacity(0.18), radius: 10, y: 4)
        .padding(.horizontal, 16)
        .padding(.bottom, 8)
    }

    /// Swipe in from the start edge (right side, the screen is right-to-left) goes back, like the iOS back gesture.
    @ViewBuilder
    private var edgeSwipe: some View {
        if let back = onBack {
            Color.clear
                .frame(width: 14)
                .frame(maxHeight: .infinity)
                .contentShape(Rectangle())
                .gesture(
                    DragGesture(minimumDistance: 24)
                        .onEnded { v in
                            if v.translation.width < -50, abs(v.translation.height) < 80 { back() }
                        }
                )
        }
    }
}
