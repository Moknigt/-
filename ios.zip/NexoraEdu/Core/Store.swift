import Foundation
import SwiftUI
import UIKit

/// Local data store (UserDefaults + JSON). Passwords are kept as SHA-256 hashes.
/// Every list is @Published, so a change refreshes the screens that show it.
final class Store: ObservableObject {
    static let shared = Store()

    static let defaultGrades = ["الصف الأول الثانوي", "الصف الثاني الثانوي", "الصف الثالث الثانوي"]
    /// Per-student saved collections: favorites, review later, important.
    static let collections = ["fav", "later", "imp"]

    private let d = UserDefaults.standard

    @Published var grades: [String] { didSet { save("grades", grades) } }
    @Published var students: [Student] { didSet { save("students", students) } }
    @Published var chapters: [Chapter] { didSet { save("chapters", chapters) } }
    @Published var lessons: [Lesson] { didSet { save("lessons", lessons) } }
    @Published var docs: [Doc] { didSet { save("docs", docs) } }
    @Published var grants: [Grant] { didSet { save("grants", grants) } }
    /// Permanent log of every opening (never shortened when a grant is removed).
    @Published var glog: [Grant] { didSet { save("glog", glog) } }
    @Published var questions: [Question] { didSet { save("questions", questions) } }
    @Published var exams: [Exam] { didSet { save("exams", exams) } }
    @Published var results: [ExamResult] { didSet { save("results", results) } }
    @Published var homework: [Homework] { didSet { save("homework", homework) } }
    @Published var submissions: [Submission] { didSet { save("subs", submissions) } }
    @Published var announcements: [Announcement] { didSet { save("ann", announcements) } }
    @Published var teacher: TeacherAccount? { didSet { saveOpt("teacher", teacher) } }
    @Published var admin: AdminAccount? { didSet { saveOpt("admin", admin) } }
    @Published var session: Session? { didSet { saveOpt("session", session) } }

    private init() {
        grades = Store.load("grades", Store.defaultGrades)
        students = Store.load("students", [Student]())
        chapters = Store.load("chapters", [Chapter]())
        lessons = Store.load("lessons", [Lesson]())
        docs = Store.load("docs", [Doc]())
        grants = Store.load("grants", [Grant]())
        glog = Store.load("glog", [Grant]())
        questions = Store.load("questions", [Question]())
        exams = Store.load("exams", [Exam]())
        results = Store.load("results", [ExamResult]())
        homework = Store.load("homework", [Homework]())
        submissions = Store.load("subs", [Submission]())
        announcements = Store.load("ann", [Announcement]())
        teacher = Store.loadOpt("teacher")
        admin = Store.loadOpt("admin")
        session = Store.loadOpt("session")
    }

    // MARK: - JSON helpers

    private static func load<T: Decodable>(_ key: String, _ def: T) -> T {
        guard let data = UserDefaults.standard.data(forKey: key),
              let v = try? JSONDecoder().decode(T.self, from: data) else { return def }
        return v
    }

    private static func loadOpt<T: Decodable>(_ key: String) -> T? {
        guard let data = UserDefaults.standard.data(forKey: key) else { return nil }
        return try? JSONDecoder().decode(T.self, from: data)
    }

    private func save<T: Encodable>(_ key: String, _ v: T) {
        if let data = try? JSONEncoder().encode(v) { d.set(data, forKey: key) }
    }

    private func saveOpt<T: Encodable>(_ key: String, _ v: T?) {
        if let v = v { save(key, v) } else { d.removeObject(forKey: key) }
    }

    // MARK: - Files (Documents/docs/<id>.pdf and Documents/hw/<name>)

    static var filesDir: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    private func folder(_ name: String) -> URL {
        let u = Store.filesDir.appendingPathComponent(name, isDirectory: true)
        try? FileManager.default.createDirectory(at: u, withIntermediateDirectories: true)
        return u
    }

    func docFile(_ id: String) -> URL { folder("docs").appendingPathComponent(id + ".pdf") }
    func photoFile(_ name: String) -> URL { folder("hw").appendingPathComponent(name) }

    /// The student's profile photo: Documents/avatars/<email with every char outside A-Z a-z 0-9 . _ - replaced by _>.jpg (may not exist).
    func avatarFile(_ email: String) -> URL {
        var safe = ""
        for c in email {
            if c.isASCII && (c.isLetter || c.isNumber) || c == "." || c == "_" || c == "-" { safe.append(c) } else { safe.append("_") }
        }
        return folder("avatars").appendingPathComponent(safe + ".jpg")
    }

    /// Bumped whenever a profile photo is saved or removed, so the header and the profile redraw.
    @Published var avatarVersion = 0

    /// Saves a picked image as a small JPEG (max 512 px, orientation applied). The old photo is replaced only when the new one is written.
    func saveAvatar(_ email: String, from data: Data) -> Bool {
        guard let img = UIImage(data: data), img.size.width > 0, img.size.height > 0 else { return false }
        let k = min(1, 512 / max(img.size.width, img.size.height))
        let size = CGSize(width: (img.size.width * k).rounded(), height: (img.size.height * k).rounded())
        let fmt = UIGraphicsImageRendererFormat.default()
        fmt.scale = 1
        let out = UIGraphicsImageRenderer(size: size, format: fmt).image { _ in img.draw(in: CGRect(origin: .zero, size: size)) }
        guard let jpg = out.jpegData(compressionQuality: 0.82) else { return false }
        let dst = avatarFile(email)
        let tmp = dst.appendingPathExtension("tmp")
        do {
            try jpg.write(to: tmp, options: .atomic)
            if FileManager.default.fileExists(atPath: dst.path) { try FileManager.default.removeItem(at: dst) }
            try FileManager.default.moveItem(at: tmp, to: dst)
        } catch {
            try? FileManager.default.removeItem(at: tmp)
            return false
        }
        avatarVersion += 1
        return true
    }

    func removeAvatar(_ email: String) {
        try? FileManager.default.removeItem(at: avatarFile(email))
        avatarVersion += 1
    }

    // MARK: - Accounts and session

    func findStudent(_ email: String) -> Student? { students.first { $0.email == email } }

    func setTeacher(email: String, password: String, name: String = "", phone: String = "") {
        teacher = TeacherAccount(email: email, pw: Util.sha256(password), name: name, phone: phone)
    }

    func setAdmin(email: String, password: String) {
        admin = AdminAccount(email: email, pw: Util.sha256(password))
    }

    /// Removes the teacher account only; the next teacher sign in creates a new one. Students and content stay.
    func deleteTeacher() { teacher = nil }

    /// Release 55: the admin was removed on the server; the local admin account goes too.
    func deleteAdmin() { admin = nil }

    func setSession(role: String, email: String) { session = Session(role: role, email: email) }
    func clearSession() { session = nil }

    func deleteStudent(_ email: String) {
        students.removeAll { $0.email == email }
        results.removeAll { $0.email == email }
        for s in submissions where s.email == email && !s.photo.isEmpty {
            try? FileManager.default.removeItem(at: photoFile(s.photo))
        }
        submissions.removeAll { $0.email == email }
        try? FileManager.default.removeItem(at: avatarFile(email))
        for prefix in ["fav:", "notes:", "hist:"] { d.removeObject(forKey: prefix + email) }
        objectWillChange.send()
    }

    // MARK: - Chapters, lessons, documents

    func newId() -> String { Util.newId() }

    func lesson(_ id: String) -> Lesson? { lessons.first { $0.id == id } }
    func doc(_ id: String) -> Doc? { docs.first { $0.id == id } }

    func deleteChapter(_ id: String) {
        lessons.filter { $0.chapterId == id }.forEach { try? FileManager.default.removeItem(at: videoFile($0.id)) }
        chapters.removeAll { $0.id == id }
        lessons.removeAll { $0.chapterId == id }
        grants.removeAll { $0.target == "c:" + id }
    }

    func deleteLesson(_ id: String) {
        try? FileManager.default.removeItem(at: videoFile(id))
        grants.removeAll { $0.target == "l:" + id }
        lessons.removeAll { $0.id == id }
    }

    // MARK: - Release 35: uploaded videos, prices, grants

    /// Uploaded video file (src == "up"). Kept until the teacher deletes the video. No expiry.
    func videoFile(_ id: String) -> URL { folder("videos").appendingPathComponent(id + ".mp4") }

    func hasVideo(_ l: Lesson) -> Bool {
        l.src == "up" ? FileManager.default.fileExists(atPath: videoFile(l.id).path) : !l.yt.isEmpty
    }

    /// What the player needs: the YouTube id, or the uploaded file.
    func videoItem(_ l: Lesson) -> VideoItem {
        VideoItem(yt: l.yt, title: l.title, file: l.src == "up" ? videoFile(l.id) : nil)
    }

    func coursePrice(_ l: Lesson) -> Int { chapters.first { $0.id == l.chapterId }?.price ?? 0 }
    func isPaid(_ l: Lesson) -> Bool { l.price > 0 || coursePrice(l) > 0 }

    /// Opens [target] for [email]. Every call is logged (who opened it, for whom, when).
    func grant(_ target: String, _ email: String, mode: String, by: String) {
        if grants.contains(where: { $0.target == target && $0.email == email }) { return }
        let g = Grant(target: target, email: email, mode: mode, by: by)
        grants.append(g)
        glog.append(g)
    }
    func revoke(_ target: String, _ email: String) { grants.removeAll { $0.target == target && $0.email == email } }

    /// What the students see: hidden lessons are left out everywhere (Android `publishedLessons` / `publishedLesson`).
    var publishedLessons: [Lesson] { lessons.filter { $0.published } }
    func publishedLesson(_ id: String) -> Lesson? {
        guard let l = lesson(id), l.published else { return nil }
        return l
    }

    func setPublished(_ id: String, _ on: Bool) {
        guard let i = lessons.firstIndex(where: { $0.id == id }) else { return }
        lessons[i].published = on
    }

    func renameChapter(_ id: String, _ title: String) {
        guard let i = chapters.firstIndex(where: { $0.id == id }) else { return }
        chapters[i].title = title
    }

    func renameDoc(_ id: String, _ title: String) {
        guard let i = docs.firstIndex(where: { $0.id == id }) else { return }
        docs[i].title = title
    }

    // The order of the saved lists is the order the students see. [dir] is -1 (up) or +1 (down).
    func moveChapter(_ id: String, _ dir: Int) {
        guard let i = chapters.firstIndex(where: { $0.id == id }), chapters.indices.contains(i + dir) else { return }
        chapters.swapAt(i, i + dir)
    }

    /// Moves a lesson among the lessons of the same chapter (or among the stand-alone videos).
    func moveLesson(_ id: String, _ dir: Int) {
        guard let l = lesson(id) else { return }
        let same = lessons.indices.filter { lessons[$0].chapterId == l.chapterId }
        guard let pos = same.firstIndex(where: { lessons[$0].id == id }), same.indices.contains(pos + dir) else { return }
        lessons.swapAt(same[pos], same[pos + dir])
    }

    /// Moves a book among the books, or a file among the files.
    func moveDoc(_ id: String, _ dir: Int) {
        guard let dd = doc(id) else { return }
        let same = docs.indices.filter { docs[$0].kind == dd.kind }
        guard let pos = same.firstIndex(where: { docs[$0].id == id }), same.indices.contains(pos + dir) else { return }
        docs.swapAt(same[pos], same[pos + dir])
    }

    func deleteDoc(_ id: String) {
        docs.removeAll { $0.id == id }
        try? FileManager.default.removeItem(at: docFile(id))
    }

    // MARK: - Question bank, exams, results

    func question(_ id: String) -> Question? { questions.first { $0.id == id } }
    func exam(_ id: String) -> Exam? { exams.first { $0.id == id } }

    func addResult(_ r: ExamResult) { results.append(r) }

    /// The latest result of a student in an exam, or nil if never taken.
    func lastResult(_ email: String, _ examId: String) -> ExamResult? {
        results.filter { $0.email == email && $0.examId == examId }.max { $0.at < $1.at }
    }

    func deleteExam(_ id: String) {
        exams.removeAll { $0.id == id }
        results.removeAll { $0.examId == id }
    }

    /// Average of a student's latest score in every official exam (nil if none taken).
    func officialAverage(_ email: String) -> Int? {
        let scores = exams.filter { $0.official }.compactMap { lastResult(email, $0.id)?.score }
        return scores.isEmpty ? nil : scores.reduce(0, +) / scores.count
    }

    /// Deletes a question and takes it out of every exam that used it.
    func deleteQuestion(_ id: String) {
        questions.removeAll { $0.id == id }
        exams = exams.map { ex in
            var c = ex
            c.qids.removeAll { $0 == id }
            return c
        }
    }

    // MARK: - Homework and submissions

    func homeworkById(_ id: String) -> Homework? { homework.first { $0.id == id } }

    func submission(_ hwId: String, _ email: String) -> Submission? {
        submissions.first { $0.hwId == hwId && $0.email == email }
    }

    func putSubmission(_ s: Submission) {
        submissions.removeAll { $0.hwId == s.hwId && $0.email == s.email }
        submissions.append(s)
    }

    func deleteHomework(_ id: String) {
        for s in submissions where s.hwId == id && !s.photo.isEmpty {
            try? FileManager.default.removeItem(at: photoFile(s.photo))
        }
        submissions.removeAll { $0.hwId == id }
        homework.removeAll { $0.id == id }
    }

    /// Average of every student's official-exam average (nil while nobody has taken an official exam). Android `teacherOfficialAverage`.
    func teacherOfficialAverage() -> Int? {
        let v = students.compactMap { officialAverage($0.email) }
        return v.isEmpty ? nil : v.reduce(0, +) / v.count
    }

    func ungraded() -> Int { submissions.filter { $0.grade < 0 }.count }

    /// A picked image, scaled down and ready to be saved.
    struct ScaledPhoto {
        let image: UIImage
        let jpeg: Data
    }

    /// Decodes a picked image and scales it down (max 1280 px, orientation applied); same idea as Android `savePhoto`.
    static func scaledPhoto(from data: Data, max m: CGFloat = 1280) -> ScaledPhoto? {
        guard let img = UIImage(data: data), img.size.width > 0, img.size.height > 0 else { return nil }
        let k = min(1, m / max(img.size.width, img.size.height))
        let size = CGSize(width: (img.size.width * k).rounded(), height: (img.size.height * k).rounded())
        let fmt = UIGraphicsImageRendererFormat.default()
        fmt.scale = 1
        let out = UIGraphicsImageRenderer(size: size, format: fmt).image { _ in img.draw(in: CGRect(origin: .zero, size: size)) }
        guard let jpg = out.jpegData(compressionQuality: 0.82) else { return nil }
        return ScaledPhoto(image: out, jpeg: jpg)
    }

    /// Writes the JPEG as a new file in Documents/hw. Returns the file name (not the path), or nil if it fails.
    func writeHomeworkPhoto(_ jpg: Data) -> String? {
        let name = Util.newId() + ".jpg"
        do {
            try jpg.write(to: photoFile(name), options: .atomic)
            return name
        } catch {
            return nil
        }
    }

    func deletePhotoFile(_ name: String) {
        try? FileManager.default.removeItem(at: photoFile(name))
    }

    // MARK: - Per student: favorites, notes, watch history

    private func favDict(_ email: String) -> [String: [String]] {
        guard let data = d.data(forKey: "fav:" + email),
              let o = try? JSONDecoder().decode([String: [String]].self, from: data) else { return [:] }
        return o
    }

    func favList(_ email: String, _ coll: String) -> [String] { favDict(email)[coll] ?? [] }

    func isIn(_ email: String, _ coll: String, _ key: String) -> Bool {
        favList(email, coll).contains(key)
    }

    func toggleIn(_ email: String, _ coll: String, _ key: String) {
        var o = favDict(email)
        var l = o[coll] ?? []
        if let i = l.firstIndex(of: key) { l.remove(at: i) } else { l.insert(key, at: 0) }
        o[coll] = l
        save("fav:" + email, o)
        objectWillChange.send()
    }

    func notes(_ email: String) -> [Note] { Store.load("notes:" + email, [Note]()) }

    func saveNotes(_ email: String, _ l: [Note]) {
        save("notes:" + email, l)
        objectWillChange.send()
    }

    /// Lesson ids, newest first, no duplicates.
    func history(_ email: String) -> [String] { Store.load("hist:" + email, [String]()) }

    func addHistory(_ email: String, _ lessonId: String) {
        let l = Array(([lessonId] + history(email).filter { $0 != lessonId }).prefix(200))
        save("hist:" + email, l)
        objectWillChange.send()
    }

    func clearHistory(_ email: String) {
        d.removeObject(forKey: "hist:" + email)
        objectWillChange.send()
    }

    /// (watched lessons, all lessons) for a student.
    func progress(_ email: String) -> (done: Int, total: Int) {
        let seen = Set(history(email))
        let visible = publishedLessons
        return (visible.filter { seen.contains($0.id) }.count, visible.count)
    }

    static func percent(_ p: (done: Int, total: Int)) -> Int {
        p.total == 0 ? 0 : p.done * 100 / p.total
    }
}


// MARK: - Release 35: paid-content access (ONE place decides), payments (skeleton), YouTube import

/// "May this student see this lesson?".
/// NOT DONE YET (needs the server): the answer comes from the local store, so it only hides the content in the app.
/// TODO(server): ask the server (`GET /access?lesson=<id>`) and make the server refuse to hand out the video (YouTube id / file URL)
/// to a student without a grant. Grants must then be written by the server only (teacher: cash / free, payment webhook: online).
enum Access {
    /// Teacher / admin preview: pass email = nil (always allowed).
    static func canView(_ store: Store, _ email: String?, _ l: Lesson) -> Bool {
        guard let email = email, store.isPaid(l) else { return true }
        return store.grants.contains { $0.email == email && ($0.target == "l:" + l.id || (!l.chapterId.isEmpty && $0.target == "c:" + l.chapterId)) }
    }
    static func shownPrice(_ store: Store, _ l: Lesson) -> Int { l.price > 0 ? l.price : store.coursePrice(l) }
}

/// Electronic payment (skeleton). Not built: needs a payment provider and the server.
/// TODO(payments): pick ONE provider (e-wallet or gateway), then: (1) the server creates an order (target, amount, student) and returns
/// the checkout URL; (2) the app opens it (SFSafariViewController) and waits; (3) the provider calls the SERVER webhook, the server
/// verifies the signature and writes the grant (mode "online"); (4) the app re-asks the server and opens the content automatically.
/// The app must never trust "payment done" from the screen itself.
enum Payments {
    /// Returns false while no provider is connected (the screen then shows the "soon" message).
    static func start(target: String, amount: Int, email: String, onPaid: @escaping () -> Void) -> Bool { false }
}

/// Imports a YouTube video's title and thumbnail through oEmbed (no API key). Calls [done] on any thread; nil if offline.
enum YtMeta {
    struct Info { let title: String; let thumb: String }
    static func thumbUrl(_ yt: String) -> String { "https://i.ytimg.com/vi/\(yt)/hqdefault.jpg" }

    static func fetch(_ yt: String, done: @escaping (Info?) -> Void) {
        let raw = "https://www.youtube.com/oembed?format=json&url=" + "https://youtu.be/\(yt)"
        guard let u = URL(string: raw.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? raw) else { return done(nil) }
        var rq = URLRequest(url: u); rq.timeoutInterval = 6
        URLSession.shared.dataTask(with: rq) { data, resp, _ in
            guard let data = data, (resp as? HTTPURLResponse)?.statusCode == 200,
                  let o = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return done(nil) }
            done(Info(title: o["title"] as? String ?? "", thumb: o["thumbnail_url"] as? String ?? thumbUrl(yt)))
        }.resume()
    }
}
