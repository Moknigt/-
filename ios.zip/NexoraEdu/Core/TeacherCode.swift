import Foundation
import CryptoKit

/// Teacher registration code: nobody can create a teacher account without one. A code is 6 random characters + 6 signature
/// characters (HMAC-SHA256 of the first 6 with `secret`), written XXXXXX-YYYYYY. It is checked offline (no server).
/// Each code works once per device. Make codes with `tools/gen_teacher_codes.py`; `secret` must be the same in all four places
/// (that script, Android `TeacherCode.kt`, here, Windows `TeacherCode.cs`). Changing it cancels every code made before.
enum TeacherCode {
    private static let secret = "rw54cHkLy7Gk_H53ezFrTLXwEuivdc7f"
    private static let alpha = Array("ABCDEFGHJKLMNPQRSTUVWXYZ23456789")
    private static let key = "t_used_codes"

    enum Result { case ok, empty, invalid, used }

    private static func signature(_ serial: String) -> String {
        let mac = HMAC<SHA256>.authenticationCode(for: Data("teacher:\(serial)".utf8), using: SymmetricKey(data: Data(secret.utf8)))
        let b = Array(mac)
        var n: UInt64 = 0
        for i in 0..<5 { n = (n << 8) | UInt64(b[i]) }
        return String((0..<6).map { alpha[Int((n >> UInt64(35 - 5 * $0)) & 31)] })
    }

    /// Only the code characters, upper case: spaces, dashes and typos like lower case are forgiven.
    private static func clean(_ raw: String) -> String { String(raw.uppercased().filter { alpha.contains($0) }) }

    private static func used() -> Set<String> { Set(UserDefaults.standard.stringArray(forKey: key) ?? []) }

    static func verify(_ raw: String) -> Result {
        if raw.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return .empty }
        let s = clean(raw)
        if s.count != 12 || signature(String(s.prefix(6))) != String(s.suffix(6)) { return .invalid }
        return used().contains(String(s.prefix(6))) ? .used : .ok
    }

    /// Call once the teacher account is really created.
    static func markUsed(_ raw: String) {
        let s = clean(raw)
        if s.count != 12 { return }
        var u = used()
        u.insert(String(s.prefix(6)))
        UserDefaults.standard.set(Array(u), forKey: key)
    }

    /// Localizable key of the message to show, or nil when the code is fine.
    static func errorKey(_ r: Result) -> String? {
        switch r {
        case .ok: return nil
        case .empty: return "err_tcode_required"
        case .invalid: return "err_tcode_invalid"
        case .used: return "err_tcode_used"
        }
    }
}
