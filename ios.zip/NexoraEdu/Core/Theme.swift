import SwiftUI

extension Color {
    init(hex: UInt32, opacity: Double = 1) {
        self.init(.sRGB,
                  red: Double((hex >> 16) & 0xFF) / 255,
                  green: Double((hex >> 8) & 0xFF) / 255,
                  blue: Double(hex & 0xFF) / 255,
                  opacity: opacity)
    }
}

/// Colors of the app. Same palette as the Android `colors.xml` (light + night) and the student/teacher accents.
struct Theme {
    var dark: Bool = true
    var teacher: Bool = false
    var admin: Bool = false
    /// Accent theme id (see Accents); "nexora" keeps the colours of the side.
    var accent: String = Accents.defaultId

    var bg1: Color { dark ? Color(hex: 0x060B1A) : Color(hex: 0xF4F8FC) }
    var bg2: Color { dark ? Color(hex: 0x0F1B3D) : Color(hex: 0xE6F2FB) }
    var bg3: Color { dark ? Color(hex: 0x082A3A) : Color(hex: 0xF4F8FC) }
    var tx: Color { dark ? Color(hex: 0xE8EEFC) : Color(hex: 0x0F1B3D) }
    var mut: Color { dark ? Color(hex: 0x93A3C7) : Color(hex: 0x5A6B8C) }
    var glass: Color { dark ? Color.white.opacity(0x12 / 255.0) : Color.white.opacity(0xC7 / 255.0) }
    /// Card glass stops copied from Android card_glass.xml / values-night.
    var glassHi: Color { dark ? Color.white.opacity(0x2E / 255.0) : Color.white.opacity(0xEB / 255.0) }
    var glassLo: Color { dark ? Color.white.opacity(0x0A / 255.0) : Color.white.opacity(0xA6 / 255.0) }
    var sheen: Color { dark ? Color.white.opacity(0x1C / 255.0) : Color.white.opacity(0x99 / 255.0) }
    var bd: Color { dark ? Color.white.opacity(0x24 / 255.0) : Color(hex: 0x0F1B3D, opacity: 0x1A / 255.0) }
    var bar: Color { dark ? Color(hex: 0x060B1A, opacity: 0.70) : Color.white.opacity(0.85) }
    var sheet: Color { dark ? Color(hex: 0x101C3B) : Color.white }
    var field: Color { dark ? Color.white.opacity(0.08) : Color(hex: 0x0F1B3D, opacity: 0.05) }
    var gold: Color { dark ? Color(hex: 0xF5C451) : Color(hex: 0xB7791F) }
    var err: Color { dark ? Color(hex: 0xFB7185) : Color(hex: 0xE11D48) }

    /// Student teal/blue, teacher indigo/purple, admin gold/orange (same values as Android `p1`/`tp1`/`ap1`).
    var p1: Color { if let a = Accents.find(accent) { return Color(hex: a.c1) }; return admin ? Color(hex: 0xD97706) : teacher ? Color(hex: 0x7C3AED) : Color(hex: 0x14B8A6) }
    var p2: Color { if let a = Accents.find(accent) { return Color(hex: a.c2) }; return admin ? Color(hex: 0xEA580C) : teacher ? Color(hex: 0xA855F7) : Color(hex: 0x3B82F6) }

    /// Left to right (buttons, chips, progress bars).
    var gradient: LinearGradient {
        LinearGradient(colors: [p1, p2], startPoint: UnitPoint(x: 0, y: 0.5), endPoint: UnitPoint(x: 1, y: 0.5))
    }

    /// Top-left to bottom-right (logo, avatar).
    var diagonal: LinearGradient {
        LinearGradient(colors: [p1, p2], startPoint: UnitPoint(x: 0, y: 0), endPoint: UnitPoint(x: 1, y: 1))
    }
}

private struct ThemeKey: EnvironmentKey {
    static let defaultValue = Theme()
}

extension EnvironmentValues {
    var theme: Theme {
        get { self[ThemeKey.self] }
        set { self[ThemeKey.self] = newValue }
    }
}

/// Screen background gradient (bg1 -> bg2 -> bg3, top-left to bottom-right).
struct AppBackground: View {
    @Environment(\.theme) private var th

    var body: some View {
        LinearGradient(colors: [th.bg1, th.bg2, th.bg3],
                       startPoint: UnitPoint(x: 0, y: 0),
                       endPoint: UnitPoint(x: 1, y: 1))
            .ignoresSafeArea()
    }
}

/// Paints the UIKit window and its root view with the app colour, so no black / system strip can show
/// behind the (transparent) status bar, while rotating, or when a screen is not full height.
struct WindowTint: UIViewRepresentable {
    let color: Color

    func makeUIView(context: Context) -> UIView {
        let v = UIView(frame: .zero)
        v.isUserInteractionEnabled = false
        v.backgroundColor = .clear
        return v
    }

    func updateUIView(_ uiView: UIView, context: Context) {
        let ui = UIColor(color)
        DispatchQueue.main.async {
            uiView.window?.backgroundColor = ui
            uiView.window?.rootViewController?.view.backgroundColor = ui
        }
    }
}

/// Glass card: translucent fill with a thin border.
struct GlassCard: ViewModifier {
    @Environment(\.theme) private var th
    var radius: CGFloat = 24

    func body(content: Content) -> some View {
        content
            .background {
                RoundedRectangle(cornerRadius: radius, style: .continuous)
                    .fill(LinearGradient(colors: [th.glassHi, th.glassLo], startPoint: .topLeading, endPoint: .bottomTrailing))
            }
            .overlay {
                RoundedRectangle(cornerRadius: radius, style: .continuous)
                    .fill(LinearGradient(colors: [th.sheen.opacity(0.72), .clear], startPoint: .top, endPoint: .bottom))
                    .allowsHitTesting(false)
            }
            .overlay(RoundedRectangle(cornerRadius: radius, style: .continuous).stroke(th.bd, lineWidth: 1))
    }
}

extension View {
    func glassCard(_ radius: CGFloat = 24) -> some View {
        modifier(GlassCard(radius: radius))
    }
}
