import Foundation
import CryptoKit
import UIKit

/// Small helpers shared by every screen.
enum Util {
    /// SHA-256 as lowercase hex (same hash the Android version stores for passwords).
    static func sha256(_ s: String) -> String {
        SHA256.hash(data: Data(s.utf8)).map { String(format: "%02x", $0) }.joined()
    }

    /// 12-character random id.
    static func newId() -> String {
        String(UUID().uuidString.replacingOccurrences(of: "-", with: "").lowercased().prefix(12))
    }

    /// Closes the keyboard (for example before the system file picker opens).
    static func hideKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }

    static func nowMillis() -> Int64 {
        Int64(Date().timeIntervalSince1970 * 1000)
    }

    /// yyyy/MM/dd with Western digits.
    static func dateText(_ ms: Int64) -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.dateFormat = "yyyy/MM/dd"
        return f.string(from: Date(timeIntervalSince1970: Double(ms) / 1000))
    }

    /// Extracts the 11-character YouTube id from a link (or a bare id). Empty if it is not valid.
    static func youtubeId(_ url: String) -> String {
        let u = url.trimmingCharacters(in: .whitespacesAndNewlines)
        let patterns = ["(?:youtu\\.be/|v=|embed/|shorts/|live/)([\\w-]{11})", "^([\\w-]{11})$"]
        for p in patterns {
            guard let re = try? NSRegularExpression(pattern: p) else { continue }
            let range = NSRange(u.startIndex..<u.endIndex, in: u)
            if let m = re.firstMatch(in: u, options: [], range: range),
               m.numberOfRanges > 1,
               let r = Range(m.range(at: 1), in: u) {
                return String(u[r])
            }
        }
        return ""
    }
}

extension String {
    var trimmed: String { trimmingCharacters(in: .whitespacesAndNewlines) }
}
