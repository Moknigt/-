import SwiftUI

// Building blocks of the screen bodies. Sizes, paddings and margins are copied from the Android layouts
// (item_card, item_row, item_tile, item_stat, item_empty...) and from Ui.kt / ShellActivity.kt.

extension View {
    /// Makes the view tappable only when [action] is given (cards and rows that open something).
    @ViewBuilder
    func tappable(_ action: (() -> Void)?) -> some View {
        if let a = action {
            self.contentShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                .onTapGesture { Sfx.shared.tap(); a() }
        } else {
            self
        }
    }

    /// `chip_bg`: glass fill, thin border, 12 radius.
    func chipBox() -> some View { modifier(ChipBox()) }
}

struct ChipBox: ViewModifier {
    @Environment(\.theme) private var th

    func body(content: Content) -> some View {
        content
            .background(RoundedRectangle(cornerRadius: 12, style: .continuous).fill(LinearGradient(colors: [th.glassHi, th.glassLo], startPoint: .topLeading, endPoint: .bottomTrailing)))
            .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(th.bd, lineWidth: 1))
    }
}

/// `item_card`: glass card with 16 padding and a 12 top margin. Free content inside.
struct CardBox<Content: View>: View {
    @Environment(\.theme) private var th
    var top: CGFloat = 12
    var onTap: (() -> Void)? = nil
    let content: Content

    init(top: CGFloat = 12, onTap: (() -> Void)? = nil, @ViewBuilder content: () -> Content) {
        self.top = top
        self.onTap = onTap
        self.content = content()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) { content }
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .glassCard(24)
            .tappable(onTap)
            .padding(.top, top)
    }
}

/// The three texts of a card: small gray line, big bold title, gray sub line (empty ones are skipped).
struct CardTexts: View {
    @Environment(\.theme) private var th
    var small: String? = nil
    let title: String
    var sub: String? = nil

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            if let s = small, !s.isEmpty {
                Text(s).font(.system(size: 12)).foregroundColor(th.mut)
            }
            Text(title).font(.system(size: 17, weight: .bold)).foregroundColor(th.tx)
            if let s = sub, !s.isEmpty {
                Text(s).font(.system(size: 13)).foregroundColor(th.mut).padding(.top, 4)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

/// `progress_bar`: 8 high track, gradient fill that starts at the start side. [top] is the margin above it.
struct ProgressBarView: View {
    @Environment(\.theme) private var th
    let pct: Int
    var top: CGFloat = 8

    var body: some View {
        GeometryReader { geo in
            let w = geo.size.width * CGFloat(min(max(pct, 0), 100)) / 100
            ZStack(alignment: .leading) {
                RoundedRectangle(cornerRadius: 4, style: .continuous).fill(th.field)
                RoundedRectangle(cornerRadius: 4, style: .continuous).fill(th.gradient)
                    .mask(alignment: .leading) { Rectangle().frame(width: w) }
            }
        }
        .frame(height: 8)
        .padding(.top, top)
    }
}

/// Small bordered number tag (`badge_bg`).
struct BadgeView: View {
    @Environment(\.theme) private var th
    let text: String

    var body: some View {
        Text(text)
            .font(.system(size: 11, weight: .bold))
            .foregroundColor(th.mut)
            .padding(.horizontal, 10)
            .padding(.vertical, 4)
            .background(RoundedRectangle(cornerRadius: 10, style: .continuous).fill(th.field))
            .overlay(RoundedRectangle(cornerRadius: 10, style: .continuous).stroke(th.bd, lineWidth: 1))
    }
}

/// Icon inside a small glass square (row icon 42/10, tile icon 40/9, empty icon 54/12, back button 42/10).
struct IconChip: View {
    @Environment(\.theme) private var th
    let icon: String
    var size: CGFloat = 42
    var pad: CGFloat = 10
    var tint: Color? = nil

    var body: some View {
        Icon(icon, size: size - pad * 2, color: tint ?? th.p1)
            .frame(width: size, height: size)
            .chipBox()
    }
}

/// Square icon button (40x40, 9 padding). The tint is chosen by the caller (heart red when on, etc.).
struct IconButton: View {
    let icon: String
    let tint: Color
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Icon(icon, size: 22, color: tint)
                .frame(width: 40, height: 40)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain).sfxTap()
    }
}

/// Big number + small label card. Two or three of these sit in a [StatRow].
struct StatBox: View {
    @Environment(\.theme) private var th
    let text: String
    let label: String

    init(num: Int, label: String) { text = "\(num)"; self.label = label }
    /// For values like "85%" or "-" (Android `addStatGridText`).
    init(text: String, label: String) { self.text = text; self.label = label }

    var body: some View {
        VStack(spacing: 0) {
            Text(text).font(.system(size: 28, weight: .bold)).foregroundColor(th.p1)
            Text(label).font(.system(size: 13)).foregroundColor(th.mut)
        }
        .padding(16)
        .frame(maxWidth: .infinity)
        .glassCard(24)
        .padding(.horizontal, 6)
        .padding(.top, 12)
    }
}

struct StatRow: View {
    let items: [(num: Int, label: String)]

    var body: some View {
        HStack(alignment: .top, spacing: 0) {
            ForEach(items.indices, id: \.self) { i in
                StatBox(num: items[i].num, label: items[i].label)
            }
        }
    }
}

/// Two text stats side by side (Android `addStatGridText`, 2 per row).
struct StatTextRow: View {
    let items: [(text: String, label: String)]

    var body: some View {
        HStack(alignment: .top, spacing: 0) {
            ForEach(items.indices, id: \.self) { i in
                StatBox(text: items[i].text, label: items[i].label)
            }
            if items.count == 1 { Color.clear.frame(maxWidth: .infinity) }
        }
    }
}

/// One tappable tile (icon, label, optional count).
struct TileSpec {
    let icon: String
    let label: String
    var count: Int? = nil
    let action: () -> Void
}

struct TileView: View {
    @Environment(\.theme) private var th
    let spec: TileSpec

    var body: some View {
        Button(action: spec.action) {
            VStack(spacing: 0) {
                IconChip(icon: spec.icon, size: 40, pad: 9)
                Text(spec.label)
                    .font(.system(size: 12, weight: .bold))
                    .foregroundColor(th.tx)
                    .multilineTextAlignment(.center)
                    .frame(maxWidth: .infinity)
                    .padding(.top, 8)
                if let c = spec.count {
                    Text("\(c)").font(.system(size: 11)).foregroundColor(th.mut)
                }
            }
            .padding(12)
            .frame(maxWidth: .infinity, minHeight: 92)
            .glassCard(24)
            .contentShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        }
        .buttonStyle(.plain).sfxTap()
        .padding(.horizontal, 6)
        .padding(.top, 12)
    }
}

/// Rows of three tiles (the last row is padded with empty cells so the tiles keep their width).
struct TileGrid: View {
    let items: [TileSpec]

    var body: some View {
        VStack(spacing: 0) {
            ForEach(0..<((items.count + 2) / 3), id: \.self) { r in
                HStack(alignment: .top, spacing: 0) {
                    ForEach(0..<3, id: \.self) { c in
                        let i = r * 3 + c
                        if i < items.count {
                            TileView(spec: items[i])
                        } else {
                            Color.clear.frame(maxWidth: .infinity, maxHeight: 1).padding(.horizontal, 6)
                        }
                    }
                }
            }
        }
    }
}

/// `item_empty`: centered icon + title + sub, 60 below the previous item.
struct EmptyState: View {
    @Environment(\.theme) private var th
    let icon: String
    let title: String
    let sub: String

    var body: some View {
        VStack(spacing: 0) {
            IconChip(icon: icon, size: 54, pad: 12)
            Text(title)
                .font(.system(size: 17, weight: .bold))
                .foregroundColor(th.tx)
                .multilineTextAlignment(.center)
                .padding(.top, 14)
            Text(sub)
                .font(.system(size: 13))
                .foregroundColor(th.mut)
                .multilineTextAlignment(.center)
                .padding(.top, 6)
        }
        .padding(24)
        .frame(maxWidth: .infinity)
        .padding(.top, 60)
    }
}

/// Section heading (17 bold, 20 above).
struct Heading: View {
    @Environment(\.theme) private var th
    let text: String

    var body: some View {
        Text(text)
            .font(.system(size: 17, weight: .bold))
            .foregroundColor(th.tx)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.top, 20)
    }
}

/// `item_row`: icon, title, optional sub, trailing buttons. The whole card opens [onTap].
struct ItemRow<Trailing: View>: View {
    @Environment(\.theme) private var th
    let icon: String
    let title: String
    var sub: String? = nil
    let trailing: Trailing
    var onTap: (() -> Void)? = nil

    init(icon: String, title: String, sub: String? = nil, onTap: (() -> Void)? = nil,
         @ViewBuilder trailing: () -> Trailing) {
        self.icon = icon
        self.title = title
        self.sub = sub
        self.onTap = onTap
        self.trailing = trailing()
    }

    var body: some View {
        HStack(spacing: 0) {
            IconChip(icon: icon, size: 42, pad: 10)
            VStack(alignment: .leading, spacing: 0) {
                Text(title).font(.system(size: 15, weight: .bold)).foregroundColor(th.tx)
                if let s = sub, !s.isEmpty {
                    Text(s).font(.system(size: 12)).foregroundColor(th.mut).padding(.top, 2)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.leading, 12)
            .padding(.trailing, 6)
            HStack(spacing: 0) { trailing }
        }
        .padding(14)
        .glassCard(24)
        .tappable(onTap)
        .padding(.top, 12)
    }
}

extension ItemRow where Trailing == EmptyView {
    init(icon: String, title: String, sub: String? = nil, onTap: (() -> Void)? = nil) {
        self.init(icon: icon, title: title, sub: sub, onTap: onTap) { EmptyView() }
    }
}

/// Back button + title (+ count badge) at the top of a sub-screen.
struct TopBar: View {
    @Environment(\.theme) private var th
    @EnvironmentObject private var prefs: Prefs
    let title: String
    var count: Int = -1
    let onBack: () -> Void

    var body: some View {
        HStack(spacing: 0) {
            Button(action: onBack) {
                Icon("chev", size: 22, color: th.tx)
                    .frame(width: 42, height: 42)
                    .chipBox()
            }
            .buttonStyle(.plain).sfxTap()
            .accessibilityLabel(prefs.t("back"))
            Text(title)
                .font(.system(size: 20, weight: .bold))
                .foregroundColor(th.tx)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.leading, 12)
            if count >= 0 { BadgeView(text: "\(count)") }
        }
        .padding(.top, 4)
    }
}

/// Text button in the accent color (or [color]), placed at the start edge like the Android `link()`.
struct StartLink: View {
    @Environment(\.theme) private var th
    let title: String
    var color: Color? = nil
    var top: CGFloat = 0
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 14, weight: .bold))
                .foregroundColor(color ?? th.p1)
                .padding(.horizontal, 12)
                .padding(.vertical, 10)
        }
        .buttonStyle(.plain).sfxTap()
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.top, top)
    }
}

/// Horizontal row of chips; exactly one is selected.
struct ChipRow: View {
    @Environment(\.theme) private var th
    let labels: [String]
    let selected: Int
    var top: CGFloat = 12
    let onSelect: (Int) -> Void

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(labels.indices, id: \.self) { i in
                    Button {
                        if i != selected { Sfx.shared.play(.select) }
                        onSelect(i)
                    } label: {
                        Text(labels[i])
                            .font(.system(size: 13, weight: .bold))
                            .foregroundColor(i == selected ? Color.white : th.tx)
                            .padding(.horizontal, 16)
                            .frame(height: 38)
                            .background(chipBackground(i == selected))
                    }
                    .buttonStyle(.plain).sfxTap()
                }
            }
        }
        .padding(.top, top)
    }

    @ViewBuilder
    private func chipBackground(_ on: Bool) -> some View {
        if on {
            RoundedRectangle(cornerRadius: 12, style: .continuous).fill(th.gradient)
        } else {
            RoundedRectangle(cornerRadius: 12, style: .continuous).fill(LinearGradient(colors: [th.glassHi, th.glassLo], startPoint: .topLeading, endPoint: .bottomTrailing))
                .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(th.bd, lineWidth: 1))
        }
    }
}

/// Multi-line text input in the look of `field_bg`.
struct TextArea: View {
    @Environment(\.theme) private var th
    let hint: String
    @Binding var text: String
    var lines: Int = 3

    var body: some View {
        TextField(hint, text: $text, prompt: Text(hint).foregroundColor(th.mut), axis: .vertical)
            .lineLimit(lines...10)
            .font(.system(size: 15))
            .foregroundColor(th.tx)
            .padding(.horizontal, 14)
            .padding(.vertical, 12)
            .frame(maxWidth: .infinity, minHeight: 52, alignment: .topLeading)
            .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(th.field))
            .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(th.bd, lineWidth: 1))
    }
}

// MARK: - Avatar (profile photo or first letter)

/// Round avatar: the student's photo when there is one (Documents/avatars), otherwise the first letter of the name
/// on the theme gradient. Redraws when a photo is saved or removed (`Store.avatarVersion`).
struct AvatarView: View {
    @EnvironmentObject private var store: Store
    @Environment(\.theme) private var th
    let email: String?
    let name: String
    let size: CGFloat

    private var photo: UIImage? {
        _ = store.avatarVersion
        guard let e = email else { return nil }
        return UIImage(contentsOfFile: store.avatarFile(e).path)
    }

    var body: some View {
        ZStack {
            Circle().fill(th.diagonal)
            if let img = photo {
                Image(uiImage: img)
                    .resizable()
                    .scaledToFill()
                    .frame(width: size, height: size)
                    .clipShape(Circle())
            } else {
                Text(name.isEmpty ? "?" : String(name.prefix(1)).uppercased())
                    .font(.system(size: size * 0.41, weight: .bold))
                    .foregroundColor(Color.white)
            }
        }
        .frame(width: size, height: size)
    }
}
