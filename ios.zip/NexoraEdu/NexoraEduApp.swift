import SwiftUI

@main
struct NexoraEduApp: App {
    @StateObject private var prefs = Prefs()
    @StateObject private var store = Store.shared

    init() {
        Sfx.shared.start(); AdminControl.registerBackground()
        // Release 59: no side scroll bar anywhere (also covers any scroll view that does not set showsIndicators itself).
        UIScrollView.appearance().showsVerticalScrollIndicator = false
        UIScrollView.appearance().showsHorizontalScrollIndicator = false
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(prefs)
                .environmentObject(store)
                // The whole app is laid out right-to-left, in both languages (same as the Android version).
                .environment(\.layoutDirection, .rightToLeft)
                .environment(\.locale, Locale(identifier: prefs.ar ? "ar" : "en"))
                .preferredColorScheme(prefs.dark ? .dark : .light)
        }
    }
}
