import SwiftUI

extension ShellUI {
    /// Asks first, then the server removes the account at once (it also refuses what is not allowed). `done` runs after the answer.
    func confirmRemove(_ prefs: Prefs, id: String, name: String, role: String, done: @escaping () -> Void) {
        confirm(prefs.tf(role == "admin" ? "confirm_remove_admin" : "confirm_remove_teacher", name),
                yes: prefs.t("adm_remove"), cancel: prefs.t("cancel")) {
            AdminControl.remove(id) { ok in
                self.toast(prefs.t(ok ? "adm_removed" : "err_remove_fail"))
                done()
            }
        }
    }
}

/// Release 55: every teacher and admin account on the server. Teachers: any admin can remove. Admins: only the main admin.
/// Nobody removes themselves or the main admin (the server refuses too).
struct AdminStaffList: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var ui: ShellUI
    @Environment(\.theme) private var th
    @State private var list: [AdminControl.Staff]? = nil
    @State private var loaded = false

    var body: some View {
        if Remote.enabled && Remote.signedIn {
            VStack(alignment: .leading, spacing: 0) {
                Heading(text: prefs.t("adm_staff_title"))
                if AdminControl.isMain {   // release 57: one-time activation code for a new admin
                    PrimaryButton(title: prefs.t("adm_newcode"), height: 46) { newCode() }
                        .padding(.bottom, 8)
                }
                if loaded {
                    if let l = list, !l.isEmpty {
                        ForEach(l) { s in row(s) }
                    } else {
                        Text(prefs.t(list == nil ? "adm_staff_fail" : "adm_staff_empty"))
                            .font(.system(size: 13)).foregroundColor(th.mut).padding(.top, 8)
                    }
                }
            }
            .onAppear(perform: load)
        }
    }

    private func load() {
        AdminControl.staff { list = $0; loaded = true }
    }

    private func newCode() {
        AdminControl.newCode { code in
            guard let code = code else { ui.toast(prefs.t("adm_newcode_fail")); return }
            ui.present(prefs.t("adm_newcode")) { AdminCodeSheet(code: code) }
        }
    }

    private func row(_ s: AdminControl.Staff) -> some View {
        let who = s.name.isEmpty ? (s.email.components(separatedBy: "@").first ?? s.email) : s.name
        let role = prefs.t(s.role == "admin" ? "role_admin_label" : "role_teacher_label")
        return ItemRow(icon: s.role == "admin" ? "key" : "user", title: who, sub: role + " · " + s.email) {
            trailing(s, who)
        }
    }

    @ViewBuilder
    private func trailing(_ s: AdminControl.Staff, _ who: String) -> some View {
        if s.removed {
            BadgeView(text: prefs.t("adm_removed_badge"))
        } else if s.id == Remote.userId {
            BadgeView(text: prefs.t("adm_you_badge"))
        } else if s.main {
            BadgeView(text: prefs.t("adm_main_badge"))
        } else if s.role == "teacher" || AdminControl.isMain {
            AdminChip(text: prefs.t("adm_remove")) {
                ui.confirmRemove(prefs, id: s.id, name: who, role: s.role) { load() }
            }
        }
    }
}

/// Release 55: main admin only (the server sends nothing to anyone else): who signed up / signed in as a teacher or admin and was not read yet.
struct AdminAlerts: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var ui: ShellUI
    @State private var list: [AdminControl.Event] = []

    var body: some View {
        if Remote.enabled && Remote.signedIn {
            VStack(alignment: .leading, spacing: 0) {
                if !list.isEmpty {
                    Heading(text: prefs.t("alerts_title"))
                    ForEach(list) { e in
                        ItemRow(icon: "key", title: AdminControl.alertText(e, ar: prefs.ar), sub: e.email + " · " + Self.day.string(from: e.at)) {
                            AdminChip(text: prefs.t("adm_remove")) {
                                ui.confirmRemove(prefs, id: e.userId, name: e.name.isEmpty ? e.email : e.name, role: e.role) { load() }
                            }
                        }
                    }
                    HStack {
                        Spacer(minLength: 0)
                        LinkButton(title: prefs.t("alerts_mark_read")) { AdminControl.markSeen { load() } }
                        Spacer(minLength: 0)
                    }
                    .padding(.top, 4)
                }
            }
            .onAppear(perform: load)
        }
    }

    private static let day: DateFormatter = {
        let f = DateFormatter(); f.locale = Locale(identifier: "en_US_POSIX"); f.dateFormat = "yyyy/MM/dd"; return f
    }()

    private func load() {
        AdminControl.events { list = $0 ?? [] }
    }
}

/// Release 57: body of the "new admin activation code" sheet: the code, copy, close. The code is shown once; it works for one admin, 7 days.
struct AdminCodeSheet: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var ui: ShellUI
    @Environment(\.theme) private var th
    let code: String

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text(prefs.t("adm_newcode_note"))
                .font(.system(size: 13))
                .foregroundColor(th.mut)
                .padding(.top, 10)
            Text(code)
                .font(.system(size: 26, weight: .bold, design: .monospaced))
                .foregroundColor(th.tx)
                .environment(\.layoutDirection, .leftToRight)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 18)
                .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(th.field))
                .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(th.bd, lineWidth: 1))
                .padding(.top, 12)
            PrimaryButton(title: prefs.t("stu_copy"), height: 50) {
                UIPasteboard.general.string = code
                ui.toast(prefs.t("stu_copied"))
            }
            .padding(.top, 14)
            StartLink(title: prefs.t("close")) { ui.dismiss() }
        }
    }
}
