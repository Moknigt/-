import SwiftUI

// MARK: - Dashboard (لوحة التحكم): five counters + the content actions

struct AdminDashboard: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            AdminAlerts()   // release 55: main admin only
            StatRow(items: [
                (num: store.students.count, label: prefs.t("stat_students")),
                (num: store.grades.count, label: prefs.t("stat_classes"))
            ])
            StatRow(items: [
                (num: store.chapters.count, label: prefs.t("stat_chapters")),
                (num: store.lessons.count, label: prefs.t("stat_lessons"))
            ])
            // Last counter alone in its row, half width (like the Android stat grid).
            HStack(alignment: .top, spacing: 0) {
                StatBox(num: store.docs.count, label: prefs.t("stat_files"))
                Color.clear.frame(maxWidth: .infinity, maxHeight: 1).padding(.horizontal, 6)
            }
            Heading(text: prefs.t("manage_content"))
            TileGrid(items: TeacherActions.tiles(prefs, store, ui))
        }
    }
}

// MARK: - Teacher (المدرس): email, change password, delete the account

struct AdminTeacher: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    @Environment(\.theme) private var th

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            teacherPart
            AdminStaffList()   // release 55: teachers / admins on the server, with Remove
        }
    }

    @ViewBuilder
    private var teacherPart: some View {
        if let t = store.teacher {
            VStack(alignment: .leading, spacing: 0) {
                CardBox { CardTexts(small: prefs.t("role_teacher_label"), title: t.displayName) }
                CardBox { CardTexts(small: prefs.t("email_label"), title: t.email) }
                PrimaryButton(title: prefs.t("adm_change_pw"), height: 50) {
                    ui.present(prefs.t("adm_change_pw")) { AdminPasswordSheet(forTeacher: true) }
                }
                .padding(.top, 16)
                LinkButton(title: prefs.t("adm_delete_teacher"), color: th.err) {
                    ui.confirm(prefs.t("confirm_delete_teacher"), yes: prefs.t("delete"), cancel: prefs.t("cancel")) {
                        store.deleteTeacher()
                    }
                }
                .frame(maxWidth: .infinity)
                .padding(.top, 6)
            }
        } else {
            EmptyState(icon: "user", title: prefs.t("adm_no_teacher"), sub: prefs.t("adm_no_teacher_sub"))
        }
    }
}

// MARK: - Students (الطلاب): search, class filter, active switch / code / delete on every card

struct AdminStudents: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @State private var query = ""
    @State private var gradeSel = 0

    var body: some View {
        if store.students.isEmpty {
            EmptyState(icon: "users", title: prefs.t("empty_students"), sub: prefs.t("empty_students_sub"))
        } else {
            let grades = store.grades
            let sel = gradeSel <= grades.count ? gradeSel : 0
            let grade: String? = sel > 0 ? grades[sel - 1] : nil
            let q = query.trimmed.lowercased()
            let shown = store.students.filter { matches($0, grade: grade, query: q) }
            VStack(alignment: .leading, spacing: 0) {
                SheetField(hint: prefs.t("hint_search"), text: $query, top: 4)
                ChipRow(labels: [prefs.t("all")] + grades, selected: sel, top: 10) { gradeSel = $0 }
                if shown.isEmpty {
                    EmptyState(icon: "users", title: prefs.t("empty_search"), sub: prefs.t("empty_search_sub"))
                } else {
                    ForEach(shown) { AdminStudentCard(student: $0) }
                }
            }
        }
    }
}

extension AdminStudents {
    /// Class filter (nil = all) and search by name or email (query already trimmed and lowercased).
    fileprivate func matches(_ s: Student, grade: String?, query q: String) -> Bool {
        if let g = grade, s.grade != g { return false }
        if q.isEmpty { return true }
        return s.name.lowercased().contains(q) || s.email.lowercased().contains(q)
    }
}

private struct AdminStudentCard: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    let student: Student

    var body: some View {
        CardBox {
            CardTexts(small: student.grade, title: student.name, sub: student.email)
            HStack(spacing: 8) {
                AdminChip(text: prefs.t(student.active ? "stu_active" : "stu_inactive"), on: student.active) {
                    toggleActive()
                }
                AdminChip(text: student.code.isEmpty ? prefs.t("stu_code_new") : student.code,
                          mono: !student.code.isEmpty) {
                    openCode()
                }
                Spacer(minLength: 0)
                TrashButton {
                    ui.confirmDelete(prefs, key: "confirm_delete_student", name: student.name) {
                        // release 75: also remove the student on the server (no network = nothing is deleted, so it can be retried;
                        // refused = this account is not a real admin there, only the local copy goes)
                        if Remote.enabled && Remote.signedIn {
                            AdminControl.removeStudent(student.email) { code in
                                if code <= 0 || code >= 500 { ui.toast(prefs.t("err_remove_fail")); return }
                                store.deleteStudent(student.email)
                            }
                        } else {
                            store.deleteStudent(student.email)
                        }
                    }
                }
            }
            .padding(.top, 12)
        }
    }

    private func toggleActive() {
        guard let i = store.students.firstIndex(where: { $0.email == student.email }) else { return }
        store.students[i].active.toggle()
    }

    /// Makes a code the first time, then shows it (copy / new code) in the same sheet the teacher side uses.
    private func openCode() {
        if student.code.isEmpty { StudentCodes.regenerate(store, student.email) }
        ui.present(prefs.t("stu_code_title")) { StudentCodeSheet(email: student.email) }
    }
}

/// Small pill button on a student card (filled with the gradient when [on]); same look as the teacher's.
struct AdminChip: View {
    @Environment(\.theme) private var th
    let text: String
    var on = false
    var mono = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(text)
                .font(.system(size: 12, weight: .bold, design: mono ? .monospaced : .default))
                .foregroundColor(on ? Color.white : th.tx)
                .environment(\.layoutDirection, mono ? .leftToRight : .rightToLeft)
                .padding(.horizontal, 14)
                .frame(height: 34)
                .background(background)
        }
        .buttonStyle(.plain).sfxTap()
    }

    @ViewBuilder
    private var background: some View {
        if on {
            RoundedRectangle(cornerRadius: 12, style: .continuous).fill(th.gradient)
        } else {
            RoundedRectangle(cornerRadius: 12, style: .continuous).fill(LinearGradient(colors: [th.glassHi, th.glassLo], startPoint: .topLeading, endPoint: .bottomTrailing))
                .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(th.bd, lineWidth: 1))
        }
    }
}

// MARK: - Content (المحتوى): actions + class list + everything uploaded, with delete buttons

struct AdminContent: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    let ctx: TeacherCtx

    var body: some View {
        let chapters = store.chapters
        let lessons = store.lessons
        let docs = store.docs
        VStack(alignment: .leading, spacing: 0) {
            TileGrid(items: TeacherActions.tiles(prefs, store, ui) + [
                TileSpec(icon: "grade", label: prefs.t("act_grade")) {
                    ui.present(prefs.t("act_grade")) { AddGradeSheet() }
                }
            ])

            Heading(text: prefs.t("classes_title"))
            ForEach(store.grades, id: \.self) { g in
                ItemRow(icon: "grade", title: g,
                        sub: prefs.tf("students_count", store.students.filter { $0.grade == g }.count)) {
                    TrashButton {
                        ui.confirmDelete(prefs, key: "confirm_delete_grade", name: g) {
                            store.grades.removeAll { $0 == g }
                        }
                    }
                }
            }

            if chapters.isEmpty && lessons.isEmpty && docs.isEmpty {
                EmptyState(icon: "folder", title: prefs.t("empty_content"), sub: prefs.t("empty_content_sub"))
            } else {
                let videos = lessons.filter { $0.chapterId.isEmpty }
                if !videos.isEmpty {
                    Heading(text: prefs.t("videos"))
                    ForEach(videos) { AdminLessonRow(lesson: $0, ctx: ctx) }
                }
                if !chapters.isEmpty { Heading(text: prefs.t("chapters_title")) }
                ForEach(chapters) { ch in
                    let ls = lessons.filter { $0.chapterId == ch.id }
                    ItemRow(icon: "folder", title: ch.title, sub: prefs.tf("lessons_count", ls.count)) {
                        TrashButton {
                            ui.confirmDelete(prefs, key: "confirm_delete_chapter", name: ch.title) {
                                store.deleteChapter(ch.id)
                            }
                        }
                    }
                    ForEach(ls) { AdminLessonRow(lesson: $0, ctx: ctx) }
                }
                let books = docs.filter { $0.kind == "book" }
                if !books.isEmpty {
                    Heading(text: prefs.t("books_title"))
                    ForEach(books) { AdminDocRow(doc: $0, ctx: ctx) }
                }
                let files = docs.filter { $0.kind == "file" }
                if !files.isEmpty {
                    Heading(text: prefs.t("files_title"))
                    ForEach(files) { AdminDocRow(doc: $0, ctx: ctx) }
                }
            }
        }
    }
}

/// Add a class to the list the students pick from when they sign up.
struct AddGradeSheet: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    @State private var name = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            SheetField(hint: prefs.t("hint_grade"), text: $name)
            PrimaryButton(title: prefs.t("add"), height: 50) { add() }
                .padding(.top, 16)
            StartLink(title: prefs.t("cancel")) { ui.dismiss() }
        }
    }

    private func add() {
        let n = name.trimmed
        if n.isEmpty {
            ui.toast(prefs.t("err_title"))
            return
        }
        if store.grades.contains(n) {
            ui.toast(prefs.t("err_grade_exists"))
            return
        }
        store.grades.append(n)
        ui.dismiss()
    }
}

// MARK: - My account (حسابي)

struct AdminAccountTab: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var ui: ShellUI
    let email: String
    let name: String

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            CardBox { CardTexts(small: prefs.t("role_admin_label"), title: name) }
            CardBox { CardTexts(small: prefs.t("email_label"), title: email) }
            PrimaryButton(title: prefs.t("adm_change_pw"), height: 50) {
                ui.present(prefs.t("adm_change_pw")) { AdminPasswordSheet(forTeacher: false) }
            }
            .padding(.top, 16)
            PrimaryButton(title: prefs.t("adm_storage"), height: 50) {
                ui.present(prefs.t("adm_storage")) { StorageSheet(canEdit: true) }
            }
            .padding(.top, 12)
        }
    }
}

// MARK: - Change password (the teacher's: new password only; the admin's own: current + new)

private struct SheetSecureField: View {
    @Environment(\.theme) private var th
    let hint: String
    @Binding var text: String

    var body: some View {
        SecureField(hint, text: $text, prompt: Text(hint).foregroundColor(th.mut))
            .font(.system(size: 15))
            .foregroundColor(th.tx)
            .multilineTextAlignment(.trailing)
            .environment(\.layoutDirection, .leftToRight)
            .padding(.horizontal, 14)
            .frame(maxWidth: .infinity, minHeight: 52)
            .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(th.field))
            .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(th.bd, lineWidth: 1))
            .padding(.top, 10)
    }
}

struct AdminPasswordSheet: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    let forTeacher: Bool
    @State private var old = ""
    @State private var new = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            if !forTeacher {
                SheetSecureField(hint: prefs.t("hint_current_password"), text: $old)
            }
            SheetSecureField(hint: prefs.t("hint_new_password"), text: $new)
            PrimaryButton(title: prefs.t("done"), height: 50) { save() }
                .padding(.top, 16)
            StartLink(title: prefs.t("cancel")) { ui.dismiss() }
        }
    }

    private func save() {
        if forTeacher {
            guard let t = store.teacher else { return }
            if new.count < 6 {
                ui.toast(prefs.t("err_teacher_short"))
                return
            }
            store.setTeacher(email: t.email, password: new, name: t.name) // keep the teacher's name
        } else {
            guard let a = store.admin else { return }
            if old.isEmpty || new.isEmpty {
                ui.toast(prefs.t("err_enter_creds"))
                return
            }
            if a.pw != Util.sha256(old) {
                ui.toast(prefs.t("err_pw_wrong"))
                return
            }
            if new.count < 6 {
                ui.toast(prefs.t("err_teacher_short"))
                return
            }
            store.setAdmin(email: a.email, password: new)
        }
        ui.dismiss()
        ui.toast(prefs.t("pw_changed"))
    }
}

// MARK: - Admin content rows (Android admin side keeps its simpler screens: delete only, no edit / move / hide)

struct AdminLessonRow: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    let lesson: Lesson
    let ctx: TeacherCtx

    var body: some View {
        ItemRow(icon: "play", title: lesson.title,
                sub: lesson.yt.isEmpty ? prefs.t("no_video_yet") : "YouTube",
                onTap: { ctx.openVideo(lesson) }) {
            TrashButton {
                ui.confirmDelete(prefs, name: lesson.title) { store.deleteLesson(lesson.id) }
            }
        }
    }
}

struct AdminDocRow: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    let doc: Doc
    let ctx: TeacherCtx

    var body: some View {
        ItemRow(icon: doc.kind == "book" ? "book" : "note", title: doc.title,
                sub: Util.dateText(doc.at),
                onTap: { ctx.openDoc(doc) }) {
            TrashButton {
                ui.confirmDelete(prefs, name: doc.title) { store.deleteDoc(doc.id) }
            }
        }
    }
}

// MARK: - Storage (التخزين): one usage bar per storage (display only); the admin edits name, limit, on/off and order only
// No R2 key, endpoint, bucket or size cap is known here: the server decides and refuses what is not allowed.

private func storageBytes(_ b: Int64) -> String {
    let gib = Double(1 << 30), mib = Double(1 << 20)
    let v = Double(b)
    if v >= gib { return String(format: "%.2f GB", locale: Locale(identifier: "en_US"), v / gib) }
    return String(format: "%.0f MB", locale: Locale(identifier: "en_US"), v / mib)
}

/// Arabic-Indic digits and the Arabic decimal mark -> plain digits and ".".
private func storageLatin(_ s: String) -> String {
    var o = ""
    for ch in s.trimmed {
        switch ch {
        case "٠": o.append("0"); case "١": o.append("1"); case "٢": o.append("2"); case "٣": o.append("3"); case "٤": o.append("4")
        case "٥": o.append("5"); case "٦": o.append("6"); case "٧": o.append("7"); case "٨": o.append("8"); case "٩": o.append("9")
        case "٫", ",", "،": o.append(".")
        default: o.append(ch)
        }
    }
    return o
}

struct StorageSheet: View {
    @EnvironmentObject private var prefs: Prefs
    @Environment(\.theme) private var th
    let canEdit: Bool
    @State private var items: [Remote.StorageInfo]? = nil
    @State private var failed = false
    @State private var editing: Remote.StorageInfo? = nil

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            if let e = editing {
                StorageEditForm(item: e, onSaved: { editing = nil; load() }, onCancel: { editing = nil })
            } else if !Remote.enabled {
                Text(prefs.t("st_not_ready")).font(.system(size: 14)).foregroundColor(th.mut)
            } else if failed {
                Text(prefs.t("st_load_fail")).font(.system(size: 14)).foregroundColor(th.err)
                PrimaryButton(title: prefs.t("st_retry"), height: 50) { load() }.padding(.top, 12)
            } else if let list = items {
                if list.isEmpty {
                    Text(prefs.t("st_empty")).font(.system(size: 15, weight: .bold)).foregroundColor(th.tx)
                    Text(prefs.t("st_empty_sub")).font(.system(size: 13)).foregroundColor(th.mut).padding(.top, 4)
                }
                ForEach(list, id: \.id) { s in row(s) }
            } else {
                ProgressView().frame(maxWidth: .infinity).padding(.vertical, 24)
            }
        }
        .onAppear { if items == nil { load() } }
    }

    private func row(_ s: Remote.StorageInfo) -> some View {
        CardBox(onTap: canEdit ? ({ editing = s }) : nil) {
            HStack(spacing: 8) {
                Text(s.name).font(.system(size: 16, weight: .bold)).foregroundColor(th.tx)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Text(prefs.t(s.active ? "st_on" : "st_off")).font(.system(size: 12, weight: .bold))
                    .foregroundColor(s.active ? th.p1 : th.err)
            }
            ProgressBarView(pct: Int((s.fraction * 100).rounded()), top: 10)
            Text(prefs.tf("st_used_fmt", storageBytes(s.usedBytes + s.reservedBytes), storageBytes(s.limitBytes)))
                .font(.system(size: 13)).foregroundColor(th.mut).padding(.top, 8)
            if s.reservedBytes > 0 {
                Text(prefs.tf("st_reserved_fmt", storageBytes(s.reservedBytes)))
                    .font(.system(size: 12)).foregroundColor(th.mut).padding(.top, 2)
            }
        }
    }

    private func load() {
        guard Remote.enabled else { return }
        failed = false; items = nil
        Remote.storages { r in
            if let r = r { items = r } else { failed = true }
        }
    }
}

private struct StorageEditForm: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var ui: ShellUI
    @Environment(\.theme) private var th
    let item: Remote.StorageInfo
    let onSaved: () -> Void
    let onCancel: () -> Void
    @State private var name = ""
    @State private var limit = ""
    @State private var order = ""
    @State private var active = true
    @State private var saving = false

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            SheetField(hint: prefs.t("st_name_hint"), text: $name)
            SheetField(hint: prefs.t("st_limit_hint"), text: $limit, ltr: true)
            SheetField(hint: prefs.t("st_order_hint"), text: $order, ltr: true)
            CardBox {
                HStack {
                    Text(prefs.t("st_switch")).font(.system(size: 15, weight: .bold)).foregroundColor(th.tx)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    Toggle("", isOn: $active.sfx()).labelsHidden().tint(th.p1)
                }
            }
            PrimaryButton(title: prefs.t("done"), height: 50) { save() }.padding(.top, 16)
            StartLink(title: prefs.t("cancel")) { onCancel() }
        }
        .onAppear {
            name = item.name
            limit = String(format: "%g", locale: Locale(identifier: "en_US"), Double(item.limitBytes) / Double(1 << 30))
            order = String(item.sortOrder)
            active = item.active
        }
    }

    private func save() {
        if saving { return }
        let n = name.trimmed
        guard !n.isEmpty else { ui.toast(prefs.t("err_title")); return }
        guard let gb = Double(storageLatin(limit)), gb > 0 else { ui.toast(prefs.t("st_bad_limit")); return }
        var s = item
        s.name = n
        s.limitBytes = Int64(gb * Double(1 << 30))
        s.sortOrder = Int(storageLatin(order)) ?? item.sortOrder
        s.active = active
        saving = true
        Remote.updateStorage(s) { ok in
            saving = false
            ui.toast(prefs.t(ok ? "st_saved" : "st_save_fail"))
            if ok { onSaved() }
        }
    }
}
