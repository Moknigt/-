import SwiftUI

/// The admin side (Android `AdminActivity`): the same shell (header + bottom tabs + sheets + settings) as the student and
/// teacher sides, with 5 tabs: dashboard, teacher, students, content, my account. Gold/orange accent (see `Theme.admin`).
/// The content actions, rows and add sheets are the teacher's (`TeacherActions`, `TeacherLessonRow`, `TeacherDocRow`).
struct AdminView: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @StateObject private var ui = ShellUI()
    let email: String

    @State private var tab = 0
    @State private var cover: PlayerCover? = nil

    init(email: String) { self.email = email }

    private let tabs = [
        ShellTab(labelKey: "tab_dashboard", icon: "home"),
        ShellTab(labelKey: "tab_teacher", icon: "user"),
        ShellTab(labelKey: "tab_students", icon: "users"),
        ShellTab(labelKey: "tab_content", icon: "folder"),
        ShellTab(labelKey: "tab_profile", icon: "key")
    ]

    /// Same as Android `email.substringBefore("@")`.
    private var displayName: String { email.components(separatedBy: "@").first ?? email }

    var body: some View {
        ShellFrame(ui: ui, helloKey: "welcome_admin", name: displayName, tabs: tabs, selected: tab,
                   screenKey: "\(tab)",
                   onSelect: { tab = $0 },
                   onSettings: { openSettings() }) {
            screen
        }
        .coverHost($cover, ui: ui)
    }

    private func openSettings() {
        ui.openSettings()
    }

    private var ctx: TeacherCtx {
        TeacherCtx(openVideo: { openVideo($0) }, openDoc: { openDoc($0) })
    }

    @ViewBuilder
    private var screen: some View {
        switch tab {
        case 0: AdminDashboard()
        case 1: AdminTeacher()
        case 2: AdminStudents()
        case 3: AdminContent(ctx: ctx)
        default: AdminAccountTab(email: email, name: displayName)
        }
    }

    // MARK: Opening content (no watch history, like the teacher)

    private func openVideo(_ l: Lesson) {
        if !store.hasVideo(l) {
            ui.toast(prefs.t("err_no_video"))
            return
        }
        cover = .video(store.videoItem(l))
    }

    private func openDoc(_ d: Doc) {
        guard FileManager.default.fileExists(atPath: store.docFile(d.id).path) else {
            ui.toast(prefs.t("err_no_file"))
            return
        }
        cover = .pdf(d)
    }
}
