import SwiftUI
import UIKit

// MARK: - Launch animation "atoms" (port of Android SplashView.kt, release 61)
//
//  1. dust floating on the screen is pulled together and forms the rounded square of the icon,
//  2. a second set of white / gold dust gathers inside the square and draws the flask (260 dots on the flask lines,
//     7 per bubble, 14 for the golden nucleus),
//  3. the real icon square takes over, the flask is TRACED stroke by stroke over it (little bubbles keep rising),
//  4. at BURST: a shine sweeps over the icon, two rings, 48 sparks and a 7% pulse of the whole icon.
//
// Everything is drawn with one SwiftUI Canvas (no libraries). Same timeline as Android: written for 4300 ms
// and played 1.3x faster, so the entry takes 3.3 s.

enum AtomTL {
    /// Real running time (ms). The timeline below was written for `timeline` ms and is played faster.
    static let totalMs: Double = 3300
    static let timeline: Double = 4300

    // timeline (ms, in the `timeline` scale)
    static let solidIn: CGFloat = 1100
    static let solidOut: CGFloat = 1750
    static let sqFade: CGFloat = 1550
    static let sqFadeEnd: CGFloat = 2100
    static let flaskIn: CGFloat = 2350
    static let flaskFull: CGFloat = 2950
    static let flFadeEnd: CGFloat = 3250
    static let burst: CGFloat = 2950
    static let burstEnd: CGFloat = 3950
}

/// A plain RGB colour, so dust can be mixed and drawn with any opacity quickly.
struct AtomRGB {
    var r: Double, g: Double, b: Double
    static let white = AtomRGB(r: 1, g: 1, b: 1)
    static let gold = AtomRGB(r: 245.0 / 255, g: 196.0 / 255, b: 81.0 / 255)

    init(r: Double, g: Double, b: Double) { self.r = r; self.g = g; self.b = b }
    init(_ c: Color) {
        var rr: CGFloat = 0, gg: CGFloat = 0, bb: CGFloat = 0, aa: CGFloat = 0
        UIColor(c).getRed(&rr, green: &gg, blue: &bb, alpha: &aa)
        r = Double(rr); g = Double(gg); b = Double(bb)
    }
    func mix(_ o: AtomRGB, _ f: Double) -> AtomRGB {
        let k = min(max(f, 0), 1)
        return AtomRGB(r: r + (o.r - r) * k, g: g + (o.g - g) * k, b: b + (o.b - b) * k)
    }
    func color(_ a: Double = 1) -> Color {
        Color(.sRGB, red: r, green: g, blue: b, opacity: min(max(a, 0), 1))
    }
}

/// Small seeded random generator (same dust every launch).
struct AtomRng {
    private var s: UInt64
    init(_ seed: UInt64) { s = (seed &* 0x9E37_79B9_7F4A_7C15) | 1 }
    mutating func next() -> CGFloat {
        s ^= s << 13; s ^= s >> 7; s ^= s << 17
        return CGFloat(s >> 11) / 9_007_199_254_740_992.0
    }
}

/// The flask artwork in the same 64 x 64 units as `FlaskMark` / `ic_flask.xml`.
enum AtomArt {
    static let rim: Path = {
        var p = Path()
        p.move(to: CGPoint(x: 24, y: 9)); p.addLine(to: CGPoint(x: 40, y: 9))
        return p
    }()
    static let glass: Path = {
        var p = Path()
        p.move(to: CGPoint(x: 28, y: 9))
        p.addLine(to: CGPoint(x: 28, y: 24))
        p.addLine(to: CGPoint(x: 12.5, y: 51.5))
        p.addQuadCurve(to: CGPoint(x: 16, y: 57), control: CGPoint(x: 9.5, y: 57))
        p.addLine(to: CGPoint(x: 48, y: 57))
        p.addQuadCurve(to: CGPoint(x: 51.5, y: 51.5), control: CGPoint(x: 54.5, y: 57))
        p.addLine(to: CGPoint(x: 36, y: 24))
        p.addLine(to: CGPoint(x: 36, y: 9))
        return p
    }()
    static let wave: Path = {
        var p = Path()
        p.move(to: CGPoint(x: 18, y: 42))
        p.addQuadCurve(to: CGPoint(x: 32, y: 42), control: CGPoint(x: 25, y: 38))
        p.addQuadCurve(to: CGPoint(x: 46, y: 42), control: CGPoint(x: 39, y: 46))
        return p
    }()
    static func orbit(_ degrees: CGFloat) -> Path {
        let e = Path(ellipseIn: CGRect(x: 32 - 8.5, y: 49 - 3, width: 17, height: 6))
        let t = CGAffineTransform(translationX: 32, y: 49)
            .rotated(by: degrees * .pi / 180)
            .translatedBy(x: -32, y: -49)
        return e.applying(t)
    }
    /// width 2.3 lines
    static let mainLines: [Path] = [rim, glass, wave]
    /// width 1.6 lines (the two orbits)
    static let thinLines: [Path] = [orbit(-30), orbit(30)]
    /// Flattens a path into a polyline (SwiftUI has no PathMeasure): used to put dust ON the lines.
    static func polyline(_ path: Path) -> [CGPoint] {
        var pts: [CGPoint] = []
        var start = CGPoint.zero
        var cur = CGPoint.zero
        let steps = 24
        path.forEach { el in
            switch el {
            case .move(let to):
                start = to; cur = to; pts.append(to)
            case .line(let to):
                pts.append(to); cur = to
            case .quadCurve(let to, let c):
                for i in 1...steps {
                    let t = CGFloat(i) / CGFloat(steps), u = 1 - t
                    pts.append(CGPoint(x: u * u * cur.x + 2 * u * t * c.x + t * t * to.x,
                                       y: u * u * cur.y + 2 * u * t * c.y + t * t * to.y))
                }
                cur = to
            case .curve(let to, let c1, let c2):
                for i in 1...steps {
                    let t = CGFloat(i) / CGFloat(steps), u = 1 - t
                    pts.append(CGPoint(
                        x: u * u * u * cur.x + 3 * u * u * t * c1.x + 3 * u * t * t * c2.x + t * t * t * to.x,
                        y: u * u * u * cur.y + 3 * u * u * t * c1.y + 3 * u * t * t * c2.y + t * t * t * to.y))
                }
                cur = to
            case .closeSubpath:
                pts.append(start); cur = start
            }
        }
        return pts
    }
    static func length(_ pts: [CGPoint]) -> CGFloat {
        var l: CGFloat = 0
        if pts.count > 1 { for i in 1..<pts.count { l += hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y) } }
        return l
    }
    /// the point at distance `d` along the polyline
    static func point(_ pts: [CGPoint], at d: CGFloat) -> CGPoint {
        guard pts.count > 1 else { return pts.first ?? .zero }
        var left = max(d, 0)
        for i in 1..<pts.count {
            let seg = hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y)
            if seg > 0 && left <= seg {
                let f = left / seg
                return CGPoint(x: pts[i - 1].x + (pts[i].x - pts[i - 1].x) * f,
                               y: pts[i - 1].y + (pts[i].y - pts[i - 1].y) * f)
            }
            left -= seg
        }
        return pts[pts.count - 1]
    }
    /// x, y, r
    static let bubbles: [(x: CGFloat, y: CGFloat, r: CGFloat)] = [(32, 19, 1.7), (33.5, 14, 1.1)]
}

/// All the dust (built once, when the position of the icon is known).
final class AtomModel {
    struct P {
        let sx: CGFloat, sy: CGFloat, tx: CGFloat, ty: CGFloat
        let delay: CGFloat, dur: CGFloat, r: CGFloat
        let col: AtomRGB
        let swirl: CGFloat, seed: CGFloat
    }

    let canvas: CGSize
    let cx: CGFloat, cy: CGFloat, size: CGFloat
    let c1: AtomRGB, c2: AtomRGB
    private(set) var square: [P] = []
    private(set) var flask: [P] = []
    /// angle, speed, size, seed
    private(set) var sparks: [(angle: CGFloat, speed: CGFloat, size: CGFloat, seed: CGFloat)] = []
    private(set) var stars: [(x: CGFloat, y: CGFloat, size: CGFloat, phase: CGFloat)] = []
    private var rnd = AtomRng(11)

    init(canvas: CGSize, center: CGPoint, side: CGFloat, color1: Color, color2: Color) {
        self.canvas = canvas
        cx = center.x; cy = center.y; size = side
        c1 = AtomRGB(color1); c2 = AtomRGB(color2)
        buildSquare()
        buildStars()
        buildFlask()
        buildSparks()
    }

    private func insideRound(_ x: CGFloat, _ y: CGFloat, _ left: CGFloat, _ top: CGFloat, _ rad: CGFloat) -> Bool {
        let px = min(max(x, left + rad), left + size - rad)
        let py = min(max(y, top + rad), top + size - rad)
        return hypot(x - px, y - py) <= rad + 0.5
    }

    private func buildSquare() {
        let w = max(canvas.width, 1), h = max(canvas.height, 1)
        let left = cx - size / 2, top = cy - size / 2
        let rad = size * 0.27
        var list: [P] = []
        let n = 650
        while list.count < n {
            var x: CGFloat, y: CGFloat
            if list.count % 100 < 35 {            // 35% on the outline (crisp edges), the rest fills the inside
                let per = 4 * size
                var s = rnd.next() * per
                if s < size { x = left + s; y = top }
                else if s < 2 * size { s -= size; x = left + size; y = top + s }
                else if s < 3 * size { s -= 2 * size; x = left + size - s; y = top + size }
                else { s -= 3 * size; x = left; y = top + size - s }
                if !insideRound(x, y, left, top, rad) { continue }
            } else {
                x = left + rnd.next() * size
                y = top + rnd.next() * size
                if !insideRound(x, y, left, top, rad) { continue }
            }
            let diag = Double(((x - left) + (y - top)) / (2 * size))
            list.append(P(
                sx: rnd.next() * w, sy: rnd.next() * h, tx: x, ty: y,
                delay: rnd.next() * 600, dur: 850 + rnd.next() * 300,
                r: 0.9 + rnd.next() * 1.1, col: c1.mix(c2, diag),
                swirl: (rnd.next() - 0.5) * 170, seed: rnd.next()))
        }
        square = list
    }

    private func buildStars() {
        stars = (0..<40).map { _ in (rnd.next(), rnd.next(), 0.6 + rnd.next() * 1.4, rnd.next() * 6.28) }
    }

    private func flaskParticle(_ x: CGFloat, _ y: CGFloat, _ color: AtomRGB, _ r: CGFloat) -> P {
        // starts somewhere inside the square, so the dust seems to gather "inside the icon"
        let sx = cx + (rnd.next() - 0.5) * size * 0.95
        let sy = cy + (rnd.next() - 0.5) * size * 0.95
        let delay = 1400 + rnd.next() * 450
        let dur = 600 + rnd.next() * 250
        let swirl = (rnd.next() - 0.5) * 60
        let seed = rnd.next()
        return P(sx: sx, sy: sy, tx: x, ty: y, delay: delay, dur: dur, r: r, col: color, swirl: swirl, seed: seed)
    }

    private func buildFlask() {
        let s = size * 0.654 / 64              // same proportion as the 68dp flask inside the 104dp icon
        let ox = cx - 32 * s, oy = cy - 32 * s
        let all = AtomArt.mainLines + AtomArt.thinLines
        let lines = all.map { AtomArt.polyline($0) }
        let lens = lines.map { AtomArt.length($0) }
        let sum = max(lens.reduce(0, +), 1)
        let total: CGFloat = 260
        var list: [P] = []
        for (i, pts) in lines.enumerated() {          // 260 dots spread over the flask lines
            let cnt = max(Int(total * lens[i] / sum), 8)
            for k in 0..<cnt {
                let pos = AtomArt.point(pts, at: lens[i] * (CGFloat(k) + rnd.next() * 0.6) / CGFloat(cnt))
                let r = 0.85 + rnd.next() * 0.6
                list.append(flaskParticle(ox + pos.x * s, oy + pos.y * s, .white, r))
            }
        }
        for b in AtomArt.bubbles {                    // 7 dots round every bubble
            for k in 0..<7 {
                let a = CGFloat(k) / 7 * 2 * .pi
                list.append(flaskParticle(ox + (b.x + cos(a) * b.r) * s, oy + (b.y + sin(a) * b.r) * s, .white, 0.8))
            }
        }
        for _ in 0..<14 {                             // the golden nucleus
            let a = rnd.next() * 2 * .pi
            let rr2 = rnd.next() * 2.3
            list.append(flaskParticle(ox + (32 + cos(a) * rr2) * s, oy + (49 + sin(a) * rr2) * s, .gold, 1.1))
        }
        flask = list
    }

    private func buildSparks() {
        sparks = (0..<48).map { _ -> (angle: CGFloat, speed: CGFloat, size: CGFloat, seed: CGFloat) in
            let a = rnd.next() * 2 * .pi
            let sp = 0.55 + rnd.next() * 0.9
            let sz = 1 + rnd.next() * 1.6
            let sd = rnd.next()
            return (angle: a, speed: sp, size: sz, seed: sd)
        }
    }

    // MARK: drawing

    static func smooth(_ x: CGFloat) -> CGFloat { let k = min(max(x, 0), 1); return k * k * (3 - 2 * k) }

    private func dot(_ c: GraphicsContext, _ x: CGFloat, _ y: CGFloat, _ r: CGFloat, _ col: Color) {
        c.fill(Path(ellipseIn: CGRect(x: x - r, y: y - r, width: r * 2, height: r * 2)), with: .color(col))
    }

    func drawParticles(_ c: GraphicsContext, _ arr: [P], now: CGFloat, fadeIn: Bool, alphaMul: CGFloat) {
        if alphaMul <= 0.01 { return }
        for p in arr {
            let pr = min(max((now - p.delay) / p.dur, 0), 1)
            let e = 1 - pow(1 - pr, 3)
            var x = p.sx + (p.tx - p.sx) * e
            var y = p.sy + (p.ty - p.sy) * e
            if pr <= 0 {                          // waiting: float around where it started
                x += sin(now * 0.0021 + p.seed * 6.28) * 7
                y += cos(now * 0.0017 + p.seed * 6.28) * 7
            } else if pr < 1 {                    // flying: a curved path, not a straight line
                let dx = p.tx - p.sx, dy = p.ty - p.sy
                let len = max(hypot(dx, dy), 1)
                let bend = p.swirl * 4 * pr * (1 - pr)
                x += -dy / len * bend
                y += dx / len * bend
            } else {                              // arrived: tiny shimmer
                x += sin(now * 0.006 + p.seed * 6.28) * 0.7
                y += cos(now * 0.005 + p.seed * 6.28) * 0.7
            }
            var a = alphaMul
            if fadeIn { a *= AtomModel.smooth((now - (p.delay - 250)) / 250) }
            if a <= 0.01 { continue }
            dot(c, x, y, p.r * 2.4, p.col.color(Double(a) * 60 / 255))
            if pr > 0 && pr < 1 {                 // a short fading tail behind every flying dot
                let dx2 = p.tx - p.sx, dy2 = p.ty - p.sy
                let len2 = max(hypot(dx2, dy2), 1)
                for k in 1...2 {
                    let pk = max(pr - CGFloat(k) * 0.05, 0)
                    let ek = 1 - pow(1 - pk, 3)
                    let bend2 = p.swirl * 4 * pk * (1 - pk)
                    let tx2 = p.sx + dx2 * ek - dy2 / len2 * bend2
                    let ty2 = p.sy + dy2 * ek + dx2 / len2 * bend2
                    dot(c, tx2, ty2, p.r * (1 - CGFloat(k) * 0.2), p.col.color(Double(a) * Double(95 - k * 28) / 255))
                }
            }
            dot(c, x, y, p.r, p.col.color(Double(a)))
        }
    }

    func draw(_ ctx: GraphicsContext, t now: CGFloat) {
        // the whole icon gives a small 7% pulse when the burst happens
        let bk = min(max((now - AtomTL.burst) / 500, 0), 1)
        let bump: CGFloat = (now >= AtomTL.burst && now <= AtomTL.burst + 500) ? 1 + 0.07 * sin(bk * .pi) : 1
        var c = ctx
        c.translateBy(x: cx, y: cy)
        c.scaleBy(x: bump, y: bump)
        c.translateBy(x: -cx, y: -cy)
        drawAll(c, t: now)
    }

    private func drawAll(_ ctx: GraphicsContext, t now: CGFloat) {
        // twinkling background dust
        let sa = 1 - AtomModel.smooth((now - AtomTL.flFadeEnd) / 700) * 0.6
        for st in stars {
            let tw = 0.5 + 0.5 * sin(now * 0.0032 + st.phase)
            let base = st.phase > 3.1 ? c1 : AtomRGB.white
            dot(ctx, st.x * canvas.width, st.y * canvas.height + sin(now * 0.0007 + st.phase) * 6, st.size,
                base.color(Double(tw * sa * 120 / 255)))
        }
        let left = cx - size / 2, top = cy - size / 2
        let rad = size * 0.27
        let rect = CGRect(x: left, y: top, width: size, height: size)

        // soft glow behind the square
        let solid = AtomModel.smooth((now - AtomTL.solidIn) / (AtomTL.solidOut - AtomTL.solidIn))
        if solid > 0 {
            let pulse = 0.85 + 0.15 * sin(now * 0.004)
            var hc = ctx
            hc.opacity = Double(solid * pulse)
            let grad = Gradient(stops: [
                .init(color: c1.color(0x66 / 255.0), location: 0),
                .init(color: c2.color(0x22 / 255.0), location: 0.55),
                .init(color: Color.clear, location: 1),
            ])
            let hr = size * 1.15
            hc.fill(Path(ellipseIn: CGRect(x: cx - hr, y: cy - hr, width: hr * 2, height: hr * 2)),
                    with: .radialGradient(grad, center: CGPoint(x: cx, y: cy), startRadius: 0, endRadius: hr))

            // the solid icon square (+ glass sheen on its top half)
            let sc = 1 + 0.05 * (1 - solid)
            var sq = ctx
            sq.opacity = Double(solid)
            sq.translateBy(x: cx, y: cy)
            sq.scaleBy(x: sc, y: sc)
            sq.translateBy(x: -cx, y: -cy)
            let rr = Path(roundedRect: rect, cornerRadius: rad)
            sq.fill(rr, with: .linearGradient(Gradient(colors: [c1.color(), c2.color()]),
                                              startPoint: CGPoint(x: left, y: top),
                                              endPoint: CGPoint(x: left + size, y: top + size)))
            sq.fill(rr, with: .linearGradient(Gradient(colors: [Color.white.opacity(0.25), Color.white.opacity(0)]),
                                              startPoint: CGPoint(x: 0, y: top),
                                              endPoint: CGPoint(x: 0, y: top + size * 0.5)))
        }

        // square dust (fades out while the solid square takes over)
        drawParticles(ctx, square, now: now, fadeIn: false,
                      alphaMul: 1 - AtomModel.smooth((now - AtomTL.sqFade) / (AtomTL.sqFadeEnd - AtomTL.sqFade)))

        // flask dust, then the real flask fades in over it
        let real = AtomModel.smooth((now - AtomTL.flaskIn) / (AtomTL.flaskFull - AtomTL.flaskIn))
        drawParticles(ctx, flask, now: now, fadeIn: true,
                      alphaMul: 1 - AtomModel.smooth((now - AtomTL.flaskFull) / (AtomTL.flFadeEnd - AtomTL.flaskFull)))
        if real > 0 { drawFlask(ctx, alpha: real, now: now) }

        // shine sweeping over the icon + two rings + sparks = the "transformation"
        if now >= AtomTL.burst && now <= AtomTL.burstEnd {
            let k = (now - AtomTL.burst) / (AtomTL.burstEnd - AtomTL.burst)
            // shine band, clipped to the rounded square
            var sh = ctx
            sh.clip(to: Path(roundedRect: rect, cornerRadius: rad))
            let bx = left - size * 0.6 + (size * 2.2) * AtomModel.smooth(k)
            sh.fill(Path(rect), with: .linearGradient(
                Gradient(stops: [
                    .init(color: Color.white.opacity(0), location: 0),
                    .init(color: Color.white.opacity(Double(0x66) / 255), location: 0.5),
                    .init(color: Color.white.opacity(0), location: 1),
                ]),
                startPoint: CGPoint(x: bx, y: top),
                endPoint: CGPoint(x: bx + size * 0.5, y: top + size * 0.5)))
            // ring 1
            let ringR = size * (0.55 + 0.9 * AtomModel.smooth(k))
            ctx.stroke(Path(ellipseIn: CGRect(x: cx - ringR, y: cy - ringR, width: ringR * 2, height: ringR * 2)),
                       with: .color(c1.color(Double((1 - k) * 200 / 255))),
                       style: StrokeStyle(lineWidth: 2))
            // ring 2 (starts a little later)
            let k2 = min(max((now - AtomTL.burst - 220) / (AtomTL.burstEnd - AtomTL.burst), 0), 1)
            if k2 > 0 && k2 < 1 {
                let r2 = size * (0.5 + 1.2 * AtomModel.smooth(k2))
                ctx.stroke(Path(ellipseIn: CGRect(x: cx - r2, y: cy - r2, width: r2 * 2, height: r2 * 2)),
                           with: .color(c2.color(Double((1 - k2) * 160 / 255))),
                           style: StrokeStyle(lineWidth: 1.5))
            }
            // sparks
            for s in sparks {
                let sp = min(max(k - s.seed * 0.15, 0), 1)
                let dist = size * (0.5 + s.speed * 0.9 * (1 - pow(1 - sp, 2)))
                let a = 1 - sp
                let base = s.seed > 0.5 ? AtomRGB.gold : AtomRGB.white
                dot(ctx, cx + cos(s.angle) * dist, cy + sin(s.angle) * dist, s.size * (1 - sp * 0.5),
                    base.color(Double(a * 230 / 255)))
            }
        }
    }

    /// `alpha` 0..1 = how much of the flask is drawn: the lines are traced, then the bubbles and the nucleus appear.
    private func drawFlask(_ ctx: GraphicsContext, alpha: CGFloat, now: CGFloat) {
        let s = size * 0.654 / 64
        var c = ctx
        c.translateBy(x: cx - 32 * s, y: cy - 32 * s)
        c.scaleBy(x: s, y: s)
        let a = min(alpha * 3, 1)
        let white = Color.white.opacity(Double(a))
        func line(_ p: Path, _ w: CGFloat) {
            c.stroke(p.trimmedPath(from: 0, to: alpha), with: .color(white),
                     style: StrokeStyle(lineWidth: w, lineCap: .round, lineJoin: .round))
        }
        for p in AtomArt.mainLines { line(p, 2.3) }
        for p in AtomArt.thinLines { line(p, 1.6) }
        let tail = min(max((alpha - 0.6) / 0.4, 0), 1)
        for b in AtomArt.bubbles {
            c.stroke(Path(ellipseIn: CGRect(x: b.x - b.r, y: b.y - b.r, width: b.r * 2, height: b.r * 2)),
                     with: .color(Color.white.opacity(Double(tail))),
                     style: StrokeStyle(lineWidth: b.r > 1.5 ? 1.5 : 1.3, lineCap: .round, lineJoin: .round))
        }
        c.fill(Path(ellipseIn: CGRect(x: 32 - 2.4, y: 49 - 2.4, width: 4.8, height: 4.8)),
               with: .color(AtomRGB.gold.color(Double(tail))))
        // small bubbles keep rising inside the flask once it is complete
        if now > AtomTL.flaskFull {
            let f = min(max((now - AtomTL.flaskFull) / 700, 0), 1)
            for i in 0..<5 {
                let ph = ((now - AtomTL.flaskFull) * 0.0009 + CGFloat(i) * 0.2).truncatingRemainder(dividingBy: 1)
                let bx = 32 + sin(ph * 12.56 + CGFloat(i)) * (1.2 + CGFloat(i) * 0.5) * (0.4 + 0.6 * (1 - ph))
                let by = 54 - ph * 26
                let r = 0.9 + CGFloat(i % 3) * 0.35
                c.fill(Path(ellipseIn: CGRect(x: bx - r, y: by - r, width: r * 2, height: r * 2)),
                       with: .color(Color.white.opacity(Double((1 - ph) * 170 / 255 * f))))
            }
        }
    }
}

/// The animated layer (sits behind the texts, over the whole screen).
struct AtomLayer: View {
    let model: AtomModel
    let start: Date

    var body: some View {
        TimelineView(.animation) { tl in
            Canvas { ctx, _ in
                let ms = min(max(tl.date.timeIntervalSince(start) * 1000, 0), AtomTL.totalMs)
                let t = CGFloat(ms * AtomTL.timeline / AtomTL.totalMs)
                model.draw(ctx, t: t)
            }
        }
        .allowsHitTesting(false)
    }
}
