import SwiftUI

/// Sign in / sign up (student) and teacher sign in. Same flow and messages as the Android LoginActivity.
struct LoginView: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @Environment(\.theme) private var envTh
    /// The teacher side of the sign-in screen is purple (indicator, button, chips, logo); the student side keeps the normal accent.
    private var th: Theme { Theme(dark: envTh.dark, teacher: teacher && !admin, admin: envTh.admin, accent: envTh.accent) }

    private enum Field: Hashable { case code, name, email, phone, pass, pass2 }

    @State private var teacher = false
    @State private var admin = false
    @State private var signup = false
    @State private var name = ""
    @State private var email = ""
    @State private var phone = ""
    @State private var tcode = ""
    @State private var pass = ""
    @State private var pass2 = ""
    @State private var gradeIndex = 0
    @State private var passVisible = false
    @State private var errorKey: String? = nil
    @State private var shakes = 0
    @State private var phoneErrorKey: String? = nil
    @State private var showOtp = false
    @State private var pending: PendingStudent? = nil
    @State private var otpPhone = ""
    @State private var otpThen: (() -> Void)? = nil
    @State private var appeared = false
    @FocusState private var focus: Field?

    /// A validated sign-up waiting for the code check (only used while `OtpConfig.PhoneOtpEnabled` is true).
    private struct PendingStudent { let name: String; let phone: String; let email: String; let pw: String; let grade: String }

    /// Sign-up mode (student or teacher). The teacher types a full name too; student and teacher both give a phone, only the student also picks a class.
    private var up: Bool { signup && !admin }
    private var studentUp: Bool { up && !teacher }
    /// First admin sign in: no admin account yet, so the screen creates one.
    private var adminSetup: Bool { admin && store.admin == nil }
    /// The confirm-password field: new account (student or teacher) and the first admin account.
    private var needsConfirm: Bool { adminSetup || up }
    /// A teacher account is about to be created (sign-up ticked, or the very first teacher sign in): the registration code is needed.
    /// Release 57: the admin sets up the account with an activation code too (the first admin ever leaves it empty).
    private var needsCode: Bool { adminSetup || (teacher && !admin && (signup || store.teacher == nil)) }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 0) {
                FlaskMark()
                    .frame(width: 54, height: 54)
                    .frame(width: 84, height: 84)
                    .background(RoundedRectangle(cornerRadius: 28, style: .continuous).fill(th.diagonal))
                    // Hidden entry to the admin side: hold the logo for 7 full seconds. Lifting the finger earlier
                    // cancels it. No `pressing` handler on purpose: nothing shows while holding.
                    .onLongPressGesture(minimumDuration: 7, maximumDistance: 40) { openAdmin() }
                Text(prefs.t("app_name"))
                    .font(.system(size: 26, weight: .bold))
                    .foregroundColor(th.tx)
                    .padding(.top, 14)
                Text(prefs.t("tagline"))
                    .font(.system(size: 13))
                    .foregroundColor(th.mut)
                    .padding(.top, 4)

                card
                    .padding(.top, 26)
                    .modifier(Shake(animatableData: CGFloat(shakes)))
            }
            .padding(.horizontal, 20)
            .padding(.top, 40)
            .padding(.bottom, 28)
            .opacity(appeared ? 1 : 0)
            .offset(y: appeared ? 0 : 36)
        }
        .background(GlassAurora(strength: 0.55).ignoresSafeArea())
        .environment(\.theme, th)
        .animation(.easeInOut(duration: 0.3), value: teacher)
        .onAppear { withAnimation(.spring(response: 0.7, dampingFraction: 0.82)) { appeared = true } }
        .otpSheet(isPresented: $showOtp,
                  phone: otpPhone,
                  send: { done in PhoneVerifier.send(otpPhone, ar: prefs.ar, done: done) },
                  openWa: { PhoneVerifier.openWhatsApp(ar: prefs.ar) },
                  verify: { code, done in PhoneVerifier.check(otpPhone, code: code, done: done) },
                  onVerified: { showOtp = false; otpThen?() })
        .scrollDismissesKeyboard(.interactively)
        .onChange(of: name) { _ in errorKey = nil }
        .onChange(of: tcode) { _ in errorKey = nil }
        .onChange(of: email) { _ in errorKey = nil }
        .onChange(of: phone) { _ in errorKey = nil; phoneErrorKey = nil }
        .onChange(of: focus) { f in
            // leaving the phone field of the student sign-up shows what is wrong with the number
            if up, f != .phone, !phone.trimmed.isEmpty { phoneErrorKey = PhoneRules.errorKey(phone) }
        }
        .onChange(of: pass) { _ in errorKey = nil }
        .onChange(of: pass2) { _ in errorKey = nil }
    }

    // MARK: - Card

    private var card: some View {
        VStack(alignment: .leading, spacing: 0) {
            header
            fields
            messages
            actions
        }
        .padding(18)
        .glassCard(24)
    }

    @ViewBuilder
    private var header: some View {
        VStack(alignment: .leading, spacing: 0) {
            if !admin {
                SegmentedPills(
                    options: [prefs.t("role_student"), prefs.t("role_teacher")],
                    selected: teacher ? 1 : 0
                ) { i in setRole(i == 1) }
            }

            Text(prefs.t(titleKey))
                .font(.system(size: 20, weight: .bold))
                .foregroundColor(th.tx)
                .padding(.top, 18)
            Text(prefs.t(subtitleKey))
                .font(.system(size: 13))
                .foregroundColor(th.mut)
                .padding(.top, 2)
                .padding(.bottom, 6)
        }
    }

    @ViewBuilder
    private var fields: some View {
        VStack(alignment: .leading, spacing: 0) {
            if needsCode {
                FieldRow(icon: "key") {
                    TextField(prefs.t(admin ? "adm_code_hint" : "hint_tcode"), text: $tcode,
                              prompt: Text(prefs.t(admin ? "adm_code_hint" : "hint_tcode")).foregroundColor(th.mut))
                        .font(.system(size: 15))
                        .foregroundColor(th.tx)
                        .textInputAutocapitalization(.characters)
                        .autocorrectionDisabled(true)
                        .submitLabel(.next)
                        .focused($focus, equals: .code)
                        .onSubmit { focus = up ? Field.name : Field.email }
                        .environment(\.layoutDirection, .leftToRight)
                }
                .padding(.top, 10)
            }

            if up {
                FieldRow(icon: "person") {
                    TextField(prefs.t("hint_name"), text: $name,
                              prompt: Text(prefs.t("hint_name")).foregroundColor(th.mut))
                        .font(.system(size: 15))
                        .foregroundColor(th.tx)
                        .textContentType(.name)
                        .textInputAutocapitalization(.words)
                        .submitLabel(.next)
                        .focused($focus, equals: .name)
                        .onSubmit { focus = .email }
                }
                .padding(.top, 10)
            }

            FieldRow(icon: "envelope") {
                TextField(prefs.t("hint_email"), text: $email,
                          prompt: Text(prefs.t("hint_email")).foregroundColor(th.mut))
                    .font(.system(size: 15))
                    .foregroundColor(th.tx)
                    .keyboardType(.emailAddress)
                    .textContentType(.emailAddress)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled(true)
                    .submitLabel(.next)
                    .focused($focus, equals: .email)
                    .onSubmit { focus = up ? Field.phone : Field.pass }
                    .environment(\.layoutDirection, .leftToRight)
            }
            .padding(.top, 10)

            if up {
                FieldRow(icon: "phone") {
                    TextField(prefs.t("hint_phone"), text: $phone,
                              prompt: Text(prefs.t("hint_phone")).foregroundColor(th.mut))
                        .font(.system(size: 15))
                        .foregroundColor(th.tx)
                        .keyboardType(.phonePad)
                        .textContentType(.telephoneNumber)
                        .submitLabel(.next)
                        .focused($focus, equals: .phone)
                        .onSubmit { focus = .pass }
                        .environment(\.layoutDirection, .leftToRight)
                }
                .padding(.top, 10)

                // the phone is required for a new student and a new teacher: the message sits right under the field
                if let k = phoneErrorKey {
                    Text(prefs.t(k))
                        .font(.system(size: 12))
                        .foregroundColor(th.err)
                        .padding(.top, 6)
                        .padding(.horizontal, 4)
                }
            }

            FieldRow(icon: "lock") {
                HStack(spacing: 0) {
                    passwordInput
                    Button {
                        passVisible.toggle()
                    } label: {
                        Image(systemName: passVisible ? "eye.slash" : "eye")
                            .font(.system(size: 17))
                            .foregroundColor(th.mut)
                            .frame(width: 40, height: 40)
                    }
                    .buttonStyle(.plain).sfxTap()
                    .accessibilityLabel(prefs.t("show_password"))
                }
            }
            .padding(.top, 10)

            if needsConfirm {
                FieldRow(icon: "lock") {
                    confirmInput
                }
                .padding(.top, 10)
            }

            // Release 18: the class is one of 3 fixed glass chips (no typing). Extra classes the teacher adds are not offered here.
            if studentUp {
                GradeChips(title: prefs.t("grade_pick_title"),
                           labels: ["grade_1_short", "grade_2_short", "grade_3_short"].map { prefs.t($0) },
                           selected: gradeIndex) { gradeIndex = $0 }
                    .padding(.top, 10)
            }

        }
    }

    @ViewBuilder
    private var messages: some View {
        VStack(alignment: .leading, spacing: 0) {
            if teacher && !admin && !up && store.teacher == nil {
                Text(prefs.t("teacher_first_hint"))
                    .font(.system(size: 12))
                    .foregroundColor(th.mut)
                    .padding(.top, 10)
            }

            if let k = errorKey {
                Text(prefs.t(k))
                    .font(.system(size: 13))
                    .foregroundColor(th.err)
                    .padding(.top, 10)
            }

        }
    }

    @ViewBuilder
    private var actions: some View {
        VStack(alignment: .leading, spacing: 0) {
            Button {
                submit()
            } label: {
                Text(prefs.t((up || adminSetup) ? "btn_signup" : "btn_signin"))
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(Color.white)
                    .frame(maxWidth: .infinity, minHeight: 52)
                    .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(th.gradient))
            }
            .buttonStyle(.plain).sfxTap()
            .padding(.top, 16)

            if admin {
                HStack(spacing: 6) {
                    Button {
                        closeAdmin()
                    } label: {
                        Text(prefs.t("back"))
                            .font(.system(size: 14, weight: .bold))
                            .foregroundColor(th.p1)
                            .padding(6)
                    }
                    .buttonStyle(.plain).sfxTap()
                }
                .frame(maxWidth: .infinity)
                .padding(.top, 10)
            } else {
                HStack(spacing: 6) {
                    Text(prefs.t(up ? "q_have_account" : "q_new_here"))
                        .font(.system(size: 13))
                        .foregroundColor(th.mut)
                    Button {
                        signup.toggle()
                        errorKey = nil
                    } label: {
                        Text(prefs.t(up ? "btn_signin" : "btn_signup"))
                            .font(.system(size: 14, weight: .bold))
                            .foregroundColor(th.p1)
                            .padding(6)
                    }
                    .buttonStyle(.plain).sfxTap()
                }
                .frame(maxWidth: .infinity)
                .padding(.top, 10)
            }
        }
    }

    @ViewBuilder
    private var passwordInput: some View {
        if passVisible {
            TextField(prefs.t("hint_password"), text: $pass,
                      prompt: Text(prefs.t("hint_password")).foregroundColor(th.mut))
                .font(.system(size: 15))
                .foregroundColor(th.tx)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled(true)
                .submitLabel(needsConfirm ? .next : .done)
                .focused($focus, equals: .pass)
                .onSubmit { if needsConfirm { focus = .pass2 } else { submit() } }
                .environment(\.layoutDirection, .leftToRight)
        } else {
            SecureField(prefs.t("hint_password"), text: $pass,
                        prompt: Text(prefs.t("hint_password")).foregroundColor(th.mut))
                .font(.system(size: 15))
                .foregroundColor(th.tx)
                .textContentType(.password)
                .submitLabel(needsConfirm ? .next : .done)
                .focused($focus, equals: .pass)
                .onSubmit { if needsConfirm { focus = .pass2 } else { submit() } }
                .environment(\.layoutDirection, .leftToRight)
        }
    }

    /// Confirm-password input of the "create admin account" screen (shows or hides with the same eye button).
    @ViewBuilder
    private var confirmInput: some View {
        if passVisible {
            TextField(prefs.t("hint_password_confirm"), text: $pass2,
                      prompt: Text(prefs.t("hint_password_confirm")).foregroundColor(th.mut))
                .font(.system(size: 15))
                .foregroundColor(th.tx)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled(true)
                .submitLabel(.done)
                .focused($focus, equals: .pass2)
                .onSubmit { submit() }
                .environment(\.layoutDirection, .leftToRight)
        } else {
            SecureField(prefs.t("hint_password_confirm"), text: $pass2,
                        prompt: Text(prefs.t("hint_password_confirm")).foregroundColor(th.mut))
                .font(.system(size: 15))
                .foregroundColor(th.tx)
                .submitLabel(.done)
                .focused($focus, equals: .pass2)
                .onSubmit { submit() }
                .environment(\.layoutDirection, .leftToRight)
        }
    }

    private var titleKey: String {
        if admin { return adminSetup ? "title_admin_setup" : "title_admin" }
        if teacher { return "title_teacher" }
        return up ? "title_signup" : "title_signin"
    }

    private var subtitleKey: String {
        if admin { return adminSetup ? "sub_admin_setup" : "sub_admin" }
        if teacher { return "sub_teacher" }
        return up ? "sub_signup" : "sub_signin"
    }

    // MARK: - Actions

    private func setRole(_ t: Bool) {
        if teacher == t { return }
        teacher = t
        signup = false
        errorKey = nil
    }

    /// Reached after holding the logo for 7 seconds: one light haptic tap, then the admin sign in.
    private func openAdmin() {
        if admin { return }
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        admin = true
        signup = false
        clearFields()
    }

    private func closeAdmin() {
        admin = false
        clearFields()
    }

    private func clearFields() {
        name = ""; email = ""; phone = ""; pass = ""; pass2 = ""; tcode = ""
        errorKey = nil
        phoneErrorKey = nil
        Util.hideKeyboard()
    }

    private func fail(_ key: String) {
        Sfx.shared.play(.error)
        errorKey = key
        withAnimation(.linear(duration: 0.38)) { shakes += 1 }
    }

    /// Phone problem of the student / teacher sign-up: written under the field, the card shakes and the cursor goes to the field.
    private func failPhone(_ key: String) {
        Sfx.shared.play(.error)
        phoneErrorKey = key
        focus = .phone
        withAnimation(.linear(duration: 0.38)) { shakes += 1 }
    }

    @State private var busy = false

    /// Release 53: an account is created only when the server accepted it first (needs internet). [ok] creates the local account.
    private func online(_ role: String, _ email: String, _ pass: String, name: String = "", phone: String = "", grade: String = "", code: String = "", _ ok: @escaping () -> Void) {
        if busy { return }
        busy = true
        ServerSync.register(role: role, email: email, pass: pass, name: name, phone: phone, grade: grade, code: code) { err in
            busy = false
            if let k = err { fail(k) } else { ok() }
        }
    }

    /// Release 64: the number must be proven before the account is made. WhatsApp opens with a ready message, the student sends it from HIS number,
    /// the server answers with a 6-digit code in the chat, the student types it in the sheet, and only then `then` runs.
    /// Without a server (Remote.enabled false) or with OtpConfig.PhoneOtpEnabled false it runs at once.
    private func askPhoneCode(_ phone: String, then: @escaping () -> Void) {
        guard OtpConfig.PhoneOtpEnabled, Remote.enabled else { then(); return }
        PhoneVerifier.clear()
        otpPhone = phone
        otpThen = then
        showOtp = true
    }

    private func createPending() {
        guard let p = pending else { return }
        online("student", p.email, pass, name: p.name, phone: p.phone, grade: p.grade) {
            store.students.append(Student(name: p.name, phone: p.phone, email: p.email, pw: p.pw, grade: p.grade))
            Sfx.shared.play(.success); store.setSession(role: "student", email: p.email)
            pending = nil
        }
    }

    private func submit() {
        let e = email.trimmed.lowercased()

        if admin {
            if e.isEmpty || pass.isEmpty { fail("err_enter_creds"); return }
            if let a = store.admin {
                if a.email != e || a.pw != Util.sha256(pass) { fail("err_bad_login"); return }
            } else {
                if !e.contains("@") { fail("err_enter_creds"); return }
                if pass.count < 6 { fail("err_teacher_short"); return }
                if pass != pass2 { fail("err_pw_mismatch"); return }
                // release 57: the server decides first (first admin = main, the others need a one-time code); then the local admin is made
                online("admin", e, pass, code: tcode) {
                    store.setAdmin(email: e, password: pass)
                    Sfx.shared.play(.success); store.setSession(role: "admin", email: e)
                }
                return
            }
            Sfx.shared.play(.success); store.setSession(role: "admin", email: e)
            ServerSync.mirror(role: "admin", email: e, pass: pass, store: store)
            return
        }

        if teacher {
            if e.isEmpty || pass.isEmpty { fail("err_enter_creds"); return }
            if signup {
                // Teacher sign-up (Android): full name is required; a second teacher account is refused.
                if !e.contains("@") { fail("err_enter_creds"); return }
                if store.teacher != nil { fail("err_teacher_exists"); return }
                if let k = TeacherCode.errorKey(TeacherCode.verify(tcode)) { fail(k); return }
                let tn = name.trimmed
                if tn.isEmpty { fail("err_name_required"); return }
                if pass.count < 6 { fail("err_teacher_short"); return }
                if pass != pass2 { fail("err_pw_mismatch"); return }
                // phone: required, checked by PhoneRules (same as the student sign-up)
                let tPhoneKey = PhoneRules.errorKey(phone)
                phoneErrorKey = tPhoneKey
                if let k = tPhoneKey { failPhone(k); return }
                guard let tp = PhoneRules.normalize(phone) else { failPhone("err_phone_invalid"); return }
                askPhoneCode(tp) {
                    online("teacher", e, pass, name: tn, phone: tp, code: tcode) {
                        store.setTeacher(email: e, password: pass, name: tn, phone: tp)
                        TeacherCode.markUsed(tcode)
                        Sfx.shared.play(.success); store.setSession(role: "teacher", email: e)
                    }
                }
                return
            } else if let t = store.teacher {
                if t.email != e || t.pw != Util.sha256(pass) { fail("err_bad_login"); return }
            } else {
                if !e.contains("@") { fail("err_enter_creds"); return }
                if let k = TeacherCode.errorKey(TeacherCode.verify(tcode)) { fail(k); return }
                if pass.count < 6 { fail("err_teacher_short"); return }
                online("teacher", e, pass, code: tcode) {
                    store.setTeacher(email: e, password: pass)
                    TeacherCode.markUsed(tcode)
                    Sfx.shared.play(.success); store.setSession(role: "teacher", email: e)
                }
                return
            }
            Sfx.shared.play(.success); store.setSession(role: "teacher", email: e)
            ServerSync.mirror(role: "teacher", email: e, pass: pass, store: store)
            return
        }

        if !signup {
            if e.isEmpty || pass.isEmpty { fail("err_enter_creds"); return }
            guard let s = store.findStudent(e), s.pw == Util.sha256(pass) else {
                fail("err_bad_login"); return
            }
            Sfx.shared.play(.success); store.setSession(role: "student", email: s.email)
            ServerSync.mirror(role: "student", email: s.email, pass: pass, store: store)
            return
        }

        let n = name.trimmed
        // phone: required, checked by PhoneRules; the message goes under the field (also when something else is missing too)
        let phoneKey = PhoneRules.errorKey(phone)
        phoneErrorKey = phoneKey
        if n.isEmpty || !e.contains("@") || pass.count < 6 {
            fail("err_fill_all"); return
        }
        if let k = phoneKey { failPhone(k); return }
        if pass != pass2 { fail("err_pw_mismatch"); return }
        guard let p = PhoneRules.normalize(phone) else { failPhone("err_phone_invalid"); return }
        if store.students.contains(where: { $0.email == e }) { fail("err_email_used"); return }
        // The stored value is still the Arabic class name, so existing students, filters and exams keep working.
        let fixed = Store.defaultGrades
        let grade = fixed.indices.contains(gradeIndex) ? fixed[gradeIndex] : fixed[0]
        pending = PendingStudent(name: n, phone: p, email: e, pw: Util.sha256(pass), grade: grade)
        askPhoneCode(p) { createPending() }
    }
}

// MARK: - Class chips (Android `GradeChips`): 1st / 2nd / 3rd secondary, the chosen one filled with the accent gradient

struct GradeChips: View {
    @Environment(\.theme) private var th
    let title: String
    let labels: [String]
    let selected: Int
    let onSelect: (Int) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.system(size: 12))
                .foregroundColor(th.mut)
            HStack(spacing: 8) {
                ForEach(labels.indices, id: \.self) { i in
                    let on = i == selected
                    Button {
                        withAnimation(.spring(response: 0.3, dampingFraction: 0.65)) { onSelect(i) }
                    } label: {
                        Text(labels[i])
                            .font(.system(size: 13, weight: .bold))
                            .multilineTextAlignment(.center)
                            .lineLimit(2)
                            .minimumScaleFactor(0.85)
                            .foregroundColor(on ? Color.white : th.tx)
                            .padding(.horizontal, 6)
                            .frame(maxWidth: .infinity, minHeight: 48)
                            .background(
                                RoundedRectangle(cornerRadius: 14, style: .continuous)
                                    .fill(on ? AnyShapeStyle(th.gradient) : AnyShapeStyle(th.field))
                            )
                            .overlay(
                                RoundedRectangle(cornerRadius: 14, style: .continuous)
                                    .stroke(on ? Color.clear : th.bd, lineWidth: 1)
                            )
                            .scaleEffect(on ? 1.04 : 1)
                    }
                    .buttonStyle(.plain).sfxTap()
                }
            }
        }
    }
}
