import SwiftUI

/// Phone verification settings. The OTP screen and everything that depends on it stays hidden while `PhoneOtpEnabled` is false.
enum OtpConfig {
    /// Master switch. false = `otpSheet` never presents and sign-up works exactly as before.
    static let PhoneOtpEnabled = false
    static let codeLength = 6
    static let resendSeconds = 60
}

/// The code entry screen: 6 boxes, a wrong-code state and a resend link that counts down for real.
/// It does not send or check anything itself: `verify` decides if the code is right, `onResend` sends a new one.
/// Present it with `.otpSheet(...)` so the flag `OtpConfig.PhoneOtpEnabled` is honoured.
struct OtpView: View {
    @EnvironmentObject private var prefs: Prefs
    @Environment(\.theme) private var th

    let phone: String
    let verify: (String) -> Bool
    let onResend: () -> Void
    let onVerified: () -> Void
    var onCancel: () -> Void = {}

    @State private var code = ""
    @State private var wrong = false
    @State private var sentAgain = false
    @State private var left = OtpConfig.resendSeconds
    @State private var shakes = 0
    @State private var verified = false
    @FocusState private var focused: Bool

    private let ticker = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    private var full: Bool { code.count == OtpConfig.codeLength }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text(prefs.t("otp_title"))
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(th.tx)
            Text(prefs.tf("otp_sub", phone))
                .font(.system(size: 13))
                .foregroundColor(th.mut)
                .padding(.top, 4)

            ZStack {
                // the digits always run left to right, also in Arabic
                HStack(spacing: 8) {
                    ForEach(0..<OtpConfig.codeLength, id: \.self) { i in box(i) }
                }
                .environment(\.layoutDirection, .leftToRight)
                .modifier(Shake(animatableData: CGFloat(shakes)))

                // one real (almost invisible) field: it keeps the keyboard, paste and the SMS suggestion in one place
                TextField("", text: $code)
                    .keyboardType(.numberPad)
                    .textContentType(.oneTimeCode)
                    .focused($focused)
                    .foregroundColor(.clear)
                    .accentColor(.clear)
                    .frame(width: 1, height: 1)
                    .opacity(0.02)
            }
            .padding(.top, 22)
            .contentShape(Rectangle())
            .onTapGesture { focused = true }

            if wrong {
                Text(prefs.t("otp_err_wrong"))
                    .font(.system(size: 13))
                    .foregroundColor(th.err)
                    .frame(maxWidth: .infinity)
                    .padding(.top, 14)
            } else if sentAgain {
                Text(prefs.t("otp_sent_again"))
                    .font(.system(size: 13))
                    .foregroundColor(th.mut)
                    .frame(maxWidth: .infinity)
                    .padding(.top, 14)
            }

            PrimaryButton(title: prefs.t("otp_verify")) { submit() }
                .opacity(full ? 1 : 0.45)
                .disabled(!full)
                .padding(.top, 18)

            HStack {
                Spacer()
                if left > 0 {
                    Text(prefs.tf("otp_resend_in", String(format: "%02d:%02d", left / 60, left % 60)))
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(th.mut)
                        .padding(.vertical, 10)
                } else {
                    LinkButton(title: prefs.t("otp_resend")) { resend() }
                }
                Spacer()
            }
            .padding(.top, 4)
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 20)
        .padding(.top, 24)
        .padding(.bottom, 12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(th.sheet.ignoresSafeArea())
        .onReceive(ticker) { _ in if left > 0 { left -= 1 } }
        .onChange(of: code) { v in
            let digits = String(v.filter { $0.isNumber }.prefix(OtpConfig.codeLength))
            if digits != v { code = digits }
            wrong = false
            sentAgain = false
        }
        .onAppear { DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { focused = true } }
        .onDisappear { if !verified { onCancel() } }
    }

    /// The next empty box is outlined in the accent colour; every box turns red after a wrong code.
    private func box(_ i: Int) -> some View {
        let chars = Array(code)
        let active = focused && i == min(code.count, OtpConfig.codeLength - 1)
        let outline = wrong ? th.err : (active ? th.p1 : th.bd)
        return Text(i < chars.count ? String(chars[i]) : "")
            .font(.system(size: 22, weight: .bold))
            .foregroundColor(th.tx)
            .frame(maxWidth: .infinity, minHeight: 54)
            .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(th.field))
            .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous)
                .stroke(outline, lineWidth: (wrong || active) ? 2 : 1))
    }

    private func submit() {
        guard full else { return }
        if verify(code) {
            verified = true
            Sfx.shared.play(.success)
            onVerified()
        } else {
            wrong = true
            Sfx.shared.play(.error)
            withAnimation(.linear(duration: 0.38)) { shakes += 1 }
        }
    }

    private func resend() {
        onResend()
        code = ""
        wrong = false
        left = OtpConfig.resendSeconds
        sentAgain = true
    }
}

extension View {
    /// Presents the code entry screen as a bottom sheet. Nothing is shown while `OtpConfig.PhoneOtpEnabled` is false.
    func otpSheet(isPresented: Binding<Bool>,
                  phone: String,
                  verify: @escaping (String) -> Bool,
                  onResend: @escaping () -> Void,
                  onVerified: @escaping () -> Void,
                  onCancel: @escaping () -> Void = {}) -> some View {
        sheet(isPresented: Binding(
            get: { isPresented.wrappedValue && OtpConfig.PhoneOtpEnabled },
            set: { isPresented.wrappedValue = $0 }
        )) {
            OtpView(phone: phone, verify: verify, onResend: onResend, onVerified: onVerified, onCancel: onCancel)
                .presentationDetents([.medium, .large])
        }
    }
}
