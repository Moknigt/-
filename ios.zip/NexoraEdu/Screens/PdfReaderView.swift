import SwiftUI
import PDFKit

/// Loads the PDF and tracks the current page; the buttons of the reader drive it.
final class PdfController: ObservableObject {
    let document: PDFDocument?
    @Published var page = 0
    @Published var count = 0
    weak var view: PDFView?

    init(url: URL) {
        document = PDFDocument(url: url)
        count = document?.pageCount ?? 0
    }

    /// Goes to page [i] (0-based, clamped to the document).
    func go(_ i: Int) {
        guard let d = document, d.pageCount > 0 else { return }
        let n = min(max(i, 0), d.pageCount - 1)
        if let p = d.page(at: n) { view?.go(to: p) }
        page = n
    }
}

/// PDFKit view showing one page at a time, fitted to the screen (pinch to zoom).
struct PdfKitView: UIViewRepresentable {
    let controller: PdfController

    func makeCoordinator() -> Coordinator { Coordinator(controller) }

    func makeUIView(context: Context) -> PDFView {
        let v = PDFView()
        v.document = controller.document
        v.displayMode = .singlePage
        v.displayDirection = .vertical
        v.autoScales = true
        v.backgroundColor = .clear
        controller.view = v
        NotificationCenter.default.addObserver(context.coordinator,
                                               selector: #selector(Coordinator.pageChanged(_:)),
                                               name: .PDFViewPageChanged, object: v)
        return v
    }

    func updateUIView(_ uiView: PDFView, context: Context) {}

    final class Coordinator: NSObject {
        let controller: PdfController

        init(_ c: PdfController) { controller = c }

        @objc func pageChanged(_ n: Notification) {
            guard let v = n.object as? PDFView, let p = v.currentPage, let d = v.document else { return }
            controller.page = d.index(for: p)
        }

        deinit { NotificationCenter.default.removeObserver(self) }
    }
}

/// In-app PDF reader (same screen as the Android PdfActivity): back + title on top,
/// the page in the middle, previous / page number / next at the bottom.
struct PdfReaderView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var prefs: Prefs
    @Environment(\.theme) private var th
    @StateObject private var pc: PdfController
    let doc: Doc
    let onFail: () -> Void

    init(doc: Doc, onFail: @escaping () -> Void) {
        self.doc = doc
        self.onFail = onFail
        _pc = StateObject(wrappedValue: PdfController(url: Store.shared.docFile(doc.id)))
    }

    var body: some View {
        ZStack {
            AppBackground()
            VStack(spacing: 0) {
                topBar
                PdfKitView(controller: pc)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                Rectangle().fill(th.bd).frame(height: 1)
                bottomBar
            }
        }
        .onAppear {
            if pc.document == nil || pc.count == 0 {
                onFail()
                DispatchQueue.main.async { dismiss() }
            }
        }
    }

    private var topBar: some View {
        HStack(spacing: 0) {
            Button {
                dismiss()
            } label: {
                Icon("chev", size: 24, color: th.tx)
                    .frame(width: 44, height: 44)
                    .chipBox()
            }
            .buttonStyle(.plain).sfxTap()
            .accessibilityLabel(prefs.t("back"))
            Text(doc.title)
                .font(.system(size: 16, weight: .bold))
                .foregroundColor(th.tx)
                .lineLimit(2)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.leading, 12)
        }
        .padding(12)
    }

    /// The screen is right-to-left, so "previous" sits on the right, but page numbers still go 1 -> N.
    private var bottomBar: some View {
        HStack(spacing: 0) {
            Button {
                pc.go(pc.page - 1)
            } label: {
                Text(prefs.t("pdf_prev"))
                    .font(.system(size: 14, weight: .bold))
                    .foregroundColor(th.tx)
                    .padding(.horizontal, 20)
                    .frame(height: 42)
                    .chipBox()
            }
            .buttonStyle(.plain).sfxTap()
            Text("\(pc.page + 1) / \(pc.count)")
                .font(.system(size: 13))
                .foregroundColor(th.mut)
                .frame(maxWidth: .infinity)
            Button {
                pc.go(pc.page + 1)
            } label: {
                Text(prefs.t("pdf_next"))
                    .font(.system(size: 14, weight: .bold))
                    .foregroundColor(Color.white)
                    .padding(.horizontal, 20)
                    .frame(height: 42)
                    .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(th.gradient))
            }
            .buttonStyle(.plain).sfxTap()
        }
        .padding(.horizontal, 16)
        .frame(height: 64)
        .background(th.bar.ignoresSafeArea(edges: .bottom))
    }
}
