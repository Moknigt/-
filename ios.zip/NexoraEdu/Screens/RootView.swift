import SwiftUI

/// Splash -> (student / teacher / admin home when a valid session exists, otherwise login).
struct RootView: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @State private var splashDone = false
    @Environment(\.scenePhase) private var scenePhase

    /// "admin" / "teacher" / "student" when the saved session still points to a real account, otherwise nil.
    private var role: String? {
        guard let s = store.session else { return nil }
        if s.role == "admin", store.admin != nil { return "admin" }
        if s.role == "teacher", store.teacher != nil { return "teacher" }
        if s.role == "student", store.findStudent(s.email) != nil { return "student" }
        return nil
    }

    var body: some View {
        ZStack {
            AppBackground()
            if !splashDone {
                SplashView {
                    withAnimation(.easeInOut(duration: 0.45)) { splashDone = true }
                    AdminControl.check(store)   // release 55: a removed teacher / admin is signed out; the main admin gets the alerts
                }
            } else if let r = role {
                if r == "student", let s = store.session {
                    StudentView(email: s.email)
                } else if r == "admin" {
                    AdminView(email: store.admin?.email ?? "")
                } else {
                    TeacherView(email: store.teacher?.email ?? "")
                }
            } else {
                LoginView()
            }
        }
        // Release 59: the window itself wears the app colour (no black strip behind the status bar).
        .background(WindowTint(color: Theme(dark: prefs.dark, teacher: false, admin: false).bg1))
        .onChange(of: scenePhase) { phase in
            if phase == .active && splashDone { AdminControl.check(store) }
            if phase == .background { AdminControl.scheduleBackground() }
        }
        // The teacher area uses the purple accent, the admin area gold/orange, everything else the teal/blue one.
        .environment(\.theme, Theme(dark: prefs.dark, teacher: role == "teacher" && splashDone,
                                     admin: role == "admin" && splashDone,
                                     accent: prefs.accent))
    }
}
