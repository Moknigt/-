import SwiftUI

/// Soft colour orbs drifting behind the screen (the "blurred background" that makes the glass cards look like glass).
/// Used by the splash and the sign-in screen. Colours follow the accent theme.
struct GlassAurora: View {
    @Environment(\.theme) private var th
    var strength: Double = 1
    @State private var drift = false

    var body: some View {
        ZStack {
            Circle().fill(th.p1.opacity(0.55 * strength)).frame(width: 300, height: 300)
                .offset(x: drift ? -80 : -130, y: drift ? -250 : -190)
            Circle().fill(th.p2.opacity(0.50 * strength)).frame(width: 340, height: 340)
                .offset(x: drift ? 130 : 80, y: drift ? 230 : 290)
            Circle().fill(Color(hex: 0x8B5CF6).opacity(0.40 * strength)).frame(width: 240, height: 240)
                .offset(x: drift ? 150 : 190, y: drift ? -40 : 40)
        }
        .blur(radius: 70)
        .allowsHitTesting(false)
        .onAppear { withAnimation(.easeInOut(duration: 6).repeatForever(autoreverses: true)) { drift = true } }
    }
}

/// Entry animation = the "atoms" animation (same as Android, release 61): dust floating on the screen is pulled in and forms the
/// icon square, the real icon takes over, the flask is traced over it, then the name and the tagline fade in. About 3.3 s, tap to skip.
/// Drawn by `AtomLayer` (AtomSplash.swift). Then `onDone`.
struct SplashView: View {
    @EnvironmentObject private var prefs: Prefs
    @Environment(\.theme) private var th
    let onDone: () -> Void

    @State private var aurora = false
    @State private var brand = false
    @State private var tag = false
    @State private var routed = false
    @State private var model: AtomModel?
    @State private var start = Date()

    private let logo: CGFloat = 120
    /// the particle timeline runs faster than the numbers in AtomTL (4.3 s -> 3.3 s)
    private let k = AtomTL.totalMs / AtomTL.timeline

    var body: some View {
        GeometryReader { geo in
            ZStack {
                GlassAurora(strength: aurora ? 1 : 0)
                    .animation(.easeOut(duration: 0.8), value: aurora)

                if let m = model { AtomLayer(model: m, start: start) }

                VStack(spacing: 0) {
                    Color.clear
                        .frame(width: logo, height: logo)
                        .background(GeometryReader { g in
                            Color.clear.onAppear { begin(g.frame(in: .named("atomSplash")), geo.size) }
                        })

                    Text(prefs.t("app_name"))
                        .font(.system(size: 30, weight: .bold))
                        .foregroundColor(th.tx)
                        .padding(.top, 26)
                        .opacity(brand ? 1 : 0)
                        .offset(y: brand ? 0 : 14)
                    Text(prefs.t("tagline"))
                        .font(.system(size: 14))
                        .foregroundColor(th.mut)
                        .padding(.top, 6)
                        .opacity(tag ? 1 : 0)
                }
                .padding(24)
            }
            .frame(width: geo.size.width, height: geo.size.height)
            .coordinateSpace(name: "atomSplash")
        }
        .ignoresSafeArea()
        .contentShape(Rectangle())
        .onTapGesture { route() }
    }

    // MARK: - Timeline

    private func after(_ s: Double, _ f: @escaping () -> Void) {
        DispatchQueue.main.asyncAfter(deadline: .now() + s, execute: f)
    }

    /// Called once the icon space is laid out: the dust needs to know where the icon square is.
    private func begin(_ frame: CGRect, _ screen: CGSize) {
        if model != nil { return }
        model = AtomModel(canvas: screen, center: CGPoint(x: frame.midX, y: frame.midY), side: logo,
                          color1: th.p1, color2: th.p2)
        start = Date()
        Sfx.shared.play(.splash)
        withAnimation(.easeOut(duration: 0.6)) { aurora = true }
        // brand name appears while the icon is finishing (the same moments as on Android)
        after(2.95 * k) { withAnimation(.easeOut(duration: 0.45)) { brand = true } }
        after(3.30 * k) { withAnimation(.easeOut(duration: 0.45)) { tag = true } }
        after(AtomTL.totalMs / 1000 + 0.35) { route() }
    }

    private func route() {
        if routed { return }
        routed = true
        Sfx.shared.stop(.splash)
        onDone()
    }
}
