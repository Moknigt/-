import SwiftUI
import PhotosUI

// The student's Exams tab (release 14, port of the Windows `ExamsPage.cs`): two chips - Exams and Homework.
//   Exams: the official-exams average, then every exam with its last result; tapping one starts it (one question at a time,
//   previous / next, submit), shows the result with a review of the answers and saves it (key "results").
//   Homework: every homework with its status (not submitted / waiting / graded n of 10); tapping one opens it:
//   the teacher's note, the grade and note if graded, and a form with a text answer + one photo (key "subs", photos in Documents/hw).
// Same keys as Android `Store.kt`.

// MARK: - The tab

struct StudentExams: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    @Environment(\.theme) private var th
    let ctx: StudentCtx
    @Binding var tab: String

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            ChipRow(labels: [prefs.t("ex_exams"), prefs.t("ex_homework")], selected: tab == "homework" ? 1 : 0, top: 0) {
                tab = ($0 == 1) ? "homework" : "exams"
            }
            if tab == "homework" { homeworkList } else { examList }
        }
    }

    // MARK: Exams

    @ViewBuilder
    private var examList: some View {
        let avg = store.officialAverage(ctx.email)
        CardBox(top: 14) {
            Text(prefs.t("ex_official_avg")).font(.system(size: 12)).foregroundColor(th.mut)
            if let a = avg {
                Text("\(a)%").font(.system(size: 30, weight: .bold)).foregroundColor(th.p1).padding(.top, 4)
            } else {
                Text(prefs.t("ex_no_avg")).font(.system(size: 14, weight: .bold)).foregroundColor(th.mut).padding(.top, 4)
            }
        }
        if store.exams.isEmpty {
            EmptyState(icon: "exam", title: prefs.t("empty_exams"), sub: prefs.t("empty_exams_sub"))
        } else {
            ForEach(store.exams.sorted { $0.at > $1.at }) { e in
                ItemRow(icon: "exam", title: e.title, sub: examSub(e), onTap: { start(e) })
            }
        }
    }

    private func examSub(_ e: Exam) -> String {
        var s = prefs.t(e.official ? "ex_official" : "ex_training")
        s += "  •  " + prefs.tf("ex_questions_count", e.qids.count)
        if let last = store.lastResult(ctx.email, e.id) {
            s += "  •  " + prefs.tf("ex_last_result", last.score) + "%"
        } else {
            s += "  •  " + prefs.t("ex_not_taken")
        }
        return s
    }

    private func start(_ e: Exam) {
        let bank = store.questions
        let usable = e.qids.contains { id in bank.contains { $0.id == id && $0.options.count >= 2 } }
        if !usable {
            ui.toast(prefs.t("ex_empty_questions"))
            return
        }
        ctx.push(.exam(e.id))
    }

    // MARK: Homework

    @ViewBuilder
    private var homeworkList: some View {
        if store.homework.isEmpty {
            EmptyState(icon: "pencil", title: prefs.t("ex_empty_hw"), sub: prefs.t("ex_empty_hw_sub"))
        } else {
            ForEach(store.homework.sorted { $0.at > $1.at }) { h in
                ItemRow(icon: "pencil", title: h.title, sub: status(h), onTap: { ctx.push(.homework(h.id)) })
            }
        }
    }

    private func status(_ h: Homework) -> String {
        guard let s = store.submission(h.id, ctx.email) else { return prefs.t("hw_status_none") }
        return s.grade >= 0 ? prefs.tf("hw_status_graded", s.grade) : prefs.t("hw_status_sent")
    }
}

// MARK: - Taking one exam

/// One question at a time. Nothing is saved until the student submits.
struct ExamRunScreen: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    @Environment(\.theme) private var th
    let examId: String
    let ctx: StudentCtx

    private struct Outcome {
        let correct: Int
        let total: Int
        let score: Int
    }

    @State private var qs: [Question]
    @State private var picks: [Int]            // chosen option per question, -1 = none
    @State private var idx = 0
    @State private var outcome: Outcome? = nil

    init(examId: String, ctx: StudentCtx) {
        self.examId = examId
        self.ctx = ctx
        let s = Store.shared
        let bank = s.questions
        var list: [Question] = []
        for id in (s.exam(examId)?.qids ?? []) {
            if let q = bank.first(where: { $0.id == id }), q.options.count >= 2 { list.append(q) }
        }
        _qs = State(initialValue: list)
        _picks = State(initialValue: Array(repeating: -1, count: list.count))
    }

    var body: some View {
        if let exam = store.exam(examId), !qs.isEmpty {
            if let r = outcome {
                resultView(exam, r)
            } else {
                questionView(exam)
            }
        } else {
            Color.clear.onAppear { ctx.back() }
        }
    }

    // MARK: Question

    private func optionCard(_ text: String, on: Bool, tap: @escaping () -> Void) -> some View {
        Text(text)
            .font(.system(size: 15, weight: on ? .bold : .regular))
            .foregroundColor(th.tx)
            .multilineTextAlignment(.leading)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 14)
            .padding(.vertical, 12)
            .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(LinearGradient(colors: [th.glassHi, th.glassLo], startPoint: .topLeading, endPoint: .bottomTrailing)))
            .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(on ? th.p1 : th.bd, lineWidth: on ? 2 : 1))
            .contentShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            .onTapGesture { Sfx.shared.play(.select); tap() }
            .padding(.top, 8)
    }

    private func questionView(_ exam: Exam) -> some View {
        let q = qs[idx]
        let last = idx == qs.count - 1
        return VStack(alignment: .leading, spacing: 0) {
            TopBar(title: exam.title, onBack: ctx.back)
            Text(prefs.tf("ex_question_of", idx + 1, qs.count))
                .font(.system(size: 13))
                .foregroundColor(th.mut)
                .padding(.top, 14)
            CardBox { CardTexts(title: q.text) }
            ForEach(q.options.indices, id: \.self) { k in
                optionCard(q.options[k], on: picks[idx] == k) { picks[idx] = k }
            }
            HStack(alignment: .center, spacing: 8) {
                LinkButton(title: prefs.t("ex_prev"), color: th.mut) {
                    if idx > 0 { idx -= 1 }
                }
                .opacity(idx > 0 ? 1 : 0.4)
                .frame(maxWidth: .infinity)
                PrimaryButton(title: prefs.t(last ? "ex_submit" : "ex_next"), height: 50) {
                    if !last {
                        idx += 1
                    } else if picks.contains(where: { $0 < 0 }) {
                        ui.confirm(prefs.t("ex_unanswered"), yes: prefs.t("ex_submit"), cancel: prefs.t("cancel")) { finish(exam) }
                    } else {
                        finish(exam)
                    }
                }
                .frame(maxWidth: .infinity)
            }
            .padding(.top, 16)
        }
    }

    private func finish(_ exam: Exam) {
        let total = qs.count
        var correct = 0
        for i in qs.indices where picks[i] == qs[i].answer { correct += 1 }
        let score = correct * 100 / total
        store.addResult(ExamResult(examId: exam.id, email: ctx.email, score: score, correct: correct, total: total))
        outcome = Outcome(correct: correct, total: total, score: score)
        Sfx.shared.play(score >= 50 ? .pass : .fail)
    }

    // MARK: Result + review

    private func resultView(_ exam: Exam, _ r: Outcome) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            TopBar(title: prefs.t("ex_result_title"), onBack: ctx.back)
            CardBox(top: 14) {
                Text("\(r.score)%")
                    .font(.system(size: 48, weight: .bold))
                    .foregroundColor(th.p1)
                    .frame(maxWidth: .infinity)
                Text(prefs.tf("ex_result_line", r.correct, r.total))
                    .font(.system(size: 15, weight: .bold))
                    .foregroundColor(th.tx)
                    .frame(maxWidth: .infinity)
                    .padding(.top, 4)
            }
            PrimaryButton(title: prefs.t("ex_retake"), height: 50) {
                picks = Array(repeating: -1, count: qs.count)
                idx = 0
                outcome = nil
            }
            .padding(.top, 14)
            Heading(text: prefs.t("ex_review"))
            ForEach(qs.indices, id: \.self) { i in
                reviewCard(qs[i], pick: picks[i])
            }
        }
    }

    private func reviewCard(_ q: Question, pick: Int) -> some View {
        let ok = pick == q.answer
        let mine = (pick >= 0 && pick < q.options.count) ? q.options[pick] : "—"
        let right = (q.answer >= 0 && q.answer < q.options.count) ? q.options[q.answer] : ""
        return CardBox(top: 8) {
            Text(q.text).font(.system(size: 15, weight: .bold)).foregroundColor(th.tx)
            Text(prefs.t("ex_your_answer") + ": " + mine)
                .font(.system(size: 14))
                .foregroundColor(ok ? th.p1 : th.err)
                .padding(.top, 6)
            if !ok {
                Text(prefs.t("ex_right_answer") + ": " + right)
                    .font(.system(size: 12))
                    .foregroundColor(th.mut)
                    .padding(.top, 2)
            }
        }
    }
}

// MARK: - One homework (the teacher's note, the grade, and the answer form)

struct HomeworkScreen: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    @Environment(\.theme) private var th
    let hwId: String
    let ctx: StudentCtx

    @State private var text: String
    @State private var item: PhotosPickerItem? = nil
    @State private var picked: UIImage? = nil      // a new photo chosen in this form
    @State private var pickedJPEG: Data? = nil
    @State private var keepOld = true              // the saved photo stays unless it is removed or replaced

    init(hwId: String, ctx: StudentCtx) {
        self.hwId = hwId
        self.ctx = ctx
        _text = State(initialValue: Store.shared.submission(hwId, ctx.email)?.text ?? "")
    }

    var body: some View {
        if let hw = store.homeworkById(hwId) {
            content(hw)
        } else {
            Color.clear.onAppear { ctx.back() }
        }
    }

    private func content(_ hw: Homework) -> some View {
        let old = store.submission(hw.id, ctx.email)
        let grade = old?.grade ?? -1
        let statusText: String = old == nil ? prefs.t("hw_status_none")
            : (grade >= 0 ? prefs.tf("hw_status_graded", grade) : prefs.t("hw_status_sent"))
        let statusColor: Color = old == nil ? th.mut : (grade >= 0 ? th.p1 : th.gold)
        let oldPhoto = (keepOld ? old?.photo : nil) ?? ""
        let hasPhoto = picked != nil || !oldPhoto.isEmpty

        return VStack(alignment: .leading, spacing: 0) {
            TopBar(title: hw.title, onBack: ctx.back)
            if !hw.note.isEmpty {
                CardBox { CardTexts(small: prefs.t("hw_note"), title: hw.note) }
            }

            // status + the teacher's feedback
            CardBox {
                Text(statusText).font(.system(size: 15, weight: .bold)).foregroundColor(statusColor)
                if let o = old, o.grade >= 0, !o.note.isEmpty {
                    Text(prefs.t("hw_teacher_note") + ": " + o.note)
                        .font(.system(size: 12))
                        .foregroundColor(th.mut)
                        .padding(.top, 4)
                }
            }

            // answer form
            Text(prefs.t("hw_your_answer"))
                .font(.system(size: 13))
                .foregroundColor(th.mut)
                .padding(.top, 16)
            TextArea(hint: prefs.t("hw_your_answer"), text: $text, lines: 5)
                .padding(.top, 6)

            if let img = picked {
                Image(uiImage: img)
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: .infinity, maxHeight: 260, alignment: .leading)
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .padding(.top, 10)
            } else if !oldPhoto.isEmpty {
                HomeworkPhoto(name: oldPhoto, maxHeight: 260).padding(.top, 10)
            }

            HStack(spacing: 0) {
                PhotosPicker(selection: $item, matching: .images) {
                    Text(prefs.t("hw_choose_photo"))
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(th.p1)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 10)
                }
                .buttonStyle(.plain).sfxTap()
                if hasPhoto {
                    Button {
                        picked = nil
                        pickedJPEG = nil
                        keepOld = false
                    } label: {
                        Text(prefs.t("hw_remove_photo"))
                            .font(.system(size: 14, weight: .bold))
                            .foregroundColor(th.err)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 10)
                    }
                    .buttonStyle(.plain).sfxTap()
                }
                Spacer(minLength: 0)
            }
            .padding(.top, 4)

            PrimaryButton(title: prefs.t(old == nil ? "hw_submit" : "hw_resubmit"), height: 50) { submit(hw, old) }
                .padding(.top, 16)
        }
        .onChange(of: item) { chosen in
            guard let chosen = chosen else { return }
            Task {
                let data = try? await chosen.loadTransferable(type: Data.self)
                await MainActor.run {
                    item = nil
                    if let d = data, let photo = Store.scaledPhoto(from: d) {
                        picked = photo.image
                        pickedJPEG = photo.jpeg
                        keepOld = false
                    } else {
                        ui.toast(prefs.t("hw_err_photo"))
                    }
                }
            }
        }
    }

    private func submit(_ hw: Homework, _ old: Submission?) {
        let answer = text.trimmed
        let hasNew = pickedJPEG != nil
        let hasOld = keepOld && !(old?.photo.isEmpty ?? true)
        if answer.isEmpty && !hasNew && !hasOld {
            ui.toast(prefs.t("hw_err_empty"))
            return
        }
        var keep = hasOld ? (old?.photo ?? "") : ""
        if let jpg = pickedJPEG {
            guard let name = store.writeHomeworkPhoto(jpg) else {
                ui.toast(prefs.t("hw_err_photo"))
                return
            }
            keep = name
        }
        // the old photo goes away when it was replaced or removed
        if let o = old, !o.photo.isEmpty, o.photo != keep { store.deletePhotoFile(o.photo) }
        store.putSubmission(Submission(hwId: hw.id, email: ctx.email, text: answer, photo: keep))
        Sfx.shared.play(.success)
        ctx.back()   // the list shows the new status
    }
}
