import SwiftUI

/// Everything the student screens need from their container (who is signed in and what to do on a tap).
struct StudentCtx {
    let email: String
    let openVideo: (Lesson) -> Void
    let openDoc: (Doc) -> Void
    let selectTab: (Int) -> Void
    let push: (StudentRoute) -> Void
    let back: () -> Void
    let openCollection: (String) -> Void
    let openChapters: Binding<Set<String>>
    let typeFilter: Binding<String>
}

/// Sub-screens opened on top of a tab (same as `show { ... }` on Android).
enum StudentRoute: Hashable {
    case books
    case collection(String)
    case notes
    case history
    case exam(String)       // exam id: taking it + the result
    case homework(String)   // homework id: note, grade, answer form
}

// MARK: - Saved collections (favorites / review later / important)

enum Coll {
    static func nameKey(_ c: String) -> String {
        switch c {
        case "fav": return "coll_fav"
        case "later": return "coll_later"
        default: return "coll_imp"
        }
    }

    static func icon(_ c: String) -> String {
        switch c {
        case "fav": return "heart"
        case "later": return "clock"
        default: return "star"
        }
    }

    static func typeKey(_ t: String) -> String {
        switch t {
        case "lesson": return "type_lesson"
        case "video": return "type_video"
        case "book": return "type_book"
        default: return "type_file"
        }
    }
}

/// A saved key ("type|id") turned into something that can be shown and opened.
struct SavedItem {
    let type: String
    let title: String
    let icon: String
    let open: () -> Void
}

extension StudentCtx {
    /// Null (nil) when the content was deleted by the teacher.
    func resolve(_ key: String, _ store: Store) -> SavedItem? {
        let parts = key.split(separator: "|", maxSplits: 1, omittingEmptySubsequences: false)
        let type = parts.isEmpty ? "" : String(parts[0])
        let id = parts.count > 1 ? String(parts[1]) : ""
        switch type {
        case "lesson", "video":
            guard let l = store.publishedLesson(id) else { return nil }
            return SavedItem(type: type, title: l.title, icon: "play") { openVideo(l) }
        case "book", "file":
            guard let d = store.doc(id) else { return nil }
            return SavedItem(type: type, title: d.title, icon: type == "book" ? "book" : "note") { openDoc(d) }
        default:
            return nil
        }
    }

    func savedCount(_ coll: String, _ store: Store) -> Int {
        store.favList(email, coll).filter { resolve($0, store) != nil }.count
    }
}

// MARK: - Heart + bookmark buttons

/// Heart (favorites) and bookmark (review later / important) buttons for one item.
struct FavButtons: View {
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var ui: ShellUI
    @Environment(\.theme) private var th
    let email: String
    let type: String
    let id: String

    private var key: String { type + "|" + id }

    var body: some View {
        let fav = store.isIn(email, "fav", key)
        let marked = store.isIn(email, "later", key) || store.isIn(email, "imp", key)
        HStack(spacing: 0) {
            IconButton(icon: fav ? "heart_on" : "heart", tint: fav ? th.err : th.mut) {
                store.toggleIn(email, "fav", key)
            }
            IconButton(icon: marked ? "mark_on" : "mark", tint: marked ? th.p1 : th.mut) {
                ui.present(prefs.t("save_to")) { SaveSheet(email: email, key: key) }
            }
        }
    }
}

/// "Save to" sheet: one switch per collection.
struct SaveSheet: View {
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var ui: ShellUI
    @Environment(\.theme) private var th
    let email: String
    let key: String

    private func binding(_ coll: String) -> Binding<Bool> {
        Binding(
            get: { store.isIn(email, coll, key) },
            set: { on in
                if on != store.isIn(email, coll, key) { store.toggleIn(email, coll, key) }
            }
        )
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            ForEach(Store.collections, id: \.self) { coll in
                HStack(spacing: 0) {
                    Icon(Coll.icon(coll), size: 22, color: th.mut)
                        .frame(width: 40, height: 40)
                    Text(prefs.t(Coll.nameKey(coll)))
                        .font(.system(size: 15, weight: .bold))
                        .foregroundColor(th.tx)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.leading, 6)
                    Toggle("", isOn: binding(coll).sfx())
                        .labelsHidden()
                        .tint(th.p1)
                }
                .padding(.top, 8)
            }
            StartLink(title: prefs.t("done"), top: 8) { ui.dismiss() }
        }
    }
}

// MARK: - Rows

struct LessonRow: View {
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var prefs: Prefs
    let lesson: Lesson
    let ctx: StudentCtx

    var body: some View {
        let seen = store.history(ctx.email).contains(lesson.id)
        let locked = !Access.canView(store, ctx.email, lesson)
        let sub: String? = !store.hasVideo(lesson) ? prefs.t("no_video_yet")
            : (locked ? prefs.tf("locked_badge", prefs.tf("price_egp", Access.shownPrice(store, lesson))) : (seen ? prefs.t("watched") : nil))
        let type = lesson.chapterId.isEmpty ? "video" : "lesson"
        ItemRow(icon: locked ? "lock" : "play", title: lesson.title, sub: sub, onTap: { ctx.openVideo(lesson) }) {
            FavButtons(email: ctx.email, type: type, id: lesson.id)
        }
    }
}

struct DocRow: View {
    let doc: Doc
    let ctx: StudentCtx

    var body: some View {
        ItemRow(icon: doc.kind == "book" ? "book" : "note", title: doc.title, onTap: { ctx.openDoc(doc) }) {
            FavButtons(email: ctx.email, type: doc.kind, id: doc.id)
        }
    }
}
