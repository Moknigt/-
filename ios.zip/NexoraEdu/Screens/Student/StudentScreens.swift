import SwiftUI

// MARK: - Books (الكتب)

struct BooksScreen: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    let ctx: StudentCtx

    var body: some View {
        let docs = store.docs
        let files = docs.filter { $0.kind == "file" }
        VStack(alignment: .leading, spacing: 0) {
            TopBar(title: prefs.t("books_title"), onBack: ctx.back)
            if docs.isEmpty {
                EmptyState(icon: "book", title: prefs.t("empty_books"), sub: prefs.t("empty_books_sub"))
            }
            ForEach(docs.filter { $0.kind == "book" }) { DocRow(doc: $0, ctx: ctx) }
            if !files.isEmpty {
                Heading(text: prefs.t("files_title"))
                ForEach(files) { DocRow(doc: $0, ctx: ctx) }
            }
        }
    }
}

// MARK: - A collection: favorites / review later / important

struct CollectionScreen: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    let coll: String
    let ctx: StudentCtx

    private struct Entry: Identifiable {
        let key: String
        let item: SavedItem
        var id: String { key }
    }

    var body: some View {
        let items: [Entry] = store.favList(ctx.email, coll).compactMap { k in
            ctx.resolve(k, store).map { Entry(key: k, item: $0) }
        }
        let kinds: [String] = items.reduce(into: [String]()) { acc, e in
            if !acc.contains(e.item.type) { acc.append(e.item.type) }
        }
        let filter = ctx.typeFilter.wrappedValue
        let list = items.filter { filter == "all" || $0.item.type == filter }

        VStack(alignment: .leading, spacing: 0) {
            TopBar(title: prefs.t(Coll.nameKey(coll)), count: items.count, onBack: ctx.back)
            if kinds.count > 1 {
                ChipRow(labels: [prefs.t("all")] + kinds.map { prefs.t(Coll.typeKey($0)) },
                        selected: filter == "all" ? 0 : max(0, (kinds.firstIndex(of: filter) ?? -1) + 1)) { i in
                    ctx.typeFilter.wrappedValue = (i == 0) ? "all" : kinds[i - 1]
                }
            }
            ForEach(list) { e in
                ItemRow(icon: e.item.icon, title: e.item.title, sub: prefs.t(Coll.typeKey(e.item.type)),
                        onTap: { e.item.open() }) {
                    TrashButton { store.toggleIn(ctx.email, coll, e.key) }
                }
            }
            if list.isEmpty {
                EmptyState(icon: Coll.icon(coll), title: prefs.t("nothing_here"), sub: prefs.t("nothing_here_sub"))
            }
        }
    }
}

/// Gray trash icon button used in rows (collections, notes).
struct TrashButton: View {
    @Environment(\.theme) private var th
    let action: () -> Void

    var body: some View {
        IconButton(icon: "trash", tint: th.mut, action: action)
    }
}

// MARK: - Notes (ملاحظاتي)

struct NotesScreen: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @Environment(\.theme) private var th
    let ctx: StudentCtx
    @State private var text = ""

    var body: some View {
        let list = store.notes(ctx.email)
        VStack(alignment: .leading, spacing: 0) {
            TopBar(title: prefs.t("notes_title"), count: list.count, onBack: ctx.back)
            VStack(alignment: .leading, spacing: 0) {
                TextArea(hint: prefs.t("note_hint"), text: $text, lines: 3)
                PrimaryButton(title: prefs.t("add_note"), height: 50) { addNote() }
                    .padding(.top, 12)
            }
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .glassCard(24)
            .padding(.top, 12)
            if list.isEmpty {
                Text(prefs.t("no_notes"))
                    .font(.system(size: 13))
                    .foregroundColor(th.mut)
                    .padding(.top, 20)
            }
            ForEach(Array(list.enumerated()), id: \.offset) { i, n in
                ItemRow(icon: "note", title: n.text, sub: n.date) {
                    TrashButton { removeNote(i) }
                }
            }
        }
    }

    private func addNote() {
        let t = text.trimmed
        guard !t.isEmpty else { return }
        var l = store.notes(ctx.email)
        l.insert(Note(text: t, date: Util.dateText(Util.nowMillis())), at: 0)
        store.saveNotes(ctx.email, l)
        text = ""
    }

    private func removeNote(_ i: Int) {
        var l = store.notes(ctx.email)
        if i < l.count { l.remove(at: i) }
        store.saveNotes(ctx.email, l)
    }
}

// MARK: - Watch history (سجل المشاهدة)

struct HistoryScreen: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    @Environment(\.theme) private var th
    let ctx: StudentCtx

    var body: some View {
        let lessons = store.history(ctx.email).compactMap { store.publishedLesson($0) }
        VStack(alignment: .leading, spacing: 0) {
            TopBar(title: prefs.t("history_title"), count: lessons.count, onBack: ctx.back)
            if lessons.isEmpty {
                EmptyState(icon: "hist", title: prefs.t("no_history"), sub: prefs.t("no_history_sub"))
            } else {
                StartLink(title: prefs.t("clear_history"), color: th.err, top: 8) {
                    ui.confirm(prefs.t("confirm_clear_history"), yes: prefs.t("clear_history"), cancel: prefs.t("cancel")) {
                        store.clearHistory(ctx.email)
                    }
                }
                ForEach(lessons) { l in
                    ItemRow(icon: "play", title: l.title, onTap: { ctx.openVideo(l) })
                }
            }
        }
    }
}
