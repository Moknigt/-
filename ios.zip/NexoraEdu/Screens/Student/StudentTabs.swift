import SwiftUI
import PhotosUI

// MARK: - Home (الرئيسية)

struct StudentHome: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @Environment(\.theme) private var th
    let me: Student
    let ctx: StudentCtx

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            CardBox { CardTexts(small: prefs.t("welcome"), title: me.name, sub: me.grade) }
            announcementsBlock
            progressCard
            continueCard
            TileGrid(items: [
                TileSpec(icon: "book", label: prefs.t("tab_subjects")) { ctx.selectTab(1) },
                TileSpec(icon: "folder", label: prefs.t("books_title")) { ctx.push(.books) },
                TileSpec(icon: "heart", label: prefs.t("coll_fav"), count: ctx.savedCount("fav", store)) {
                    ctx.openCollection("fav")
                }
            ])
            latest
        }
    }

    /// Latest 3 announcements from the teacher (Android: heading + one card each, date / title / text).
    @ViewBuilder
    private var announcementsBlock: some View {
        let anns = Array(store.announcements.sorted { $0.at > $1.at }.prefix(3))
        if !anns.isEmpty {
            Heading(text: prefs.t("ann_title"))
            ForEach(anns) { a in
                CardBox { CardTexts(small: Util.dateText(a.at), title: a.title, sub: a.text.isEmpty ? nil : a.text) }
            }
        }
    }

    private var progressCard: some View {
        let p = store.progress(me.email)
        let pct = Store.percent(p)
        let seen = Set(store.history(me.email))
        return CardBox {
            CardTexts(small: prefs.t("study_progress"), title: "\(pct)%",
                      sub: prefs.tf("lessons_done_of", p.done, p.total))
            ProgressBarView(pct: pct, top: 12)
            ForEach(store.chapters) { ch in
                let ls = store.publishedLessons.filter { $0.chapterId == ch.id }
                if !ls.isEmpty {
                    Text(ch.title)
                        .font(.system(size: 12))
                        .foregroundColor(th.mut)
                        .padding(.top, 12)
                    ProgressBarView(pct: ls.filter { seen.contains($0.id) }.count * 100 / ls.count, top: 4)
                }
            }
        }
    }

    private var continueCard: some View {
        let last = store.history(me.email).compactMap { store.publishedLesson($0) }.first
        return CardBox {
            CardTexts(small: prefs.t("continue_studying"), title: last?.title ?? prefs.t("pick_lesson_hint"))
            if let l = last {
                PrimaryButton(title: prefs.t("resume_watching"), height: 50) { ctx.openVideo(l) }
                    .padding(.top, 12)
            }
        }
    }

    @ViewBuilder
    private var latest: some View {
        let newestLessons = Array(store.publishedLessons.sorted { $0.at > $1.at }.prefix(2))
        let docs = store.docs.sorted { $0.at > $1.at }
        let newBooks = Array(docs.filter { $0.kind == "book" }.prefix(2))
        let newFiles = Array(docs.filter { $0.kind == "file" }.prefix(2))
        if newestLessons.isEmpty && newBooks.isEmpty && newFiles.isEmpty {
            EmptyState(icon: "book", title: prefs.t("empty_courses"), sub: prefs.t("empty_courses_sub"))
        } else {
            Heading(text: prefs.t("latest_content"))
            ForEach(newestLessons) { LessonRow(lesson: $0, ctx: ctx) }
            ForEach(newBooks) { DocRow(doc: $0, ctx: ctx) }
            ForEach(newFiles) { DocRow(doc: $0, ctx: ctx) }
        }
    }
}

// MARK: - Courses (كورساتي)

struct StudentStudy: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    let ctx: StudentCtx

    var body: some View {
        let lessons = store.publishedLessons
        let chapters = store.chapters
        let docs = store.docs
        if lessons.isEmpty && chapters.isEmpty && docs.isEmpty {
            EmptyState(icon: "book", title: prefs.t("empty_courses"), sub: prefs.t("empty_courses_sub"))
        } else {
            VStack(alignment: .leading, spacing: 0) {
                let videos = lessons.filter { $0.chapterId.isEmpty }
                if !videos.isEmpty {
                    Heading(text: prefs.t("videos"))
                    ForEach(videos) { LessonRow(lesson: $0, ctx: ctx) }
                }
                if !chapters.isEmpty { Heading(text: prefs.t("chapters_title")) }
                ForEach(chapters) { ch in
                    ChapterBlock(chapter: ch, lessons: lessons.filter { $0.chapterId == ch.id }, ctx: ctx)
                }
                let books = docs.filter { $0.kind == "book" }
                if !books.isEmpty {
                    Heading(text: prefs.t("books_title"))
                    ForEach(books) { DocRow(doc: $0, ctx: ctx) }
                }
                let files = docs.filter { $0.kind == "file" }
                if !files.isEmpty {
                    Heading(text: prefs.t("files_title"))
                    ForEach(files) { DocRow(doc: $0, ctx: ctx) }
                }
            }
        }
    }
}

/// A chapter card with its progress bar; tapping it opens/closes its lessons.
private struct ChapterBlock: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    let chapter: Chapter
    let lessons: [Lesson]
    let ctx: StudentCtx

    var body: some View {
        let seen = Set(store.history(ctx.email))
        let done = lessons.filter { seen.contains($0.id) }.count
        let open = ctx.openChapters.wrappedValue.contains(chapter.id)
        VStack(alignment: .leading, spacing: 0) {
            CardBox(onTap: {
                var set = ctx.openChapters.wrappedValue
                if set.contains(chapter.id) { set.remove(chapter.id) } else { set.insert(chapter.id) }
                ctx.openChapters.wrappedValue = set
            }) {
                CardTexts(title: chapter.title, sub: prefs.tf("lessons_done_of", done, lessons.count))
                ProgressBarView(pct: lessons.isEmpty ? 0 : done * 100 / lessons.count, top: 10)
            }
            if open {
                ForEach(lessons) { LessonRow(lesson: $0, ctx: ctx) }
            }
        }
    }
}

// MARK: - Profile (حسابي)

struct StudentProfile: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    let me: Student
    let ctx: StudentCtx
    let openSettings: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            AvatarEditor(me: me)
            CardBox { CardTexts(small: prefs.t("role_student_label"), title: me.name, sub: me.grade) }
            StatRow(items: Store.collections.map { (num: ctx.savedCount($0, store), label: prefs.t(Coll.nameKey($0))) })
            Heading(text: prefs.t("my_collections"))
            TileGrid(items: [
                TileSpec(icon: "heart", label: prefs.t("coll_fav"), count: ctx.savedCount("fav", store)) {
                    ctx.openCollection("fav")
                },
                TileSpec(icon: "clock", label: prefs.t("coll_later"), count: ctx.savedCount("later", store)) {
                    ctx.openCollection("later")
                },
                TileSpec(icon: "star", label: prefs.t("coll_imp"), count: ctx.savedCount("imp", store)) {
                    ctx.openCollection("imp")
                },
                TileSpec(icon: "note", label: prefs.t("notes_title"), count: store.notes(me.email).count) {
                    ctx.push(.notes)
                },
                TileSpec(icon: "hist", label: prefs.t("history_title"),
                         count: store.history(me.email).filter { store.publishedLesson($0) != nil }.count) {
                    ctx.push(.history)
                },
                TileSpec(icon: "gear", label: prefs.t("settings"), action: openSettings)
            ])
            AccountRows(me: me)
        }
    }
}

// MARK: - Account rows (Android release 17): name, email (copy), phone, class, change password; every row reacts when tapped

struct AccountRows: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    @Environment(\.theme) private var th
    let me: Student

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Heading(text: prefs.t("sec_account"))
            ItemRow(icon: "user", title: me.name, sub: prefs.t("role_student_label"), onTap: editName) { chev }
            ItemRow(icon: "email", title: me.email, sub: prefs.t("acc_tap_copy"), onTap: copyEmail) {
                IconButton(icon: "copy", tint: th.mut, action: copyEmail)
            }
            ItemRow(icon: "phone", title: me.phone.isEmpty ? prefs.t("acc_no_phone") : me.phone,
                    sub: prefs.t("hint_phone"), onTap: editPhone) { chev }
            ItemRow(icon: "grade", title: me.grade, sub: prefs.t("grade_label")) { EmptyView() }   // release 66: shown only, a student cannot change his class
            ItemRow(icon: "key", title: prefs.t("acc_change_pw"), onTap: changePassword) { chev }
        }
    }

    /// Points to the end of the row (the app is right-to-left, so it is flipped like Android's rotation in RTL).
    private var chev: some View {
        Icon("chev", size: 20, color: th.mut)
            .scaleEffect(x: -1, y: 1)
            .frame(width: 32, height: 32)
    }

    /// Applies [change] to the saved copy of this student (the header and every screen follow the store).
    private func save(_ change: (inout Student) -> Void) {
        guard let i = store.students.firstIndex(where: { $0.email == me.email }) else { return }
        change(&store.students[i])
    }

    private func copyEmail() {
        UIPasteboard.general.string = me.email
        ui.toast(prefs.t("acc_email_copied"))
    }

    private func editName() {
        ui.present(prefs.t("acc_edit_name")) {
            AccountTextSheet(initial: me.name, hint: prefs.t("hint_name"), ltr: false, allowEmpty: false) { v in
                save { $0.name = v }
            }
        }
    }

    private func editPhone() {
        ui.present(prefs.t("acc_edit_phone")) {
            AccountTextSheet(initial: me.phone, hint: prefs.t("hint_phone"), ltr: true, allowEmpty: true) { v in
                save { $0.phone = v }
            }
        }
    }

    private func changePassword() {
        ui.present(prefs.t("acc_change_pw")) { AccountPasswordSheet(email: me.email) }
    }
}

/// One text field + done / cancel (name, phone).
struct AccountTextSheet: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var ui: ShellUI
    let hint: String
    let ltr: Bool
    let allowEmpty: Bool
    let onSave: (String) -> Void
    @State private var text: String

    init(initial: String, hint: String, ltr: Bool, allowEmpty: Bool, onSave: @escaping (String) -> Void) {
        self.hint = hint; self.ltr = ltr; self.allowEmpty = allowEmpty; self.onSave = onSave
        _text = State(initialValue: initial)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            SheetField(hint: hint, text: $text, ltr: ltr)
            PrimaryButton(title: prefs.t("done"), height: 50) { done() }
                .padding(.top, 16)
            StartLink(title: prefs.t("cancel")) { ui.dismiss() }
        }
    }

    private func done() {
        let v = text.trimmed
        if v.isEmpty && !allowEmpty {
            ui.toast(prefs.t("err_title"))
            return
        }
        onSave(v)
        ui.dismiss()
        ui.toast(prefs.t("acc_saved"))
    }
}

/// Current / new / confirm password (same rules as Android: 6+ characters, stored as a SHA-256 hash).
struct AccountPasswordSheet: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    @Environment(\.theme) private var th
    let email: String
    @State private var old = ""
    @State private var new = ""
    @State private var again = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            field(prefs.t("hint_current_password"), $old)
            field(prefs.t("hint_new_password"), $new)
            field(prefs.t("hint_password_confirm"), $again)
            PrimaryButton(title: prefs.t("done"), height: 50) { save() }
                .padding(.top, 16)
            StartLink(title: prefs.t("cancel")) { ui.dismiss() }
        }
    }

    private func field(_ hint: String, _ text: Binding<String>) -> some View {
        SecureField(hint, text: text, prompt: Text(hint).foregroundColor(th.mut))
            .font(.system(size: 15))
            .foregroundColor(th.tx)
            .textInputAutocapitalization(.never)
            .autocorrectionDisabled(true)
            .environment(\.layoutDirection, .leftToRight)
            .padding(.horizontal, 14)
            .frame(maxWidth: .infinity, minHeight: 52)
            .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(th.field))
            .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(th.bd, lineWidth: 1))
            .padding(.top, 10)
    }

    private func save() {
        guard let i = store.students.firstIndex(where: { $0.email == email }) else { return }
        if old.isEmpty || new.isEmpty { ui.toast(prefs.t("err_enter_creds")); return }
        if store.students[i].pw != Util.sha256(old) { ui.toast(prefs.t("err_pw_wrong")); return }
        if new.count < 6 { ui.toast(prefs.t("err_teacher_short")); return }
        if new != again { ui.toast(prefs.t("err_pw_mismatch")); return }
        store.students[i].pw = Util.sha256(new)
        ui.dismiss()
        ui.toast(prefs.t("pw_changed"))
    }
}

// MARK: - Profile photo (round photo + change / remove links)

struct AvatarEditor: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    @Environment(\.theme) private var th
    let me: Student
    @State private var item: PhotosPickerItem? = nil

    private var hasPhoto: Bool {
        _ = store.avatarVersion
        return FileManager.default.fileExists(atPath: store.avatarFile(me.email).path)
    }

    var body: some View {
        VStack(spacing: 0) {
            AvatarView(email: me.email, name: me.name, size: 96)
                .padding(.top, 16)
            PhotosPicker(selection: $item, matching: .images) {
                Text(prefs.t(hasPhoto ? "change_photo" : "add_photo"))
                    .font(.system(size: 14, weight: .bold))
                    .foregroundColor(th.p1)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 10)
            }
            .buttonStyle(.plain).sfxTap()
            if hasPhoto {
                StartLink(title: prefs.t("remove_photo"), color: th.err) {
                    ui.confirm(prefs.t("confirm_remove_photo"), yes: prefs.t("remove_photo"), cancel: prefs.t("cancel")) {
                        store.removeAvatar(me.email)
                    }
                }
                .frame(maxWidth: .infinity)
            }
        }
        .frame(maxWidth: .infinity)
        .onChange(of: item) { picked in
            guard let picked = picked else { return }
            Task {
                let data = try? await picked.loadTransferable(type: Data.self)
                await MainActor.run {
                    item = nil
                    if let d = data, store.saveAvatar(me.email, from: d) { return }
                    ui.toast(prefs.t("err_photo"))
                }
            }
        }
    }
}
