import SwiftUI

/// The student side: shell (header + 4 tabs) with the home, courses, exams and profile tabs,
/// sub-screens opened on top of a tab, the settings sheet, the in-app PDF reader and the in-app video player.
struct StudentView: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @Environment(\.theme) private var th
    @StateObject private var ui = ShellUI()
    let email: String

    @State private var tab = 0
    @State private var stack: [StudentRoute] = []
    @State private var openChapters: Set<String> = []
    @State private var typeFilter = "all"
    @State private var exTab = "exams"   // chip of the Exams tab, kept when coming back from an exam / homework
    @State private var cover: PlayerCover? = nil

    init(email: String) { self.email = email }

    private let tabs = [
        ShellTab(labelKey: "tab_home", icon: "home"),
        ShellTab(labelKey: "tab_subjects", icon: "book"),
        ShellTab(labelKey: "tab_tests", icon: "exam"),
        ShellTab(labelKey: "tab_profile", icon: "user")
    ]

    var body: some View {
        if let me = store.findStudent(email) {
            ShellFrame(ui: ui, helloKey: "welcome", name: me.name, tabs: tabs, selected: tab,
                       screenKey: screenKey,
                       avatarEmail: email,
                       onBack: backAction,
                       onSelect: { select($0) },
                       onSettings: { openSettings() }) {
                screen(me)
            }
            .coverHost($cover, ui: ui)
        } else {
            Color.clear
        }
    }

    // MARK: Navigation (same model as ShellActivity: a tab, plus a stack of screens opened on top of it)

    private var screenKey: String {
        "\(tab)/" + stack.map { "\($0)" }.joined(separator: ",")
    }

    private func select(_ i: Int) {
        tab = i
        stack = []
    }

    private var backAction: (() -> Void)? {
        if stack.isEmpty { return nil }
        return { goBack() }
    }

    private func goBack() {
        if !stack.isEmpty { stack.removeLast() }
    }

    private func openSettings() {
        ui.openSettings()
    }

    private var ctx: StudentCtx {
        StudentCtx(
            email: email,
            openVideo: { openVideo($0) },
            openDoc: { openDoc($0) },
            selectTab: { select($0) },
            push: { stack.append($0) },
            back: { goBack() },
            openCollection: { c in
                typeFilter = "all"
                stack.append(.collection(c))
            },
            openChapters: $openChapters,
            typeFilter: $typeFilter
        )
    }

    @ViewBuilder
    private func screen(_ me: Student) -> some View {
        if let r = stack.last {
            switch r {
            case .books: BooksScreen(ctx: ctx)
            case .collection(let c): CollectionScreen(coll: c, ctx: ctx)
            case .notes: NotesScreen(ctx: ctx)
            case .history: HistoryScreen(ctx: ctx)
            case .exam(let id): ExamRunScreen(examId: id, ctx: ctx)
            case .homework(let id): HomeworkScreen(hwId: id, ctx: ctx)
            }
        } else {
            switch tab {
            case 0: StudentHome(me: me, ctx: ctx)
            case 1: StudentStudy(ctx: ctx)
            case 2: StudentExams(ctx: ctx, tab: $exTab)
            default: StudentProfile(me: me, ctx: ctx, openSettings: { openSettings() })
            }
        }
    }

    // MARK: Opening content

    /// Android `openVideo(l, email)`: no link -> message; otherwise the lesson goes into the watch history and the in-app player opens.
    private func openVideo(_ l: Lesson) {
        if !store.hasVideo(l) {
            ui.toast(prefs.t("err_no_video"))
            return
        }
        if !Access.canView(store, email, l) {   // locked: show the price instead of the player
            Sfx.shared.play(.locked)
            ui.present(prefs.t("locked_title")) { PaywallSheet(lesson: l, email: email) }
            return
        }
        store.addHistory(email, l.id)
        cover = .video(store.videoItem(l))
    }

    private func openDoc(_ d: Doc) {
        guard FileManager.default.fileExists(atPath: store.docFile(d.id).path) else {
            ui.toast(prefs.t("err_no_file"))
            return
        }
        cover = .pdf(d)
    }
}


/// Locked lesson: what it costs. Online payment is a skeleton (see `Payments` in Core/Store.swift).
struct PaywallSheet: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    @Environment(\.theme) private var th
    let lesson: Lesson
    let email: String

    var body: some View {
        let cp = store.coursePrice(lesson)
        VStack(alignment: .leading, spacing: 0) {
            Text(prefs.t("locked_sub"))
                .font(.system(size: 14))
                .foregroundColor(th.mut)
                .padding(.top, 8)
            if cp > 0 {
                PrimaryButton(title: prefs.tf("pay_course", cp), height: 50) { pay("c:" + lesson.chapterId, cp) }
                    .padding(.top, 16)
            }
            if lesson.price > 0 {
                PrimaryButton(title: prefs.tf("pay_video", lesson.price), height: 50) { pay("l:" + lesson.id, lesson.price) }
                    .padding(.top, 10)
            }
            StartLink(title: prefs.t("cancel")) { ui.dismiss() }
        }
    }

    private func pay(_ target: String, _ amount: Int) {
        ui.dismiss()
        if !Payments.start(target: target, amount: amount, email: email, onPaid: {}) { ui.toast(prefs.t("pay_soon")) }
    }
}
