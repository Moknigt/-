import SwiftUI

// The teacher's Exams tab (release 14, port of the Windows `TeacherShell.Exams.cs`): three sections chosen by chips -
// Exams / Question bank / Homework.
//   Exams: create from the bank (official / practice), delete, tap one to see the students' latest results.
//   Questions: multiple choice (2-4 options, one right answer, optional chapter); deleting one also removes it from the exams.
//   Homework: title + note, delete; tap one to read the students' answers (text + photo) and grade each out of 10 with a note.
// Same keys as Android `Store.kt` (questions, exams, results, homework, subs).

/// Sub-screens of the teacher side (the homework answers). The teacher side has a tab plus this small route stack.
enum TeacherRoute: Hashable {
    case homework(String)   // homework id
    case classes            // manage classes (release 19)
    case student(String)    // a student's own page (student email)
    case grade(String)      // release 66: one class (its content / tests), the value is the class name
}

extension String {
    /// Shortens a long text for a list row.
    func cut(_ n: Int) -> String { count <= n ? self : String(prefix(n)).trimmed + "…" }
}

// MARK: - The tab

struct TeacherExams: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    @Binding var tab: String
    let openHomework: (String) -> Void
    /// Release 66: runs the action inside a class (asks "which class?" first when none is open). Admin: runs it straight away.
    var ask: (@escaping () -> Void) -> Void = { $0() }

    private let tags = ["exams", "questions", "homework"]

    private var addKey: String {
        switch tab {
        case "questions": return "ex_add_question"
        case "homework": return "ex_add_homework"
        default: return "ex_add_exam"
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            ChipRow(labels: [prefs.t("ex_exams"), prefs.t("ex_questions"), prefs.t("ex_homework")],
                    selected: tags.firstIndex(of: tab) ?? 0, top: 0) { tab = tags[$0] }
            PrimaryButton(title: prefs.t(addKey), height: 50) { add() }
                .padding(.top, 14)
            switch tab {
            case "questions": QuestionsList()
            case "homework": HomeworkList(open: openHomework)
            default: ExamsList()
            }
        }
    }

    private func add() {
        ask { addHere() }
    }

    private func addHere() {
        switch tab {
        case "questions":
            ui.present(prefs.t("ex_add_question")) { AddQuestionSheet() }
        case "homework":
            ui.present(prefs.t("ex_add_homework")) { AddHomeworkSheet() }
        default:
            let bank = store.questions
            if bank.isEmpty {
                ui.toast(prefs.t("ex_err_add_questions_first"))
                return
            }
            ui.present(prefs.t("ex_add_exam")) { AddExamSheet(bank: bank) }
        }
    }
}

// MARK: - Question bank

private struct QuestionsList: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI

    var body: some View {
        if store.questions.isEmpty {
            EmptyState(icon: "note", title: prefs.t("ex_empty_questions"), sub: prefs.t("ex_empty_questions_sub"))
        } else {
            ForEach(store.questions) { q in
                ItemRow(icon: "note", title: q.text.cut(80), sub: subText(q)) {
                    TrashButton {
                        ui.confirmDelete(prefs, key: "ex_confirm_delete_question", name: "") { store.deleteQuestion(q.id) }
                    }
                }
            }
        }
    }

    private func subText(_ q: Question) -> String {
        let right = (q.answer >= 0 && q.answer < q.options.count) ? q.options[q.answer] : ""
        var s = prefs.t("ex_right_answer") + ": " + right.cut(40)
        if let ch = store.chapters.first(where: { $0.id == q.chapter }) { s += "  •  " + ch.title }
        return s
    }
}

struct AddQuestionSheet: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    @Environment(\.theme) private var th
    @State private var text = ""
    @State private var chapter = 0           // 0 = no chapter, i = the i-th chapter
    @State private var opts = ["", "", "", ""]
    @State private var right = 0

    var body: some View {
        let chapters = store.chapters
        VStack(alignment: .leading, spacing: 0) {
            TextArea(hint: prefs.t("ex_question_text"), text: $text, lines: 3)
                .padding(.top, 10)
            if !chapters.isEmpty {
                Text(prefs.t("ex_chapter_optional"))
                    .font(.system(size: 13))
                    .foregroundColor(th.mut)
                    .padding(.top, 14)
                ChipRow(labels: [prefs.t("ex_no_chapter")] + chapters.map { $0.title }, selected: chapter, top: 8) { chapter = $0 }
            }
            ForEach(0..<4, id: \.self) { i in
                SheetField(hint: prefs.tf("ex_option_n", i + 1), text: $opts[i])
            }
            Text(prefs.t("ex_correct"))
                .font(.system(size: 13))
                .foregroundColor(th.mut)
                .padding(.top, 14)
            ChipRow(labels: ["1", "2", "3", "4"], selected: right, top: 8) { right = $0 }
            PrimaryButton(title: prefs.t("add"), height: 50) { add() }
                .padding(.top, 16)
            StartLink(title: prefs.t("cancel")) { ui.dismiss() }
        }
    }

    private func add() {
        let qt = text.trimmed
        if qt.isEmpty {
            ui.toast(prefs.t("ex_err_question"))
            return
        }
        let filled = opts.indices.filter { !opts[$0].trimmed.isEmpty }
        if filled.count < 2 {
            ui.toast(prefs.t("ex_err_options"))
            return
        }
        // position of the right option once the empty ones are dropped
        guard let at = filled.firstIndex(of: right) else {
            ui.toast(prefs.t("ex_err_correct"))
            return
        }
        let chapters = store.chapters
        let ch = (chapter > 0 && chapter <= chapters.count) ? chapters[chapter - 1].id : ""
        store.questions.append(Question(id: store.newId(), text: qt, chapter: ch,
                                        options: filled.map { opts[$0].trimmed }, answer: at))
        ui.dismiss()
    }
}

// MARK: - Exams

private struct ExamsList: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI

    var body: some View {
        if store.exams.isEmpty {
            EmptyState(icon: "exam", title: prefs.t("empty_exams"), sub: prefs.t("empty_exams_sub"))
        } else {
            ForEach(store.exams.sorted { $0.at > $1.at }) { e in
                ItemRow(icon: "exam", title: e.title, sub: subText(e),
                        onTap: { ui.present(e.title) { ExamResultsSheet(exam: e) } }) {
                    TrashButton {
                        ui.confirmDelete(prefs, key: "ex_confirm_delete_exam", name: e.title) { store.deleteExam(e.id) }
                    }
                }
            }
        }
    }

    private func subText(_ e: Exam) -> String {
        var s = prefs.t(e.official ? "ex_official" : "ex_training")
        s += "  •  " + prefs.tf("ex_questions_count", e.qids.count)
        s += "  •  " + Util.dateText(e.at)
        return s
    }
}

struct AddExamSheet: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    @Environment(\.theme) private var th
    let bank: [Question]
    @State private var title = ""
    @State private var official = false
    @State private var picked: Set<String> = []

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            SheetField(hint: prefs.t("hint_title"), text: $title)
            ChipRow(labels: [prefs.t("ex_training"), prefs.t("ex_official")], selected: official ? 1 : 0, top: 12) {
                official = ($0 == 1)
            }
            Text(prefs.t("ex_pick_questions"))
                .font(.system(size: 13))
                .foregroundColor(th.mut)
                .padding(.top, 14)
            ForEach(bank) { q in
                Button {
                    if picked.contains(q.id) { picked.remove(q.id) } else { picked.insert(q.id) }
                } label: {
                    HStack(spacing: 10) {
                        Image(systemName: picked.contains(q.id) ? "checkmark.square.fill" : "square")
                            .font(.system(size: 20))
                            .foregroundColor(picked.contains(q.id) ? th.p1 : th.mut)
                        Text(q.text.cut(70))
                            .font(.system(size: 14))
                            .foregroundColor(th.tx)
                            .multilineTextAlignment(.leading)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    .padding(.top, 8)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain).sfxTap()
            }
            PrimaryButton(title: prefs.t("add"), height: 50) { add() }
                .padding(.top, 16)
            StartLink(title: prefs.t("cancel")) { ui.dismiss() }
        }
    }

    private func add() {
        let t = title.trimmed
        if t.isEmpty {
            ui.toast(prefs.t("err_title"))
            return
        }
        let ids = bank.map { $0.id }.filter { picked.contains($0) }
        if ids.isEmpty {
            ui.toast(prefs.t("ex_err_no_questions"))
            return
        }
        store.exams.append(Exam(id: store.newId(), title: t, official: official, qids: ids))
        ui.dismiss()
    }
}

/// The latest result of every student who took the exam, best first.
struct ExamResultsSheet: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    @Environment(\.theme) private var th
    let exam: Exam

    private struct Row {
        let name: String
        let result: ExamResult
    }

    private var rows: [Row] {
        var list: [Row] = []
        for s in store.students {
            if let r = store.lastResult(s.email, exam.id) { list.append(Row(name: s.name, result: r)) }
        }
        list.sort { $0.result.score > $1.result.score }
        return list
    }

    var body: some View {
        let list = rows
        VStack(alignment: .leading, spacing: 0) {
            if list.isEmpty {
                Text(prefs.t("ex_no_results"))
                    .font(.system(size: 13))
                    .foregroundColor(th.mut)
                    .padding(.top, 10)
            }
            ForEach(list.indices, id: \.self) { i in
                HStack(spacing: 0) {
                    VStack(alignment: .leading, spacing: 0) {
                        Text(list[i].name).font(.system(size: 15, weight: .bold)).foregroundColor(th.tx)
                        Text(line(list[i].result)).font(.system(size: 12)).foregroundColor(th.mut)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    Text("\(list[i].result.score)%")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(th.p1)
                }
                .padding(.top, 10)
            }
            StartLink(title: prefs.t("close"), top: 8) { ui.dismiss() }
        }
    }

    private func line(_ r: ExamResult) -> String {
        prefs.tf("ex_result_line", r.correct, r.total) + "  •  " + Util.dateText(r.at)
    }
}

// MARK: - Homework

private struct HomeworkList: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    let open: (String) -> Void

    var body: some View {
        if store.homework.isEmpty {
            EmptyState(icon: "pencil", title: prefs.t("ex_empty_hw"), sub: prefs.t("ex_empty_hw_teacher_sub"))
        } else {
            ForEach(store.homework.sorted { $0.at > $1.at }) { h in
                ItemRow(icon: "pencil", title: h.title, sub: subText(h), onTap: { open(h.id) }) {
                    TrashButton {
                        ui.confirmDelete(prefs, key: "ex_confirm_delete_hw", name: h.title) { store.deleteHomework(h.id) }
                    }
                }
            }
        }
    }

    private func subText(_ h: Homework) -> String {
        let mine = store.submissions.filter { $0.hwId == h.id }
        var s = prefs.t("hw_submissions") + ": \(mine.count)"
        let open = mine.filter { $0.grade < 0 }.count
        if open > 0 { s += "  •  " + prefs.t("hw_ungraded") + ": \(open)" }
        return s
    }
}

struct AddHomeworkSheet: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    @State private var title = ""
    @State private var note = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            SheetField(hint: prefs.t("hw_hint_title"), text: $title)
            TextArea(hint: prefs.t("hw_hint_note"), text: $note, lines: 3)
                .padding(.top, 10)
            PrimaryButton(title: prefs.t("add"), height: 50) { add() }
                .padding(.top, 16)
            StartLink(title: prefs.t("cancel")) { ui.dismiss() }
        }
    }

    private func add() {
        let t = title.trimmed
        if t.isEmpty {
            ui.toast(prefs.t("err_title"))
            return
        }
        store.homework.append(Homework(id: store.newId(), title: t, note: note.trimmed))
        ui.dismiss()
    }
}

/// The students' answers to one homework (sub-screen): text, photo, status, and a link to grade.
struct HomeworkAnswersScreen: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @Environment(\.theme) private var th
    let hwId: String
    let back: () -> Void

    var body: some View {
        if let h = store.homework.first(where: { $0.id == hwId }) {
            let subs = store.submissions.filter { $0.hwId == hwId }.sorted { $0.at < $1.at }
            VStack(alignment: .leading, spacing: 0) {
                TopBar(title: h.title, count: subs.count, onBack: back)
                if !h.note.isEmpty {
                    CardBox { CardTexts(small: prefs.t("hw_note"), title: h.note) }
                }
                if subs.isEmpty {
                    Text(prefs.t("hw_no_submissions"))
                        .font(.system(size: 13))
                        .foregroundColor(th.mut)
                        .padding(.top, 16)
                }
                ForEach(subs) { SubmissionCard(sub: $0) }
            }
        } else {
            Color.clear.onAppear { back() }
        }
    }
}

private struct SubmissionCard: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    @Environment(\.theme) private var th
    let sub: Submission

    var body: some View {
        let name = store.findStudent(sub.email)?.name ?? sub.email
        let graded = sub.grade >= 0
        CardBox {
            Text(name).font(.system(size: 16, weight: .bold)).foregroundColor(th.tx)
            Text(sub.email + "  •  " + Util.dateText(sub.at)).font(.system(size: 12)).foregroundColor(th.mut)
            if !sub.text.isEmpty {
                Text(sub.text).font(.system(size: 14)).foregroundColor(th.tx).padding(.top, 10)
            }
            if !sub.photo.isEmpty {
                HomeworkPhoto(name: sub.photo, maxHeight: 320).padding(.top, 10)
            }
            Text(graded ? prefs.tf("hw_status_graded", sub.grade) : prefs.t("hw_status_sent"))
                .font(.system(size: 14, weight: .bold))
                .foregroundColor(graded ? th.p1 : th.gold)
                .padding(.top, 10)
            if graded && !sub.note.isEmpty {
                Text(prefs.t("hw_teacher_note") + ": " + sub.note)
                    .font(.system(size: 12))
                    .foregroundColor(th.mut)
                    .padding(.top, 2)
            }
            StartLink(title: prefs.t("hw_save_grade"), top: 6) {
                ui.present(prefs.t("hw_save_grade")) { GradeSheet(sub: sub) }
            }
        }
    }
}

/// A homework answer photo (Documents/hw/<name>); a short message when the file is gone. Used by the teacher and the student side.
struct HomeworkPhoto: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @Environment(\.theme) private var th
    let name: String
    var maxHeight: CGFloat = 260

    var body: some View {
        if let img = UIImage(contentsOfFile: store.photoFile(name).path) {
            Image(uiImage: img)
                .resizable()
                .scaledToFit()
                .frame(maxWidth: .infinity, maxHeight: maxHeight, alignment: .leading)
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        } else {
            Text(prefs.t("hw_photo_missing")).font(.system(size: 12)).foregroundColor(th.mut)
        }
    }
}

/// Number field in the look of `SheetField` with a number keyboard.
private struct NumberField: View {
    @Environment(\.theme) private var th
    let hint: String
    @Binding var text: String

    var body: some View {
        TextField(hint, text: $text, prompt: Text(hint).foregroundColor(th.mut))
            .font(.system(size: 15))
            .foregroundColor(th.tx)
            .keyboardType(.numberPad)
            .multilineTextAlignment(.trailing)
            .environment(\.layoutDirection, .leftToRight)
            .padding(.horizontal, 14)
            .frame(maxWidth: .infinity, minHeight: 52)
            .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(th.field))
            .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(th.bd, lineWidth: 1))
            .padding(.top, 10)
    }
}

struct GradeSheet: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    let sub: Submission
    @State private var grade: String
    @State private var note: String

    init(sub: Submission) {
        self.sub = sub
        _grade = State(initialValue: sub.grade >= 0 ? "\(sub.grade)" : "")
        _note = State(initialValue: sub.note)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            NumberField(hint: prefs.t("hw_grade_label"), text: $grade)
            TextArea(hint: prefs.t("hw_grade_note"), text: $note, lines: 3)
                .padding(.top, 10)
            PrimaryButton(title: prefs.t("hw_save_grade"), height: 50) { save() }
                .padding(.top, 16)
            StartLink(title: prefs.t("cancel")) { ui.dismiss() }
        }
    }

    private func save() {
        guard let n = Int(grade.trimmed), n >= 0, n <= 10 else {
            ui.toast(prefs.t("hw_err_grade"))
            return
        }
        guard var cur = store.submission(sub.hwId, sub.email) else {
            ui.dismiss()
            return
        }
        cur.grade = n
        cur.note = note.trimmed
        store.putSubmission(cur)
        ui.dismiss()   // the answers redraw with the new grade
    }
}
