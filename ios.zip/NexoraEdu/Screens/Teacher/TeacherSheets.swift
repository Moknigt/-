import SwiftUI
import UniformTypeIdentifiers

// The add / delete bottom sheets of the teacher side (Android addChapterSheet, addLessonSheet,
// addVideoSheet, addDocSheet and the delete confirmation). Same fields, order, margins and messages.

// MARK: - Actions (the five tiles of the home and content tabs)

enum TeacherActions {
    /// Android `contentActions()`: chapter, lesson, YouTube video, book (PDF), file (PDF).
    /// Release 66: [ask] runs the action inside a class (the teacher is asked "which class?" when none is open).
    static func tiles(_ prefs: Prefs, _ store: Store, _ ui: ShellUI,
                      ask: @escaping (@escaping () -> Void) -> Void = { $0() }) -> [TileSpec] {
        [
            TileSpec(icon: "folder", label: prefs.t("act_chapter")) {
                ask { ui.present(prefs.t("act_chapter")) { AddChapterSheet() } }
            },
            TileSpec(icon: "play", label: prefs.t("act_lesson")) {
                ask {
                    let chapters = store.chapters
                    if chapters.isEmpty {
                        ui.toast(prefs.t("err_add_chapter_first"))
                        return
                    }
                    ui.present(prefs.t("act_lesson")) { AddLessonSheet(chapters: chapters) }
                }
            },
            TileSpec(icon: "play", label: prefs.t("act_video")) {
                ask { ui.present(prefs.t("act_video")) { AddVideoSheet() } }
            },
            TileSpec(icon: "book", label: prefs.t("act_book")) {
                ask { ui.present(prefs.t("act_book")) { AddDocSheet(kind: "book") } }
            },
            TileSpec(icon: "note", label: prefs.t("act_file")) {
                ask { ui.present(prefs.t("act_file")) { AddDocSheet(kind: "file") } }
            }
        ]
    }
}

extension ShellUI {
    /// Android `trash(...)`: the message is `confirm_delete` (or [key]) with the item name, the button says "delete".
    func confirmDelete(_ prefs: Prefs, key: String = "confirm_delete", name: String, onYes: @escaping () -> Void) {
        confirm(prefs.tf(key, name), yes: prefs.t("delete"), cancel: prefs.t("cancel"), onYes: onYes)
    }
}

// MARK: - Text field of the sheets (Android `field()`: field_bg, 15 sp, 52 high, 10 above)

struct SheetField: View {
    @Environment(\.theme) private var th
    let hint: String
    @Binding var text: String
    var ltr = false
    var top: CGFloat = 10

    var body: some View {
        TextField(hint, text: $text, prompt: Text(hint).foregroundColor(th.mut))
            .font(.system(size: 15))
            .foregroundColor(th.tx)
            .keyboardType(ltr ? UIKeyboardType.URL : UIKeyboardType.default)
            .textInputAutocapitalization(ltr ? TextInputAutocapitalization.never : TextInputAutocapitalization.sentences)
            .autocorrectionDisabled(ltr)
            // Links are typed left-to-right but still line up with the start (right side) of the screen, like Android.
            .multilineTextAlignment(ltr ? TextAlignment.trailing : TextAlignment.leading)
            .environment(\.layoutDirection, ltr ? LayoutDirection.leftToRight : LayoutDirection.rightToLeft)
            .padding(.horizontal, 14)
            .frame(maxWidth: .infinity, minHeight: 52)
            .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(th.field))
            .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(th.bd, lineWidth: 1))
            .padding(.top, top)
    }
}

// MARK: - Add announcement (Android `addAnnouncementSheet`: title + optional text)

struct AddAnnouncementSheet: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    @State private var title = ""
    @State private var text = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            SheetField(hint: prefs.t("hint_title"), text: $title)
            TextArea(hint: prefs.t("hint_ann_text"), text: $text, lines: 3)
                .padding(.top, 10)
            PrimaryButton(title: prefs.t("add"), height: 50) { add() }
                .padding(.top, 16)
            StartLink(title: prefs.t("cancel")) { ui.dismiss() }
        }
    }

    private func add() {
        let t = title.trimmed
        if t.isEmpty {
            ui.toast(prefs.t("err_title"))
            return
        }
        store.announcements.append(Announcement(id: store.newId(), title: t, text: text.trimmed))
        ui.dismiss()
    }
}

// MARK: - Edit announcement

struct EditAnnouncementSheet: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    let announcement: Announcement
    @State private var title: String
    @State private var text: String

    init(announcement: Announcement) {
        self.announcement = announcement
        _title = State(initialValue: announcement.title)
        _text = State(initialValue: announcement.text)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            SheetField(hint: prefs.t("hint_title"), text: $title)
            TextArea(hint: prefs.t("hint_ann_text"), text: $text, lines: 3)
                .padding(.top, 10)
            PrimaryButton(title: prefs.t("btn_save"), height: 50) { save() }
                .padding(.top, 16)
            StartLink(title: prefs.t("cancel")) { ui.dismiss() }
        }
    }

    private func save() {
        let cleanTitle = title.trimmed
        guard !cleanTitle.isEmpty else { ui.toast(prefs.t("err_title")); return }
        guard let index = store.announcements.firstIndex(where: { $0.id == announcement.id }) else {
            ui.dismiss(); return
        }
        store.announcements[index].title = cleanTitle
        store.announcements[index].text = text.trimmed
        ui.dismiss()
    }
}

// MARK: - Action list sheet (Android `actionSheet`: full-width actions - edit, move, publish, delete)

struct SheetAction: Identifiable {
    let id = UUID()
    let label: String
    var destructive = false
    let run: () -> Void
}

struct ActionListSheet: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var ui: ShellUI
    @Environment(\.theme) private var th
    let acts: [SheetAction]

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            ForEach(acts) { a in
                Button {
                    ui.dismiss()
                    // let the sheet close before the action opens the next sheet / confirmation
                    DispatchQueue.main.async { a.run() }
                } label: {
                    Text(a.label)
                        .font(.system(size: 15, weight: .bold))
                        .foregroundColor(a.destructive ? th.err : th.tx)
                        .frame(maxWidth: .infinity, minHeight: 50, alignment: .leading)
                        .padding(.horizontal, 16)
                        .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(th.field))
                        .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(th.bd, lineWidth: 1))
                }
                .buttonStyle(.plain).sfxTap()
                .padding(.top, 8)
            }
            StartLink(title: prefs.t("cancel"), top: 6) { ui.dismiss() }
        }
    }
}

/// Rename a chapter / book / file (Android `renameSheet`).
struct RenameSheet: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var ui: ShellUI
    let onSave: (String) -> Void
    @State private var title: String

    init(initial: String, onSave: @escaping (String) -> Void) {
        self.onSave = onSave
        _title = State(initialValue: initial)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            SheetField(hint: prefs.t("hint_title"), text: $title)
            PrimaryButton(title: prefs.t("btn_save"), height: 50) { save() }
                .padding(.top, 16)
            StartLink(title: prefs.t("cancel")) { ui.dismiss() }
        }
    }

    private func save() {
        let t = title.trimmed
        if t.isEmpty {
            ui.toast(prefs.t("err_title"))
            return
        }
        onSave(t)
        ui.dismiss()
    }
}

/// Edit a lesson: title, chapter (only for a lesson that is in a chapter), YouTube link (Android `editLessonSheet`).
struct EditLessonSheet: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    @Environment(\.theme) private var th
    let lesson: Lesson
    let chapters: [Chapter]
    @State private var title: String
    @State private var url: String
    @State private var sel: Int
    @State private var paid: Bool
    @State private var price: String

    init(lesson: Lesson, chapters: [Chapter]) {
        self.lesson = lesson; self.chapters = chapters
        _paid = State(initialValue: lesson.price > 0)
        _price = State(initialValue: lesson.price > 0 ? String(lesson.price) : "")
        _title = State(initialValue: lesson.title)
        _url = State(initialValue: lesson.yt.isEmpty ? "" : "https://youtu.be/" + lesson.yt)
        _sel = State(initialValue: max(0, chapters.firstIndex(where: { $0.id == lesson.chapterId }) ?? 0))
    }

    private var inChapter: Bool { !lesson.chapterId.isEmpty }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            SheetField(hint: prefs.t("hint_title"), text: $title)
            if inChapter && !chapters.isEmpty {
                Text(prefs.t("pick_chapter"))
                    .font(.system(size: 13))
                    .foregroundColor(th.mut)
                    .padding(.top, 14)
                ChipRow(labels: chapters.map { $0.title }, selected: sel, top: 8) { sel = $0 }
            }
            if lesson.src == "yt" {
                SheetField(hint: prefs.t(inChapter ? "hint_youtube_optional" : "hint_youtube"), text: $url, ltr: true)
            }
            PriceFields(paid: $paid, price: $price)
            PrimaryButton(title: prefs.t("btn_save"), height: 50) { save() }
                .padding(.top, 16)
            StartLink(title: prefs.t("cancel")) { ui.dismiss() }
        }
    }

    private func save() {
        let t = title.trimmed
        if t.isEmpty { ui.toast(prefs.t("err_title")); return }
        guard let pr = PriceFields.value(paid: paid, price: price) else { ui.toast(prefs.t("err_price")); return }
        if lesson.src == "up" {   // uploaded video: only the title and the price change here
            if let i = store.lessons.firstIndex(where: { $0.id == lesson.id }) { store.lessons[i].title = t; store.lessons[i].price = pr }
            ui.dismiss(); return
        }
        let raw = url.trimmed
        let yt = raw.isEmpty ? "" : Util.youtubeId(raw)
        if !raw.isEmpty && yt.isEmpty { ui.toast(prefs.t("err_bad_link")); return }
        if !inChapter && yt.isEmpty { ui.toast(prefs.t("err_bad_link")); return }   // a stand-alone video needs its link
        let ch = inChapter && !chapters.isEmpty ? chapters[min(max(sel, 0), chapters.count - 1)].id : lesson.chapterId
        guard let i = store.lessons.firstIndex(where: { $0.id == lesson.id }) else { ui.dismiss(); return }
        store.lessons[i].title = t
        store.lessons[i].yt = yt
        store.lessons[i].chapterId = ch
        store.lessons[i].price = pr
        ui.dismiss()
    }
}

// MARK: - Add chapter

struct AddChapterSheet: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    @State private var title = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            SheetField(hint: prefs.t("hint_title"), text: $title)
            PrimaryButton(title: prefs.t("add"), height: 50) { add() }
                .padding(.top, 16)
            StartLink(title: prefs.t("cancel")) { ui.dismiss() }
        }
    }

    private func add() {
        let t = title.trimmed
        if t.isEmpty {
            ui.toast(prefs.t("err_title"))
            return
        }
        store.chapters.append(Chapter(id: store.newId(), title: t))
        ui.dismiss()
    }
}

// MARK: - Add lesson (into a chapter, YouTube link optional)

struct AddLessonSheet: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    @Environment(\.theme) private var th
    let chapters: [Chapter]
    @State private var title = ""
    @State private var url = ""
    @State private var sel = 0
    @State private var src = 0
    @State private var picked: URL? = nil
    @State private var thumb = ""
    @State private var paid = false
    @State private var price = ""
    @State private var busy = false

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            SheetField(hint: prefs.t("hint_title"), text: $title)
            Text(prefs.t("pick_chapter"))
                .font(.system(size: 13))
                .foregroundColor(th.mut)
                .padding(.top, 14)
            ChipRow(labels: chapters.map { $0.title }, selected: sel, top: 8) { sel = $0 }
            VideoSourceFields(src: $src, url: $url, picked: $picked, title: $title, thumb: $thumb, optionalLink: true)
            PriceFields(paid: $paid, price: $price)
            PrimaryButton(title: prefs.t("add"), height: 50) { add() }
                .padding(.top, 16)
            StartLink(title: prefs.t("cancel")) { ui.dismiss() }
        }
    }

    private func add() {
        guard !chapters.isEmpty else { return }
        let ch = chapters[min(max(sel, 0), chapters.count - 1)]
        LessonSave.add(store, prefs, ui, chapterId: ch.id, title: title.trimmed, src: src, url: url, picked: picked,
                       paid: paid, price: price, thumb: thumb, busy: $busy)
    }
}

// MARK: - Add standalone video (YouTube link or uploaded file)

struct AddVideoSheet: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    @State private var title = ""
    @State private var url = ""
    @State private var src = 0
    @State private var picked: URL? = nil
    @State private var thumb = ""
    @State private var paid = false
    @State private var price = ""
    @State private var busy = false

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            SheetField(hint: prefs.t("hint_title"), text: $title)
            VideoSourceFields(src: $src, url: $url, picked: $picked, title: $title, thumb: $thumb, optionalLink: false)
            PriceFields(paid: $paid, price: $price)
            PrimaryButton(title: prefs.t("add"), height: 50) { add() }
                .padding(.top, 16)
            StartLink(title: prefs.t("cancel")) { ui.dismiss() }
        }
    }

    private func add() {
        LessonSave.add(store, prefs, ui, chapterId: "", title: title.trimmed, src: src, url: url, picked: picked,
                       paid: paid, price: price, thumb: thumb, busy: $busy)
    }
}

// MARK: - Release 35 shared pieces: video source, price, saving, course price, opening paid content for a student

/// "YouTube link / Upload video" chips + the link field or the file picker. A pasted link imports the title + thumbnail.
struct VideoSourceFields: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var ui: ShellUI
    @Environment(\.theme) private var th
    @Binding var src: Int
    @Binding var url: String
    @Binding var picked: URL?
    @Binding var title: String
    @Binding var thumb: String
    let optionalLink: Bool
    @State private var showPicker = false
    @State private var lastYt = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            ChipRow(labels: [prefs.t("src_youtube"), prefs.t("src_upload")], selected: src, top: 12) { src = $0 }
            if src == 0 {
                SheetField(hint: prefs.t(optionalLink ? "hint_youtube_optional" : "hint_youtube"), text: $url, ltr: true)
                    .onChange(of: url) { _ in importMeta() }
            } else {
                StartLink(title: prefs.t("choose_video"), top: 8) {
                    Util.hideKeyboard()
                    showPicker = true
                }
                Text(picked == nil ? "" : prefs.t("video_selected"))
                    .font(.system(size: 13))
                    .foregroundColor(th.mut)
                    .padding(.top, 4)
            }
        }
        .fileImporter(isPresented: $showPicker, allowedContentTypes: [UTType.movie], allowsMultipleSelection: false) { result in
            switch result {
            case .success(let urls):
                if let u = urls.first { picked = u }
            case .failure(let e):
                if (e as? CocoaError)?.code != .userCancelled { ui.toast(prefs.t("err_no_picker")) }
            }
        }
    }

    private func importMeta() {
        let id = Util.youtubeId(url)
        guard !id.isEmpty, id != lastYt else { return }
        lastYt = id
        YtMeta.fetch(id) { info in
            DispatchQueue.main.async {
                guard let info = info else { ui.toast(prefs.t("yt_import_fail")); return }
                thumb = info.thumb
                if title.trimmed.isEmpty { title = info.title }
                ui.toast(prefs.t("yt_imported"))
            }
        }
    }
}

/// "Free / Paid" chips + the price field.
struct PriceFields: View {
    @EnvironmentObject private var prefs: Prefs
    @Binding var paid: Bool
    @Binding var price: String

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            ChipRow(labels: [prefs.t("free"), prefs.t("paid")], selected: paid ? 1 : 0, top: 10) { paid = $0 == 1 }
            if paid { SheetField(hint: prefs.t("price_hint"), text: $price, ltr: true) }
        }
    }

    /// 0 = free, > 0 = the price, nil = paid but the number is missing.
    static func value(paid: Bool, price: String) -> Int? {
        if !paid { return 0 }
        if let n = Int(price.trimmed), n > 0 { return n }
        return nil
    }
}

enum LessonSave {
    static func add(_ store: Store, _ prefs: Prefs, _ ui: ShellUI, chapterId: String, title t: String, src: Int, url: String,
                    picked: URL?, paid: Bool, price: String, thumb: String, busy: Binding<Bool>) {
        if t.isEmpty { ui.toast(prefs.t("err_title")); return }
        guard let p = PriceFields.value(paid: paid, price: price) else { ui.toast(prefs.t("err_price")); return }
        if src == 1 {
            guard let from = picked else { ui.toast(prefs.t("err_pick_video")); return }
            if busy.wrappedValue { return }
            busy.wrappedValue = true
            ui.toast(prefs.t("saving"))
            let id = store.newId()
            let dst = store.videoFile(id)
            DispatchQueue.global(qos: .userInitiated).async {   // TODO(server): upload to the platform server (resumable, progress) instead of copying locally
                let ok = DocImport.copy(from: from, to: dst)
                DispatchQueue.main.async {
                    busy.wrappedValue = false
                    if ok {
                        store.lessons.append(Lesson(id: id, chapterId: chapterId, title: t, yt: "", src: "up", price: p))
                        ui.dismiss()
                    } else { ui.toast(prefs.t("err_copy")) }
                }
            }
            return
        }
        let raw = url.trimmed
        let yt = raw.isEmpty ? "" : Util.youtubeId(raw)
        if (!raw.isEmpty && yt.isEmpty) || (chapterId.isEmpty && yt.isEmpty) { ui.toast(prefs.t("err_bad_link")); return }
        store.lessons.append(Lesson(id: store.newId(), chapterId: chapterId, title: t, yt: yt, price: p, thumb: thumb))
        ui.dismiss()
    }
}

/// Course (chapter) price.
struct CoursePriceSheet: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    let chapter: Chapter
    @State private var paid: Bool
    @State private var price: String

    init(chapter: Chapter) {
        self.chapter = chapter
        _paid = State(initialValue: chapter.price > 0)
        _price = State(initialValue: chapter.price > 0 ? String(chapter.price) : "")
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            PriceFields(paid: $paid, price: $price)
            PrimaryButton(title: prefs.t("btn_save"), height: 50) { save() }
                .padding(.top, 16)
            StartLink(title: prefs.t("cancel")) { ui.dismiss() }
        }
    }

    private func save() {
        guard let p = PriceFields.value(paid: paid, price: price) else { ui.toast(prefs.t("err_price")); return }
        if let i = store.chapters.firstIndex(where: { $0.id == chapter.id }) { store.chapters[i].price = p }
        ui.dismiss()
    }
}

// MARK: - Add book / file (PDF picked with the system file picker, copied to Documents/docs/<id>.pdf)

struct AddDocSheet: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    @Environment(\.theme) private var th
    let kind: String
    @State private var title = ""
    @State private var picked: URL? = nil
    @State private var showPicker = false
    @State private var busy = false

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            SheetField(hint: prefs.t("hint_title"), text: $title)
            StartLink(title: prefs.t("choose_pdf"), top: 8) {
                Util.hideKeyboard()
                showPicker = true
            }
            Text(picked == nil ? "" : prefs.t("pdf_selected"))
                .font(.system(size: 13))
                .foregroundColor(th.mut)
                .padding(.top, 4)
            PrimaryButton(title: prefs.t("add"), height: 50) { add() }
                .padding(.top, 12)
            StartLink(title: prefs.t("cancel")) { ui.dismiss() }
        }
        .fileImporter(isPresented: $showPicker, allowedContentTypes: [UTType.pdf], allowsMultipleSelection: false) { result in
            switch result {
            case .success(let urls):
                if let u = urls.first { picked = u }
            case .failure(let e):
                // Closing the picker is not an error; anything else means no file could be picked.
                if (e as? CocoaError)?.code != .userCancelled { ui.toast(prefs.t("err_no_picker")) }
            }
        }
    }

    private func add() {
        let t = title.trimmed
        if t.isEmpty {
            ui.toast(prefs.t("err_title"))
            return
        }
        guard let src = picked else {
            ui.toast(prefs.t("err_pick_pdf"))
            return
        }
        if busy { return }
        busy = true
        ui.toast(prefs.t("saving"))
        let id = store.newId()
        let dst = store.docFile(id)
        let kind = self.kind
        DispatchQueue.global(qos: .userInitiated).async {
            let ok = DocImport.copy(from: src, to: dst)
            DispatchQueue.main.async {
                busy = false
                if ok {
                    store.docs.append(Doc(id: id, title: t, kind: kind))
                    ui.dismiss()
                } else {
                    ui.toast(prefs.t("err_copy"))
                }
            }
        }
    }
}

/// Android `Store.copyUri`: copies the picked file into the app's own storage; on any failure the half-copied file is removed.
enum DocImport {
    static func copy(from src: URL, to dst: URL) -> Bool {
        let scoped = src.startAccessingSecurityScopedResource()
        defer { if scoped { src.stopAccessingSecurityScopedResource() } }
        var ok = false
        var coordinationError: NSError?
        NSFileCoordinator(filePresenter: nil).coordinate(readingItemAt: src, options: [], error: &coordinationError) { readable in
            do {
                try? FileManager.default.removeItem(at: dst)
                try FileManager.default.copyItem(at: readable, to: dst)
                ok = true
            } catch {
                ok = false
            }
        }
        if coordinationError != nil { ok = false }
        if !ok { try? FileManager.default.removeItem(at: dst) }
        return ok
    }
}
