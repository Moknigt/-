import SwiftUI

// MARK: - Students (الطلاب)
//
// The Android tab only lists the registered students as cards (class, name, email).
// iPhone additions, as requested for this part: an active switch, a student code and a delete button on each card.
// They use the strings marked "iPhone additions" in Localizable.strings; the card texts themselves are the Android ones.

struct TeacherStudents: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    /// Kept by `TeacherView` so the home shortcut "Activate accounts" can open this tab already on "not active".
    @Binding var query: String
    @Binding var gradeSel: Int      // 0 = all classes, n = n-th class
    @Binding var statusSel: Int     // 0 = all, 1 = active, 2 = not active
    let openStudent: (String) -> Void

    var body: some View {
        if store.students.isEmpty {
            EmptyState(icon: "users", title: prefs.t("empty_students"), sub: prefs.t("empty_students_sub"))
        } else {
            let grades = store.grades
            let sel = gradeSel <= grades.count ? gradeSel : 0
            let grade: String? = sel > 0 ? grades[sel - 1] : nil
            let q = query.trimmed.lowercased()
            // not active first, then by name
            let shown = store.students.filter { s in
                (grade == nil || s.grade == grade) &&
                (statusSel == 0 || (statusSel == 1) == s.active) &&
                (q.isEmpty || s.name.lowercased().contains(q))
            }.sorted { a, b in
                a.active != b.active ? !a.active : a.name.lowercased() < b.name.lowercased()
            }
            VStack(alignment: .leading, spacing: 0) {
                SheetField(hint: prefs.t("hint_search_name"), text: $query, top: 4)
                ChipRow(labels: [prefs.t("all")] + grades, selected: sel, top: 10) { gradeSel = $0 }
                ChipRow(labels: [prefs.t("all"), prefs.t("stat_active"), prefs.t("stat_inactive")],
                        selected: statusSel, top: 8) { statusSel = $0 }
                if shown.isEmpty {
                    EmptyState(icon: "users", title: prefs.t("empty_search"), sub: prefs.t("empty_search_sub"))
                } else {
                    ForEach(shown) { s in StudentCard(student: s, open: { openStudent(s.email) }) }
                }
            }
        }
    }
}

private struct StudentCard: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    @Environment(\.theme) private var th
    let student: Student
    let open: () -> Void   // tap on the card = the student's page

    var body: some View {
        CardBox(onTap: open) {
            CardTexts(small: student.grade, title: student.name, sub: student.email)
            HStack(spacing: 10) {
                Text(prefs.t(student.active ? "stu_active" : "stu_inactive"))
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(student.active ? th.tx : th.mut)
                Spacer(minLength: 0)
                Toggle("", isOn: Binding(
                    get: { store.findStudent(student.email)?.active ?? student.active },
                    set: { setActive($0) }
                ).sfx())
                .labelsHidden()
                .tint(th.p1)
                .fixedSize()
            }
            .padding(.top, 12)
            HStack(spacing: 8) {
                if student.code.isEmpty {
                    ActionChip(text: prefs.t("stu_code_new")) { openCode() }
                } else {
                    ActionChip(text: student.code, mono: true) { copyCode() }
                    IconButton(icon: "doc.on.doc", tint: th.mut) { copyCode() }
                }
                if !student.code.isEmpty {
                    StartLink(title: prefs.t("stu_code_regen")) { openCode() }
                }
                Spacer(minLength: 0)
                TrashButton {
                    ui.confirmDelete(prefs, key: "confirm_delete_student", name: student.name) {
                        store.deleteStudent(student.email)
                    }
                }
            }
            .padding(.top, 8)
        }
    }

    private func setActive(_ active: Bool) {
        guard let i = store.students.firstIndex(where: { $0.email == student.email }) else { return }
        store.students[i].active = active
    }

    private func copyCode() {
        UIPasteboard.general.string = student.code
        ui.toast(prefs.t("stu_copied"))
    }

    /// Makes a code the first time, then shows it (copy / new code) in a sheet.
    private func openCode() {
        if student.code.isEmpty { StudentCodes.regenerate(store, student.email) }
        ui.present(prefs.t("stu_code_title")) { StudentCodeSheet(email: student.email) }
    }
}

// MARK: - A student's own page (Android `studentProfile`): data + switch + code, progress, results, submissions

struct TeacherStudentProfile: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    @Environment(\.theme) private var th
    let email: String
    let back: () -> Void
    let openHomework: (String) -> Void

    var body: some View {
        if let s = store.findStudent(email) {
            page(s)
        } else {
            Color.clear.onAppear { back() }   // deleted from this page
        }
    }

    @ViewBuilder
    private func page(_ s: Student) -> some View {
        let p = store.progress(email)
        let pct = Store.percent(p)
        let results = store.results.filter { $0.email == email }.sorted { $0.at > $1.at }
        let subs = store.submissions.filter { $0.email == email }.sorted { $0.at > $1.at }
        let avg = store.officialAverage(email)
        VStack(alignment: .leading, spacing: 0) {
            TopBar(title: s.name, onBack: back)
            CardBox {
                CardTexts(small: s.grade, title: s.name, sub: s.email)
                Text(s.phone.isEmpty ? prefs.t("acc_no_phone") : s.phone)
                    .font(.system(size: 13))
                    .foregroundColor(th.mut)
                    .environment(\.layoutDirection, .leftToRight)
                    .padding(.top, 4)
                HStack(spacing: 10) {
                    Text(prefs.t(s.active ? "stu_active" : "stu_inactive"))
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(s.active ? th.tx : th.mut)
                    Toggle("", isOn: Binding(
                        get: { store.findStudent(email)?.active ?? s.active },
                        set: { setActive($0) }
                    ).sfx())
                    .labelsHidden()
                    .tint(th.p1)
                    .fixedSize()
                    Spacer(minLength: 0)
                    if s.code.isEmpty {
                        ActionChip(text: prefs.t("stu_code_new")) { StudentCodes.regenerate(store, email) }
                    } else {
                        ActionChip(text: s.code, mono: true) {
                            UIPasteboard.general.string = s.code
                            ui.toast(prefs.t("stu_copied"))
                        }
                        // asks first: the old code stops working
                        StartLink(title: prefs.t("stu_code_regen")) {
                            ui.confirm(prefs.t("stu_regen_confirm"), yes: prefs.t("stu_code_regen"), cancel: prefs.t("cancel")) {
                                StudentCodes.regenerate(store, email)
                            }
                        }
                    }
                    TrashButton {
                        ui.confirmDelete(prefs, key: "confirm_delete_student", name: s.name) {
                            store.deleteStudent(email)
                        }
                    }
                }
                .padding(.top, 12)
            }

            CardBox {
                CardTexts(small: prefs.t("study_progress"), title: "\(pct)%",
                          sub: prefs.tf("lessons_done_of", p.done, p.total))
                ProgressBarView(pct: pct, top: 12)
            }

            StatTextRow(items: [
                (text: avg.map { "\($0)%" } ?? "-", label: prefs.t("ex_official_avg")),
                (text: "\(Set(results.map { $0.examId }).count)", label: prefs.t("prof_exams_taken"))
            ])
            StatTextRow(items: [
                (text: "\(subs.count)", label: prefs.t("prof_hw_sent")),
                (text: "\(subs.filter { $0.grade >= 0 }.count)", label: prefs.t("prof_hw_graded"))
            ])

            Heading(text: prefs.t("paid_content"))
            PrimaryButton(title: prefs.t("grant_open"), height: 50) { grantSheet() }
                .padding(.top, 8)
            ForEach(store.grants.filter { $0.email == email }.indices, id: \.self) { i in
                let g = store.grants.filter { $0.email == email }[i]
                ItemRow(icon: "key", title: targetName(g.target), sub: modeName(g.mode), onTap: {
                    ui.confirm(prefs.t("grant_revoke"), yes: prefs.t("grant_revoke"), cancel: prefs.t("cancel")) {
                        store.revoke(g.target, email)
                    }
                }) { EmptyView() }
            }
            let glog = store.glog.filter { $0.email == email }.sorted { $0.at > $1.at }
            if !glog.isEmpty {
                Heading(text: prefs.t("grant_log"))
                ForEach(glog.indices, id: \.self) { i in
                    let g = glog[i]
                    ItemRow(icon: "hist", title: targetName(g.target),
                            sub: prefs.tf("grant_log_row", modeName(g.mode), g.by, Util.dateText(g.at))) { EmptyView() }
                }
            }

            Heading(text: prefs.t("prof_results"))
            if results.isEmpty { note(prefs.t("prof_no_results")) }
            ForEach(results.indices, id: \.self) { i in
                let r = results[i]
                ItemRow(icon: "exam", title: store.exam(r.examId)?.title ?? "",
                        sub: "\(r.score)%  •  \(r.correct)/\(r.total)  •  \(Util.dateText(r.at))") { EmptyView() }
            }

            Heading(text: prefs.t("prof_submissions"))
            if subs.isEmpty { note(prefs.t("prof_no_subs")) }
            ForEach(subs) { sb in
                if let h = store.homeworkById(sb.hwId) {
                    let st = sb.grade >= 0 ? prefs.tf("hw_status_graded", sb.grade) : prefs.t("hw_status_sent")
                    ItemRow(icon: "note", title: h.title, sub: st + "  •  " + Util.dateText(sb.at),
                            onTap: { openHomework(h.id) }) { EmptyView() }
                }
            }
        }
    }

    private func note(_ text: String) -> some View {
        Text(text).font(.system(size: 13)).foregroundColor(th.mut).padding(.top, 8)
    }

    private func setActive(_ active: Bool) {
        guard let i = store.students.firstIndex(where: { $0.email == email }) else { return }
        store.students[i].active = active
    }
}

/// Small pill button on a student card (filled with the gradient when [on]).
private struct ActionChip: View {
    @Environment(\.theme) private var th
    let text: String
    var on = false
    var mono = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(text)
                .font(.system(size: 12, weight: .bold, design: mono ? .monospaced : .default))
                .foregroundColor(on ? Color.white : th.tx)
                .environment(\.layoutDirection, mono ? .leftToRight : .rightToLeft)
                .padding(.horizontal, 14)
                .frame(height: 34)
                .background(background)
        }
        .buttonStyle(.plain).sfxTap()
    }

    @ViewBuilder
    private var background: some View {
        if on {
            RoundedRectangle(cornerRadius: 12, style: .continuous).fill(th.gradient)
        } else {
            RoundedRectangle(cornerRadius: 12, style: .continuous).fill(LinearGradient(colors: [th.glassHi, th.glassLo], startPoint: .topLeading, endPoint: .bottomTrailing))
                .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(th.bd, lineWidth: 1))
        }
    }
}

// MARK: - Student code

enum StudentCodes {
    /// 10 characters, no look-alikes (no O/0, I/1).
    private static func make(avoiding used: Set<String>) -> String {
        let chars = Array("ABCDEFGHJKLMNPQRSTUVWXYZ23456789")
        while true {
            let c = String((0..<10).map { _ in chars[Int.random(in: 0..<chars.count)] })
            if !used.contains(c) { return c }
        }
    }

    static func regenerate(_ store: Store, _ email: String) {
        guard let i = store.students.firstIndex(where: { $0.email == email }) else { return }
        store.students[i].code = make(avoiding: Set(store.students.map { $0.code }))
    }
}

/// Body of the code sheet: the code, copy, make a new one.
struct StudentCodeSheet: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    @Environment(\.theme) private var th
    let email: String

    var body: some View {
        let code = store.findStudent(email)?.code ?? ""
        VStack(alignment: .leading, spacing: 0) {
            Text(prefs.t("stu_code_note"))
                .font(.system(size: 13))
                .foregroundColor(th.mut)
                .padding(.top, 10)
            Text(code)
                .font(.system(size: 26, weight: .bold, design: .monospaced))
                .foregroundColor(th.tx)
                .environment(\.layoutDirection, .leftToRight)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 18)
                .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(th.field))
                .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(th.bd, lineWidth: 1))
                .padding(.top, 12)
            PrimaryButton(title: prefs.t("stu_copy"), height: 50) {
                UIPasteboard.general.string = code
                ui.toast(prefs.t("stu_copied"))
            }
            .padding(.top, 14)
            StartLink(title: prefs.t("stu_code_regen"), top: 4) {
                StudentCodes.regenerate(store, email)
            }
            StartLink(title: prefs.t("close")) { ui.dismiss() }
        }
    }
}


// MARK: - Release 35: opening paid content for a student (cash / free). Every opening is logged in `store.glog`.

extension TeacherStudentProfile {
    fileprivate func targetName(_ t: String) -> String {
        if t.hasPrefix("c:") { return prefs.tf("course_tag", store.chapters.first { $0.id == String(t.dropFirst(2)) }?.title ?? "?") }
        return store.lesson(String(t.dropFirst(2)))?.title ?? "?"
    }

    fileprivate func modeName(_ m: String) -> String {
        prefs.t(m == "online" ? "grant_mode_online" : (m == "cash" ? "grant_mode_cash" : "grant_mode_free"))
    }

    fileprivate func grantSheet() {
        let have = Set(store.grants.filter { $0.email == email }.map { $0.target })
        var items: [(String, String)] = []
        for c in store.chapters where c.price > 0 && !have.contains("c:" + c.id) {
            items.append(("c:" + c.id, prefs.tf("course_tag", c.title) + "  •  " + prefs.tf("price_egp", c.price)))
        }
        for l in store.lessons where l.price > 0 && !have.contains("l:" + l.id) {
            items.append(("l:" + l.id, l.title + "  •  " + prefs.tf("price_egp", l.price)))
        }
        if items.isEmpty { ui.toast(prefs.t("grant_none")); return }
        let acts = items.map { it in
            SheetAction(label: it.1) {
                ui.present(it.1) {
                    ActionListSheet(acts: [
                        SheetAction(label: prefs.t("grant_cash")) { doGrant(it.0, "cash") },
                        SheetAction(label: prefs.t("grant_free")) { doGrant(it.0, "free") }
                    ])
                }
            }
        }
        ui.present(prefs.t("grant_open")) { ActionListSheet(acts: acts) }
    }

    fileprivate func doGrant(_ target: String, _ mode: String) {
        store.grant(target, email, mode: mode, by: store.teacher?.email ?? "teacher")
        ui.toast(prefs.t("grant_done"))
    }
}
