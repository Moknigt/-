import SwiftUI

// MARK: - Home (الرئيسية): overview stats (active / not active students, official average, homework to grade, lessons, exams) + quick access

/// Release 66: the short name of one of the three classes (grade_1_short ...); any other name is shown as it is.
func gradeLabel(_ g: String, _ prefs: Prefs) -> String {
    guard let i = Store.defaultGrades.firstIndex(of: g) else { return g }
    return prefs.t("grade_\(i + 1)_short")
}

struct TeacherHome: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    @Environment(\.theme) private var th
    let ctx: TeacherCtx
    /// Opens the Students tab already filtered on "not active".
    let openInactive: () -> Void
    let openClasses: () -> Void
    /// Release 66: opens one class (its own content and tests).
    let openGrade: (String) -> Void

    var body: some View {
        let all = store.students
        let active = all.filter { $0.active }.count
        let inactive = all.count - active
        let avg = store.teacherOfficialAverage()
        VStack(alignment: .leading, spacing: 0) {
            Heading(text: prefs.t("sec_classes"))
            ForEach(Store.defaultGrades, id: \.self) { g in
                ItemRow(icon: "grade", title: gradeLabel(g, prefs),
                        sub: prefs.tf("students_count", all.filter { $0.grade == g }.count), onTap: { openGrade(g) }) {
                    Icon("chev", size: 20, color: th.mut)
                        .scaleEffect(x: -1, y: 1)
                        .frame(width: 32, height: 32)
                }
            }
            Heading(text: prefs.t("sec_overview"))
            StatTextRow(items: [
                (text: "\(active)", label: prefs.t("stat_active")),
                (text: "\(inactive)", label: prefs.t("stat_inactive"))
            ])
            StatTextRow(items: [
                (text: avg.map { "\($0)%" } ?? "-", label: prefs.t("ex_official_avg")),
                (text: "\(store.ungraded())", label: prefs.t("hw_ungraded"))
            ])
            StatTextRow(items: [
                (text: "\(store.lessons.count)", label: prefs.t("stat_lessons")),
                (text: "\(store.exams.count)", label: prefs.t("ex_exams"))
            ])
            Heading(text: prefs.t("sec_quick"))
            TileGrid(items: [
                TileSpec(icon: "play", label: prefs.t("act_lesson")) {
                    ctx.ask {
                        let chapters = store.chapters
                        if chapters.isEmpty {
                            ui.toast(prefs.t("err_add_chapter_first"))
                            return
                        }
                        ui.present(prefs.t("act_lesson")) { AddLessonSheet(chapters: chapters) }
                    }
                },
                TileSpec(icon: "exam", label: prefs.t("act_exam")) {
                    ctx.ask {
                        let bank = store.questions
                        if bank.isEmpty {
                            ui.toast(prefs.t("ex_err_add_questions_first"))
                            return
                        }
                        ui.present(prefs.t("ex_add_exam")) { AddExamSheet(bank: bank) }
                    }
                },
                TileSpec(icon: "note", label: prefs.t("act_homework")) {
                    ctx.ask { ui.present(prefs.t("ex_add_homework")) { AddHomeworkSheet() } }
                },
                TileSpec(icon: "users", label: prefs.t("act_activate"), count: inactive) { openInactive() },
                TileSpec(icon: "grade", label: prefs.t("act_classes")) { openClasses() }
            ])
        }
    }
}

// MARK: - Content (المحتوى): actions + everything the teacher uploaded, with delete buttons

struct TeacherContent: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    let ctx: TeacherCtx
    let openClasses: () -> Void

    var body: some View {
        let chapters = store.chapters
        let lessons = store.lessons
        let docs = store.docs
        let anns = store.announcements.sorted { $0.at > $1.at }
        VStack(alignment: .leading, spacing: 0) {
            TileGrid(items: TeacherActions.tiles(prefs, store, ui, ask: ctx.ask) + [
                TileSpec(icon: "grade", label: prefs.t("act_classes")) { openClasses() },
                TileSpec(icon: "note", label: prefs.t("act_announce")) {
                    ctx.ask { ui.present(prefs.t("act_announce")) { AddAnnouncementSheet() } }
                }
            ])
            if !anns.isEmpty {
                Heading(text: prefs.t("ann_title"))
                ForEach(anns) { a in
                    let sub = a.text.cut(60)
                    ItemRow(icon: "note", title: a.title, sub: sub.isEmpty ? Util.dateText(a.at) : sub,
                            onTap: { ui.present(prefs.t("act_edit")) { EditAnnouncementSheet(announcement: a) } }) {
                        HStack(spacing: 4) {
                            ManageButton {
                                ui.present(prefs.t("act_edit")) { EditAnnouncementSheet(announcement: a) }
                            }
                            TrashButton {
                                ui.confirmDelete(prefs, name: a.title) {
                                    store.announcements.removeAll { $0.id == a.id }
                                }
                            }
                        }
                    }
                }
            }
            if chapters.isEmpty && lessons.isEmpty && docs.isEmpty {
                if anns.isEmpty {
                    EmptyState(icon: "folder", title: prefs.t("empty_content"), sub: prefs.t("empty_content_sub"))
                }
            } else {
                let videos = lessons.filter { $0.chapterId.isEmpty }
                if !videos.isEmpty {
                    Heading(text: prefs.t("videos"))
                    ForEach(Array(videos.enumerated()), id: \.element.id) { p in
                        TeacherLessonRow(lesson: p.element, idx: p.offset, count: videos.count, ctx: ctx)
                    }
                }
                if !chapters.isEmpty { Heading(text: prefs.t("chapters_title")) }
                ForEach(Array(chapters.enumerated()), id: \.element.id) { cp in
                    let ch = cp.element
                    let ls = lessons.filter { $0.chapterId == ch.id }
                    ItemRow(icon: "folder", title: ch.title, sub: prefs.tf("lessons_count", ls.count),
                            onTap: { chapterActions(ch, cp.offset, chapters.count) }) {
                        ManageButton { chapterActions(ch, cp.offset, chapters.count) }
                    }
                    ForEach(Array(ls.enumerated()), id: \.element.id) { lp in
                        TeacherLessonRow(lesson: lp.element, idx: lp.offset, count: ls.count, ctx: ctx)
                    }
                }
                let books = docs.filter { $0.kind == "book" }
                if !books.isEmpty {
                    Heading(text: prefs.t("books_title"))
                    ForEach(Array(books.enumerated()), id: \.element.id) { p in
                        TeacherDocRow(doc: p.element, idx: p.offset, count: books.count, ctx: ctx)
                    }
                }
                let files = docs.filter { $0.kind == "file" }
                if !files.isEmpty {
                    Heading(text: prefs.t("files_title"))
                    ForEach(Array(files.enumerated()), id: \.element.id) { p in
                        TeacherDocRow(doc: p.element, idx: p.offset, count: files.count, ctx: ctx)
                    }
                }
            }
        }
    }
}

extension TeacherContent {
    /// Android `chapterActions`: rename, move up / down, delete.
    fileprivate func chapterActions(_ ch: Chapter, _ idx: Int, _ n: Int) {
        var acts = [SheetAction(label: prefs.t("course_price") + (ch.price > 0 ? "  •  " + prefs.tf("price_egp", ch.price) : "")) {
            ui.present(prefs.t("course_price")) { CoursePriceSheet(chapter: ch) }
        }, SheetAction(label: prefs.t("act_rename")) {
            ui.present(prefs.t("rename_chapter")) {
                RenameSheet(initial: ch.title) { store.renameChapter(ch.id, $0) }
            }
        }]
        acts += moveActions(prefs, idx, n) { store.moveChapter(ch.id, $0) }
        acts.append(SheetAction(label: prefs.t("delete"), destructive: true) {
            ui.confirmDelete(prefs, key: "confirm_delete_chapter", name: ch.title) { store.deleteChapter(ch.id) }
        })
        ui.present(ch.title) { ActionListSheet(acts: acts) }
    }
}

/// Up / down entries of an action sheet (only the moves that are possible).
func moveActions(_ prefs: Prefs, _ idx: Int, _ n: Int, move: @escaping (Int) -> Void) -> [SheetAction] {
    var a: [SheetAction] = []
    if idx > 0 { a.append(SheetAction(label: prefs.t("act_move_up")) { move(-1) }) }
    if idx < n - 1 { a.append(SheetAction(label: prefs.t("act_move_down")) { move(1) }) }
    return a
}

/// The pencil button of a manageable row (Android `manageBtn`).
struct ManageButton: View {
    @Environment(\.theme) private var th
    let action: () -> Void
    var body: some View { IconButton(icon: "pencil", tint: th.mut, action: action) }
}

/// A lesson / standalone video: a switch to publish or hide it, a pencil button, tap = the action sheet.
/// Hidden lessons are dimmed and marked "Hidden from students"; the students no longer see them anywhere.
struct TeacherLessonRow: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    @Environment(\.theme) private var th
    let lesson: Lesson
    let idx: Int
    let count: Int
    let ctx: TeacherCtx

    var body: some View {
        let kind = !store.hasVideo(lesson) ? "no_video_yet" : (lesson.src == "up" ? "lesson_video_upload" : "lesson_video_label")
        let cost = lesson.price > 0 ? prefs.tf("price_egp", lesson.price) : prefs.t("free")
        let sub = prefs.t(kind) + "  •  " + cost + "  •  "
            + prefs.t(lesson.published ? "lesson_published" : "lesson_hidden")
        ItemRow(icon: "play", title: lesson.title, sub: sub, onTap: actions) {
            HStack(spacing: 4) {
                Toggle("", isOn: Binding(
                    get: { store.lesson(lesson.id)?.published ?? lesson.published },
                    set: { store.setPublished(lesson.id, $0) }
                ).sfx())
                .labelsHidden()
                .tint(th.p1)
                .fixedSize()
                ManageButton(action: actions)
            }
        }
        .opacity(lesson.published ? 1 : 0.6)
    }

    /// Android `lessonActions`: preview, edit, publish / hide, move up / down, delete.
    private func actions() {
        var acts: [SheetAction] = []
        if store.hasVideo(lesson) { acts.append(SheetAction(label: prefs.t("act_preview")) { ctx.openVideo(lesson) }) }
        acts.append(SheetAction(label: prefs.t("act_edit")) {
            ui.present(prefs.t("edit_lesson")) { EditLessonSheet(lesson: lesson, chapters: store.chapters) }
        })
        acts.append(SheetAction(label: prefs.t(lesson.published ? "act_hide" : "act_publish")) {
            store.setPublished(lesson.id, !lesson.published)
        })
        acts += moveActions(prefs, idx, count) { store.moveLesson(lesson.id, $0) }
        acts.append(SheetAction(label: prefs.t("delete"), destructive: true) {
            ui.confirmDelete(prefs, name: lesson.title) { store.deleteLesson(lesson.id) }
        })
        ui.present(lesson.title) { ActionListSheet(acts: acts) }
    }
}

/// A book / file: icon by kind, upload date, pencil button; tap = the action sheet (open, rename, move, delete).
struct TeacherDocRow: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    let doc: Doc
    let idx: Int
    let count: Int
    let ctx: TeacherCtx

    var body: some View {
        ItemRow(icon: doc.kind == "book" ? "book" : "note", title: doc.title,
                sub: Util.dateText(doc.at), onTap: actions) {
            ManageButton(action: actions)
        }
    }

    /// Android `docActions`.
    private func actions() {
        var acts = [
            SheetAction(label: prefs.t("act_open")) { ctx.openDoc(doc) },
            SheetAction(label: prefs.t("act_rename")) {
                ui.present(prefs.t("rename_doc")) { RenameSheet(initial: doc.title) { store.renameDoc(doc.id, $0) } }
            }
        ]
        acts += moveActions(prefs, idx, count) { store.moveDoc(doc.id, $0) }
        acts.append(SheetAction(label: prefs.t("delete"), destructive: true) {
            ui.confirmDelete(prefs, name: doc.title) { store.deleteDoc(doc.id) }
        })
        ui.present(doc.title) { ActionListSheet(acts: acts) }
    }
}

// MARK: - Profile (حسابي)

struct TeacherProfile: View {
    @EnvironmentObject private var prefs: Prefs
    let email: String
    let name: String

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            CardBox { CardTexts(small: prefs.t("role_teacher_label"), title: name) }
            CardBox { CardTexts(small: prefs.t("email_label"), title: email) }
        }
    }
}

// MARK: - Manage classes (sub-screen, Android `classesScreen`): add, delete with confirmation, student count per class

struct TeacherClassesScreen: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @EnvironmentObject private var ui: ShellUI
    @Environment(\.theme) private var th
    let back: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            TopBar(title: prefs.t("classes_title"), count: store.grades.count, onBack: back)
            PrimaryButton(title: prefs.t("act_grade"), height: 50) {
                ui.present(prefs.t("act_grade")) { AddGradeSheet() }
            }
            .padding(.top, 8)
            if store.grades.isEmpty {
                Text(prefs.t("no_grades"))
                    .font(.system(size: 13))
                    .foregroundColor(th.mut)
                    .padding(.top, 16)
            }
            ForEach(store.grades, id: \.self) { g in
                ItemRow(icon: "grade", title: g,
                        sub: prefs.tf("students_count", store.students.filter { $0.grade == g }.count)) {
                    TrashButton {
                        ui.confirmDelete(prefs, key: "confirm_delete_grade", name: g) {
                            store.grades.removeAll { $0 == g }
                        }
                    }
                }
            }
            Text(prefs.t("classes_note"))
                .font(.system(size: 12))
                .foregroundColor(th.mut)
                .padding(.top, 16)
        }
    }
}


// MARK: - Release 66: one class (Android `gradeScreen`): its stats, a Content part and a Tests part. Everything added here belongs to the class.

struct TeacherGradeScreen: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    let grade: String
    let ctx: TeacherCtx
    @Binding var sec: Int          // 0 = content, 1 = exams / questions / homework
    @Binding var exTab: String
    let back: () -> Void
    let openHomework: (String) -> Void
    let openClasses: () -> Void

    var body: some View {
        let mine = store.students.filter { $0.grade == grade }
        let active = mine.filter { $0.active }.count
        VStack(alignment: .leading, spacing: 0) {
            TopBar(title: gradeLabel(grade, prefs), onBack: back)
            StatTextRow(items: [
                (text: "\(active)", label: prefs.t("stat_active")),
                (text: "\(mine.count - active)", label: prefs.t("stat_inactive"))
            ])
            ChipRow(labels: [prefs.t("tab_content"), prefs.t("tab_tests")], selected: sec, top: 8) { sec = $0 }
            if sec == 0 {
                TeacherContent(ctx: ctx, openClasses: openClasses)
            } else {
                TeacherExams(tab: $exTab, openHomework: openHomework, ask: ctx.ask)
            }
        }
        .onAppear { store.teacherGrade = grade }   // set again on every return from a sub-screen
    }
}
