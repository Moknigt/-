import SwiftUI

/// What the teacher screens need from their container: how to open a lesson and a PDF.
struct TeacherCtx {
    let openVideo: (Lesson) -> Void
    let openDoc: (Doc) -> Void
}

/// The teacher side (Android `TeacherActivity`): shell (header + 5 tabs: home, students, content, exams, profile),
/// the add / delete sheets, the settings sheet, the in-app PDF reader and the in-app video player.
/// A tab index plus a small route stack (only the homework answers are opened on top of the Exams tab).
struct TeacherView: View {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @Environment(\.theme) private var th
    @StateObject private var ui = ShellUI()
    let email: String

    @State private var tab = 0
    @State private var stack: [TeacherRoute] = []   // sub-screens on top of a tab (the homework answers)
    @State private var exTab = "exams"              // chip of the Exams tab, kept when coming back from a homework
    @State private var cover: PlayerCover? = nil
    @State private var stuQuery = ""                // Students tab filters (the home shortcut presets them)
    @State private var stuGrade = 0
    @State private var stuStatus = 0

    init(email: String) { self.email = email }

    private let tabs = [
        ShellTab(labelKey: "tab_home", icon: "home"),
        ShellTab(labelKey: "tab_students", icon: "users"),
        ShellTab(labelKey: "tab_content", icon: "folder"),
        ShellTab(labelKey: "tab_tests", icon: "exam"),
        ShellTab(labelKey: "tab_profile", icon: "user")
    ]

    /// Same as Android `Store.teacherName().ifEmpty { email.substringBefore("@") }`.
    private var displayName: String { store.teacher?.displayName ?? (email.components(separatedBy: "@").first ?? email) }

    var body: some View {
        ShellFrame(ui: ui, helloKey: "welcome_teacher", name: displayName, tabs: tabs, selected: tab,
                   screenKey: "\(tab)/" + stack.map { "\($0)" }.joined(separator: ","),
                   onBack: backAction,
                   onSelect: { tab = $0; stack = [] },
                   onSettings: { openSettings() }) {
            screen
        }
        .coverHost($cover, ui: ui)
    }

    private var backAction: (() -> Void)? {
        if stack.isEmpty { return nil }
        return { goBack() }
    }

    private func goBack() {
        if !stack.isEmpty { stack.removeLast() }
    }

    private func openSettings() {
        ui.openSettings()
    }

    private var ctx: TeacherCtx {
        TeacherCtx(openVideo: { openVideo($0) }, openDoc: { openDoc($0) })
    }

    @ViewBuilder
    private var screen: some View {
        if let r = stack.last {
            switch r {
            case .homework(let id): HomeworkAnswersScreen(hwId: id, back: { goBack() })
            case .classes: TeacherClassesScreen(back: { goBack() })
            case .student(let e):
                TeacherStudentProfile(email: e, back: { goBack() }, openHomework: { stack.append(.homework($0)) })
            }
        } else {
            switch tab {
            case 0: TeacherHome(openInactive: openInactiveStudents, openClasses: { stack.append(.classes) })
            case 1: TeacherStudents(query: $stuQuery, gradeSel: $stuGrade, statusSel: $stuStatus,
                                         openStudent: { stack.append(.student($0)) })
            case 2: TeacherContent(ctx: ctx, openClasses: { stack.append(.classes) })
            case 3: TeacherExams(tab: $exTab, openHomework: { stack.append(.homework($0)) })
            default: TeacherProfile(email: email, name: displayName)
            }
        }
    }

    /// Home shortcut "Activate accounts": the Students tab, filtered on "not active", no search, all classes.
    private func openInactiveStudents() {
        stuStatus = 2; stuGrade = 0; stuQuery = ""
        stack = []
        tab = 1
    }

    // MARK: Opening content

    /// Android `openVideo(l)` without an email: the in-app player opens and nothing is added to any watch history.
    private func openVideo(_ l: Lesson) {
        if !store.hasVideo(l) {
            ui.toast(prefs.t("err_no_video"))
            return
        }
        cover = .video(store.videoItem(l))
    }

    private func openDoc(_ d: Doc) {
        guard FileManager.default.fileExists(atPath: store.docFile(d.id).path) else {
            ui.toast(prefs.t("err_no_file"))
            return
        }
        cover = .pdf(d)
    }
}
