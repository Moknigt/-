import SwiftUI
import WebKit
import AVFoundation
import AVKit

// In-app lesson player (Android `VideoActivity` + activity_video.xml + strings_player.xml).
// The video is a YouTube video drawn by the YouTube IFrame player inside a WKWebView (its own controls are hidden),
// and everything the student touches is a native control on top of it: play / pause, skip (buttons + double tap),
// seek bar, playback speed, full screen and resume position. Same JS bridge, same polling (every 0.4 s), same keys.

// MARK: - What gets presented

/// Android `VideoActivity` extras: the YouTube id and the lesson title.
struct VideoItem: Identifiable {
    let id = UUID()
    let yt: String
    let title: String
    /// Uploaded video file (release 35); nil = YouTube.
    var file: URL? = nil
}

/// One full screen cover for both the PDF reader and the video player (a view can only host one reliably).
enum PlayerCover: Identifiable {
    case pdf(Doc)
    case video(VideoItem)

    var id: String {
        switch self {
        case .pdf(let d): return "pdf:" + d.id
        case .video(let v): return "video:" + v.id.uuidString
        }
    }
}

/// Presents [cover] full screen with the app environment re-injected (a cover does not always inherit it).
struct CoverHost: ViewModifier {
    @EnvironmentObject private var prefs: Prefs
    @EnvironmentObject private var store: Store
    @Environment(\.theme) private var th
    @Binding var cover: PlayerCover?
    let ui: ShellUI

    func body(content: Content) -> some View {
        content.fullScreenCover(item: $cover) { c in
            Group {
                switch c {
                case .pdf(let d):
                    PdfReaderView(doc: d, onFail: { ui.toast(prefs.t("err_no_file")) })
                case .video(let v):
                    if let f = v.file { UploadPlayerView(item: v, file: f) } else { VideoPlayerView(item: v) }
                }
            }
            .environmentObject(prefs)
            .environmentObject(store)
            .environment(\.theme, th)
            .environment(\.layoutDirection, .rightToLeft)
        }
    }
}

extension View {
    func coverHost(_ cover: Binding<PlayerCover?>, ui: ShellUI) -> some View {
        modifier(CoverHost(cover: cover, ui: ui))
    }
}

// MARK: - Web view holder

/// Owns the WKWebView that runs the YouTube IFrame player.
final class PlayerWeb {
    let web: WKWebView

    init() {
        let cfg = WKWebViewConfiguration()
        cfg.allowsInlineMediaPlayback = true
        cfg.mediaTypesRequiringUserActionForPlayback = []
        let w = WKWebView(frame: .zero, configuration: cfg)
        w.isOpaque = false
        w.backgroundColor = UIColor.black
        w.scrollView.backgroundColor = UIColor.black
        w.scrollView.isScrollEnabled = false
        w.scrollView.bounces = false
        // All touches go to the native layer drawn on top (taps, double taps, buttons).
        w.isUserInteractionEnabled = false
        web = w
    }

    func load(_ id: String, start: Int) {
        web.loadHTMLString(PlayerWeb.page(id, start), baseURL: URL(string: "https://www.youtube-nocookie.com"))
    }

    func js(_ code: String) {
        web.evaluateJavaScript(code, completionHandler: nil)
    }

    /// "time,duration,state,rate" or an empty string while the player is not ready.
    func poll(_ done: @escaping (String) -> Void) {
        web.evaluateJavaScript("window.nx?window.nx.s():''") { r, _ in
            done((r as? String) ?? "")
        }
    }

    func blank() {
        web.loadHTMLString("", baseURL: nil)
    }

    /// Same page as Android `page()`.
    static func page(_ id: String, _ start: Int) -> String {
        let parts: [String] = [
            "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'>",
            "<style>html,body{margin:0;height:100%;background:#000;overflow:hidden}",
            "#pl{position:absolute;left:0;top:0;width:100%;height:100%;border:0}</style>",
            "<script src='https://www.youtube.com/iframe_api'></script></head><body><div id='pl'></div><script>",
            "var p=null,st=-2;",
            "function onYouTubeIframeAPIReady(){p=new YT.Player('pl',{host:'https://www.youtube-nocookie.com',",
            "width:'100%',height:'100%',videoId:'\(id)',playerVars:{controls:0,rel:0,playsinline:1,modestbranding:1,",
            "fs:0,iv_load_policy:3,disablekb:1,autoplay:1,start:\(start),origin:'https://www.youtube-nocookie.com'},",
            "events:{onStateChange:function(e){st=e.data},onError:function(e){st=-100-e.data}}});}",
            "window.nx={s:function(){if(!p)return '';var t=0,d=0,r=1;",
            "try{t=p.getCurrentTime();d=p.getDuration();r=p.getPlaybackRate()}catch(x){}return [t,d,st,r].join(',')},",
            "play:function(){try{p.playVideo()}catch(x){}},pause:function(){try{p.pauseVideo()}catch(x){}},",
            "seek:function(t){try{p.seekTo(t,true)}catch(x){}},rate:function(r){try{p.setPlaybackRate(r)}catch(x){}}};",
            "</script></body></html>"
        ]
        return parts.joined()
    }
}

struct WebHost: UIViewRepresentable {
    let web: WKWebView

    func makeUIView(context: Context) -> WKWebView { web }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

// MARK: - Model (state + logic of VideoActivity)

final class PlayerModel: ObservableObject {
    static let idChars = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-")

    let vid: String
    let player = PlayerWeb()

    let steps = [5, 10, 15, 30]
    let rates: [Double] = [0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0]
    let rateLabels = ["0.5x", "0.75x", "1x", "1.25x", "1.5x", "1.75x", "2x"]

    // What the screen shows.
    @Published var cur = 0.0
    @Published var dur = 0.0
    @Published var state = -2
    @Published var controls = true
    @Published var settings = false
    @Published var loading = true
    @Published var error = false
    @Published var flash: String? = nil
    @Published var showResume = false
    @Published var resumeAt = 0
    @Published var dragging = false
    @Published var dragFraction = 0.0
    @Published var full = false
    @Published var step = 10
    @Published var want = 1.0

    // Internal state (not drawn).
    private var started = false
    private var startAt = 0
    private var rate = 1.0
    private var lastState = -2
    private var gotState = false
    private var lastSave = Date.distantPast
    private var openedAt = Date()
    private var tick: Timer? = nil
    private var hideWork: DispatchWorkItem? = nil
    private var flashWork: DispatchWorkItem? = nil

    /// Same file name as the Android SharedPreferences ("nexora_video").
    private let sp: UserDefaults = UserDefaults(suiteName: "nexora_video") ?? UserDefaults.standard

    init(yt: String) {
        // Same filter as Android: only letters, digits, "_" and "-" reach the page.
        vid = String(yt.unicodeScalars.filter { PlayerModel.idChars.contains($0) })

        let saved = sp.integer(forKey: "pos_" + vid)
        startAt = saved > 5 ? saved : 0
        if startAt > 0 {
            resumeAt = startAt
            showResume = true
        }
        let r = (sp.object(forKey: "rate") as? Double) ?? 1.0
        want = rates.contains(where: { abs($0 - r) < 0.01 }) ? r : 1.0
        let s = (sp.object(forKey: "step") as? Int) ?? 10
        step = steps.contains(s) ? s : 10
    }

    var rateIndex: Int {
        rates.firstIndex(where: { abs($0 - want) < 0.01 }) ?? 2
    }

    // MARK: lifecycle

    func start(land: Bool) {
        if started { return }
        started = true
        UIApplication.shared.isIdleTimerDisabled = true
        // Without this the lesson is silent when the phone's ring/silent switch is on.
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .moviePlayback)
        try? AVAudioSession.sharedInstance().setActive(true)
        player.load(vid, start: startAt)
        openedAt = Date()
        setFull(land, byUser: false)
        showControls()
        resume()
    }

    /// Android onResume: the polling loop runs.
    func resume() {
        tick?.invalidate()
        let t = Timer(timeInterval: 0.4, repeats: true) { [weak self] _ in self?.poll() }
        RunLoop.main.add(t, forMode: .common)
        tick = t
    }

    /// Android onPause: remember the position, pause, stop polling.
    func pause() {
        savePos()
        player.js("nx.pause()")
        tick?.invalidate()
        tick = nil
        hideWork?.cancel()
        flashWork?.cancel()
    }

    func stop() {
        pause()
        player.blank()
        UIApplication.shared.isIdleTimerDisabled = false
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        Sfx.shared.restoreSession()
        if full { PlayerModel.rotate(.portrait) }
    }

    // MARK: polling

    private func poll() {
        player.poll { [weak self] r in
            guard let s = self else { return }
            let p = r.split(separator: ",", omittingEmptySubsequences: false).map { String($0) }
            if p.count < 4 {
                if !s.gotState && Date().timeIntervalSince(s.openedAt) > 12 { s.showError() }
                return
            }
            let c = Double(p[0]) ?? 0
            let d = Double(p[1]) ?? 0
            s.cur = c.isFinite ? c : 0
            s.dur = d.isFinite ? d : 0
            s.state = Int(p[2]) ?? -2
            let rr = Double(p[3]) ?? 1
            s.rate = rr.isFinite ? rr : 1
            s.gotState = true
            s.render()
        }
    }

    private func render() {
        if state <= -100 {
            showError()
            return
        }
        error = false
        let playing = state == 1
        loading = (state == 3 || state == -1)
        if playing && abs(rate - want) > 0.01 { player.js("nx.rate(\(want))") }
        if state != lastState {
            if state == 0 {
                sp.removeObject(forKey: "pos_" + vid)
                controls = true
            } else if state == 1 && controls {
                showControls()
            }
            lastState = state
        }
        if playing && cur > 5 && Date().timeIntervalSince(lastSave) > 5 {
            lastSave = Date()
            savePos()
        }
    }

    private func showError() {
        loading = false
        error = true
    }

    func retry() {
        error = false
        loading = true
        gotState = false
        state = -2
        openedAt = Date()
        let from = cur > 5 ? Int(cur) : startAt
        player.load(vid, start: from)
    }

    // MARK: position

    private func savePos() {
        if vid.isEmpty { return }
        let nearEnd = dur > 0 && cur > dur - 10
        if cur > 5 && state != 0 && !nearEnd {
            sp.set(Int(cur), forKey: "pos_" + vid)
        } else if nearEnd || state == 0 {
            sp.removeObject(forKey: "pos_" + vid)
        }
    }

    // MARK: controls

    func showControls() {
        controls = true
        hideWork?.cancel()
        if state == 1 {
            let w = DispatchWorkItem { [weak self] in
                guard let s = self else { return }
                if s.state == 1 && !s.dragging { s.controls = false }
            }
            hideWork = w
            DispatchQueue.main.asyncAfter(deadline: .now() + 3, execute: w)
        }
    }

    func toggleControls() {
        if controls { controls = false } else { showControls() }
    }

    func playPause() {
        Sfx.shared.play(state == 1 ? .pause : .play)
        switch state {
        case 1: player.js("nx.pause()")
        case 0: player.js("nx.seek(0);nx.play()")
        default: player.js("nx.play()")
        }
        showControls()
    }

    func skip(_ d: Double) {
        let mx = dur > 0 ? dur : Double.greatestFiniteMagnitude
        let t = min(max(cur + d, 0), mx)
        cur = t
        Sfx.shared.play(.skip)
        player.js("nx.seek(\(t))")
        flash = d < 0 ? "-\(step)" : "+\(step)"
        flashWork?.cancel()
        let w = DispatchWorkItem { [weak self] in self?.flash = nil }
        flashWork = w
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6, execute: w)
        showControls()
    }

    // Seek bar (Android OnSeekBarChangeListener).
    func seekBegan() {
        dragging = true
        hideWork?.cancel()
    }

    func seekMoved(_ f: Double) {
        dragFraction = f
    }

    func seekEnded(_ f: Double) {
        dragging = false
        if dur > 0 {
            let t = dur * f
            cur = t
            player.js("nx.seek(\(t))")
        }
        showControls()
    }

    // MARK: settings

    func openSettings() {
        hideWork?.cancel()
        settings = true
    }

    func closeSettings() {
        settings = false
        showControls()
    }

    func setRate(_ i: Int) {
        want = rates[i]
        sp.set(want, forKey: "rate")
        player.js("nx.rate(\(want))")
    }

    func setStep(_ v: Int) {
        step = v
        sp.set(v, forKey: "step")
    }

    func restart() {
        player.js("nx.seek(0);nx.play()")
        sp.removeObject(forKey: "pos_" + vid)
        showResume = false
        closeSettings()
    }

    // MARK: full screen

    func setFull(_ on: Bool, byUser: Bool) {
        if byUser { Sfx.shared.play(.tab) }
        full = on
        if byUser { PlayerModel.rotate(on ? .landscape : .portrait) }
    }

    static func rotate(_ mask: UIInterfaceOrientationMask) {
        guard let scene = UIApplication.shared.connectedScenes.compactMap({ $0 as? UIWindowScene }).first else { return }
        scene.windows.first?.rootViewController?.setNeedsUpdateOfSupportedInterfaceOrientations()
        scene.requestGeometryUpdate(.iOS(interfaceOrientations: mask)) { _ in }
    }

    /// Android `fmt`: m:ss or h:mm:ss with Western digits.
    static func fmt(_ t: Double) -> String {
        let s = (t.isNaN || t < 0 || !t.isFinite) ? 0 : Int(t)
        let hh = s / 3600
        let mm = (s % 3600) / 60
        let ss = s % 60
        if hh > 0 { return String(format: "%d:%02d:%02d", hh, mm, ss) }
        return String(format: "%d:%02d", mm, ss)
    }
}

// MARK: - Seek bar (player_progress + seek_thumb)

private struct PlayerSeek: View {
    @Environment(\.theme) private var th
    let fraction: Double
    let onBegin: () -> Void
    let onMove: (Double) -> Void
    let onEnd: (Double) -> Void
    @State private var began = false

    var body: some View {
        GeometryReader { g in
            let w = max(g.size.width - 24, 1)
            let x = CGFloat(min(max(fraction, 0), 1)) * w
            ZStack(alignment: .leading) {
                Capsule().fill(Color.white.opacity(0.35)).frame(height: 4)
                Capsule().fill(th.gradient).frame(height: 4)
                    .mask(alignment: .leading) { Rectangle().frame(width: x) }
                Circle().fill(Color.white).frame(width: 14, height: 14).offset(x: x - 7)
            }
            .padding(.horizontal, 12)
            .frame(width: g.size.width, height: g.size.height)
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { v in
                        if !began {
                            began = true
                            onBegin()
                        }
                        onMove(Double(min(max((v.location.x - 12) / w, 0), 1)))
                    }
                    .onEnded { v in
                        began = false
                        onEnd(Double(min(max((v.location.x - 12) / w, 0), 1)))
                    }
            )
        }
        .frame(height: 32)
    }
}

// MARK: - Screen

struct VideoPlayerView: View {
    @EnvironmentObject private var prefs: Prefs
    @Environment(\.theme) private var th
    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var phase
    @StateObject private var m: PlayerModel
    let title: String

    init(item: VideoItem) {
        _m = StateObject(wrappedValue: PlayerModel(yt: item.yt))
        title = item.title
    }

    var body: some View {
        GeometryReader { geo in
            let land = geo.size.width > geo.size.height
            let portraitH = min(geo.size.width, geo.size.height) * 9 / 16
            let fs = m.full ? geo.size : CGSize(width: geo.size.width, height: portraitH)
            ZStack {
                if m.full { Color.black } else { AppBackground() }
                VStack(spacing: 0) {
                    if !m.full { header }
                    frameView(fs)
                        .frame(width: fs.width, height: fs.height)
                    if !m.full { panel }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
            }
            .frame(width: geo.size.width, height: geo.size.height)
            .onAppear { m.start(land: land) }
            .onChange(of: land) { v in
                // Rotating the phone switches full screen on / off (Android onConfigurationChanged).
                if v != m.full { m.setFull(v, byUser: false) }
            }
        }
        .ignoresSafeArea(.all, edges: m.full ? Edge.Set.all : Edge.Set())
        .statusBarHidden(m.full)
        .persistentSystemOverlays(m.full ? Visibility.hidden : Visibility.automatic)
        .onDisappear { m.stop() }
        .onChange(of: phase) { p in
            if p == .active { m.resume() } else { m.pause() }
        }
    }

    // MARK: header + panel (portrait only)

    private var header: some View {
        HStack(spacing: 0) {
            Button { dismiss() } label: {
                Icon("chev", size: 24, color: th.tx)
                    .frame(width: 44, height: 44)
                    .chipBox()
            }
            .buttonStyle(.plain).sfxTap()
            .accessibilityLabel(prefs.t("back"))
            Text(title)
                .font(.system(size: 16, weight: .bold))
                .foregroundColor(th.tx)
                .lineLimit(2)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.leading, 12)
        }
        .padding(12)
    }

    private var panel: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 0) {
                if m.showResume {
                    Text(prefs.tf("resume_info", PlayerModel.fmt(Double(m.resumeAt)) as NSString))
                        .font(.system(size: 13))
                        .foregroundColor(th.mut)
                }
                Text(prefs.t("player_hint"))
                    .font(.system(size: 12))
                    .foregroundColor(th.mut)
                    .padding(.top, 14)
            }
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    // MARK: the video frame (vFrame): video, touch layer, loading, flash, error, controls, settings

    private func frameView(_ fs: CGSize) -> some View {
        ZStack {
            Color.black
            WebHost(web: m.player.web)
            touchLayer
            if m.loading && !m.error {
                ProgressView()
                    .progressViewStyle(.circular)
                    .tint(th.p1)
                    .scaleEffect(1.6)
                    .allowsHitTesting(false)
            }
            if let f = m.flash {
                Text(f)
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(Color.white)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                    .background(RoundedRectangle(cornerRadius: 10, style: .continuous).fill(Color.black.opacity(0.5)))
                    .allowsHitTesting(false)
            }
            if m.error {
                Text(prefs.t("player_error"))
                    .font(.system(size: 14))
                    .foregroundColor(Color.white)
                    .multilineTextAlignment(.center)
                    .padding(24)
                    .frame(maxWidth: .infinity)
                    .contentShape(Rectangle())
                    .onTapGesture { m.retry() }
            }
            if m.controls { controlsLayer }
            if m.settings { settingsLayer(fs) }
        }
        // The video and its controls always run left to right (play / seek bar), like the Android frame.
        .environment(\.layoutDirection, .leftToRight)
        .clipped()
    }

    /// vTouch: one tap shows / hides the controls, a double tap on the left / right half skips back / forward.
    private var touchLayer: some View {
        GeometryReader { g in
            Color.clear
                .contentShape(Rectangle())
                .gesture(
                    SpatialTapGesture(count: 2)
                        .onEnded { v in
                            let d = Double(m.step)
                            if v.location.x < g.size.width / 2 { m.skip(-d) } else { m.skip(d) }
                        }
                        .exclusively(before: SpatialTapGesture(count: 1).onEnded { _ in m.toggleControls() })
                )
        }
    }

    // MARK: controls (vControls)

    private var controlsLayer: some View {
        ZStack {
            LinearGradient(colors: [Color.black.opacity(0.4), Color.black.opacity(0.2), Color.black.opacity(0.8)],
                           startPoint: .top, endPoint: .bottom)
                .allowsHitTesting(false)

            // Gear (top left) and the speed badge (top right).
            Button { m.openSettings() } label: {
                Icon("gear", size: 24, color: Color.white)
                    .frame(width: 40, height: 40)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain).sfxTap()
            .accessibilityLabel(prefs.t("settings_title"))
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
            .padding(4)

            Text(m.rateLabels[m.rateIndex])
                .font(.system(size: 12, weight: .bold))
                .foregroundColor(Color.white)
                .padding(.horizontal, 10)
                .padding(.vertical, 4)
                .background(RoundedRectangle(cornerRadius: 10, style: .continuous).fill(Color.black.opacity(0.5)))
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing)
                .padding(10)
                .allowsHitTesting(false)

            // Back / play / forward.
            HStack(spacing: 0) {
                roundButton(48) {
                    Text("-\(m.step)").font(.system(size: 14, weight: .bold)).foregroundColor(Color.white)
                } action: { m.skip(-Double(m.step)) }
                    .accessibilityLabel(prefs.t("rewind_10"))
                roundButton(68) {
                    Icon(m.state == 1 ? "p_pause" : "p_play", size: 32, color: Color.white)
                } action: { m.playPause() }
                    .padding(.horizontal, 22)
                    .accessibilityLabel(prefs.t("play_pause"))
                roundButton(48) {
                    Text("+\(m.step)").font(.system(size: 14, weight: .bold)).foregroundColor(Color.white)
                } action: { m.skip(Double(m.step)) }
                    .accessibilityLabel(prefs.t("forward_10"))
            }

            // Time, seek bar, total, full screen.
            VStack {
                Spacer(minLength: 0)
                HStack(spacing: 0) {
                    Text(PlayerModel.fmt(m.dragging ? m.dur * m.dragFraction : m.cur))
                        .font(.system(size: 12))
                        .foregroundColor(Color.white)
                    PlayerSeek(
                        fraction: m.dragging ? m.dragFraction : (m.dur > 0 ? m.cur / m.dur : 0),
                        onBegin: { m.seekBegan() },
                        onMove: { m.seekMoved($0) },
                        onEnd: { m.seekEnded($0) }
                    )
                    Text(PlayerModel.fmt(m.dur))
                        .font(.system(size: 12))
                        .foregroundColor(Color.white)
                    Button { m.setFull(!m.full, byUser: true) } label: {
                        Icon(m.full ? "p_full_exit" : "p_full", size: 24, color: Color.white)
                            .frame(width: 40, height: 40)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain).sfxTap()
                    .accessibilityLabel(prefs.t("fullscreen"))
                }
                .padding(.leading, 10)
                .padding(.trailing, 6)
                .padding(.bottom, 4)
            }
        }
    }

    /// player_btn: dark circle with a thin light border.
    private func roundButton<C: View>(_ size: CGFloat, @ViewBuilder label: () -> C, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            label()
                .frame(width: size, height: size)
                .background(Circle().fill(Color.black.opacity(0.4)))
                .overlay(Circle().stroke(Color.white.opacity(0.2), lineWidth: 1))
                .contentShape(Circle())
        }
        .buttonStyle(.plain).sfxTap()
    }

    // MARK: settings panel (vSettings): speed, skip length, restart

    private func settingsLayer(_ fs: CGSize) -> some View {
        ZStack {
            Color.black.opacity(0.6)
                .contentShape(Rectangle())
                .onTapGesture { m.closeSettings() }
            WrapScroll(maxHeight: max(fs.height - 16, 120)) { settingsBody }
                .frame(width: 300)
                .background(RoundedRectangle(cornerRadius: 18, style: .continuous).fill(Color(hex: 0x0B1224, opacity: 0.8)))
                .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(Color.white.opacity(0.25), lineWidth: 1))
                .contentShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                .onTapGesture { }
                .padding(.vertical, 8)
        }
        .environment(\.layoutDirection, .rightToLeft)
    }

    private var settingsBody: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(spacing: 0) {
                Text(prefs.t("settings_title"))
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(Color.white)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Button { m.closeSettings() } label: {
                    Text("✕")
                        .font(.system(size: 18))
                        .foregroundColor(Color.white)
                        .frame(width: 36, height: 36)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain).sfxTap()
            }
            Text(prefs.t("speed_title"))
                .font(.system(size: 12))
                .foregroundColor(Color(hex: 0xB8C4E0))
                .padding(.top, 10)
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(m.rates.indices, id: \.self) { i in
                        pchip(m.rateLabels[i], on: i == m.rateIndex) { m.setRate(i) }
                    }
                }
            }
            .padding(.top, 6)
            Text(prefs.t("skip_step"))
                .font(.system(size: 12))
                .foregroundColor(Color(hex: 0xB8C4E0))
                .padding(.top, 12)
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(m.steps, id: \.self) { v in
                        pchip(prefs.tf("sec_fmt", v), on: v == m.step) { m.setStep(v) }
                    }
                }
            }
            .padding(.top, 6)
            Button { m.restart() } label: {
                Text(prefs.t("restart"))
                    .font(.system(size: 13, weight: .bold))
                    .foregroundColor(Color.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 40)
                    .background(RoundedRectangle(cornerRadius: 10, style: .continuous).fill(Color.white.opacity(0.12)))
                    .overlay(RoundedRectangle(cornerRadius: 10, style: .continuous).stroke(Color.white.opacity(0.2), lineWidth: 1))
            }
            .buttonStyle(.plain).sfxTap()
            .padding(.top, 14)
        }
        .padding(14)
    }

    /// pchip_bg: gradient when selected, light glass otherwise.
    private func pchip(_ s: String, on: Bool, _ tap: @escaping () -> Void) -> some View {
        Button(action: tap) {
            Text(s)
                .font(.system(size: 13, weight: .bold))
                .foregroundColor(Color.white)
                .padding(.horizontal, 14)
                .frame(height: 34)
                .background(
                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                        .fill(on ? AnyShapeStyle(th.gradient) : AnyShapeStyle(Color.white.opacity(0.12)))
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                        .stroke(on ? Color.clear : Color.white.opacity(0.2), lineWidth: 1)
                )
        }
        .buttonStyle(.plain).sfxTap()
    }
}


/// Player for a video file uploaded to the platform (release 35). SKELETON: plain AVKit player + a close button.
/// TODO: the same custom controls as `VideoPlayerView` (skip 5/10/15/30 s, speed 0.5x-2x, resume position, full screen, error + retry).
/// TODO(server): stream from the server URL (HTTPS, protected) instead of the local file.
struct UploadPlayerView: View {
    @Environment(\.presentationMode) private var presentation
    let item: VideoItem
    let file: URL

    var body: some View {
        ZStack(alignment: .topLeading) {
            Color.black.ignoresSafeArea()
            VideoPlayer(player: AVPlayer(url: file)).ignoresSafeArea()
            Button { presentation.wrappedValue.dismiss() } label: {
                Image(systemName: "xmark.circle.fill").font(.system(size: 30)).foregroundColor(.white.opacity(0.85)).padding(16)
            }
        }
    }
}
