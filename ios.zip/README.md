## Visual identity (release 25)

Android 1.8.0 is the visual reference. iPhone glass cards, chips and compact glass rows use the same light/dark glass opacity stops, border alpha values and top sheen as Android. The existing SwiftUI layouts remain adapted to the iPhone screen.

# NEXORA EDU (iPhone, native SwiftUI)

Native iOS app (SwiftUI, iOS 16+). The Xcode project is a normal `NexoraEdu.xcodeproj` (no XcodeGen, no WebView).
It follows the Android app screen by screen: same data, same Arabic/English texts, same colors, whole app right-to-left.

## Folder map
- `NexoraEdu.xcodeproj/` - real Xcode project + shared scheme `NexoraEdu`.
- `NexoraEdu/NexoraEduApp.swift` - app entry (language, theme and layout direction are set here).
- `NexoraEdu/Core/` - Models, Store (data), Prefs (language/theme + string lookup), Theme (colors), Components, Util, FlaskMark (logo).
- `NexoraEdu/Screens/` - Splash, Login, Root (routing), `Student/` (part 2), `Teacher/` (part 3), PdfReaderView, VideoPlayerView (part 4).
- `NexoraEdu/Resources/ar.lproj`, `en.lproj` - `Localizable.strings`, generated from the Android strings.xml files (same keys).
- `NexoraEdu/Assets.xcassets` - app icon + launch color.  `NexoraEdu/Info.plist` - app settings.
- `tools/gen_xcodeproj.py` - regenerates the Xcode project after adding/removing files (`--check` only verifies).

## Rebuild status (4 parts)
1. DONE - project files, data layer, theme, Arabic/English, splash, sign in / sign up / teacher sign in.
2. DONE - screen shell (header, bottom tabs, bottom sheets, settings sheet, confirm sheet, toast) + the whole student side:
   home (progress + chapter bars, continue studying, 3 tiles, latest content), courses (videos, collapsible chapters, books, files),
   exams (see "Exams and homework" below), profile, favorites / review later / important (heart + bookmark + "save to" sheet), notes, watch history,
   books screen and the in-app PDF reader (PDFKit, one page at a time with previous / next).
3. DONE - Teacher side (same screens as the Android `TeacherActivity`), built on ShellFrame / ShellUI / Widgets:
   5 tabs (home, students, content, exams (release 14, see below), profile); home = 4 counters (students, classes, chapters, lessons) + the 5 content actions;
   content = the same 5 actions + videos / chapters (with their lessons) / books / files, each with a trash button and the delete confirm sheet
   (`confirm_delete`, `confirm_delete_chapter`); add chapter / lesson (into a chapter, YouTube link optional) / YouTube video /
   book and file (system file picker `fileImporter`, copied to `Documents/docs/<id>.pdf`) with the Android messages;
   tapping a book / file opens the in-app PDF reader, tapping a lesson opens the in-app video player. `WipHomeView` is deleted.
   iPhone teacher student management: student cards include the active switch, access-code generation/copy/regeneration and confirmed deletion; the detail screen shows progress, results and homework submissions.
4. DONE - In-app video player + final polish (`Screens/VideoPlayerView.swift`, port of `VideoActivity.kt` + `activity_video.xml` + `strings_player.xml`):
   YouTube IFrame player in a WKWebView with its own controls hidden, everything else native: play / pause, back / forward buttons (5, 10, 15 or 30 s,
   chosen in the gear panel), double tap on the left / right half of the video, seek bar (drag), playback speed 0.5x - 2x (kept between videos),
   full screen (button, or rotate the phone; the screen turns landscape by itself), resume from the last position (saved every 5 s, cleared near the end),
   "start over", retry on error. Same JS bridge and same polling (0.4 s) as Android; saved in the `nexora_video` UserDefaults suite (`pos_<id>`, `rate`, `step`).
   The student opens it through `openVideo` in `StudentView` (the lesson is added to the watch history first); the teacher through `TeacherView` (no history, like Android).
   Both sides show the PDF reader and the player through one `coverHost` (`PlayerCover` = `.pdf` / `.video`).
   iPhone details: audio session `.playback` (sound even when the silent switch is on), screen stays awake, pauses when the app goes to the background.
   Polish: bottom sheets now rise above the keyboard (the header and tabs stay in place, the sheet height follows the free space, dragging closes the keyboard);
   `fileImporter` in `AddDocSheet` reviewed (keyboard is closed before the picker opens); RTL kept everywhere, only the video frame (play / seek bar) is left-to-right like Android;
   colors come from `Theme` (dark / light), the player overlay is always dark like Android.

## Exams and homework (1.4.0, port of the Windows screens)
Same keys as Android (`questions`, `exams`, `results`, `homework`, `subs`); photos in `Documents/hw/<name>`. Strings: `ex_*` and `hw_*` in both Localizable.strings (same keys as Android `strings_exams.xml`).
- Teacher (`Screens/Teacher/TeacherExams.swift`): Exams tab with chips Exams / Question bank / Homework, add + delete questions (2-4 options, one right answer, optional chapter; `Store.deleteQuestion` also removes it from the exams),
  create exams (practice / official) from the bank, tap an exam for the students' latest results, add + delete homework, tap a homework (route `TeacherRoute.homework`, `HomeworkAnswersScreen`) to read the answers (text + photo) and grade 0-10 with a note (`GradeSheet`).
  Home shows two more counters (exams, answers to grade). `TeacherView` now has a small route stack like the student side.
- Student (`Screens/Student/StudentExams.swift`): `StudentExams` (chips Exams / Homework, official average, last results, homework status), `ExamRunScreen` (route `.exam`: one question at a time, submit with a warning,
  result + review, retake; saved only on submit), `HomeworkScreen` (route `.homework`: note, grade, text answer + one photo with `PhotosPicker`, photo scaled to 1280 px by `Store.scaledPhoto`, written on send by `Store.writeHomeworkPhoto`).
- No timer, questions are not shuffled, no admin screens for exams (same as Windows).
- Written without a Swift toolchain (no build was run): if Actions shows a compile error, send the log line.

## Admin side (part 5)
How to open it (nothing on the normal sign-in screen shows it):
- On the sign-in screen, press and hold the flask logo for 7 full seconds (`onLongPressGesture(minimumDuration: 7)`). Lifting the finger earlier cancels it
  and the next press starts from zero. No hint, progress or haptic while holding; at 7 seconds one light haptic tap, then the admin sign in appears.
- First time (no admin account) the same screen is "Create admin account": email, password (6+ characters), confirm password. After that it is a normal sign in. "Back" returns.
- The account is stored under its own key (`admin` in UserDefaults, SHA-256 password), apart from `teacher`. The session role is `admin`; `RootView` opens `AdminView` for a valid admin session.
- Tabs (`Screens/Admin/`): dashboard (5 counters + the teacher's add actions), teacher (email, change password, delete account; the next teacher sign in creates a new one),
  students (search by name/email, class filter, active switch, code generate/copy/new, delete with confirmation - same logic as `TeacherStudents`, reusing `StudentCodes` and `StudentCodeSheet`),
  content (add actions + class list add/delete + all chapters, lessons, videos, books, files with delete), my account (email, change password with the current one).
- Gold/orange theme: `Theme.admin` (`#D97706` / `#EA580C`), dark and light.
- Reused from the teacher side without changes: `TeacherActions`, `TeacherLessonRow`, `TeacherDocRow`, `TeacherCtx`, `SheetField`. Only routing/shared files were touched: `Models`, `Store`, `Theme`, `RootView`, `LoginView`, strings.
- New strings are the same keys as Android `strings_admin.xml` (plus the existing `stu_*` and `confirm_delete_student`).
- Written without a Swift toolchain (no build was run): if Actions shows a compile error, send the log line.

## Where things are (for the next parts)
- `Core/Shell.swift` - `ShellFrame` (header + scrolling body + bottom tabs), `ShellUI` (bottom sheet `present`, `confirm`, `toast`), `SettingsSheet`.
  Both sides use it: each owns a `@StateObject ShellUI` and a tab index (the student side adds a route stack, see `Screens/Student/StudentView.swift` and `Screens/Teacher/TeacherView.swift`).
  A toast raised inside a sheet is drawn above that sheet.
- `Core/Widgets.swift` - CardBox / CardTexts / ItemRow / TileGrid / StatRow / EmptyState / TopBar / ChipRow / TextArea / ProgressBarView ...
  (same sizes and margins as the Android layouts).
- `Core/SVGPath.swift` + `Core/Icons.swift` - `Icon("home", size: 24, color: ...)` draws the exact Android vector icons.
  `Icons.swift` is generated: `python3 tools/gen_icons.py <android>/app/src/main/res/drawable`.
- `Screens/Student/` - StudentView (navigation + opening content), StudentTabs, StudentScreens, StudentParts (rows, heart/bookmark, save sheet).
- `Screens/Admin/` - AdminView (shell + tabs + opening content), AdminTabs (dashboard, teacher, students, content, account, password sheet, add class).
- `Screens/Teacher/` - TeacherView (shell, tabs, opening a lesson / PDF), TeacherTabs (home, content, profile, rows), TeacherStudents, TeacherSheets (add sheets, `SheetField`, `DocImport`).
- `Screens/PdfReaderView.swift` - in-app PDF reader, used by both sides.
- `Screens/VideoPlayerView.swift` - `VideoItem`, `PlayerCover`, `coverHost` (full screen cover for PDF + video), `PlayerWeb` (WKWebView + JS), `PlayerModel` (state and logic of VideoActivity), `VideoPlayerView` (screen).

## Build note
Parts 3 and 4 were written without a Swift toolchain (no build was run). If Actions shows a compile error, send the log line and it is a one-line fix.
After adding or renaming a file run `python3 tools/gen_xcodeproj.py` (the workflow also runs it with `--check`).
Things to test on a real iPhone: a YouTube video that does not allow embedding (shows the retry message), rotating while a video plays, the keyboard with the add-lesson sheet, picking a PDF from Files / iCloud in the add-book sheet.

## Themes (1.3.0)
Palette icon at the end of the settings sheet title (`ThemesButton`) -> themes sheet (`ThemesSheet`, `Core/Accents.swift`). `nexora` keeps the colours of each side; 11 accent themes (same ids / colours as Android) change `Theme.p1/p2` for every side. Saved as `pref_accent` in `Prefs`; `RootView` passes it to `Theme`. Strings `th_*` in both Localizable.strings; icon `palette` in `Icons.swift` (generated from Android `ic_palette.xml`).

## Profile photo (1.2.1)
Profile tab -> round photo with add / change / remove (`AvatarEditor` in `StudentTabs.swift`, system `PhotosPicker`, no permission needed). The header avatar (`AvatarView` in `Widgets.swift`, used by `ShellFrame`) shows it too.
Saved as a JPEG (max 512 px) in `Documents/avatars/<email, other chars as _>.jpg` (`Store.avatarFile` / `saveAvatar` / `removeAvatar`), deleted with the student. Strings: `add_photo`, `change_photo`, `remove_photo`, `confirm_remove_photo`, `err_photo`.

## Release 19 (1.5.0) - ported from Android release 18, phase 1 (items 1-3)
- Teacher full name: `TeacherAccount.name` (old accounts without it decode as empty; `displayName` falls back to the part of the email before the @). The teacher tab of the sign-in screen now also has the "new here?" link; in that sign-up mode the Full name field is required (`err_name_required`) and a second teacher account is refused (`err_teacher_exists`). First sign-in on a brand new install (creates the account) is unchanged and has no name field, like Android. The header, the teacher profile and the admin "Teacher" card show the name; the admin password change keeps it.
- Student sign-up class: `GradeChips` (in `LoginView.swift`) = 3 fixed chips (1st / 2nd / 3rd secondary) instead of the menu picker. The stored value is still the Arabic class name (`Store.defaultGrades`). Extra classes the teacher adds are not offered at sign-up (the "no classes yet" message is gone).
- Announcements: `Announcement` (`Models.swift`), `Store.announcements` (key `ann`, same short keys as Android). Teacher Content tab: new "Add announcement" tile (`AddAnnouncementSheet`) + a list with delete. Student Home: the latest 3 under the welcome card.
- New strings (ar + en, same keys as Android `strings_v18.xml`): grade_pick_title, grade_1_short, grade_2_short, grade_3_short, err_name_required, err_teacher_exists, ann_title, hint_ann_text, act_announce.
- Not built here: no Swift toolchain, compile with Actions. Not tested on a device: chips with long labels on small iPhones, the teacher sign-up flow.

## Release 20 (1.6.0) - ported from Android release 18, phase 2 (items 4-5)
- Teacher Home = Android dashboard: Overview (active students, not active students, official-exam average of all students `Store.teacherOfficialAverage` or "-", homework waiting for a grade, lessons, exams; `StatTextRow` / `StatBox(text:)` for values like "85%") and Quick access (add lesson, add exam, add homework, activate accounts with the not-active count, manage classes). The old six counters are gone, like Android.
- "Activate accounts" opens the Students tab already on "not active" (`TeacherView.openInactiveStudents` presets `stuStatus = 2`, all classes, empty search).
- Students tab (`TeacherStudents`): search by name, class chips, status chips (all / active / not active), not-active students first. Cards unchanged (switch, code, delete). Student profile page is NOT ported yet.
- Manage classes: sub-screen `TeacherClassesScreen` (route `TeacherRoute.classes`, opened from Home and from a new tile in the Content tab): add (`AddGradeSheet`), delete with confirmation, student count per class, note. The three secondary classes stay fixed at sign-up.
- New strings (ar + en, same keys as Android): sec_overview, sec_quick, stat_active, stat_inactive, act_exam, act_homework, act_activate, act_classes, hint_search_name, classes_note.
- Written without a Swift toolchain (no build was run): if Actions shows a compile error, send the log line.

## Release 21 (1.7.0) - ported from Android (items 6-7)
- Student "Account" tab: the plain email card is replaced by rows that react when tapped (`AccountRows` in `StudentTabs.swift`, Android release 17): name (edit sheet, the header follows), email (copies it), phone (edit sheet, may be empty), class (choose from the classes list), change password (current / new / confirm, 6+ characters, SHA-256). Sheets: `AccountTextSheet`, `AccountGradeSheet`, `AccountPasswordSheet`.
- Teacher student page (Android release 18, `TeacherStudentProfile` in `TeacherStudents.swift`, route `TeacherRoute.student`): tap a student card to open it. Data + phone + active chip + code (tap copies, "New code" asks first, delete asks first), study progress, official average, exams taken, homework sent / graded, every exam result (percent, correct / total, date) and every submission (tap opens that homework's answers; back returns to the student). Search + class + status filters were added in release 20.
- New strings (ar + en, same keys as Android): acc_edit_name, acc_edit_phone, acc_pick_grade, acc_change_pw, acc_email_copied, acc_saved, acc_no_phone, acc_tap_copy, prof_exams_taken, prof_hw_sent, prof_hw_graded, prof_results, prof_no_results, prof_submissions, prof_no_subs, stu_regen_confirm, sec_account.
- Not ported: the sliding "active" switch (the card chip is kept), hiding lessons (item 9).
- Written without a Swift toolchain (no build was run): if Actions shows a compile error, send the log line.

## Release 22 (1.8.0) - ported from Android release 18 phase 2 (items 8-9)
- Teacher Content tab: every chapter, lesson, book and file has a pencil button (the whole row also opens it) with an action sheet (`ActionListSheet`, `SheetAction`): rename (chapters, books, files: `RenameSheet`), move up / down (`Store.moveChapter / moveLesson / moveDoc`; the order of the saved lists is what the students see; lessons move inside their own chapter or among the stand-alone videos, books among books, files among files), delete (with the existing confirmations). Lessons also: preview, edit (`EditLessonSheet`: title, chapter, YouTube link; a stand-alone video must keep a valid link), publish / hide. Books and files: open.
- Hidden lessons: `Lesson.published` (JSON key `p`, default true so old data stays visible). Each lesson row has a switch (accent colour); hidden ones are dimmed and marked "Hidden from students". `Store.publishedLessons` / `publishedLesson(id)` / `setPublished` are used on the whole student side (home, courses, progress, history, saved items) and in `Store.progress`; the teacher and the admin still see everything.
- The admin side keeps its simple delete-only rows (`AdminLessonRow`, `AdminDocRow`), like Android.
- Not done (same as Android): no drag-and-drop (up / down only), books / files cannot be hidden (only lessons).
- New strings (ar + en, same keys as Android): act_rename, act_edit, act_move_up, act_move_down, act_publish, act_hide, act_preview, act_open, lesson_hidden, lesson_published, lesson_video_label, edit_lesson, rename_chapter, rename_doc, btn_save.
- Written without a Swift toolchain (no build was run): if Actions shows a compile error, send the log line.

## Release 23 (1.8.1) - parity with Android, item 1-2 (look only)
- Tab names now match Android: student "Home / Subjects / Tests / Profile" (`tab_subjects`, `tab_tests`), teacher "Home / Students / Content / Tests". The Home tile "Subjects" uses the same key. Old keys `tab_courses` / `tab_exams` are kept in the strings files (unused by tabs).
- Removed the waving-hand emoji from `title_signin` (ar + en), like Android release 16.
- Files: `Screens/Student/{StudentView,StudentTabs}.swift`, `Screens/Teacher/TeacherView.swift`, both `Localizable.strings`, `tools/gen_xcodeproj.py` (1.8.1 / build 12). No new Swift file.
- Not built here (no Swift toolchain): compile with Actions.


## Release 26 (1.8.3)
- Teacher student cards and student details now use a native iOS switch with the same status-row pattern as Android; access-code copy and regeneration actions are separated for clearer interaction.
- Teacher announcements can now be opened and edited on iPhone; changes update the shared `ann` data key without changing the announcement timestamp.
- Reviewed the shared iOS theme/components and the teacher/student/admin screen entry points for consistent role accents, light/dark surfaces, card borders and controls. Platform-specific navigation/layout remains native to iPhone.
- Source syntax parsed with Swift 6.2.1. A full iOS build/signing run still requires Xcode on macOS.

## Release 28 (1.8.4) - phone verification screen, round 1
- New `Screens/OtpView.swift`: `OtpView` (6 boxes over one hidden `.oneTimeCode` field, wrong-code state with shake, verify button dimmed until 6 digits, resend link with a real 60 s countdown) and `.otpSheet(isPresented:phone:verify:onResend:onVerified:onCancel:)`. The caller sets `isPresented = false` in `onVerified`.
- `OtpConfig.PhoneOtpEnabled = false`: the sheet never presents while the flag is false. Not connected to `LoginView` yet (round 2).
- Strings (ar + en): otp_*. `tools/gen_xcodeproj.py` 1.8.4 / build 14, project regenerated (31 Swift files).
- Not built here (no Swift toolchain): compile with Actions.

## Release 29 (1.8.5) - phone rules + glass entry
- `Core/PhoneRules.swift` (`PhoneRules`, `PhoneVerifier`). `LoginView`: student sign-up phone required, message under the field, `.otpSheet` before creating the account (flag `OtpConfig.PhoneOtpEnabled`, false = account created at once). `SplashView.swift`: 3.4 s glass entry + `GlassAurora` (also behind the sign-in card). Not built here.

## Release 31 (1.8.7) - confirm password
- `LoginView`: `needsConfirm` shows the confirm-password field for a new student, a new teacher and the first admin; mismatch -> `err_pw_mismatch`. Not built here.


## Release 35 (1.8.8) - paid content
Video from a YouTube link (title + thumbnail import) or an uploaded file (`Documents/videos/<id>.mp4`); Free / Paid price on videos (`Lesson.price`) and chapters (`Chapter.price`); locked rows + `PaywallSheet`; teacher opens content for a student as cash / free from the student page, every opening kept in `store.glog`. New code lives in existing files (no new Swift file, so the Xcode project did not need regeneration): `Core/Store.swift` (Access, Payments, YtMeta), `TeacherSheets.swift` (VideoSourceFields, PriceFields, LessonSave, CoursePriceSheet), `VideoPlayerView.swift` (UploadPlayerView, skeleton).
Skeletons / TODO: server-side access check, electronic payment (`Payments.start`), server upload, full controls in `UploadPlayerView`, admin side adds free YouTube videos only.

## Sound effects (release 46)
`NexoraEdu/Core/Sfx.swift` + `NexoraEdu/Resources/Sfx/sfx_*.wav` (the same 18 sounds as Android). Ambient audio session: follows the silent switch. Tap sound: `.sfxTap()` on buttons; switches: `Binding.sfx()`; other hooks are one `Sfx.shared.play(...)` line each (list in CHANGELOG release 46).
