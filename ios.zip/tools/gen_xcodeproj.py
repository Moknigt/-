#!/usr/bin/env python3
"""
Regenerates NexoraEdu.xcodeproj (project.pbxproj + shared scheme) from the files inside ./NexoraEdu.

Use it every time you add / remove / rename a file under NexoraEdu/:

    python3 tools/gen_xcodeproj.py            # rewrite the Xcode project
    python3 tools/gen_xcodeproj.py --check    # only verify that the project is consistent

Rules: *.swift -> compiled; Assets.xcassets and any other resource file -> copied into the app;
X.lproj/Y files -> one localized Y (variant group); Info.plist is only referenced (INFOPLIST_FILE).
IDs are derived from the file path, so regenerating produces a stable diff.
"""
import hashlib, os, re, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
APP = 'NexoraEdu'                 # folder with the sources, also the target/product name
BUNDLE_ID = 'com.moknight.nexoraedu'
VERSION = '1.9.20'
BUILD = '40'
DEPLOY = '16.0'
REGIONS = ['en', 'ar', 'Base']
SKIP = {'.DS_Store'}

FILE_TYPES = {
    '.swift': 'sourcecode.swift', '.plist': 'text.plist.xml', '.strings': 'text.plist.strings',
    '.json': 'text.json', '.html': 'text.html', '.png': 'image.png', '.jpg': 'image.jpeg',
    '.jpeg': 'image.jpeg', '.pdf': 'image.pdf', '.ttf': 'file', '.otf': 'file', '.mp3': 'audio.mp3', '.wav': 'audio.wav',
    '.txt': 'text', '.md': 'net.daringfireball.markdown', '.entitlements': 'text.plist.entitlements',
}


def uid(key):
    return hashlib.md5(('nexora:' + key).encode()).hexdigest()[:24].upper()


def q(s):
    s = str(s)
    return s if re.fullmatch(r'[A-Za-z0-9_$./]+', s) else '"' + s.replace('\\', '\\\\').replace('"', '\\"') + '"'


def ftype(name):
    if name.endswith('.xcassets'):
        return 'folder.assetcatalog'
    return FILE_TYPES.get(os.path.splitext(name)[1].lower(), 'file')


class Gen:
    def __init__(self):
        self.build_files = []      # (id, fileRefId, name, phase)
        self.file_refs = []        # raw lines
        self.groups = []           # raw blocks
        self.variants = []
        self.sources = []
        self.resources = []

    def add_ref(self, key, name, path, explicit_name=None):
        rid = uid('ref:' + key)
        extra = f'name = {q(explicit_name)}; ' if explicit_name else ''
        self.file_refs.append(
            f'\t\t{rid} /* {explicit_name or name} */ = {{isa = PBXFileReference; lastKnownFileType = {ftype(name)}; {extra}path = {q(path)}; sourceTree = "<group>"; }};')
        return rid

    def add_build(self, key, ref, label, phase):
        bid = uid('build:' + key)
        self.build_files.append(f'\t\t{bid} /* {label} in {phase} */ = {{isa = PBXBuildFile; fileRef = {ref} /* {label} */; }};')
        (self.sources if phase == 'Sources' else self.resources).append((bid, label))

    def walk(self, rel):
        """Returns the list of (id, comment) children of the folder `rel` (relative to ROOT)."""
        full = os.path.join(ROOT, rel)
        entries = sorted(e for e in os.listdir(full) if e not in SKIP and not e.startswith('.'))
        dirs = [e for e in entries if os.path.isdir(os.path.join(full, e))]
        files = [e for e in entries if os.path.isfile(os.path.join(full, e))]
        children = []

        lprojs = [d for d in dirs if d.endswith('.lproj')]
        for d in [d for d in dirs if not d.endswith('.lproj')]:
            if d.endswith('.xcassets'):
                rid = self.add_ref(f'{rel}/{d}', d, d)
                self.add_build(f'{rel}/{d}', rid, d, 'Resources')
                children.append((rid, d))
            else:
                gid = uid('group:' + f'{rel}/{d}')
                sub = self.walk(f'{rel}/{d}')
                self.groups.append((gid, d, d, sub))
                children.append((gid, d))

        if lprojs:  # localized files: one variant group per file name
            names = sorted({f for l in lprojs for f in os.listdir(os.path.join(full, l)) if f not in SKIP})
            for n in names:
                vid = uid(f'variant:{rel}/{n}')
                kids = []
                for l in sorted(lprojs):
                    if os.path.exists(os.path.join(full, l, n)):
                        lang = l[:-len('.lproj')]
                        kids.append((self.add_ref(f'{rel}/{l}/{n}', n, f'{l}/{n}', explicit_name=lang), lang))
                self.variants.append((vid, n, kids))
                self.add_build(f'{rel}/{n}', vid, n, 'Resources')
                children.append((vid, n))

        for f in files:
            rid = self.add_ref(f'{rel}/{f}', f, f)
            if f.endswith('.swift'):
                self.add_build(f'{rel}/{f}', rid, f, 'Sources')
            elif f != 'Info.plist' and not f.endswith('.entitlements'):
                self.add_build(f'{rel}/{f}', rid, f, 'Resources')
            children.append((rid, f))
        return children


def generate():
    g = Gen()
    top = g.walk(APP)
    app_group = uid('group:' + APP)
    root_group = uid('group:root')
    products = uid('group:products')
    app_ref = uid('ref:product')
    target = uid('target')
    proj = uid('project')
    src_phase, fw_phase, res_phase = uid('phase:src'), uid('phase:fw'), uid('phase:res')
    cl_proj, cl_tgt = uid('cl:project'), uid('cl:target')
    c_pd, c_pr, c_td, c_tr = uid('cfg:pd'), uid('cfg:pr'), uid('cfg:td'), uid('cfg:tr')

    out = ['// !$*UTF8*$!', '{', '\tarchiveVersion = 1;', '\tclasses = {', '\t};', '\tobjectVersion = 56;', '\tobjects = {', '']

    out.append('/* Begin PBXBuildFile section */')
    out += sorted(g.build_files)
    out.append('/* End PBXBuildFile section */\n')

    out.append('/* Begin PBXFileReference section */')
    refs = sorted(g.file_refs)
    refs.append(f'\t\t{app_ref} /* {APP}.app */ = {{isa = PBXFileReference; explicitFileType = wrapper.application; includeInIndex = 0; path = {q(APP + ".app")}; sourceTree = BUILT_PRODUCTS_DIR; }};')
    out += refs
    out.append('/* End PBXFileReference section */\n')

    out.append('/* Begin PBXFrameworksBuildPhase section */')
    out.append(f'\t\t{fw_phase} /* Frameworks */ = {{\n\t\t\tisa = PBXFrameworksBuildPhase;\n\t\t\tbuildActionMask = 2147483647;\n\t\t\tfiles = (\n\t\t\t);\n\t\t\trunOnlyForDeploymentPostprocessing = 0;\n\t\t}};')
    out.append('/* End PBXFrameworksBuildPhase section */\n')

    out.append('/* Begin PBXGroup section */')
    def group_block(gid, name, path, kids):
        body = ''.join(f'\t\t\t\t{i} /* {c} */,\n' for i, c in kids)
        p = f'\t\t\tpath = {q(path)};\n' if path else ''
        return f'\t\t{gid} /* {name} */ = {{\n\t\t\tisa = PBXGroup;\n\t\t\tchildren = (\n{body}\t\t\t);\n{p}\t\t\tsourceTree = "<group>";\n\t\t}};'
    blocks = [group_block(root_group, 'Root', None, [(app_group, APP), (products, 'Products')]).replace('\t\t\tsourceTree', '\t\t\tsourceTree', 1)]
    blocks.append(group_block(app_group, APP, APP, top))
    for gid, name, path, kids in g.groups:
        blocks.append(group_block(gid, name, name, kids))
    blocks.append(group_block(products, 'Products', None, [(app_ref, APP + '.app')]))
    out += blocks
    out.append('/* End PBXGroup section */\n')

    out.append('/* Begin PBXNativeTarget section */')
    out.append(f'''\t\t{target} /* {APP} */ = {{
\t\t\tisa = PBXNativeTarget;
\t\t\tbuildConfigurationList = {cl_tgt} /* Build configuration list for PBXNativeTarget "{APP}" */;
\t\t\tbuildPhases = (
\t\t\t\t{src_phase} /* Sources */,
\t\t\t\t{fw_phase} /* Frameworks */,
\t\t\t\t{res_phase} /* Resources */,
\t\t\t);
\t\t\tbuildRules = (
\t\t\t);
\t\t\tdependencies = (
\t\t\t);
\t\t\tname = {APP};
\t\t\tproductName = {APP};
\t\t\tproductReference = {app_ref} /* {APP}.app */;
\t\t\tproductType = "com.apple.product-type.application";
\t\t}};''')
    out.append('/* End PBXNativeTarget section */\n')

    out.append('/* Begin PBXProject section */')
    regions = ''.join(f'\t\t\t\t{r},\n' for r in REGIONS)
    out.append(f'''\t\t{proj} /* Project object */ = {{
\t\t\tisa = PBXProject;
\t\t\tattributes = {{
\t\t\t\tBuildIndependentTargetsInParallel = 1;
\t\t\t\tLastSwiftUpdateCheck = 1500;
\t\t\t\tLastUpgradeCheck = 1500;
\t\t\t\tTargetAttributes = {{
\t\t\t\t\t{target} = {{
\t\t\t\t\t\tCreatedOnToolsVersion = 15.0;
\t\t\t\t\t}};
\t\t\t\t}};
\t\t\t}};
\t\t\tbuildConfigurationList = {cl_proj} /* Build configuration list for PBXProject "{APP}" */;
\t\t\tcompatibilityVersion = "Xcode 14.0";
\t\t\tdevelopmentRegion = en;
\t\t\thasScannedForEncodings = 0;
\t\t\tknownRegions = (
{regions}\t\t\t);
\t\t\tmainGroup = {root_group};
\t\t\tproductRefGroup = {products} /* Products */;
\t\t\tprojectDirPath = "";
\t\t\tprojectRoot = "";
\t\t\ttargets = (
\t\t\t\t{target} /* {APP} */,
\t\t\t);
\t\t}};''')
    out.append('/* End PBXProject section */\n')

    out.append('/* Begin PBXResourcesBuildPhase section */')
    files = ''.join(f'\t\t\t\t{b} /* {l} in Resources */,\n' for b, l in sorted(g.resources, key=lambda x: x[1]))
    out.append(f'\t\t{res_phase} /* Resources */ = {{\n\t\t\tisa = PBXResourcesBuildPhase;\n\t\t\tbuildActionMask = 2147483647;\n\t\t\tfiles = (\n{files}\t\t\t);\n\t\t\trunOnlyForDeploymentPostprocessing = 0;\n\t\t}};')
    out.append('/* End PBXResourcesBuildPhase section */\n')

    out.append('/* Begin PBXSourcesBuildPhase section */')
    files = ''.join(f'\t\t\t\t{b} /* {l} in Sources */,\n' for b, l in sorted(g.sources, key=lambda x: x[1]))
    out.append(f'\t\t{src_phase} /* Sources */ = {{\n\t\t\tisa = PBXSourcesBuildPhase;\n\t\t\tbuildActionMask = 2147483647;\n\t\t\tfiles = (\n{files}\t\t\t);\n\t\t\trunOnlyForDeploymentPostprocessing = 0;\n\t\t}};')
    out.append('/* End PBXSourcesBuildPhase section */\n')

    out.append('/* Begin PBXVariantGroup section */')
    for vid, name, kids in g.variants:
        body = ''.join(f'\t\t\t\t{i} /* {c} */,\n' for i, c in kids)
        out.append(f'\t\t{vid} /* {name} */ = {{\n\t\t\tisa = PBXVariantGroup;\n\t\t\tchildren = (\n{body}\t\t\t);\n\t\t\tname = {q(name)};\n\t\t\tsourceTree = "<group>";\n\t\t}};')
    out.append('/* End PBXVariantGroup section */\n')

    common = {
        'ALWAYS_SEARCH_USER_PATHS': 'NO', 'CLANG_ENABLE_MODULES': 'YES', 'CLANG_ENABLE_OBJC_ARC': 'YES',
        'COPY_PHASE_STRIP': 'NO', 'ENABLE_STRICT_OBJC_MSGSEND': 'YES', 'GCC_NO_COMMON_BLOCKS': 'YES',
        'IPHONEOS_DEPLOYMENT_TARGET': DEPLOY, 'SDKROOT': 'iphoneos', 'SWIFT_VERSION': '5.0',
    }
    debug = {**common, 'DEBUG_INFORMATION_FORMAT': 'dwarf', 'ENABLE_TESTABILITY': 'YES', 'GCC_OPTIMIZATION_LEVEL': '0',
             'MTL_ENABLE_DEBUG_INFO': 'INCLUDE_SOURCE', 'ONLY_ACTIVE_ARCH': 'YES',
             'SWIFT_ACTIVE_COMPILATION_CONDITIONS': 'DEBUG', 'SWIFT_OPTIMIZATION_LEVEL': '"-Onone"'}
    release = {**common, 'DEBUG_INFORMATION_FORMAT': '"dwarf-with-dsym"', 'ENABLE_NS_ASSERTIONS': 'NO',
               'MTL_ENABLE_DEBUG_INFO': 'NO', 'SWIFT_COMPILATION_MODE': 'wholemodule', 'VALIDATE_PRODUCT': 'YES'}
    tgt = {
        'ASSETCATALOG_COMPILER_APPICON_NAME': 'AppIcon', 'CODE_SIGN_STYLE': 'Automatic',
        'CURRENT_PROJECT_VERSION': BUILD, 'GENERATE_INFOPLIST_FILE': 'NO',
        'INFOPLIST_FILE': f'{APP}/Info.plist',
        'LD_RUNPATH_SEARCH_PATHS': '(\n\t\t\t\t\t"$(inherited)",\n\t\t\t\t\t"@executable_path/Frameworks",\n\t\t\t\t)',
        'MARKETING_VERSION': VERSION, 'PRODUCT_BUNDLE_IDENTIFIER': BUNDLE_ID, 'PRODUCT_NAME': '"$(TARGET_NAME)"',
        'SWIFT_EMIT_LOC_STRINGS': 'YES', 'TARGETED_DEVICE_FAMILY': '"1,2"',
    }

    def cfg(cid, name, settings):
        body = ''.join(f'\t\t\t\t{k} = {v if (v.startswith(chr(34)) or v.startswith("(")) else q(v)};\n' for k, v in sorted(settings.items()))
        return f'\t\t{cid} /* {name} */ = {{\n\t\t\tisa = XCBuildConfiguration;\n\t\t\tbuildSettings = {{\n{body}\t\t\t}};\n\t\t\tname = {name};\n\t\t}};'

    out.append('/* Begin XCBuildConfiguration section */')
    out += [cfg(c_pd, 'Debug', debug), cfg(c_pr, 'Release', release), cfg(c_td, 'Debug', tgt), cfg(c_tr, 'Release', tgt)]
    out.append('/* End XCBuildConfiguration section */\n')

    out.append('/* Begin XCConfigurationList section */')
    for cid, label, d, r in ((cl_proj, f'PBXProject "{APP}"', c_pd, c_pr), (cl_tgt, f'PBXNativeTarget "{APP}"', c_td, c_tr)):
        out.append(f'\t\t{cid} /* Build configuration list for {label} */ = {{\n\t\t\tisa = XCConfigurationList;\n\t\t\tbuildConfigurations = (\n\t\t\t\t{d} /* Debug */,\n\t\t\t\t{r} /* Release */,\n\t\t\t);\n\t\t\tdefaultConfigurationIsVisible = 0;\n\t\t\tdefaultConfigurationName = Release;\n\t\t}};')
    out.append('/* End XCConfigurationList section */')

    out += ['\t};', f'\trootObject = {proj} /* Project object */;', '}', '']

    xp = os.path.join(ROOT, f'{APP}.xcodeproj')
    os.makedirs(os.path.join(xp, 'xcshareddata', 'xcschemes'), exist_ok=True)
    with open(os.path.join(xp, 'project.pbxproj'), 'w', encoding='utf-8') as f:
        f.write('\n'.join(out))

    ref = f'''<BuildableReference
               BuildableIdentifier = "primary"
               BlueprintIdentifier = "{target}"
               BuildableName = "{APP}.app"
               BlueprintName = "{APP}"
               ReferencedContainer = "container:{APP}.xcodeproj">
            </BuildableReference>'''
    scheme = f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme
   LastUpgradeVersion = "1500"
   version = "1.7">
   <BuildAction
      parallelizeBuildables = "YES"
      buildImplicitDependencies = "YES">
      <BuildActionEntries>
         <BuildActionEntry
            buildForTesting = "YES"
            buildForRunning = "YES"
            buildForProfiling = "YES"
            buildForArchiving = "YES"
            buildForAnalyzing = "YES">
            {ref}
         </BuildActionEntry>
      </BuildActionEntries>
   </BuildAction>
   <TestAction
      buildConfiguration = "Debug"
      selectedDebuggerIdentifier = "Xcode.DebuggerFoundation.Debugger.LLDB"
      selectedLauncherIdentifier = "Xcode.DebuggerFoundation.Launcher.LLDB"
      shouldUseLaunchSchemeArgsEnv = "YES">
      <Testables>
      </Testables>
   </TestAction>
   <LaunchAction
      buildConfiguration = "Debug"
      selectedDebuggerIdentifier = "Xcode.DebuggerFoundation.Debugger.LLDB"
      selectedLauncherIdentifier = "Xcode.DebuggerFoundation.Launcher.LLDB"
      launchStyle = "0"
      useCustomWorkingDirectory = "NO"
      ignoresPersistentStateOnLaunch = "NO"
      debugDocumentVersioning = "YES"
      debugServiceExtension = "internal"
      allowLocationSimulation = "YES">
      <BuildableProductRunnable
         runnableDebuggingMode = "0">
         {ref}
      </BuildableProductRunnable>
   </LaunchAction>
   <ProfileAction
      buildConfiguration = "Release"
      shouldUseLaunchSchemeArgsEnv = "YES"
      savedToolIdentifier = ""
      useCustomWorkingDirectory = "NO"
      debugDocumentVersioning = "YES">
      <BuildableProductRunnable
         runnableDebuggingMode = "0">
         {ref}
      </BuildableProductRunnable>
   </ProfileAction>
   <AnalyzeAction
      buildConfiguration = "Debug">
   </AnalyzeAction>
   <ArchiveAction
      buildConfiguration = "Release"
      revealArchiveInOrganizer = "YES">
   </ArchiveAction>
</Scheme>
'''
    with open(os.path.join(xp, 'xcshareddata', 'xcschemes', f'{APP}.xcscheme'), 'w', encoding='utf-8') as f:
        f.write(scheme)
    print(f'wrote {APP}.xcodeproj: {len(g.sources)} source files, {len(g.resources)} resources')


# ------------------------------------------------------------------ checker
def parse_plist(text):
    """Tiny parser for the old-style (OpenStep) plist format used by project.pbxproj."""
    text = re.sub(r'/\*.*?\*/', '', text, flags=re.S)
    pos = 0
    ws = re.compile(r'\s+')
    tok = re.compile(r'"((?:[^"\\]|\\.)*)"|([^\s{}()=;,"]+)')

    def skip():
        nonlocal pos
        m = ws.match(text, pos)
        if m:
            pos = m.end()

    def value():
        nonlocal pos
        skip()
        c = text[pos]
        if c == '{':
            pos += 1
            d = {}
            while True:
                skip()
                if text[pos] == '}':
                    pos += 1
                    return d
                k = value()
                skip()
                assert text[pos] == '=', f'expected = at {pos}'
                pos += 1
                d[k] = value()
                skip()
                assert text[pos] == ';', f'expected ; at {pos}: {text[pos-20:pos+20]!r}'
                pos += 1
        if c == '(':
            pos += 1
            l = []
            while True:
                skip()
                if text[pos] == ')':
                    pos += 1
                    return l
                l.append(value())
                skip()
                if text[pos] == ',':
                    pos += 1
        m = tok.match(text, pos)
        assert m, f'bad token at {pos}: {text[pos:pos+30]!r}'
        pos = m.end()
        return m.group(1) if m.group(1) is not None else m.group(2)

    skip()
    if text.startswith('//', pos):
        pos = text.index('\n', pos)
    return value()


def check():
    path = os.path.join(ROOT, f'{APP}.xcodeproj', 'project.pbxproj')
    data = parse_plist(open(path, encoding='utf-8').read())
    objs = data['objects']
    problems = []

    def ref(i, what):
        if i not in objs:
            problems.append(f'{what}: unknown id {i}')

    ref(data['rootObject'], 'rootObject')
    for oid, o in objs.items():
        isa = o['isa']
        if isa == 'PBXGroup' or isa == 'PBXVariantGroup':
            for c in o['children']:
                ref(c, f'{isa} {oid}')
        elif isa == 'PBXBuildFile':
            ref(o['fileRef'], f'build file {oid}')
        elif isa.endswith('BuildPhase'):
            for f in o['files']:
                ref(f, f'phase {oid}')
        elif isa == 'PBXNativeTarget':
            ref(o['buildConfigurationList'], 'target cfg list')
            for p in o['buildPhases']:
                ref(p, 'target phase')
            ref(o['productReference'], 'product ref')
        elif isa == 'PBXProject':
            ref(o['mainGroup'], 'mainGroup')
            ref(o['buildConfigurationList'], 'project cfg list')
            for t in o['targets']:
                ref(t, 'project target')
        elif isa == 'XCConfigurationList':
            for c in o['buildConfigurations']:
                ref(c, 'cfg list')

    # every file on disk must be in the project, every file ref must exist on disk
    on_disk = set()
    for dp, dn, fn in os.walk(os.path.join(ROOT, APP)):
        dn[:] = [d for d in dn if not d.endswith('.xcassets')]  # catalogs are referenced as a whole
        for f in fn:
            if f not in SKIP:
                on_disk.add(os.path.relpath(os.path.join(dp, f), os.path.join(ROOT, APP)))
    for dp, dn, fn in os.walk(os.path.join(ROOT, APP)):
        for d in dn:
            if d.endswith('.xcassets'):
                on_disk.add(os.path.relpath(os.path.join(dp, d), os.path.join(ROOT, APP)))

    # rebuild the full path of each file reference
    parents = {}
    for oid, o in objs.items():
        if o['isa'] in ('PBXGroup', 'PBXVariantGroup'):
            for c in o['children']:
                parents[c] = oid

    def full_path(i):
        o = objs[i]
        parts = []
        cur = i
        while cur in objs:
            p = objs[cur].get('path')
            if p and objs[cur]['isa'] != 'PBXVariantGroup':
                parts.append(p)
            cur = parents.get(cur)
            if cur is None:
                break
        return '/'.join(reversed(parts))

    referenced = set()
    for oid, o in objs.items():
        if o['isa'] == 'PBXFileReference' and o.get('sourceTree') == '"<group>"' or (o['isa'] == 'PBXFileReference' and o.get('sourceTree') == '<group>'):
            fp = full_path(oid)
            if fp.startswith(APP + '/'):
                fp = fp[len(APP) + 1:]
            referenced.add(fp)
            if not os.path.exists(os.path.join(ROOT, APP, fp)):
                problems.append(f'project references a missing file: {fp}')
    for f in sorted(on_disk - referenced):
        problems.append(f'file on disk is not in the project: {f}')

    sw_disk = {f for f in on_disk if f.endswith('.swift')}
    sources = [o for o in objs.values() if o['isa'] == 'PBXSourcesBuildPhase']
    compiled = set()
    for b in sources[0]['files']:
        compiled.add(full_path(objs[b]['fileRef']).replace(APP + '/', '', 1))
    for f in sorted(sw_disk - compiled):
        problems.append(f'swift file not compiled: {f}')

    if problems:
        print('PROBLEMS:')
        for p in problems:
            print(' -', p)
        sys.exit(1)
    print(f'OK: {len(objs)} objects, {len(sw_disk)} swift files compiled, all references resolve')


if __name__ == '__main__':
    if '--check' in sys.argv:
        check()
    else:
        generate()
        check()
