using System.Windows;
using NexoraEdu.Core;

namespace NexoraEdu;

public partial class App : Application
{
    static ResourceDictionary _theme, _accent;

    /// <summary>Swaps the colour dictionary (generated from the Android colors.xml / values-night).</summary>
    public static void ApplyTheme(bool dark)
    {
        var d = new ResourceDictionary
        {
            Source = new Uri(dark ? "Themes/Colors.Dark.xaml" : "Themes/Colors.Light.xaml", UriKind.Relative)
        };
        var md = Current.Resources.MergedDictionaries;
        if (_theme != null) md.Remove(_theme);
        _theme = d;
        md.Insert(0, d);

        if (_accent != null) md.Remove(_accent);
        _accent = Accents.Overlay(d, Prefs.Accent);   // chosen accent theme (p1 / p2), last = highest priority
        if (_accent != null) md.Add(_accent);
    }

    protected override void OnStartup(StartupEventArgs e)
    {
        Sfx.Start();
        Sfx.Hook();
        ApplyTheme(Prefs.Dark);
        base.OnStartup(e);
    }
}
