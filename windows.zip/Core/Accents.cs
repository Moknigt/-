using System.Windows;
using System.Windows.Media;

namespace NexoraEdu.Core;

/// <summary>Accent themes (same ids and colours as Android Accents.kt; the colours come from the generated th_&lt;id&gt;_1 / _2 brushes).
/// "nexora" keeps the normal colours (p1 / p2 of the colour dictionary).</summary>
public static class Accents
{
    public const string Default = "nexora";

    /// <summary>"student" | "teacher" | "admin": the side on screen. With the default theme the teacher side is purple and the admin side gold (tp1/tp2, ap1/ap2).</summary>
    public static string Role = "student";

    public static readonly string[] Ids = { Default, "ocean", "emerald", "sunset", "rose", "violet", "gold", "crimson", "aurora", "candy", "lime", "slate" };

    public static string Name(string id) => Strings.T("th_" + id);

    /// <summary>The two gradient colours of a theme, read from the current colour dictionary.</summary>
    public static (Color A, Color B) Colors(string id)
    {
        // read from the colour dictionary itself, so the "nexora" disc is not tinted by the accent that is active now
        var a = id == Default ? "p1" : "th_" + id + "_1";
        var b = id == Default ? "p2" : "th_" + id + "_2";
        return (((SolidColorBrush)_colors[a]).Color, ((SolidColorBrush)_colors[b]).Color);
    }

    static ResourceDictionary _colors;

    /// <summary>Overlay with p1 / p2 for the chosen theme (null for the default). Added after the colour dictionary so it wins.</summary>
    public static ResourceDictionary Overlay(ResourceDictionary colors, string id)
    {
        _colors = colors;
        string k1, k2;
        if (id != Default && Ids.Contains(id)) { k1 = "th_" + id + "_1"; k2 = "th_" + id + "_2"; }
        else if (Role == "teacher") { k1 = "tp1"; k2 = "tp2"; }
        else if (Role == "admin") { k1 = "ap1"; k2 = "ap2"; }
        else return null;
        var d = new ResourceDictionary();
        d["p1"] = new SolidColorBrush(((SolidColorBrush)colors[k1]).Color);
        d["p2"] = new SolidColorBrush(((SolidColorBrush)colors[k2]).Color);
        return d;
    }
}
