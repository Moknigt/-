using System.Text.Json;

namespace NexoraEdu.Core;

/// <summary>
/// Release 35: paid-content access. ONE place decides "may this student see this lesson?".
/// NOT DONE YET (needs the server): today the answer comes from the local store, so it only hides the content in the app.
/// TODO(server): ask the server (GET /access?lesson=id) and make the server refuse to hand out the video (YouTube id / file URL)
/// to a student without a grant. Grants must then be written by the server only (teacher: cash / free, payment webhook: online).
/// </summary>
public static class Access
{
    /// <summary>Teacher / admin preview: pass email = null (always allowed).</summary>
    public static bool CanView(string email, Lesson l)
    {
        if (email == null || !Store.IsPaid(l)) return true;
        return Store.Grants().Any(g => g.Email == email && (g.Target == "l:" + l.Id || (l.ChapterId.Length > 0 && g.Target == "c:" + l.ChapterId)));
    }
    public static int ShownPrice(Lesson l) => l.Price > 0 ? l.Price : Store.CoursePrice(l);
}

/// <summary>
/// Electronic payment (skeleton). Not built: needs a payment provider and the server.
/// TODO(payments): pick ONE provider (e-wallet or gateway), then: (1) the server creates an order (target, amount, student) and returns the
/// checkout URL; (2) the app opens it (WebView2 / browser) and waits; (3) the provider calls the SERVER webhook, the server verifies the
/// signature and writes the grant (mode "online"); (4) the app re-asks the server and opens the content automatically.
/// The app must never trust "payment done" from the screen itself.
/// </summary>
public static class Payments
{
    /// <summary>Returns false while no provider is connected (the screen then shows the "soon" message).</summary>
    public static bool Start(string target, int amount, string email, Action onPaid) => false;
}

/// <summary>Imports a YouTube video's title and thumbnail through oEmbed (no API key). Returns null if offline.</summary>
public static class YtMeta
{
    public record Info(string Title, string Thumb);
    static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(6) };

    public static string ThumbUrl(string yt) => $"https://i.ytimg.com/vi/{yt}/hqdefault.jpg";

    public static async Task<Info> FetchAsync(string yt)
    {
        try
        {
            var url = "https://www.youtube.com/oembed?format=json&url=" + Uri.EscapeDataString("https://youtu.be/" + yt);
            using var doc = JsonDocument.Parse(await Http.GetStringAsync(url));
            var r = doc.RootElement;
            return new Info(r.TryGetProperty("title", out var t) ? t.GetString() ?? "" : "",
                            r.TryGetProperty("thumbnail_url", out var th) ? th.GetString() ?? ThumbUrl(yt) : ThumbUrl(yt));
        }
        catch { return null; }
    }
}
