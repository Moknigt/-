using System.Globalization;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace NexoraEdu.Core;

/// <summary>
/// Release 56: admin control on Windows (port of Android AdminControl.kt / iOS AdminControl.swift; server side = server/supabase/004_admin_control.sql).
///  - the FIRST admin is the MAIN admin; an admin removes teachers, only the main admin removes another admin;
///  - the main admin is told each time a teacher or an admin signs up / signs in (while the app is open: Windows has no push);
///  - a removed account is signed out and its local account is wiped the next time the app is opened / shown with internet.
/// The server decides everything. The app only asks and shows. Every call is async and never throws.
/// </summary>
public static class AdminControl
{
    public record Status(string Role, bool Main, bool Removed);
    public record Staff(string Id, string Role, string Name, string Email, bool Main, bool Removed, DateTime At);
    /// <summary>Kind = signup | signin | removed; Role = teacher | admin.</summary>
    public record Event(long Id, string Kind, string Role, string UserId, string Name, string Email, DateTime At);

    static readonly string StateFile = Path.Combine(Store.DataDir, "admin_control.json");
    static JsonObject _o;

    static JsonObject O()
    {
        if (_o != null) return _o;
        try { _o = JsonNode.Parse(File.ReadAllText(StateFile)) as JsonObject; } catch { }
        return _o ??= new JsonObject();
    }

    static void Put(string key, JsonNode v)
    {
        try
        {
            O()[key] = v;
            Directory.CreateDirectory(Store.DataDir);
            File.WriteAllText(StateFile, O().ToJsonString());
        }
        catch { }
    }

    /// <summary>Cached answer of the server: true only for the main admin who is signed in on this PC.</summary>
    public static bool IsMain => (bool?)O()["main"] ?? false;
    static void SetMain(bool v) => Put("main", v);
    static long LastEvent => (long?)O()["last_event"] ?? 0;

    static DateTime ParseAt(string s)
    {
        if (!string.IsNullOrEmpty(s) && DateTimeOffset.TryParse(s, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out var d)) return d.LocalDateTime;
        return DateTime.MinValue;
    }

    static JsonNode Parse(string text) { try { return JsonNode.Parse(text); } catch { return null; } }

    // ------------------------------------------------------------------ server calls

    public static async Task<Status> StatusAsync()
    {
        var r = await Remote.ApiAsync("POST", "/rest/v1/rpc/my_status", new JsonObject());
        if (r.Code != 200) return null;
        var o = Parse(r.Text);
        return o == null ? null : new Status((string)o["role"] ?? "", (bool?)o["main"] ?? false, (bool?)o["removed"] ?? false);
    }

    /// <summary>Release 57: answer of register_admin. Reason = "" | "code" (missing / wrong / used / expired) | "locked" (5 wrong tries, wait an hour).</summary>
    public record AdminReg(bool Ok, bool Main, string Reason);

    /// <summary>Becomes admin on the server. The first admin ever = main admin (no code); every other one needs a one-time code from the main admin
    /// (code, XXXXXX-YYYYYY). Answers null when the server refused / no network.</summary>
    public static async Task<AdminReg> RegisterAdminAsync(string code = "")
    {
        var r = await Remote.ApiAsync("POST", "/rest/v1/rpc/register_admin", new JsonObject { ["p_code"] = code });
        if (r.Code != 200) return null;
        var o = Parse(r.Text);
        if (o == null) return null;
        var reg = new AdminReg((bool?)o["ok"] ?? false, (bool?)o["main"] ?? false, (string)o["reason"] ?? "");
        if (reg.Ok) SetMain(reg.Main);
        return reg;
    }

    /// <summary>Release 57, main admin only: a new one-time activation code (shown once). Null = refused / no network.</summary>
    public static async Task<string> NewCodeAsync()
    {
        var r = await Remote.ApiAsync("POST", "/rest/v1/rpc/new_admin_code", new JsonObject());
        if (r.Code != 200) return null;
        var t = r.Text.Trim().Trim('"');
        return t.Length == 0 ? null : t;
    }

    public static Task LogEntryAsync(string kind) =>
        Remote.ApiAsync("POST", "/rest/v1/rpc/log_entry", new JsonObject { ["p_kind"] = kind });

    public static async Task<List<Staff>> StaffAsync()
    {
        var r = await Remote.ApiAsync("POST", "/rest/v1/rpc/staff_list", new JsonObject());
        if (r.Code != 200) return null;
        try
        {
            var list = new List<Staff>();
            foreach (var n in JsonNode.Parse(r.Text).AsArray())
                list.Add(new Staff(n["id"]?.ToString() ?? "", n["role"]?.ToString() ?? "", n["name"]?.ToString() ?? "", n["email"]?.ToString() ?? "",
                    (bool?)n["main"] ?? false, (bool?)n["removed"] ?? false, ParseAt(n["at"]?.ToString())));
            return list;
        }
        catch { return null; }
    }

    /// <summary>Unread alerts, newest first. The server returns rows only to the main admin (anyone else gets an empty list), so there is no local check.</summary>
    public static async Task<List<Event>> EventsAsync()
    {
        var r = await Remote.ApiAsync("GET", "/rest/v1/security_events?seen=eq.false&kind=neq.removed&order=id.desc&limit=50&select=id,kind,role,user_id,name,email,at", null);
        if (r.Code != 200) return null;
        try
        {
            var list = new List<Event>();
            foreach (var n in JsonNode.Parse(r.Text).AsArray())
                list.Add(new Event((long?)n["id"] ?? 0, n["kind"]?.ToString() ?? "", n["role"]?.ToString() ?? "", n["user_id"]?.ToString() ?? "",
                    n["name"]?.ToString() ?? "", n["email"]?.ToString() ?? "", ParseAt(n["at"]?.ToString())));
            return list;
        }
        catch { return null; }
    }

    /// <summary>false = refused or no network (the server refuses: yourself, the main admin, an admin when you are not the main admin).</summary>
    public static async Task<bool> RemoveAsync(string userId)
    {
        var r = await Remote.ApiAsync("POST", "/rest/v1/rpc/remove_account", new JsonObject { ["p_user"] = userId, ["p_reason"] = "" });
        return r.Code == 200 && r.Text.Trim() == "true";
    }

    /// <summary>Release 58, admin only: removes a STUDENT on the server (rpc remove_student, file 006): the account loses every right at once and the
    /// student's own app signs out the next time it opens with internet. Answer = HTTP code: 200 removed (or not on the server), 0 / -1 = no network,
    /// 401 / 403 = this account is not a real admin on the server (the caller then only deletes the local copy).</summary>
    public static async Task<int> RemoveStudentAsync(string email)
    {
        try
        {
            var r = await Remote.ApiAsync("POST", "/rest/v1/rpc/remove_student", new JsonObject { ["p_email"] = email, ["p_reason"] = "" });
            return r.Code;
        }
        catch { return -1; }
    }

    public static Task MarkSeenAsync() => Remote.ApiAsync("POST", "/rest/v1/rpc/mark_events_seen", new JsonObject());

    /// <summary>Called by <see cref="ServerSync"/> right after a teacher / admin is signed in on the server. kind = "signup" | "signin". Silent.</summary>
    public static async Task EnteredAsync(string role, string kind)
    {
        if (role != "teacher" && role != "admin") return;
        try
        {
            if (role == "admin") await RegisterAdminAsync();   // the first admin ever becomes the main admin here
            await LogEntryAsync(kind);
        }
        catch { }
    }

    // ------------------------------------------------------------------ removed account + alerts

    /// <summary>Raised on the UI thread when the account was removed and the local account is already wiped. MainWindow shows the message and the sign-in screen.</summary>
    public static event Action Removed;
    /// <summary>Raised on the UI thread with the alerts that are newer than the last one shown (main admin only).</summary>
    public static event Action<List<Event>> NewAlerts;

    static bool _checking;
    static DateTime _lastGuard = DateTime.MinValue;
    static System.Windows.Threading.DispatcherTimer _timer;

    /// <summary>Call when the teacher / admin screen opens and each time the window is activated. No internet: nothing happens.</summary>
    public static async void Guard()
    {
        if (_checking || DateTime.UtcNow - _lastGuard < TimeSpan.FromSeconds(15)) return;   // the window can be activated many times a minute
        var s = Store.Session();
        if (s == null) return;
        var role = s.Value.Role;
        if (role != "teacher" && role != "admin" && role != "student") return;   // release 58: a removed student is signed out too
        if (!Remote.Enabled || !ServerSync.Mirrored(s.Value.Email)) return;
        _checking = true; _lastGuard = DateTime.UtcNow;
        try
        {
            var st = await StatusAsync();
            if (st == null) return;
            // the session may have changed (sign-out) while we were waiting
            if (Store.Session()?.Email != s.Value.Email) return;
            if (st.Removed) { Wipe(role, s.Value.Email); return; }
            var isMain = role == "admin" && st.Main;
            SetMain(isMain);
            if (isMain) { StartAlerts(); await PollAsync(); } else StopAlerts();
        }
        catch { }
        finally { _checking = false; }
    }

    static void Wipe(string role, string email)
    {
        Store.ClearSession();
        if (role == "teacher") Store.DeleteTeacher();
        else if (role == "student") Store.DeleteStudent(email);   // release 58
        else Store.DeleteAdmin();
        ServerSync.SignOut();
        Removed?.Invoke();
    }

    /// <summary>Sign-out / removal: stop the alerts and forget the main flag. last_event stays, so an alert already shown is not shown again after the next sign-in.</summary>
    public static void Reset()
    {
        StopAlerts();
        Put("main", false);
    }

    // ------------------------------------------------------------------ alerts (no push on Windows: a timer asks the server while the app is open)

    static void StartAlerts()
    {
        if (_timer != null) return;
        _timer = new System.Windows.Threading.DispatcherTimer { Interval = TimeSpan.FromMinutes(1) };
        _timer.Tick += async (_, _) => { if (IsMain) await PollAsync(); else StopAlerts(); };
        _timer.Start();
    }

    static void StopAlerts()
    {
        _timer?.Stop();
        _timer = null;
    }

    static async Task PollAsync()
    {
        var list = await EventsAsync();
        if (list == null) return;
        var fresh = list.Where(e => e.Id > LastEvent).ToList();
        if (fresh.Count == 0) return;
        Put("last_event", fresh.Max(e => e.Id));
        NewAlerts?.Invoke(fresh);
    }

    /// <summary>"&lt;who&gt; signed in as a teacher" etc.</summary>
    public static string AlertText(Event e)
    {
        var who = string.IsNullOrEmpty(e.Name) ? e.Email : e.Name;
        var key = e.Role == "admin" && e.Kind == "signup" ? "alert_signup_admin"
                : e.Role == "admin" ? "alert_signin_admin"
                : e.Kind == "signup" ? "alert_signup_teacher"
                : "alert_signin_teacher";
        return Strings.T(key, who);
    }
}
