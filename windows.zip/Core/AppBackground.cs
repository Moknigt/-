using System.Windows;
using System.Windows.Media;

namespace NexoraEdu.Core;

/// <summary>The colour of the whole app background: the theme background (dark / light) tinted with the accent the user picked in the settings
/// (p1 / p2 of the current colour dictionary, so the teacher purple and admin gold follow too). Same idea as Android bg_screen + AuroraView.</summary>
public static class AppBackground
{
    static Color C(string key) => ((SolidColorBrush)Application.Current.FindResource(key)).Color;

    static Color Mix(Color a, Color b, double t) => Color.FromRgb(
        (byte)Math.Round(a.R + (b.R - a.R) * t),
        (byte)Math.Round(a.G + (b.G - a.G) * t),
        (byte)Math.Round(a.B + (b.B - a.B) * t));

    public static Brush Make()
    {
        var k = Prefs.Dark ? 0.24 : 0.15;
        var p1 = C("p1");
        var p2 = C("p2");
        var g = new LinearGradientBrush { StartPoint = new Point(0, 0), EndPoint = new Point(1, 1) };
        g.GradientStops.Add(new GradientStop(Mix(C("bg1"), p1, k), 0));
        g.GradientStops.Add(new GradientStop(Mix(C("bg2"), p2, k * 1.25), 0.55));
        g.GradientStops.Add(new GradientStop(Mix(C("bg3"), p1, k * 0.9), 1));
        g.Freeze();
        return g;
    }
}
