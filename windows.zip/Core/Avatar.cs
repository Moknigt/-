using System.Text.RegularExpressions;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace NexoraEdu.Core;

/// <summary>Student profile photo (same idea as Store.avatarFile / savePhoto on Android).
/// File: %APPDATA%\NEXORA EDU\data\avatars\&lt;email with every char outside A-Z a-z 0-9 . _ - replaced by _&gt;.jpg</summary>
public static class Avatar
{
    public static string PathOf(string email) =>
        System.IO.Path.Combine(Store.DataDir, "avatars", Regex.Replace(email ?? "", "[^A-Za-z0-9._-]", "_") + ".jpg");

    public static bool Exists(string email) => System.IO.File.Exists(PathOf(email));

    /// <summary>The photo, or null when there is none. Read fully into memory so the file is never locked.</summary>
    public static BitmapImage Load(string email)
    {
        var p = PathOf(email);
        if (!System.IO.File.Exists(p)) return null;
        try
        {
            var bi = new BitmapImage();
            bi.BeginInit();
            bi.CacheOption = BitmapCacheOption.OnLoad;
            bi.CreateOptions = BitmapCreateOptions.IgnoreImageCache;
            bi.UriSource = new Uri(p);
            bi.EndInit();
            bi.Freeze();
            return bi;
        }
        catch { return null; }
    }

    /// <summary>Saves the picked image as a small JPEG (max 512 px, EXIF rotation applied). The old photo is replaced only when the new one is written.</summary>
    public static bool Save(string email, string source)
    {
        var dst = PathOf(email);
        var tmp = dst + ".tmp";
        try
        {
            BitmapSource src = BitmapDecoder.Create(new Uri(source), BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.OnLoad).Frames[0];

            int orientation = 1;
            try
            {
                if (src is BitmapFrame f && f.Metadata is BitmapMetadata m && m.GetQuery("/app1/ifd/{ushort=274}") is ushort o) orientation = o;
            }
            catch { }
            double angle = orientation switch { 3 => 180, 6 => 90, 8 => 270, _ => 0 };
            if (angle != 0) src = new TransformedBitmap(src, new RotateTransform(angle));

            double k = Math.Min(1.0, 512.0 / Math.Max(src.PixelWidth, src.PixelHeight));
            if (k < 1) src = new TransformedBitmap(src, new ScaleTransform(k, k));
            src = new FormatConvertedBitmap(src, PixelFormats.Bgr24, null, 0);

            var enc = new JpegBitmapEncoder { QualityLevel = 82 };
            enc.Frames.Add(BitmapFrame.Create(src));
            Directory.CreateDirectory(System.IO.Path.GetDirectoryName(tmp));
            using (var fs = System.IO.File.Create(tmp)) enc.Save(fs);
            System.IO.File.Move(tmp, dst, true);
            return true;
        }
        catch
        {
            try { System.IO.File.Delete(tmp); } catch { }
            return false;
        }
    }

    public static void Delete(string email)
    {
        try { System.IO.File.Delete(PathOf(email)); } catch { }
    }
}
