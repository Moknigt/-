namespace NexoraEdu.Core;

public class Student
{
    public string Name = "", Phone = "", Email = "", PwHash = "", Grade = "", Code = "";
    public bool Active = true;
}
public class Chapter { public string Id = "", Title = ""; public int Price; }
/// <summary>Src: "yt" = YouTube link, "up" = video file uploaded to the platform (data\\videos\\&lt;id&gt;.mp4). Price in EGP, 0 = free. Thumb = YouTube thumbnail URL.</summary>
public class Lesson { public string Id = "", ChapterId = "", Title = "", Yt = "", Src = "yt", Thumb = ""; public long At; public bool Published = true; public int Price; }
/// <summary>Access to paid content. Target = "l:&lt;lessonId&gt;" or "c:&lt;chapterId&gt;"; Mode = "online", "cash" (teacher took cash) or "free" (teacher gift).</summary>
public class Grant { public string Target = "", Email = "", Mode = "free", By = ""; public long At; }
public class Announcement { public string Id = "", Title = "", Text = ""; public long At; }
public class Doc { public string Id = "", Title = "", Kind = "book"; public long At; }
public class Note { public string Text = "", Date = ""; }

/// <summary>Multiple-choice question of the teacher's bank. Answer = index of the right option.</summary>
public class Question { public string Id = "", Text = "", Chapter = ""; public List<string> Options = new(); public int Answer; }
public class Exam { public string Id = "", Title = ""; public bool Official; public List<string> Qids = new(); public long At; }
/// <summary>One try of a student in an exam. Score = percent (0-100).</summary>
public class Result { public string ExamId = "", Email = ""; public int Score, Correct, Total; public long At; }
public class Homework { public string Id = "", Title = "", Note = ""; public long At; }
/// <summary>A student's answer to a homework. Photo = file name in data\hw ("" = none). Grade = -1 until graded (out of 10).</summary>
public class Submission { public string HwId = "", Email = "", Text = "", Photo = "", Note = ""; public int Grade = -1; public long At; }
