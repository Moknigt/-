using System.Text;
using System.Text.RegularExpressions;

namespace NexoraEdu.Core;

/// <summary>
/// Phone number rules used by the sign-up screen (student only).
/// Accepted: Egyptian mobile <c>01[0125]xxxxxxxx</c> (also written <c>+20 1xxxxxxxxx</c> / <c>0020 1xxxxxxxxx</c>) or any international
/// number <c>+</c> followed by 8 to 15 digits. Arabic-Indic digits, spaces, dashes, dots and brackets are fine.
/// Same rules, same names on Android (<c>PhoneRules.kt</c>) and iPhone (<c>PhoneRules.swift</c>).
/// </summary>
public static class PhoneRules
{
    static readonly Regex EgLocal = new(@"^01[0125][0-9]{8}$");
    static readonly Regex Intl = new(@"^\+[1-9][0-9]{7,14}$");

    /// <summary>Digits turned to 0-9, separators removed, <c>00</c> to <c>+</c>, Egyptian <c>+20</c> to <c>0</c>.</summary>
    public static string Clean(string raw)
    {
        var sb = new StringBuilder();
        foreach (var ch in (raw ?? "").Trim())
        {
            if (ch >= '٠' && ch <= '٩') sb.Append((char)('0' + (ch - '٠')));
            else if (ch >= '۰' && ch <= '۹') sb.Append((char)('0' + (ch - '۰')));
            else if ((ch >= '0' && ch <= '9') || ch == '+') sb.Append(ch);
            // spaces, - . ( ) and anything else are dropped
        }
        var s = sb.ToString();
        if (s.StartsWith("00")) s = "+" + s.Substring(2);
        if (s.StartsWith("+201") && s.Length == 13) s = "0" + s.Substring(3);
        return s;
    }

    /// <summary>The number to store, or null when it is not valid.</summary>
    public static string Normalize(string raw)
    {
        var s = Clean(raw);
        return EgLocal.IsMatch(s) || Intl.IsMatch(s) ? s : null;
    }

    /// <summary>String key of the message to show under the field, or null when the number is fine.</summary>
    public static string ErrorKey(string raw)
    {
        if (string.IsNullOrWhiteSpace(raw)) return "err_phone_required";
        return Normalize(raw) == null ? "err_phone_invalid" : null;
    }
}

/// <summary>Answers of <see cref="PhoneVerifier"/> (and what <c>OtpView</c> shows for each).</summary>
public enum OtpResult { Ok, Wrong, Net, Expired, Locked, Soon, Limit, Fail, Waiting }

/// <summary>
/// Release 64: the phone check through WhatsApp, the STUDENT writes first (free). <see cref="SendAsync"/> asks the server for a short reference and opens
/// WhatsApp (app or web) with a ready message that contains it; the server (wa-webhook) checks that the SENDER number is the typed number and answers
/// with the 6-digit code in the same chat; <see cref="CheckAsync"/> sends the typed code to the server. The app never sees the right code.
/// See server/supabase/OTP_SETUP.md. After a right code the server gives a one-time token that <c>Remote.SignUpAsync</c> sends with the account.
/// </summary>
public static class PhoneVerifier
{
    static string _tokenPhone = "", _token = "", _waNumber = "", _waRef = "";

    /// <summary>The token earned for exactly this phone, or "".</summary>
    public static string TokenFor(string phone) => !string.IsNullOrEmpty(phone) && phone == _tokenPhone ? _token : "";

    public static void Clear() { _tokenPhone = _token = _waNumber = _waRef = ""; }

    static OtpResult Reason(string r) => r switch
    {
        "wrong" => OtpResult.Wrong,
        "expired" => OtpResult.Expired,
        "locked" => OtpResult.Locked,
        "too_soon" => OtpResult.Soon,
        "limit" => OtpResult.Limit,
        "waiting" => OtpResult.Waiting,
        _ => OtpResult.Fail,
    };

    /// <summary>Opens WhatsApp with the ready message of the LAST <see cref="SendAsync"/> (nothing happens before one succeeded).</summary>
    public static void OpenWhatsApp()
    {
        if (_waNumber.Length == 0 || _waRef.Length == 0) return;
        var url = "https://wa.me/" + _waNumber + "?text=" + Uri.EscapeDataString(Strings.T("otp_wa_message", _waRef));
        try { System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(url) { UseShellExecute = true }); } catch { }
    }

    /// <summary>New request for <paramref name="phone"/>: on Ok WhatsApp is opened at once with the ready message.</summary>
    public static async Task<OtpResult> SendAsync(string phone)
    {
        var r = await Remote.FnAsync("otp-start", new System.Text.Json.Nodes.JsonObject { ["phone"] = phone });
        if (r.Code == -1) return OtpResult.Net;
        if (r.Code == 200 && (bool?)r.Json?["ok"] == true)
        {
            _waRef = (string)r.Json["ref"] ?? ""; _waNumber = (string)r.Json["wa"] ?? "";
            OpenWhatsApp();
            return OtpResult.Ok;
        }
        return Reason((string)r.Json?["error"] ?? "");
    }

    /// <summary>Checks the typed <paramref name="code"/>. Ok also stores the token for <see cref="TokenFor"/>.</summary>
    public static async Task<OtpResult> CheckAsync(string phone, string code)
    {
        var r = await Remote.FnAsync("otp-verify", new System.Text.Json.Nodes.JsonObject { ["phone"] = phone, ["code"] = code });
        if (r.Code == -1) return OtpResult.Net;
        if (r.Code != 200) return OtpResult.Fail;
        if ((bool?)r.Json?["ok"] == true) { _tokenPhone = phone; _token = (string)r.Json["token"] ?? ""; return OtpResult.Ok; }
        return Reason((string)r.Json?["reason"] ?? "");
    }
}
