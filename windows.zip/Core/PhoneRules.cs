using System.Text;
using System.Text.RegularExpressions;

namespace NexoraEdu.Core;

/// <summary>
/// Phone number rules used by the sign-up screen (student only).
/// Accepted: Egyptian mobile <c>01[0125]xxxxxxxx</c> (also written <c>+20 1xxxxxxxxx</c> / <c>0020 1xxxxxxxxx</c>) or any international
/// number <c>+</c> followed by 8 to 15 digits. Arabic-Indic digits, spaces, dashes, dots and brackets are fine.
/// Same rules, same names on Android (<c>PhoneRules.kt</c>) and iPhone (<c>PhoneRules.swift</c>).
/// </summary>
public static class PhoneRules
{
    static readonly Regex EgLocal = new(@"^01[0125][0-9]{8}$");
    static readonly Regex Intl = new(@"^\+[1-9][0-9]{7,14}$");

    /// <summary>Digits turned to 0-9, separators removed, <c>00</c> to <c>+</c>, Egyptian <c>+20</c> to <c>0</c>.</summary>
    public static string Clean(string raw)
    {
        var sb = new StringBuilder();
        foreach (var ch in (raw ?? "").Trim())
        {
            if (ch >= '٠' && ch <= '٩') sb.Append((char)('0' + (ch - '٠')));
            else if (ch >= '۰' && ch <= '۹') sb.Append((char)('0' + (ch - '۰')));
            else if ((ch >= '0' && ch <= '9') || ch == '+') sb.Append(ch);
            // spaces, - . ( ) and anything else are dropped
        }
        var s = sb.ToString();
        if (s.StartsWith("00")) s = "+" + s.Substring(2);
        if (s.StartsWith("+201") && s.Length == 13) s = "0" + s.Substring(3);
        return s;
    }

    /// <summary>The number to store, or null when it is not valid.</summary>
    public static string Normalize(string raw)
    {
        var s = Clean(raw);
        return EgLocal.IsMatch(s) || Intl.IsMatch(s) ? s : null;
    }

    /// <summary>String key of the message to show under the field, or null when the number is fine.</summary>
    public static string ErrorKey(string raw)
    {
        if (string.IsNullOrWhiteSpace(raw)) return "err_phone_required";
        return Normalize(raw) == null ? "err_phone_invalid" : null;
    }
}

/// <summary>
/// Sending and checking the SMS code. There is no server in the app yet, so this is the one place to connect it.
/// Only called while <c>OtpConfig.PhoneOtpEnabled</c> is true; until a real backend is wired <see cref="Check"/> never accepts a code.
/// </summary>
public static class PhoneVerifier
{
    public static void Send(string phone) { /* TODO: call the SMS backend */ }
    public static bool Check(string phone, string code) => false;
}
