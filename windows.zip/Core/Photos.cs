using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace NexoraEdu.Core;

/// <summary>Homework answer photos (same idea as Store.savePhoto on Android: JPEG, max 1280 px, EXIF rotation applied).
/// Files live in %APPDATA%\NEXORA EDU\data\hw\&lt;name&gt;.</summary>
public static class Photos
{
    /// <summary>Saves the picked image as a downscaled JPEG; returns the file name (not the path), or null if it fails.</summary>
    public static string SaveHomework(string source, int max = 1280)
    {
        var name = Store.NewId() + ".jpg";
        var dst = Store.PhotoFile(name);
        var tmp = dst + ".tmp";
        try
        {
            BitmapSource src = BitmapDecoder.Create(new Uri(source), BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.OnLoad).Frames[0];

            int orientation = 1;
            try
            {
                if (src is BitmapFrame f && f.Metadata is BitmapMetadata m && m.GetQuery("/app1/ifd/{ushort=274}") is ushort o) orientation = o;
            }
            catch { }
            double angle = orientation switch { 3 => 180, 6 => 90, 8 => 270, _ => 0 };
            if (angle != 0) src = new TransformedBitmap(src, new RotateTransform(angle));

            double k = Math.Min(1.0, (double)max / Math.Max(src.PixelWidth, src.PixelHeight));
            if (k < 1) src = new TransformedBitmap(src, new ScaleTransform(k, k));
            src = new FormatConvertedBitmap(src, PixelFormats.Bgr24, null, 0);

            var enc = new JpegBitmapEncoder { QualityLevel = 82 };
            enc.Frames.Add(BitmapFrame.Create(src));
            Directory.CreateDirectory(System.IO.Path.GetDirectoryName(tmp)!);
            using (var fs = File.Create(tmp)) enc.Save(fs);
            File.Move(tmp, dst, true);
            return name;
        }
        catch
        {
            try { File.Delete(tmp); } catch { }
            return null;
        }
    }

    /// <summary>The photo, read fully into memory so the file is never locked; null when missing.</summary>
    public static BitmapImage Load(string name)
    {
        var p = Store.PhotoFile(name);
        if (!File.Exists(p)) return null;
        try
        {
            var bi = new BitmapImage();
            bi.BeginInit();
            bi.CacheOption = BitmapCacheOption.OnLoad;
            bi.CreateOptions = BitmapCreateOptions.IgnoreImageCache;
            bi.UriSource = new Uri(p);
            bi.EndInit();
            bi.Freeze();
            return bi;
        }
        catch { return null; }
    }
}
