using System.Text.Json;
using System.Text.Json.Nodes;

namespace NexoraEdu.Core;

/// <summary>Language + theme (port of Prefs.kt). File: %APPDATA%\NEXORA EDU\data\nexora_settings.json. Defaults: Arabic, dark.</summary>
public static class Prefs
{
    static JsonObject _o;
    static string FilePath => Path.Combine(Store.DataDir, "nexora_settings.json");

    static JsonObject O()
    {
        if (_o != null) return _o;
        try { _o = JsonNode.Parse(File.ReadAllText(FilePath)) as JsonObject; } catch { }
        return _o ??= new JsonObject();
    }

    static void Put(string key, bool v)
    {
        O()[key] = v;
        Directory.CreateDirectory(Store.DataDir);
        File.WriteAllText(FilePath, O().ToJsonString());
    }

    public static string Accent
    {
        get => (string)O()["accent"] ?? Accents.Default;
        set { O()["accent"] = value; Directory.CreateDirectory(Store.DataDir); File.WriteAllText(FilePath, O().ToJsonString()); }
    }

    public static bool Ar { get => (bool?)O()["ar"] ?? true; set => Put("ar", value); }
    public static bool Dark { get => (bool?)O()["dark"] ?? true; set => Put("dark", value); }
}
