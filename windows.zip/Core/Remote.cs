using System.IO;
using System.Net.Http;
using System.Diagnostics;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace NexoraEdu.Core;

/// <summary>
/// Release 37, step 1 of 3: talks to Supabase (see server/supabase/001_accounts.sql and SERVER_SPEC.md).
/// NOT wired to any screen yet: today <see cref="Access.CanView"/> still decides locally.
/// Fill the two constants with the values from Supabase -> Project Settings -> API (the anon key is public by design).
/// </summary>
public static class Remote
{
    /// <summary>e.g. https://abcd1234.supabase.co (no trailing slash)</summary>
    public const string BaseUrl = "https://xgwfxzbutkkauxilcpzf.supabase.co";
    public const string AnonKey = "sb_publishable_WTL6TvHBsZblJoqt8Xjbjg_vNZVLD5f";
    public static bool Enabled => BaseUrl.Length > 0 && AnonKey.Length > 0;

    public record AccessResult(bool Allowed, string Reason, int Price);
    /// <summary>Src = "yt" or "up". For "up" the file is at StorageId/StorageKey (step 3).</summary>
    public record Source(string Src, string YtId, string StorageId, string StorageKey);

    static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(8) };
    static readonly string SessionFile = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "NexoraEdu", "remote.json");
    static string _jwt, _rt, _uid;
    static bool _loaded;

    static void Load()
    {
        if (_loaded) return; _loaded = true;
        try { var o = JsonNode.Parse(File.ReadAllText(SessionFile)); _jwt = (string)o["jwt"]; _rt = (string)o["rt"]; _uid = (string)o["uid"]; } catch { }
    }
    static void Save(JsonNode o)
    {
        _jwt = (string)o["access_token"] ?? ""; _rt = (string)o["refresh_token"] ?? ""; _uid = (string)o["user"]?["id"] ?? "";
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(SessionFile));
            File.WriteAllText(SessionFile, new JsonObject { ["jwt"] = _jwt, ["rt"] = _rt, ["uid"] = _uid }.ToJsonString());
        }
        catch { }
    }
    public static bool SignedIn { get { Load(); return !string.IsNullOrEmpty(_jwt); } }
    public static string UserId { get { Load(); return _uid ?? ""; } }
    public static void SignOut() { _jwt = _rt = _uid = null; _loaded = true; try { File.Delete(SessionFile); } catch { } }

    static async Task<(int Code, string Text)> SendAsync(string method, string path, JsonNode body, string token, string prefer = null)
    {
        try
        {
            var req = new HttpRequestMessage(new HttpMethod(method), BaseUrl + path);
            req.Headers.Add("apikey", AnonKey);
            req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", string.IsNullOrEmpty(token) ? AnonKey : token);
            if (prefer != null) req.Headers.Add("Prefer", prefer);
            if (body != null) req.Content = new StringContent(body.ToJsonString(), Encoding.UTF8, "application/json");
            using var res = await Http.SendAsync(req);
            return ((int)res.StatusCode, await res.Content.ReadAsStringAsync());
        }
        catch { return (-1, ""); }
    }

    /// <summary>Release 64: calls an Edge Function without a user token (the phone code is asked BEFORE the account exists). Code -1 = no network.</summary>
    internal static async Task<(int Code, JsonNode Json)> FnAsync(string name, JsonObject body)
    {
        var r = await SendAsync("POST", "/functions/v1/" + name, body, null);
        JsonNode o = null;
        try { o = JsonNode.Parse(r.Text); } catch { }
        return (r.Code, o);
    }

    /// <summary>Signed-in call; tries once to refresh an expired token.</summary>
    internal static async Task<(int Code, string Text)> ApiAsync(string method, string path, JsonNode body, string prefer = null)
    {
        Load();
        var r = await SendAsync(method, path, body, _jwt, prefer);
        if (r.Code == 401 && !string.IsNullOrEmpty(_rt))
        {
            var rf = await SendAsync("POST", "/auth/v1/token?grant_type=refresh_token", new JsonObject { ["refresh_token"] = _rt }, null);
            if (rf.Code == 200) { Save(JsonNode.Parse(rf.Text)); r = await SendAsync(method, path, body, _jwt, prefer); }
        }
        return r;
    }

    /// <summary>Student / teacher sign-in. true = signed in.</summary>
    public static async Task<bool> SignInAsync(string email, string password)
    {
        var r = await SendAsync("POST", "/auth/v1/token?grant_type=password", new JsonObject { ["email"] = email, ["password"] = password }, null);
        if (r.Code != 200) return false;
        Save(JsonNode.Parse(r.Text)); return true;
    }

    /// <summary>New STUDENT account. The role is always "student" on the server. true = created (turn OFF "Confirm email" in Supabase, or students must confirm first).</summary>
    public static async Task<bool> SignUpAsync(string email, string password, string name, string phone, string grade)
    {
        var meta = new JsonObject { ["full_name"] = name, ["phone"] = phone, ["grade"] = grade };
        var tok = PhoneVerifier.TokenFor(phone);
        if (tok.Length > 0) meta["phone_token"] = tok;   // release 64: proof that this phone got the WhatsApp code
        var body = new JsonObject { ["email"] = email, ["password"] = password, ["data"] = meta };
        var r = await SendAsync("POST", "/auth/v1/signup", body, null);
        if (r.Code == 200) { var o = JsonNode.Parse(r.Text); if (o?["access_token"] != null) Save(o); }
        return r.Code == 200;
    }

    /// <summary>Turns the signed-in account into a teacher with a registration code (works once, on any device).</summary>
    public static async Task<bool> ClaimTeacherAsync(string code)
    {
        var r = await ApiAsync("POST", "/rest/v1/rpc/claim_teacher", new JsonObject { ["p_code"] = code });
        return r.Code == 200 && r.Text.Trim() == "true";
    }

    /// <summary>Server decision for one lesson (uuid). Null = network error: show retry, never open.</summary>
    public static async Task<AccessResult> AccessAsync(string lessonId)
    {
        var r = await ApiAsync("POST", "/rest/v1/rpc/access_lesson", new JsonObject { ["p_lesson"] = lessonId });
        if (r.Code != 200) return null;
        var o = JsonNode.Parse(r.Text);
        return new AccessResult((bool?)o["allowed"] ?? false, (string)o["reason"] ?? "", (int?)o["price"] ?? 0);
    }

    /// <summary>The ONLY way the player gets the video source. Null = locked or network error.</summary>
    public static async Task<Source> PlaySourceAsync(string lessonId)
    {
        var r = await ApiAsync("POST", "/rest/v1/rpc/play_source", new JsonObject { ["p_lesson"] = lessonId });
        if (r.Code != 200) return null;
        var o = JsonNode.Parse(r.Text);
        return new Source((string)o["src"] ?? "", (string)o["ytId"] ?? "", (string)o["storageId"], (string)o["storageKey"]);
    }

    /// <summary>Teacher: open for a student (cash / free). student = profile uuid, target = "l:&lt;lesson uuid&gt;" or "c:&lt;chapter uuid&gt;".</summary>
    public static async Task<bool> GrantAsync(string student, string target, string mode)
    {
        var body = new JsonObject { ["p_student"] = student, ["p_type"] = target.StartsWith("c:") ? "chapter" : "lesson", ["p_target"] = target.Substring(2), ["p_mode"] = mode };
        var r = await ApiAsync("POST", "/rest/v1/rpc/teacher_grant", body);
        return r.Code == 200;
    }

    /// <summary>Teacher: close a grant (the log line stays).</summary>
    public static async Task<bool> RevokeAsync(string grantId)
    {
        var r = await ApiAsync("POST", "/rest/v1/rpc/teacher_revoke", new JsonObject { ["p_grant"] = grantId });
        return r.Code == 200 && r.Text.Trim() == "true";
    }

    /// <summary>Teacher: delete a video (the server refuses anyone else; 0 rows = refused).</summary>
    public static async Task<bool> DeleteVideoAsync(string lessonId)
    {
        var r = await ApiAsync("DELETE", "/rest/v1/lessons?id=eq." + lessonId, null, "return=representation");
        if (r.Code < 200 || r.Code > 299) return false;
        try { return JsonNode.Parse(r.Text) is JsonArray a && a.Count > 0; } catch { return false; }
    }

    // ------------------------------------------------------------------ Release 42, step 3 part 3: storages (upload, play link, storage list)
    // The app knows NO R2 key, endpoint, bucket or size cap. The server decides and answers with a reason.

    /// <summary>Why an upload did not finish. Message keys (ar + en): see <see cref="UploadMessageKey"/>.</summary>
    public enum UploadError { Full, Off, TooBig, Failed }
    public static string UploadMessageKey(UploadError e) => e switch
    {
        UploadError.Full => "up_err_full",
        UploadError.Off => "up_err_off",
        UploadError.TooBig => "up_err_big",
        _ => "up_err_fail"
    };

    public record UploadResult(bool Ok, bool Cancelled, UploadError Error, long SizeBytes);
    static UploadResult UpFail(UploadError e) => new(false, false, e, 0);
    static readonly UploadResult UpCancelled = new(false, true, UploadError.Failed, 0);

    static readonly HttpClient PutHttp = new() { Timeout = TimeSpan.FromHours(1) };

    static string ReasonOf(string text)
    {
        try { return (string)JsonNode.Parse(text)?["error"] ?? ""; } catch { return ""; }
    }

    static UploadError UploadErrorOf(string reason) => reason switch
    {
        "full" => UploadError.Full,
        "not_allowed" or "storage_not_configured" => UploadError.Off,
        "bad_size" or "too_large" => UploadError.TooBig,
        _ => UploadError.Failed
    };

    static Task CancelReservationAsync(string id) =>
        ApiAsync("POST", "/functions/v1/upload-complete", new JsonObject { ["reservationId"] = id, ["cancel"] = true });

    /// <summary>The file body of the PUT: the length is fixed to the reserved size and progress is reported while it is written.</summary>
    sealed class FileContent : HttpContent
    {
        readonly string _path; readonly long _size; readonly IProgress<double> _p; readonly CancellationToken _ct;
        public FileContent(string path, long size, IProgress<double> p, CancellationToken ct) { _path = path; _size = size; _p = p; _ct = ct; }
        protected override async Task SerializeToStreamAsync(Stream stream, System.Net.TransportContext context)
        {
            using var f = File.OpenRead(_path);
            var buf = new byte[64 * 1024];
            long sent = 0; int n;
            while ((n = await f.ReadAsync(buf, 0, buf.Length, _ct)) > 0)
            {
                await stream.WriteAsync(buf, 0, n, _ct);
                sent += n;
                _p?.Report((double)sent / _size);
            }
        }
        protected override bool TryComputeLength(out long length) { length = _size; return true; }
    }

    /// <summary>upload-url (the server reserves the exact size) -> PUT the file -> upload-complete (the server checks the real size).
    /// Cancel with the token: the reserved space is given back. progress = 0..1.</summary>
    public static async Task<UploadResult> UploadVideoAsync(string lessonId, string filePath, IProgress<double> progress = null, CancellationToken ct = default)
    {
        try
        {
            var size = new FileInfo(filePath).Length;
            if (size <= 0) return UpFail(UploadError.Failed);
            var body = new JsonObject { ["lessonId"] = lessonId, ["sizeBytes"] = size };
            var ext = Path.GetExtension(filePath).TrimStart('.').ToLowerInvariant();
            if (ext.Length > 0) body["ext"] = ext;
            var r = await ApiAsync("POST", "/functions/v1/upload-url", body);
            if (r.Code != 200) return UpFail(UploadErrorOf(ReasonOf(r.Text)));
            var o = JsonNode.Parse(r.Text);
            var rid = (string)o?["reservationId"]; var link = (string)o?["uploadUrl"];
            if (string.IsNullOrEmpty(rid) || string.IsNullOrEmpty(link)) return UpFail(UploadError.Failed);
            if (ct.IsCancellationRequested) { await CancelReservationAsync(rid); return UpCancelled; }

            bool ok;
            try
            {
                using var req = new HttpRequestMessage(HttpMethod.Put, link) { Content = new FileContent(filePath, size, progress, ct) };
                using var res = await PutHttp.SendAsync(req, ct);
                ok = res.IsSuccessStatusCode;
            }
            catch (OperationCanceledException) { await CancelReservationAsync(rid); return UpCancelled; }
            catch { ok = false; }
            if (ct.IsCancellationRequested) { await CancelReservationAsync(rid); return UpCancelled; }
            if (!ok) { await CancelReservationAsync(rid); return UpFail(UploadError.Failed); }

            for (var tries = 3; ; tries--)   // the file is already in the bucket: a network problem or 502 is retried
            {
                var q = await ApiAsync("POST", "/functions/v1/upload-complete", new JsonObject { ["reservationId"] = rid });
                if (q.Code == 200)
                {
                    try { var j = JsonNode.Parse(q.Text); if ((bool?)j?["ok"] == true) return new UploadResult(true, false, UploadError.Failed, (long?)j["sizeBytes"] ?? 0); }
                    catch { }
                }
                if ((q.Code == -1 || q.Code == 502) && tries > 1) { await Task.Delay(2000); continue; }
                return UpFail(UploadErrorOf(ReasonOf(q.Text)));
            }
        }
        catch { return UpFail(UploadError.Failed); }
    }

    // ---- play link

    public record PlayLink(string Src, string Url, string YtId, int ExpiresIn);
    public enum PlayProblem { None, Locked, NoFile, Failed }
    /// <summary>Link is set when Problem is None.</summary>
    public record PlayResult(PlayLink Link, PlayProblem Problem);
    public static string PlayMessageKey(PlayProblem p) => p switch
    {
        PlayProblem.Locked => "pl_err_locked",
        PlayProblem.NoFile => "pl_err_nofile",
        PlayProblem.Failed => "pl_err_fail",
        _ => null
    };

    /// <summary>The ONLY way to get a playable address: "up" gives a temporary link (about 3 h, ask again when it ends), "yt" gives the YouTube id.</summary>
    public static async Task<PlayResult> PlayUrlAsync(string lessonId)
    {
        var r = await ApiAsync("POST", "/functions/v1/play-url", new JsonObject { ["lessonId"] = lessonId });
        switch (r.Code)
        {
            case 200:
                try
                {
                    var o = JsonNode.Parse(r.Text);
                    return new PlayResult(new PlayLink((string)o["src"] ?? "", (string)o["url"] ?? "", (string)o["ytId"] ?? "", (int?)o["expiresIn"] ?? 0), PlayProblem.None);
                }
                catch { return new PlayResult(null, PlayProblem.Failed); }
            case 403: return new PlayResult(null, PlayProblem.Locked);
            case 404: return new PlayResult(null, PlayProblem.NoFile);
            default: return new PlayResult(null, PlayProblem.Failed);
        }
    }

    // ---- storage list (read only; the admin edits name / limit / on-off / order)

    public record StorageInfo(string Id, string Name, long LimitBytes, long UsedBytes, long ReservedBytes, bool Active, int SortOrder)
    {
        /// <summary>(used + reserved) / limit, 0..1 for the bar.</summary>
        public double Fraction => LimitBytes > 0 ? Math.Min(1.0, (double)(UsedBytes + ReservedBytes) / LimitBytes) : 0;
    }

    /// <summary>Null = network error / not allowed. Teacher and admin only (the server decides).</summary>
    public static async Task<List<StorageInfo>> StoragesAsync()
    {
        var r = await ApiAsync("GET", "/rest/v1/storages?select=id,name,limit_bytes,used_bytes,reserved_bytes,active,sort_order&order=sort_order", null);
        if (r.Code != 200) return null;
        try
        {
            var list = new List<StorageInfo>();
            foreach (var n in JsonNode.Parse(r.Text).AsArray())
                list.Add(new StorageInfo(n["id"]?.ToString() ?? "", n["name"]?.ToString() ?? "", (long?)n["limit_bytes"] ?? 0, (long?)n["used_bytes"] ?? 0,
                    (long?)n["reserved_bytes"] ?? 0, (bool?)n["active"] ?? false, (int?)n["sort_order"] ?? 0));
            return list;
        }
        catch { return null; }
    }

    /// <summary>Admin only. The server refuses a limit above its own cap (false); the app never knows that number.</summary>
    public static async Task<bool> UpdateStorageAsync(StorageInfo s)
    {
        var body = new JsonObject { ["name"] = s.Name, ["limit_bytes"] = s.LimitBytes, ["active"] = s.Active, ["sort_order"] = s.SortOrder };
        var r = await ApiAsync("PATCH", "/rest/v1/storages?id=eq." + s.Id, body, "return=representation");
        if (r.Code < 200 || r.Code > 299) return false;
        try { return JsonNode.Parse(r.Text) is JsonArray a && a.Count > 0; } catch { return false; }
    }
}

/// <summary>
/// Electronic payment (Paymob), release 38 = step 2 of 3. NOT wired to any screen yet; <see cref="Payments.Start"/> still returns false.
/// Flow: CreateOrderAsync (the SERVER decides the price) -> Open the Paymob page in the browser -> PollStatusAsync until "paid"
/// -> ask <see cref="Remote.AccessAsync"/> again and open the content. Paying is never trusted from the screen: only the server webhook marks an order paid.
/// CreateOrderAsync gives null when it fails or when the content is already open (then just call AccessAsync).
/// Status values: pending, paid, failed, refunded, mismatch, missing.
/// </summary>
public static class PaymentFlow
{
    public record Order(string Id, int Amount, string CheckoutUrl);

    /// <summary>target = "l:&lt;lesson uuid&gt;" or "c:&lt;chapter uuid&gt;".</summary>
    public static async Task<Order> CreateOrderAsync(string target)
    {
        var body = new System.Text.Json.Nodes.JsonObject { ["target_type"] = target.StartsWith("c:") ? "chapter" : "lesson", ["target_id"] = target.Substring(2) };
        var r = await Remote.ApiAsync("POST", "/functions/v1/create-order", body);
        if (r.Code != 200) return null;
        var o = System.Text.Json.Nodes.JsonNode.Parse(r.Text);
        return new Order((string)o["orderId"] ?? "", (int?)o["amount"] ?? 0, (string)o["checkoutUrl"] ?? "");
    }

    /// <summary>Opens the Paymob checkout page in the browser. No card data is ever typed inside the app.</summary>
    public static void Open(Order o) => Process.Start(new ProcessStartInfo(o.CheckoutUrl) { UseShellExecute = true });

    /// <summary>One check.</summary>
    public static async Task<string> StatusOnceAsync(string orderId)
    {
        var r = await Remote.ApiAsync("POST", "/rest/v1/rpc/order_status", new System.Text.Json.Nodes.JsonObject { ["p_order"] = orderId });
        return r.Code == 200 ? r.Text.Trim().Trim('"') : "pending";
    }

    /// <summary>Checks every 3 s (up to about 10 minutes) until the status is not "pending"; gives "pending" if time ran out.</summary>
    public static async Task<string> PollStatusAsync(string orderId, CancellationToken ct = default)
    {
        var st = "pending";
        for (int n = 0; n < 200 && st == "pending" && !ct.IsCancellationRequested; n++)
        {
            st = await StatusOnceAsync(orderId);
            if (st == "pending") { try { await Task.Delay(3000, ct); } catch (TaskCanceledException) { break; } }
        }
        return st;
    }
}
