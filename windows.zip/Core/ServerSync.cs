namespace NexoraEdu.Core;

/// <summary>
/// Release 52: first wiring step (same as Android ServerSync.kt). The local login / sign-up stays exactly as it was and decides
/// whether the user gets in. Right after it succeeds, the account is mirrored to Supabase in the background:
/// sign in -> if the account does not exist there yet, sign up -> (teacher with a code) claim the teacher code.
/// Silent on purpose: no new screen, no new string, never blocks; a server that is not ready (SQL not run, offline) changes nothing.
/// Existing users are mirrored the next time they type their password (it is needed and never stored).
/// </summary>
public static class ServerSync
{
    static string? _email; // the email that owns the current server session
    static readonly string EmailFile = Path.Combine(Store.DataDir, "server_email.txt");
    static bool _emailLoaded;

    /// <summary>Release 56: the owner email is also kept on disk (next to the saved server session in remote.json), so the removed-account check can run right after a restart.</summary>
    static string? Owner
    {
        get
        {
            if (!_emailLoaded) { _emailLoaded = true; try { _email ??= File.ReadAllText(EmailFile).Trim(); } catch { } }
            return string.IsNullOrEmpty(_email) ? null : _email;
        }
        set
        {
            _email = value; _emailLoaded = true;
            try
            {
                if (string.IsNullOrEmpty(value)) File.Delete(EmailFile);
                else { Directory.CreateDirectory(Store.DataDir); File.WriteAllText(EmailFile, value); }
            }
            catch { }
        }
    }

    public static bool Mirrored(string email) => Remote.SignedIn && Owner == email;

    /// <summary>Teacher codes are written XXXXXX-YYYYYY on the server; the user may type them with spaces, dashes or lower case.</summary>
    static string ServerCode(string raw)
    {
        const string alpha = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        var s = new string(raw.ToUpperInvariant().Where(ch => alpha.Contains(ch)).ToArray());
        return s.Length == 12 ? s[..6] + "-" + s[6..] : raw.Trim();
    }

    /// <summary>role = "student" | "teacher" | "admin". code = the teacher code typed at sign-up (empty otherwise).</summary>
    public static async void Mirror(string role, string email, string pass, string code = "")
    {
        if (!Remote.Enabled) return;
        // Release 56: already linked -> only tell the main admin (same as Android ServerSync.mirror)
        if (Mirrored(email) && code.Length == 0) { await AdminControl.EnteredAsync(role, "signin"); return; }
        try
        {
            var st = role == "student" ? Store.FindStudent(email) : null;
            var name = role == "teacher" ? Store.TeacherName() : st?.Name ?? "";
            var ok = await Remote.SignInAsync(email, pass);
            if (!ok)   // release 57: an admin gets a (limited) account on the server too; the activation code makes it admin
                ok = await Remote.SignUpAsync(email, pass, name, st?.Phone ?? "", st?.Grade ?? "") && Remote.SignedIn;
            if (!ok) return;
            Owner = email;
            // TODO(server): the teacher code is only claimed here; if the server was not ready then, promote the teacher by hand (see SQL notes).
            if (role == "teacher" && code.Length > 0) await Remote.ClaimTeacherAsync(ServerCode(code));
            // Release 56: tell the server (and the main admin) who entered. An account that was already linked only "signs in".
            await AdminControl.EnteredAsync(role, code.Length > 0 ? "signup" : "signin");
        }
        catch { /* the local app keeps working whatever the server does */ }
    }

    /// <summary>
    /// Release 53: creating an account works ONLY online. The server must accept it first; the local account is created by the caller
    /// only when this answers null. Otherwise it answers a string key: "err_need_net" (no internet / server refused) or "err_tcode_invalid"
    /// (teacher code unknown to the server). Without a server configured it answers null at once.
    /// </summary>
    public static async Task<string?> RegisterAsync(string role, string email, string pass, string name, string phone, string grade, string code)
    {
        if (!Remote.Enabled) return null;
        try
        {
            Remote.SignOut();
            var ok = await Remote.SignUpAsync(email, pass, name, phone, grade) && Remote.SignedIn;
            if (!ok) ok = await Remote.SignInAsync(email, pass); // already on the server (e.g. a retry)
            if (!ok) return "err_need_net";
            Owner = email;
            if (role == "teacher" && !await Remote.ClaimTeacherAsync(ServerCode(code))) return "err_tcode_invalid";
            if (role == "teacher") _ = AdminControl.EnteredAsync("teacher", "signup");   // silent, never blocks
            if (role == "admin")   // release 57: first admin = main (no code), the others need the one-time code
            {
                var reg = await AdminControl.RegisterAdminAsync(ServerCode(code));
                if (reg == null) return "err_need_net";
                if (!reg.Ok) return reg.Reason == "locked" ? "err_admin_locked" : "err_admin_code";
            }
            return null;
        }
        catch { return "err_need_net"; }
    }

    public static void SignOut() { AdminControl.Reset(); Remote.SignOut(); Owner = null; }
}
