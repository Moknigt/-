using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;

namespace NexoraEdu.Core;

/// <summary>
/// Short interface sounds: Resources/Sfx/sfx_*.wav, the same 18 files, names and volumes as the Android app
/// (made by tools/make_sfx.py inside android.zip). The files are embedded in the exe (the build ships ONE file),
/// copied once to a temp folder and played with MediaPlayer, which allows overlapping sounds and a volume per sound.
/// A plain tap is skipped when a more specific sound (success, error, sheet...) plays at the same moment.
/// </summary>
public static class Sfx
{
    public enum S { Tap, Tab, Select, On, Off, Open, Close, Notice, Success, Error, Delete, Locked, Play, Pause, Skip, Pass, Fail, Splash }

    static readonly Dictionary<S, double> Vol = new()
    {
        [S.Tap] = 0.45, [S.Tab] = 0.55, [S.Select] = 0.5, [S.On] = 0.55, [S.Off] = 0.55, [S.Open] = 0.5, [S.Close] = 0.4,
        [S.Notice] = 0.55, [S.Success] = 0.7, [S.Error] = 0.75, [S.Delete] = 0.7, [S.Locked] = 0.7, [S.Play] = 0.5,
        [S.Pause] = 0.5, [S.Skip] = 0.5, [S.Pass] = 0.75, [S.Fail] = 0.7, [S.Splash] = 0.8,
    };

    static readonly Dictionary<S, MediaPlayer> _players = new();
    static readonly Dictionary<S, long> _last = new();
    static long _lastAction;
    static bool _started, _hooked;
    static RadioButton _down;
    static bool _downWasOn;

    static long Now => Environment.TickCount64;

    /// <summary>Loads the sounds (once). Called from App.OnStartup, on the UI thread.</summary>
    public static void Start()
    {
        if (_started) return;
        _started = true;
        try
        {
            var dir = Path.Combine(Path.GetTempPath(), "NexoraEdu-sfx");
            Directory.CreateDirectory(dir);
            var asm = Assembly.GetExecutingAssembly();
            var names = asm.GetManifestResourceNames();
            foreach (var s in Enum.GetValues<S>())
            {
                try
                {
                    var file = "sfx_" + s.ToString().ToLowerInvariant() + ".wav";
                    var res = names.FirstOrDefault(n => n.EndsWith("." + file));
                    if (res == null) continue;
                    var path = Path.Combine(dir, file);
                    using (var st = asm.GetManifestResourceStream(res))
                    {
                        if (!File.Exists(path) || new FileInfo(path).Length != st.Length)
                        {
                            using var fs = File.Create(path);
                            st.CopyTo(fs);
                        }
                    }
                    var p = new MediaPlayer { Volume = Vol[s] };
                    p.Open(new Uri(path));
                    _players[s] = p;
                }
                catch { /* one missing sound must never stop the app */ }
            }
        }
        catch { /* no temp folder: the app simply stays silent */ }
    }

    /// <summary>Plain tap sound for every button, check box, tab / chip and clickable card, without touching each screen.</summary>
    public static void Hook()
    {
        if (_hooked) return;
        _hooked = true;
        EventManager.RegisterClassHandler(typeof(RadioButton), UIElement.PreviewMouseLeftButtonDownEvent,
            new MouseButtonEventHandler((s, _) => { _down = s as RadioButton; _downWasOn = _down?.IsChecked == true; }));
        EventManager.RegisterClassHandler(typeof(ButtonBase), ButtonBase.ClickEvent, new RoutedEventHandler(OnClick));
        EventManager.RegisterClassHandler(typeof(Border), UIElement.MouseLeftButtonUpEvent, new MouseButtonEventHandler(OnBorderUp));
    }

    static void OnClick(object sender, RoutedEventArgs e)
    {
        switch (sender)
        {
            case RadioButton rb:
                // tabs, segments and chips: only when the choice really changes
                var changed = !(ReferenceEquals(_down, rb) && _downWasOn);
                _down = null;
                if (changed) Play(ReferenceEquals(rb.Style, Application.Current.TryFindResource("Chip")) ? S.Select : S.Tab);
                break;
            case ToggleButton tb:   // check boxes (activate a student, publish a lesson...)
                Play(tb.IsChecked == true ? S.On : S.Off);
                break;
            default:
                Tap();
                break;
        }
    }

    static void OnBorderUp(object sender, MouseButtonEventArgs e)
    {
        // rows, cards and tiles that open something are the Borders with the hand cursor
        if (!e.Handled && sender is Border b && ReferenceEquals(b.Cursor, Cursors.Hand)) Tap();
    }

    public static void Play(S s)
    {
        var d = Application.Current?.Dispatcher;
        if (d == null) return;
        if (!d.CheckAccess()) { d.BeginInvoke(() => Play(s)); return; }
        var t = Now;
        if (s != S.Tap) _lastAction = t;
        if (_last.TryGetValue(s, out var l) && t - l < 45) return;   // the same sound twice in a blink
        _last[s] = t;
        Start();
        if (!_players.TryGetValue(s, out var p)) return;
        try { p.Position = TimeSpan.Zero; p.Play(); } catch { }
    }

    public static void Stop(S s)
    {
        if (_players.TryGetValue(s, out var p)) { try { p.Stop(); } catch { } }
    }

    /// <summary>Plain tap: waits a moment so a more specific sound (played by the click itself) can replace it.</summary>
    public static void Tap()
    {
        var timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(35) };
        timer.Tick += (_, _) =>
        {
            timer.Stop();
            if (Now - _lastAction > 150) Play(S.Tap);
        };
        timer.Start();
    }

    /// <summary>The sound that fits a message, taken from the name of its string (err_*, *_saved, *_copied...). Same rule as Android.</summary>
    public static void ForToast(string message)
    {
        var n = Strings.KeyOf(message) ?? "";
        var bad = n.StartsWith("err_") || n.Contains("_err") || n.EndsWith("_fail") || n.EndsWith("_bad_limit")
                  || n == "grant_none" || n == "ex_empty_questions";
        var good = n.EndsWith("_saved") || n.EndsWith("_done") || n.EndsWith("_copied") || n.EndsWith("_changed")
                   || n.EndsWith("_imported") || n == "pw_changed";
        Play(bad ? S.Error : good ? S.Success : S.Notice);
    }
}
