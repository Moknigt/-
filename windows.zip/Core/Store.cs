using System.Text.Json;
using System.Text.Json.Nodes;

namespace NexoraEdu.Core;

/// <summary>
/// Data layer (port of Store.kt). Same model as the Android app: a flat key -> string map where every value is a JSON string,
/// same key names, same short JSON field names. File: %APPDATA%\NEXORA EDU\data\nexora_data.json
///   students [{n,p,e,pw,g,c,act}]   chapters [{i,t}]   lessons [{i,c,t,y,a}]   docs [{i,t,k,a}]
///   s_role / s_email (session)   fav:&lt;email&gt; {"fav":[],"later":[],"imp":[]}   notes:&lt;email&gt; [{t,d}]   hist:&lt;email&gt; ["lessonId"...]
/// Exams / homework: questions [{i,t,c,o,a}]  exams [{i,t,o,q,a}]  results [{x,e,s,c,n,a}]  homework [{i,t,n,a}]  subs [{h,e,t,p,g,n,a}]
/// Writes so far: students (sign-up) and the session. Favourites, notes and history writes come with the student pages.
/// </summary>
public static class Store
{
    public static readonly string DataDir = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "NEXORA EDU", "data");

    static Dictionary<string, string> _map;
    static string DataFile => Path.Combine(DataDir, "nexora_data.json");

    static Dictionary<string, string> Map
    {
        get
        {
            if (_map != null) return _map;
            try { _map = JsonSerializer.Deserialize<Dictionary<string, string>>(File.ReadAllText(DataFile)); } catch { }
            return _map ??= new Dictionary<string, string>();
        }
    }

    static string Str(string key) => Map.TryGetValue(key, out var v) ? v : null;

    static JsonArray Arr(string key)
    {
        try { return JsonNode.Parse(Str(key) ?? "[]") as JsonArray ?? new JsonArray(); }
        catch { return new JsonArray(); }
    }

    static string S(JsonNode n, string k) => (string)n?[k] ?? "";

    // ---------- session ----------
    public static (string Role, string Email)? Session()
    {
        var r = Str("s_role"); var e = Str("s_email");
        return string.IsNullOrEmpty(r) || string.IsNullOrEmpty(e) ? null : (r, e);
    }

    // ---------- students ----------
    public static List<Student> Students() => Arr("students").Select(o => new Student
    {
        Name = S(o, "n"), Phone = S(o, "p"), Email = S(o, "e"), PwHash = S(o, "pw"),
        Grade = S(o, "g"), Code = S(o, "c"), Active = (bool?)o["act"] ?? false
    }).ToList();

    public static Student FindStudent(string email) => Students().FirstOrDefault(s => s.Email == email);

    /// <summary>The signed-in student, or null when the session is not a student.</summary>
    public static Student CurrentStudent()
    {
        var s = Session();
        return s != null && s.Value.Role == "student" ? FindStudent(s.Value.Email) : null;
    }

    // ---------- content ----------
    // Release 66: every list below is read through Pick (filtered by class) and written through Merge. The raw functions
    // (RawChapters / RawSaveChapters ...) always see everything. All the old functions keep their names and signatures.
    static List<Chapter> RawChapters() =>
        Arr("chapters").Select(o => new Chapter { Id = S(o, "i"), Title = S(o, "t"), Price = (int?)o["pr"] ?? 0, Grade = S(o, "gr") }).ToList();

    static List<Lesson> RawLessons() => Arr("lessons").Select(o => new Lesson
    {
        Id = S(o, "i"), ChapterId = S(o, "c"), Title = S(o, "t"), Yt = S(o, "y"), At = (long?)o["a"] ?? 0, Published = (bool?)o["p"] ?? true,
        Src = S(o, "s") is { Length: > 0 } sv ? sv : "yt", Price = (int?)o["pr"] ?? 0, Thumb = S(o, "th"), Grade = S(o, "gr")
    }).ToList();

    static List<Announcement> RawAnnouncements() => Arr("ann").Select(o => new Announcement
    {
        Id = S(o, "i"), Title = S(o, "t"), Text = S(o, "x"), At = (long?)o["a"] ?? 0, Grade = S(o, "gr")
    }).ToList();

    static List<Doc> RawDocs() => Arr("docs").Select(o => new Doc
    {
        Id = S(o, "i"), Title = S(o, "t"), Kind = S(o, "k") is "" ? "book" : S(o, "k"), At = (long?)o["a"] ?? 0, Grade = S(o, "gr")
    }).ToList();

    // ---------- release 66: classes ----------
    /// <summary>Teacher only: the class opened on the teacher's class screen. null = no filter (the admin always sees everything).</summary>
    public static string TeacherGrade;

    /// <summary>The three fixed classes content can belong to (same as Android Store.FIXED_GRADES).</summary>
    public static IReadOnlyList<string> FixedGrades => DefaultGrades;

    /// <summary>What the current session may see: null = everything, otherwise a test for one item's class.</summary>
    static Func<string, bool> Visible()
    {
        var s = Session();
        if (s != null && s.Value.Role == "student")
        {
            var g = FindStudent(s.Value.Email)?.Grade ?? "";
            return x => x.Length == 0 || x == g;
        }
        var t = TeacherGrade;
        return t == null ? null : x => x == t;
    }

    static List<T> Pick<T>(List<T> all, Func<T, string> grade)
    {
        MigrateGrades();
        var v = Visible();
        return v == null ? all : all.Where(x => v(grade(x))).ToList();
    }

    /// <summary>Writes back what one session was allowed to see; items of other classes stay as they are. New items get the open class.</summary>
    static List<T> Merge<T>(List<T> all, List<T> now, Func<T, string> grade, Action<T, string> setGrade)
    {
        MigrateGrades();
        var v = Visible();
        if (v == null) return now;
        if (TeacherGrade != null && Session()?.Role != "student")
            foreach (var x in now) if (grade(x).Length == 0) setGrade(x, TeacherGrade);
        return all.Where(x => !v(grade(x))).Concat(now).ToList();
    }

    static bool _migrating;

    /// <summary>Once: content made before release 66 has no class; it goes to the FIRST class so the teacher can manage it.</summary>
    static void MigrateGrades()
    {
        if (_migrating || Str("gr_done") == "1") return;
        _migrating = true;
        try
        {
            var first = DefaultGrades[0];
            var ch = RawChapters(); foreach (var x in ch) if (x.Grade.Length == 0) x.Grade = first; WriteChapters(ch);
            var le = RawLessons(); foreach (var x in le) if (x.Grade.Length == 0) x.Grade = first; WriteLessons(le);
            var dc = RawDocs(); foreach (var x in dc) if (x.Grade.Length == 0) x.Grade = first; WriteDocs(dc);
            var qs = RawQuestions(); foreach (var x in qs) if (x.Grade.Length == 0) x.Grade = first; WriteQuestions(qs);
            var ex = RawExams(); foreach (var x in ex) if (x.Grade.Length == 0) x.Grade = first; WriteExams(ex);
            var hw = RawHomework(); foreach (var x in hw) if (x.Grade.Length == 0) x.Grade = first; WriteHomework(hw);
            var an = RawAnnouncements(); foreach (var x in an) if (x.Grade.Length == 0) x.Grade = first; WriteAnnouncements(an);
            Put("gr_done", "1");
        }
        finally { _migrating = false; }
    }

    public static List<Chapter> Chapters() => Pick(RawChapters(), x => x.Grade);
    public static List<Lesson> Lessons() => Pick(RawLessons(), x => x.Grade);
    public static List<Announcement> Announcements() => Pick(RawAnnouncements(), x => x.Grade);
    public static List<Doc> Docs() => Pick(RawDocs(), x => x.Grade);

    /// <summary>Student-visible lessons only. Missing p values from v23 are treated as published.</summary>
    public static List<Lesson> PublishedLessons() => Lessons().Where(l => l.Published).ToList();

    /// <summary>Release 66: the published lessons of one class (a student's progress counts his own class, whoever asks).</summary>
    public static List<Lesson> PublishedLessonsOf(string grade)
    {
        MigrateGrades();
        return RawLessons().Where(l => l.Published && (l.Grade.Length == 0 || l.Grade == grade)).ToList();
    }

    public static void SaveAnnouncements(List<Announcement> list) => WriteAnnouncements(Merge(RawAnnouncements(), list, x => x.Grade, (x, g) => x.Grade = g));

    static void WriteAnnouncements(List<Announcement> list)
    {
        var a = new JsonArray();
        foreach (var x in list) a.Add(new JsonObject { ["i"] = x.Id, ["t"] = x.Title, ["x"] = x.Text, ["a"] = x.At, ["gr"] = x.Grade });
        Put("ann", a.ToJsonString(Out));
    }

    // ---------- per-student ----------
    /// <summary>coll = "fav" | "later" | "imp"; items look like "lesson|id".</summary>
    public static List<string> Collection(string email, string coll)
    {
        try
        {
            var o = JsonNode.Parse(Str("fav:" + email) ?? "{}") as JsonObject;
            return (o?[coll] as JsonArray)?.Select(x => (string)x).Where(x => x != null).ToList() ?? new();
        }
        catch { return new(); }
    }

    public static List<Note> Notes(string email) =>
        Arr("notes:" + email).Select(o => new Note { Text = S(o, "t"), Date = S(o, "d") }).ToList();

    /// <summary>Watched lesson ids, newest first.</summary>
    public static List<string> History(string email) =>
        Arr("hist:" + email).Select(x => (string)x).Where(x => x != null).ToList();

    // ---------- writes ----------
    static readonly JsonSerializerOptions Out = new()
    {
        Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
    };

    static void Put(string key, string value)
    {
        Map[key] = value;
        Save();
    }

    static void Remove(params string[] keys)
    {
        foreach (var k in keys) Map.Remove(k);
        Save();
    }

    /// <summary>Atomic write (temp file + rename), like the Electron port did.</summary>
    static void Save()
    {
        Directory.CreateDirectory(DataDir);
        var tmp = DataFile + ".tmp";
        File.WriteAllText(tmp, JsonSerializer.Serialize(Map, Out));
        File.Move(tmp, DataFile, true);
    }

    /// <summary>SHA-256 hex of the UTF-8 password (same as Store.hash in the Android app).</summary>
    public static string Hash(string s) =>
        Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(s))).ToLowerInvariant();

    static readonly string[] DefaultGrades = { "الصف الأول الثانوي", "الصف الثاني الثانوي", "الصف الثالث الثانوي" };

    public static List<string> Grades()
    {
        var s = Str("grades");
        if (s == null) return DefaultGrades.ToList();
        try { return (JsonNode.Parse(s) as JsonArray)?.Select(x => (string)x).Where(x => x != null).ToList() ?? new(); }
        catch { return DefaultGrades.ToList(); }
    }

    public static void SaveStudents(List<Student> list)
    {
        var a = new JsonArray();
        foreach (var x in list)
            a.Add(new JsonObject
            {
                ["n"] = x.Name, ["p"] = x.Phone, ["e"] = x.Email, ["pw"] = x.PwHash,
                ["g"] = x.Grade, ["c"] = x.Code, ["act"] = x.Active
            });
        Put("students", a.ToJsonString(Out));
    }

    // ---------- admin account (own keys a_email / a_pw, separate from the teacher) ----------
    public static (string Email, string PwHash)? Admin()
    {
        var e = Str("a_email"); var p = Str("a_pw");
        return e == null || p == null ? null : (e, p);
    }

    public static void SetAdmin(string email, string password)
    {
        Map["a_email"] = email;
        Map["a_pw"] = Hash(password);
        Save();
    }

    public static void SetSession(string role, string email)
    {
        Map["s_role"] = role;
        Map["s_email"] = email;
        Save();
    }

    public static void ClearSession() { TeacherGrade = null; Remove("s_role", "s_email"); }

    // ---------- teacher account (own keys t_email / t_pw, same as Store.kt) ----------
    public static (string Email, string PwHash)? Teacher()
    {
        var e = Str("t_email"); var p = Str("t_pw");
        return e == null || p == null ? null : (e, p);
    }

    /// <summary>Serials of the teacher registration codes already used on this computer (comma separated), see <see cref="TeacherCode"/>.</summary>
    public static string UsedTeacherCodes() => Map.TryGetValue("t_used_codes", out var v) ? v : "";
    public static void SetUsedTeacherCodes(string v) => Put("t_used_codes", v);

    /// <summary>Same keys as Store.kt: <c>t_name</c> / <c>t_phone</c> are written only when given (a password change keeps the old name: pass <c>TeacherName()</c>).</summary>
    public static void SetTeacher(string email, string password, string phone = "", string name = "")
    {
        Map["t_email"] = email;
        Map["t_pw"] = Hash(password);
        if (!string.IsNullOrEmpty(phone)) Map["t_phone"] = phone; else Map.Remove("t_phone");
        if (!string.IsNullOrEmpty(name)) Map["t_name"] = name; else Map.Remove("t_name");
        Save();
    }

    /// <summary>The teacher's full name (empty for accounts made before the sign-up form existed on Windows).</summary>
    public static string TeacherName() => (Str("t_name") ?? "").Trim();

    // ---------- PDF files (Android: filesDir/docs/<id>.pdf) ----------
    public static string DocFile(string id) => Path.Combine(DataDir, "docs", id + ".pdf");

    // ---------- teacher writes (same keys / format as Store.kt: chapters [{i,t}], lessons [{i,c,t,y,a}], docs [{i,t,k,a}]) ----------
    public static string NewId() => Guid.NewGuid().ToString("N")[..12];
    public static long Now() => DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();

    public static void SaveChapters(List<Chapter> list) => WriteChapters(Merge(RawChapters(), list, x => x.Grade, (x, g) => x.Grade = g));
    public static void SaveLessons(List<Lesson> list) => WriteLessons(Merge(RawLessons(), list, x => x.Grade, (x, g) => x.Grade = g));
    public static void SaveDocs(List<Doc> list) => WriteDocs(Merge(RawDocs(), list, x => x.Grade, (x, g) => x.Grade = g));

    static void WriteChapters(List<Chapter> list)
    {
        var a = new JsonArray();
        foreach (var c in list) a.Add(new JsonObject { ["i"] = c.Id, ["t"] = c.Title, ["pr"] = c.Price, ["gr"] = c.Grade });
        Put("chapters", a.ToJsonString(Out));
    }

    static void WriteLessons(List<Lesson> list)
    {
        var a = new JsonArray();
        foreach (var l in list) a.Add(new JsonObject { ["i"] = l.Id, ["c"] = l.ChapterId, ["t"] = l.Title, ["y"] = l.Yt, ["a"] = l.At, ["p"] = l.Published, ["s"] = l.Src, ["pr"] = l.Price, ["th"] = l.Thumb, ["gr"] = l.Grade });
        Put("lessons", a.ToJsonString(Out));
    }

    static void WriteDocs(List<Doc> list)
    {
        var a = new JsonArray();
        foreach (var d in list) a.Add(new JsonObject { ["i"] = d.Id, ["t"] = d.Title, ["k"] = d.Kind, ["a"] = d.At, ["gr"] = d.Grade });
        Put("docs", a.ToJsonString(Out));
    }

    /// <summary>Deletes the chapter and all its lessons (same as Store.deleteChapter).</summary>
    public static void DeleteChapter(string id)
    {
        foreach (var l in Lessons().Where(l => l.ChapterId == id)) TryDelete(VideoFile(l.Id));
        SaveChapters(Chapters().Where(c => c.Id != id).ToList());
        SaveLessons(Lessons().Where(l => l.ChapterId != id).ToList());
        SaveGrants(Grants().Where(g => g.Target != "c:" + id).ToList());
    }

    /// <summary>Deletes one lesson / video with its uploaded file and its grants (the teacher is the only one who can).</summary>
    public static void DeleteLesson(string id)
    {
        TryDelete(VideoFile(id));
        SaveGrants(Grants().Where(g => g.Target != "l:" + id).ToList());
        SaveLessons(Lessons().Where(l => l.Id != id).ToList());
    }

    static void TryDelete(string path) { try { File.Delete(path); } catch { } }

    // ---------- release 35: uploaded videos, prices, grants ----------
    /// <summary>Uploaded video file (Src == "up"). Kept until the teacher deletes the video. No expiry.</summary>
    public static string VideoFile(string id) => Path.Combine(DataDir, "videos", id + ".mp4");
    public static bool HasVideo(Lesson l) => l.Src == "up" ? File.Exists(VideoFile(l.Id)) : l.Yt.Length > 0;
    public static int CoursePrice(Lesson l) => Chapters().FirstOrDefault(c => c.Id == l.ChapterId)?.Price ?? 0;
    public static bool IsPaid(Lesson l) => l.Price > 0 || CoursePrice(l) > 0;

    public static List<Grant> Grants() => Arr("grants").Select(o => new Grant { Target = S(o, "t"), Email = S(o, "e"), Mode = S(o, "m"), By = S(o, "b"), At = (long?)o["a"] ?? 0 }).ToList();
    /// <summary>Permanent log of every opening (who opened it, for whom, when). Removing a grant does not delete its log line.</summary>
    public static List<Grant> GrantLog() => Arr("glog").Select(o => new Grant { Target = S(o, "t"), Email = S(o, "e"), Mode = S(o, "m"), By = S(o, "b"), At = (long?)o["a"] ?? 0 }).ToList();

    static JsonArray GrantJson(IEnumerable<Grant> list)
    {
        var a = new JsonArray();
        foreach (var g in list) a.Add(new JsonObject { ["t"] = g.Target, ["e"] = g.Email, ["m"] = g.Mode, ["b"] = g.By, ["a"] = g.At });
        return a;
    }
    public static void SaveGrants(List<Grant> list) => Put("grants", GrantJson(list).ToJsonString(Out));

    /// <summary>Opens [target] for [email] and logs it.</summary>
    public static void GrantAccess(string target, string email, string mode, string by)
    {
        var all = Grants();
        if (all.Any(g => g.Target == target && g.Email == email)) return;
        var g = new Grant { Target = target, Email = email, Mode = mode, By = by, At = Now() };
        all.Add(g); SaveGrants(all);
        Put("glog", GrantJson(GrantLog().Append(g)).ToJsonString(Out));
    }
    public static void RevokeAccess(string target, string email) => SaveGrants(Grants().Where(g => !(g.Target == target && g.Email == email)).ToList());

    /// <summary>Deletes the book / file and its PDF (same as Store.deleteDoc).</summary>
    public static void DeleteDoc(string id)
    {
        SaveDocs(Docs().Where(d => d.Id != id).ToList());
        try { File.Delete(DocFile(id)); } catch { }
    }

    /// <summary>The 11-character YouTube id of a link or of the bare id; "" when it is not one (same as Ui.kt youtubeId).</summary>
    public static string YoutubeId(string url)
    {
        var u = (url ?? "").Trim();
        var m = System.Text.RegularExpressions.Regex.Match(u, @"(?:youtu\.be/|v=|embed/|shorts/|live/)([A-Za-z0-9_-]{11})");
        if (!m.Success) m = System.Text.RegularExpressions.Regex.Match(u, @"^([A-Za-z0-9_-]{11})$");
        return m.Success ? m.Groups[1].Value : "";
    }

    // ---------- per-student writes (same keys / format as Store.kt: fav:<email>, notes:<email>, hist:<email>) ----------
    public static bool IsIn(string email, string coll, string key) => Collection(email, coll).Contains(key);

    /// <summary>Adds the key to the collection (at the top), or removes it when it is already there. Other collections are kept.</summary>
    public static void ToggleIn(string email, string coll, string key)
    {
        JsonObject o;
        try { o = JsonNode.Parse(Str("fav:" + email) ?? "{}") as JsonObject ?? new JsonObject(); }
        catch { o = new JsonObject(); }
        var l = Collection(email, coll);
        if (!l.Remove(key)) l.Insert(0, key);
        var a = new JsonArray();
        foreach (var x in l) a.Add(x);
        o[coll] = a;
        Put("fav:" + email, o.ToJsonString(Out));
    }

    public static void SaveNotes(string email, List<Note> list)
    {
        var a = new JsonArray();
        foreach (var n in list) a.Add(new JsonObject { ["t"] = n.Text, ["d"] = n.Date });
        Put("notes:" + email, a.ToJsonString(Out));
    }

    /// <summary>Same as Store.addHistory: the lesson goes to the top, no duplicates, max 200.</summary>
    public static void AddHistory(string email, string lessonId)
    {
        var l = new List<string> { lessonId };
        l.AddRange(History(email).Where(x => x != lessonId));
        var a = new JsonArray();
        foreach (var x in l.Take(200)) a.Add(x);
        Put("hist:" + email, a.ToJsonString(Out));
    }

    public static void ClearHistory(string email) => Remove("hist:" + email);

    // ---------- admin writes (same keys / rules as Store.kt: grades, students, t_email / t_pw) ----------
    public static void SaveGrades(List<string> list)
    {
        var a = new JsonArray();
        foreach (var g in list) a.Add(g);
        Put("grades", a.ToJsonString(Out));
    }

    /// <summary>Removes the teacher account (the next teacher sign-in creates a new one; students and content stay).</summary>
    public static void DeleteTeacher() => Remove("t_email", "t_pw", "t_phone", "t_name");

    /// <summary>Release 56: the admin was removed on the server; the local admin account goes too (same keys as Android Store.deleteAdmin).</summary>
    public static void DeleteAdmin() => Remove("a_email", "a_pw");

    public static bool UpdateStudentProfile(string email, string name, string phone, string grade)
    {
        var all = Students();
        var student = all.FirstOrDefault(x => string.Equals(x.Email, email, StringComparison.OrdinalIgnoreCase));
        if (student == null) return false;
        student.Name = name.Trim(); student.Phone = phone.Trim(); student.Grade = grade.Trim();
        SaveStudents(all); return true;
    }

    public static bool ChangeStudentPassword(string email, string currentPassword, string newPassword)
    {
        var all = Students();
        var student = all.FirstOrDefault(x => string.Equals(x.Email, email, StringComparison.OrdinalIgnoreCase));
        if (student == null || student.PwHash != Hash(currentPassword)) return false;
        student.PwHash = Hash(newPassword); SaveStudents(all); return true;
    }

    public static void SetStudentActive(string email, bool on)
    {
        var all = Students();
        foreach (var s in all) if (s.Email == email) s.Active = on;
        SaveStudents(all);
    }

    /// <summary>New 10-character code (no look-alikes: no O/0, I/1) that no other student has; saved and returned (same as Store.newStudentCode).</summary>
    public static string NewStudentCode(string email)
    {
        var all = Students();
        var used = all.Select(s => s.Code).ToHashSet();
        const string chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        string code;
        do
        {
            code = new string(Enumerable.Range(0, 10)
                .Select(_ => chars[System.Security.Cryptography.RandomNumberGenerator.GetInt32(chars.Length)]).ToArray());
        } while (used.Contains(code));
        foreach (var s in all) if (s.Email == email) s.Code = code;
        SaveStudents(all);
        return code;
    }

    /// <summary>Deletes the student with his photo, favourites, notes, history, exam results and homework answers (same as Store.deleteStudent).</summary>
    public static void DeleteStudent(string email)
    {
        SaveStudents(Students().Where(s => s.Email != email).ToList());
        SaveResults(Results().Where(r => r.Email != email).ToList());
        var subs = Submissions();
        foreach (var s in subs.Where(s => s.Email == email && s.Photo.Length > 0)) DeletePhotoFile(s.Photo);
        SaveSubmissions(subs.Where(s => s.Email != email).ToList());
        Avatar.Delete(email);
        Remove("fav:" + email, "notes:" + email, "hist:" + email);
    }

    // ---------- exams and homework (same keys / short field names as Store.kt) ----------
    //   questions [{i,t,c,o:[..],a}]   exams [{i,t,o,q:[..],a}]   results [{x,e,s,c,n,a}]   homework [{i,t,n,a}]   subs [{h,e,t,p,g,n,a}]

    static List<string> StrList(JsonNode n) =>
        (n as JsonArray)?.Select(x => (string)x).Where(x => x != null).ToList() ?? new List<string>();

    static JsonArray StrArr(IEnumerable<string> l)
    {
        var a = new JsonArray();
        foreach (var s in l) a.Add(s);
        return a;
    }

    static List<Question> RawQuestions() => Arr("questions").Select(o => new Question
    {
        Id = S(o, "i"), Text = S(o, "t"), Chapter = S(o, "c"), Options = StrList(o?["o"]), Answer = (int?)o["a"] ?? 0, Grade = S(o, "gr")
    }).ToList();

    public static List<Question> Questions() => Pick(RawQuestions(), x => x.Grade);
    public static void SaveQuestions(List<Question> list) => WriteQuestions(Merge(RawQuestions(), list, x => x.Grade, (x, g) => x.Grade = g));

    static void WriteQuestions(List<Question> list)
    {
        var a = new JsonArray();
        foreach (var q in list)
            a.Add(new JsonObject { ["i"] = q.Id, ["t"] = q.Text, ["c"] = q.Chapter, ["o"] = StrArr(q.Options), ["a"] = q.Answer, ["gr"] = q.Grade });
        Put("questions", a.ToJsonString(Out));
    }

    /// <summary>Deletes a question and takes it out of every exam that used it.</summary>
    public static void DeleteQuestion(string id)
    {
        SaveQuestions(Questions().Where(q => q.Id != id).ToList());
        var exams = Exams();
        foreach (var e in exams) e.Qids.RemoveAll(x => x == id);
        SaveExams(exams);
    }

    static List<Exam> RawExams() => Arr("exams").Select(o => new Exam
    {
        Id = S(o, "i"), Title = S(o, "t"), Official = (bool?)o["o"] ?? false, Qids = StrList(o?["q"]), At = (long?)o["a"] ?? 0, Grade = S(o, "gr")
    }).ToList();

    public static List<Exam> Exams() => Pick(RawExams(), x => x.Grade);
    public static void SaveExams(List<Exam> list) => WriteExams(Merge(RawExams(), list, x => x.Grade, (x, g) => x.Grade = g));

    static void WriteExams(List<Exam> list)
    {
        var a = new JsonArray();
        foreach (var e in list)
            a.Add(new JsonObject { ["i"] = e.Id, ["t"] = e.Title, ["o"] = e.Official, ["q"] = StrArr(e.Qids), ["a"] = e.At, ["gr"] = e.Grade });
        Put("exams", a.ToJsonString(Out));
    }

    public static Exam ExamById(string id) => Exams().FirstOrDefault(e => e.Id == id);

    public static List<Result> Results() => Arr("results").Select(o => new Result
    {
        ExamId = S(o, "x"), Email = S(o, "e"), Score = (int?)o["s"] ?? 0, Correct = (int?)o["c"] ?? 0,
        Total = (int?)o["n"] ?? 0, At = (long?)o["a"] ?? 0
    }).ToList();

    public static void SaveResults(List<Result> list)
    {
        var a = new JsonArray();
        foreach (var r in list)
            a.Add(new JsonObject { ["x"] = r.ExamId, ["e"] = r.Email, ["s"] = r.Score, ["c"] = r.Correct, ["n"] = r.Total, ["a"] = r.At });
        Put("results", a.ToJsonString(Out));
    }

    public static void AddResult(Result r)
    {
        var all = Results();
        all.Add(r);
        SaveResults(all);
    }

    /// <summary>The latest result of a student in an exam, or null if never taken.</summary>
    public static Result LastResult(string email, string examId) =>
        Results().Where(r => r.Email == email && r.ExamId == examId).OrderByDescending(r => r.At).FirstOrDefault();

    public static void DeleteExam(string id)
    {
        SaveExams(Exams().Where(e => e.Id != id).ToList());
        SaveResults(Results().Where(r => r.ExamId != id).ToList());
    }

    /// <summary>Average of a student's latest score in every official exam (null if none taken).</summary>
    public static int? OfficialAverage(string email)
    {
        var scores = Exams().Where(e => e.Official).Select(e => LastResult(email, e.Id)?.Score).Where(s => s != null).Select(s => s.Value).ToList();
        return scores.Count == 0 ? null : scores.Sum() / scores.Count;
    }

    // "Homework" is also the class name, so the list is HomeworkAll().
    static List<Homework> RawHomework() => Arr("homework").Select(o => new Homework
    {
        Id = S(o, "i"), Title = S(o, "t"), Note = S(o, "n"), At = (long?)o["a"] ?? 0, Grade = S(o, "gr")
    }).ToList();

    public static List<Homework> HomeworkAll() => Pick(RawHomework(), x => x.Grade);
    public static void SaveHomework(List<Homework> list) => WriteHomework(Merge(RawHomework(), list, x => x.Grade, (x, g) => x.Grade = g));

    static void WriteHomework(List<Homework> list)
    {
        var a = new JsonArray();
        foreach (var h in list) a.Add(new JsonObject { ["i"] = h.Id, ["t"] = h.Title, ["n"] = h.Note, ["a"] = h.At, ["gr"] = h.Grade });
        Put("homework", a.ToJsonString(Out));
    }

    public static List<Submission> Submissions() => Arr("subs").Select(o => new Submission
    {
        HwId = S(o, "h"), Email = S(o, "e"), Text = S(o, "t"), Photo = S(o, "p"),
        Grade = (int?)o["g"] ?? -1, Note = S(o, "n"), At = (long?)o["a"] ?? 0
    }).ToList();

    public static void SaveSubmissions(List<Submission> list)
    {
        var a = new JsonArray();
        foreach (var s in list)
            a.Add(new JsonObject { ["h"] = s.HwId, ["e"] = s.Email, ["t"] = s.Text, ["p"] = s.Photo, ["g"] = s.Grade, ["n"] = s.Note, ["a"] = s.At });
        Put("subs", a.ToJsonString(Out));
    }

    public static Submission SubmissionOf(string hwId, string email) =>
        Submissions().FirstOrDefault(s => s.HwId == hwId && s.Email == email);

    /// <summary>Adds or replaces the student's answer to a homework (one per student per homework).</summary>
    public static void PutSubmission(Submission s)
    {
        var all = Submissions().Where(x => !(x.HwId == s.HwId && x.Email == s.Email)).ToList();
        all.Add(s);
        SaveSubmissions(all);
    }

    public static void DeleteHomework(string id)
    {
        var subs = Submissions();
        foreach (var s in subs.Where(s => s.HwId == id && s.Photo.Length > 0)) DeletePhotoFile(s.Photo);
        SaveSubmissions(subs.Where(s => s.HwId != id).ToList());
        SaveHomework(HomeworkAll().Where(h => h.Id != id).ToList());
    }

    /// <summary>Number of submitted answers that have no grade yet.</summary>
    public static int Ungraded()
    {
        if (TeacherGrade == null) return Submissions().Count(s => s.Grade < 0);
        var mine = HomeworkAll().Select(h => h.Id).ToHashSet();   // release 66: only the open class's homework
        return Submissions().Count(s => s.Grade < 0 && mine.Contains(s.HwId));
    }

    /// <summary>Homework answer photos (Android: filesDir/hw/&lt;name&gt;).</summary>
    public static string PhotoFile(string name) => Path.Combine(DataDir, "hw", name);

    public static void DeletePhotoFile(string name)
    {
        try { File.Delete(PhotoFile(name)); } catch { }
    }
}
