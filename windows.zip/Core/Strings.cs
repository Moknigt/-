using System.Reflection;
using System.Text.Json;
using System.Windows.Markup;

namespace NexoraEdu.Core;

/// <summary>Every string of the Android app (generated JSON, see tools/gen_resources.py). Arabic or English by Prefs.Ar.</summary>
public static class Strings
{
    static Dictionary<string, string> _ar, _en;

    static Dictionary<string, string> Load(string lang)
    {
        var asm = Assembly.GetExecutingAssembly();
        var name = asm.GetManifestResourceNames().First(n => n.EndsWith("strings." + lang + ".json"));
        using var s = asm.GetManifestResourceStream(name);
        return JsonSerializer.Deserialize<Dictionary<string, string>>(s) ?? new();
    }

    static Dictionary<string, string> _rev;

    /// <summary>Key of a string text (either language), or null. Used by Sfx to choose the sound of a message.</summary>
    public static string KeyOf(string text)
    {
        if (_rev == null)
        {
            var m = new Dictionary<string, string>();
            foreach (var d in new[] { _ar ??= Load("ar"), _en ??= Load("en") })
                foreach (var kv in d) m[kv.Value] = kv.Key;
            _rev = m;
        }
        return text != null && _rev.TryGetValue(text, out var k) ? k : null;
    }

    public static string T(string key, params object[] args)
    {
        var d = Prefs.Ar ? (_ar ??= Load("ar")) : (_en ??= Load("en"));
        if (!d.TryGetValue(key, out var v)) return key;
        return args.Length == 0 ? v : string.Format(v, args);
    }
}

/// <summary>XAML: Text="{loc:T tab_home}"</summary>
[MarkupExtensionReturnType(typeof(string))]
public class TExtension : MarkupExtension
{
    public string Key { get; set; }
    public TExtension() { }
    public TExtension(string key) { Key = key; }
    public override object ProvideValue(IServiceProvider serviceProvider) => Strings.T(Key);
}
