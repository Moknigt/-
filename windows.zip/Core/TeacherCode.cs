using System.Security.Cryptography;
using System.Text;

namespace NexoraEdu.Core;

/// <summary>
/// Teacher registration code: nobody can create a teacher account without one. A code is 6 random characters + 6 signature
/// characters (HMAC-SHA256 of the first 6 with <c>Secret</c>), written XXXXXX-YYYYYY. It is checked offline (no server).
/// Each code works once per computer. Make codes with <c>tools/gen_teacher_codes.py</c>; <c>Secret</c> must be the same in all four places
/// (that script, Android <c>TeacherCode.kt</c>, iPhone <c>TeacherCode.swift</c>, here). Changing it cancels every code made before.
/// </summary>
public static class TeacherCode
{
    const string Secret = "rw54cHkLy7Gk_H53ezFrTLXwEuivdc7f";
    const string Alpha = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

    public enum Result { Ok, Empty, Invalid, Used }

    static string Signature(string serial)
    {
        var b = HMACSHA256.HashData(Encoding.UTF8.GetBytes(Secret), Encoding.UTF8.GetBytes("teacher:" + serial));
        ulong n = 0;
        for (var i = 0; i < 5; i++) n = (n << 8) | b[i];
        var sb = new StringBuilder();
        for (var i = 0; i < 6; i++) sb.Append(Alpha[(int)((n >> (35 - 5 * i)) & 31)]);
        return sb.ToString();
    }

    /// <summary>Only the code characters, upper case: spaces, dashes and typos like lower case are forgiven.</summary>
    static string Clean(string raw) => new((raw ?? "").ToUpperInvariant().Where(c => Alpha.Contains(c)).ToArray());

    static HashSet<string> Used() => Store.UsedTeacherCodes().Split(',', StringSplitOptions.RemoveEmptyEntries).ToHashSet();

    public static Result Verify(string raw)
    {
        if (string.IsNullOrWhiteSpace(raw)) return Result.Empty;
        var s = Clean(raw);
        if (s.Length != 12 || Signature(s[..6]) != s[6..]) return Result.Invalid;
        return Used().Contains(s[..6]) ? Result.Used : Result.Ok;
    }

    /// <summary>Call once the teacher account is really created.</summary>
    public static void MarkUsed(string raw)
    {
        var s = Clean(raw);
        if (s.Length != 12) return;
        var u = Used();
        u.Add(s[..6]);
        Store.SetUsedTeacherCodes(string.Join(',', u));
    }

    /// <summary>String key of the message to show, or null when the code is fine.</summary>
    public static string ErrorKey(Result r) => r switch
    {
        Result.Empty => "err_tcode_required",
        Result.Invalid => "err_tcode_invalid",
        Result.Used => "err_tcode_used",
        _ => null,
    };
}
