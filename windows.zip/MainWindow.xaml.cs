using System.Windows;
using NexoraEdu.Core;
using NexoraEdu.Views;
using NexoraEdu.Views.Student;

namespace NexoraEdu;

public partial class MainWindow : Window
{
    public static MainWindow Instance { get; private set; }

    Func<System.Windows.Controls.UserControl> _screen;

    public MainWindow()
    {
        InitializeComponent();
        Instance = this;
        // Release 56: admin control. A removed account lands back on the sign-in screen; the main admin gets toasts while the app is open.
        AdminControl.Removed += () => { ShowLogin(); Ui.Notice(Strings.T("acct_removed")); };
        AdminControl.NewAlerts += AlertToast.Show;
        Activated += (_, _) => AdminControl.Guard();   // each time the window comes back to the front
        ShowSplash();
    }

    void Show_(string role, Func<System.Windows.Controls.UserControl> make)
    {
        Accents.Role = role;   // decides the default colours (student teal/blue, teacher purple, admin gold)
        _screen = make;
        SettingsHost.Content = null;
        Reload();
        if (role == "admin" || role == "teacher") AdminControl.Guard();   // release 56: removed-account check when the side opens
    }

    public void ShowSplash() => Show_("student", () => new SplashView());
    public void ShowLogin() => Show_("student", () => new LoginView());
    public void ShowStudent() { Show_("student", () => new StudentShell()); AdminControl.Guard(); }   // release 58: removed-student check
    public void ShowAdmin() => Show_("admin", () => new Views.Admin.AdminShell());
    public void ShowTeacher() => Show_("teacher", () => new Views.Teacher.TeacherShell());

    /// <summary>After the splash: a valid saved student session opens the student side, anything else the sign-in screen.
    /// (Teacher and admin sessions open their own sides.)</summary>
    public void Route()
    {
        var sess = Store.Session();
        if (sess != null && sess.Value.Role == "admin" && Store.Admin() != null) ShowAdmin();
        else if (sess != null && sess.Value.Role == "teacher" && Store.Teacher() != null) ShowTeacher();
        else if (Store.CurrentStudent() != null) ShowStudent();
        else ShowLogin();
    }

    /// <summary>Rebuilds the current screen. Used after a language change (direction + texts) or a theme change.</summary>
    public void Reload()
    {
        FlowDirection = Prefs.Ar ? FlowDirection.RightToLeft : FlowDirection.LeftToRight;
        App.ApplyTheme(Prefs.Dark);
        RefreshBackground();
        LoginView.Reloading = true;   // a language / theme change rebuilds the sign-in screen without playing its entrance again
        try { Host.Content = _screen(); }
        finally { LoginView.Reloading = false; }
        if (SettingsHost.Content != null) SettingsHost.Content = new SettingsPage(false);   // rebuilt with the new texts / colours
    }

    /// <summary>Repaints the app background with the colours now in use (after a theme / accent / role change).</summary>
    public void RefreshBackground() => BgLayer.Background = AppBackground.Make();

    /// <summary>The settings page covers the whole window (it is not a sheet).</summary>
    public void OpenSettings()
    {
        if (SettingsHost.Content != null) return;
        Sfx.Play(Sfx.S.Open);
        SettingsHost.Content = new SettingsPage(true);
    }

    public void CloseSettings()
    {
        if (SettingsHost.Content == null) return;
        Sfx.Play(Sfx.S.Close);
        SettingsHost.Content = null;
    }
}
