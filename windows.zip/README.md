## Visual identity (release 25)

Android 1.8.0 is the visual reference. Windows uses the matching light/dark palette and accent values; card surfaces use the Android glass gradient and 24dp-style corner radius. Primary actions and selected navigation continue to use the active role/accent colors.

# NEXORA EDU - Windows (native WPF)

Native Windows app: C# + XAML (WPF, .NET 8). No Electron, no WebView for the UI.
Mirrors the Android app: same data keys, same Arabic/English texts, same colours. Same layout idea as `ios.zip`.

## The parts
| Part | Content | Status |
|------|---------|--------|
| 1 | Project, data layer, language + theme, **student skeleton**: shell (sidebar), Home, Courses, Exams, Profile | **Skeleton done** |
| 1b | **Splash, student sign-in + sign-up, log out** (same checks and error texts as `LoginActivity`) | **Done** |
| 1d | **Eye button** (show / hide password) on the sign-in screen; **Home** completed: per-chapter progress bars, shortcuts (courses / books / favourites), latest content; read-only Books screen and collection screens (favourites / review later / important, with the type filter; opened from the Home shortcuts and the Profile lines) | **Done** |
| 1e | **Courses page like Android**: standalone videos, collapsible chapters with progress bars, books, files, watched / no video marks (read-only) | **Done** |
| 1f | **Notes screen** (add / delete), **history screen** (+ clear with confirmation), **heart + bookmark** buttons on lessons / books / files (heart = favourites; bookmark opens the "Save to" sheet with favourites / review later / important). Opened from the Profile lines. Same keys as Android (`notes:<email>`, `hist:<email>`, `fav:<email>`) | **Done** |
| 1g | **Teacher sign-in**: Student / Teacher switch on the sign-in screen (first time = the entered email + password become the teacher account, same keys `t_email` / `t_pw`, same checks and texts as `LoginActivity`). After it the teacher side (`TeacherShell`, part 4a) | **Done** |
| 1h | **PDF reader** (`PdfReaderPage`, Windows.Data.Pdf, one page at a time, previous / next, page counter). Books and files open from Home, Courses, Books and the collection screens. Files live in `%APPDATA%\NEXORA EDU\data\docs\<id>.pdf` (same name rule as Android); a missing file shows the same message | **Done** |
| 2a | **Remove from a collection screen** (trash button on every row, no confirmation, same as Android; counter, chips and Home/Profile counts follow) | **Done** |
| 2b | **Settings sheet** (Profile -> Settings): appearance dark / light, language Arabic / English, log out, close. The sidebar buttons stay | **Done** |
| 2d | **Profile photo** (new on all three apps): Profile -> round photo with add / change / remove; the sidebar card shows it too. Image is saved as a small JPEG (max 512 px, EXIF rotation applied) in `%APPDATA%\\NEXORA EDU\\data\\avatars\\<email with other chars as _>.jpg` (same rule as Android `Store.avatarFile`) | **Done** |
| 2c | **Adding to the history when a lesson is opened** (Courses, Home, History, collection screens; no video = same message as Android). The player opens from `Ui.OpenLesson` | **Done** |
| 2e | **Themes**: palette icon in the Settings sheet -> themes sheet (Nexora + 11 accents). Same ids / colours as Android (`Core/Accents.cs`; colours `th_<id>_1/_2` are generated from Android `colors.xml`). Saved as `accent` in `nexora_settings.json`; `App.ApplyTheme` adds a p1/p2 overlay | **Done** |
| 3 | **In-app video player** (`Views/Student/VideoWindow.cs`, WebView2 + YouTube IFrame player): play / pause, seek bar, skip 5/10/15/30 s (buttons, double-click on the video, arrow keys), speed 0.5x-2x, full screen (button / F / F11 / Esc), resume position, restart, error + retry. Prefs in `%APPDATA%\NEXORA EDU\data\nexora_video.json` (`pos_<id>`, `rate`, `step`, same names as Android) | **Done** |
| 1c | **Hidden admin entry** (hold the logo 7 s) + admin sign-in / create-account; after it the real admin side (part 4b) | **Done** |
| 4a | **Teacher side base** (`Views/Teacher/TeacherShell.cs`): Home counters + tiles, Content, Exams, Profile + Settings | **Done** |
| 4c | **Android parity improvements (release 24)**: teacher student search + class/status filters, activate/deactivate, code generation/copy, edit student details, delete student, student detail page with progress/results/homework; teacher announcements create/edit/delete + student Home display; class management for teacher; edit chapters/lessons, reorder lessons, publish/hide lessons; student profile edit and password change; students only see published lessons. Uses Android-compatible `ann`, `p` keys. | **Implemented; build verification pending** |
| 4b | **Admin side** (`Views/Admin/AdminShell.cs`, port of `AdminActivity`, gold theme): Dashboard (5 counters + add tiles), Teacher (account, change password, delete account), Students (search, class filter, active / inactive, student code generate / copy / new code, delete with confirmation, 2 cards per row), Content (add chapter / lesson / video / book / file / class; class list with delete; all content with delete, lesson opens in the player, PDF in the reader), My account (email, change password, Settings). New in `Core/Store.cs`: `SaveGrades`, `DeleteTeacher`, `SetStudentActive`, `NewStudentCode`, `DeleteStudent` | **Done** |
| 5 | **Exams and homework** (release 13, new on Windows; Android and iPhone got the same screens in release 14). Teacher (`Views/Teacher/TeacherShell.Exams.cs`): chips Exams / Question bank / Homework; add + delete questions (2-4 options, one right answer, optional chapter), create exams from the bank (official / practice), tap an exam for the students' latest results, add + delete homework, read each student's answer (text + photo) and grade it 0-10 with a note; Home shows exams count and answers to grade. Student (`Views/Student/ExamsPage.cs`): official-exams average, exam list with last result, take an exam (one question at a time, review at the end, retake), homework list with status, answer form (text + one photo, edit and resend). Same keys as Android `Store.kt` (`questions`, `exams`, `results`, `homework`, `subs`, photos in `data\\hw`). New in `Core/Store.cs`: Questions / Exams / Results / HomeworkAll / Submissions + writes, `DeleteStudent` now also removes results, answers and photos. Strings: `strings_exams.xml` in Android res (generated into Windows) | **Done**

| 6 | **Paid content (release 35)**: video from YouTube link (title + thumbnail import) or uploaded file (`data\\videos\\<id>.mp4`, `Views/Student/UploadVideoWindow.cs` = skeleton player); Free / Paid price on videos and chapters; student lock + "Paid content" sheet (`Ui.Paywall`); teacher opens content for a student as cash / free with a permanent log (`Store.GrantAccess`, `glog`). Same keys as Android (`pr`, `s`, `th`, `grants`, `glog`). `Core/Access.cs`: `Access.CanView` (one place; local only), `Payments.Start` (skeleton), `YtMeta` | **Done locally; server + payment skeleton** |

## Still missing (NOT built yet)
0. Release 35 skeletons: server-side access check, electronic payment provider, server upload, full controls in `UploadVideoWindow`, admin side still adds free YouTube videos only.
1. Update + backup (Android README "Phase 4b (next)"): not built on any platform.
2. Server + shared accounts and photos (all data is local per device).
3. Exams + homework: admin side has no exam / homework screens yet; no timer; questions are not shuffled.
4. Windows build/runtime verification for release 24 is pending because the .NET SDK is not available in the editing environment.
5. Some Android teacher-management details may still differ; run the full parity checklist on a Windows machine before calling the port complete.

## Folder map
- `NexoraEdu.csproj` - project (net8.0-windows10.0.19041.0, WPF; the Windows 10 target is needed for the PDF reader). `App.xaml(.cs)` - start + theme swap.
- `MainWindow.xaml(.cs)` - window and routing (`Route()`: valid student session -> student side, else sign-in); `Reload()` rebuilds the screen after a language/theme change (RTL in Arabic, LTR in English).
- `Core/` - `Avatar.cs` (profile photo file: load / save / delete), `Store.cs` (data, same keys as Store.kt, file `%APPDATA%\NEXORA EDU\data\nexora_data.json`), `Prefs.cs`, `Strings.cs` (`{loc:T key}` in XAML), `Models.cs`.
- `Views/` - `SplashView`, `LoginView` (student sign-in / sign-up, teacher sign-in, hidden admin sign-in), `Views/Teacher/` - `TeacherShell`. `Views/Admin/` - `AdminShell`.
- `Views/Student/` - `StudentShell` (sidebar + page area, `ShowSub`/`Back` for sub-screens), `HomePage`, `CoursesPage`, `ExamsPage`, `ProfilePage`, `BooksPage`, `CollectionPage`, `NotesPage`, `HistoryPage`, `PdfReaderPage`, `Ui.cs` (row / heading / back-header / heart-bookmark buttons / sheet + confirm helpers).
- `Themes/` - `Styles.xaml` (hand-written), `Colors.Dark.xaml` / `Colors.Light.xaml` (generated, include the `th_*` accent colours). `Core/Accents.cs` - accent theme list.
- `Resources/strings.ar.json`, `strings.en.json` - generated.
- `tools/gen_resources.py` - `python3 tools/gen_resources.py <android>/app/src/main/res` regenerates the 4 generated files (`--check` only verifies; CI runs it).

## What works now
Splash -> sign-in or sign-up (name, phone, email, password 6+, class chosen from the class list) -> student shell -> log out (sidebar).
The session (`s_role` / `s_email`) is saved, so the next start goes straight to the student side.
Students are stored in the same format as the Android app (`students` key, SHA-256 password). Admin: hold the flask logo on the sign-in screen for 7 seconds (no hint while holding; lifting the mouse or leaving the logo cancels). First time = create admin account (email, password 6+, confirm), then a normal sign-in, then the admin side. The admin account uses its own keys (`a_email`, `a_pw`) and the session role is `admin`. Teacher sign-in works (Student / Teacher switch) and opens the real teacher side.
Student pages: favourites, notes, history, profile photo, exams and homework are all interactive.

## Run / build
```
dotnet run
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o out
```
On GitHub: Actions -> "Build Android, iOS and Windows" -> **NexoraEdu-Windows-EXE**. The exe is unsigned (SmartScreen: More info -> Run anyway).

## READ FIRST - how to continue this project (build + update rules)

### 1. Never rebuild from scratch
This project is already built in parts. If you are the next person (or the next Claude session):
1. Unzip `windows.zip` (and `android.zip`, which the Windows build reads) and **edit the existing files**.
2. Do not recreate the project, the csproj, `Themes/`, `Core/` or `tools/`. Add new files or change existing ones only.
3. Keep the same keys as Android (`students`, `notes:<email>`, `hist:<email>`, `fav:<email>`, `t_email`, `t_pw`, `a_email`, `a_pw`, `s_role`, `s_email`).
4. Do not touch what is marked **Done** in the parts table unless the task says so.
5. Do the next part marked **Not started** (see the table above), or only the part you were asked for.

### 2. Build (what to run)
```
python3 tools/gen_resources.py ../android/app/src/main/res --check
dotnet publish NexoraEdu.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o out
```
- Strings and colours come from `android.zip`. If Android strings changed, run `python3 tools/gen_resources.py <android>/app/src/main/res` (without `--check`) and commit the 4 generated files.
- On GitHub just push `.github/ android.zip ios.zip windows.zip README.md VERSION` to the repo root; the workflow builds everything.

### 3. Updating without "version conflict" problems
- Keep the **inner zip names fixed**: `android.zip`, `ios.zip`, `windows.zip` (the workflow unzips these exact names). Replace the file with the new one under the same name.
- Do not add a second copy (`windows (1).zip`, `windows-new.zip`) next to the old one: delete the old one, then add the new one.
- Upload the new files over the old ones in the same commit, so the repo never holds two versions of the same part.

### 4. Every new package MUST get a new name and version (do this every time)
1. Raise `release` in the root `VERSION` file by 1 (6 -> 7 ...).
2. Raise `windows=` in `VERSION` **and** `<Version>` in `NexoraEdu.csproj` to the same number (patch +1 for fixes / docs, minor +1 for a finished part).
3. Name the outer package `NexoraEdu-All-v<release>.zip` (example: `NexoraEdu-All-v7.zip`). Never reuse an old name and never keep "(5)" style browser copies.
4. Add one line to `CHANGELOG.txt` (release, date, what changed, what is still missing).
5. Update the parts table status in this README.

## Build note
Written without a .NET toolchain (no build was run here). If Actions shows a compile error, send the log line.


## Release 24 implementation notes
- Teacher can search/filter students, activate/deactivate accounts, generate/copy access codes, edit basic student information, delete students, and inspect student progress, exam results and homework submissions.
- Teacher can manage announcements; students see the latest announcements on Home.
- Teacher can manage classes, edit chapter and lesson metadata, reorder lessons within their current group, and publish/hide lessons.
- Student profile now supports editing name, phone, grade, and optionally changing the password after current-password verification.
- The Windows data layer reads/writes Android-compatible announcement (`ann`) and lesson published (`p`) fields. Old lessons without `p` remain published for backward compatibility.
- Student course, home, favourites and history views filter hidden lessons.

## Release 28 (0.7.2) - phone verification screen, round 1
- New `Views/OtpView.cs`: `OtpView.Show(phone, verify, onResend, onVerified, onCancel)` opens a sheet (`Ui.Sheet`) with 6 boxes over one invisible TextBox, wrong-code state (red boxes, shake, message), verify button dimmed until 6 digits (Enter also verifies), resend link with a real 60 s countdown.
- `OtpConfig.PhoneOtpEnabled = false`: `Show` returns false and shows nothing while the flag is false. Not connected to `LoginView` yet (round 2).
- Strings `otp_*` come from the Android files (`tools/gen_resources.py`). Do not let the script rewrite `Themes/Colors.*.xaml` without re-adding the `cardGlass` brush.
- Not built here (no .NET SDK): compile with Actions.

## Release 29 (0.7.3) - phone rules + glass entry
- `Core/PhoneRules.cs` (`PhoneRules`, `PhoneVerifier`). `LoginView`: student sign-up phone required, `PhoneError` under the field, `OtpView.Show` before creating the account (flag false = created at once). `SplashView` 3.4 s glass entry, `Views/GlassAurora.xaml` behind splash and sign-in. Not built here.

## Release 31 (0.7.5) - confirm password + teacher sign-up
- `LoginView`: confirm password for a new student; teacher sign-up (code, name, phone optional, confirm) behind the "create a new account" link on the Teacher tab. `Store.SetTeacher(email, pw, phone, name)`, `Store.TeacherName()`. Not built here.

## Release 34 (0.7.7) - themes sheet
`Ui.OpenThemes`: rounded gradient tiles (2 per row, name inside, ring + tick on the chosen one) instead of circles, like Android and iPhone.

## Sound effects (release 46)
`Core/Sfx.cs` + `Resources/Sfx/*.wav` (embedded; same 18 sounds as Android, copied once to %TEMP%\NexoraEdu-sfx). `Sfx.Hook()` (App.OnStartup) gives every button, tab / chip, check box and clickable card its sound; the other hooks are one `Sfx.Play(...)` line each (list in CHANGELOG release 46).
