using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using NexoraEdu.Core;
using NexoraEdu.Views.Student;

namespace NexoraEdu.Views.Admin;

/// <summary>Admin side (port of AdminActivity): sidebar with Dashboard / Teacher / Students / Content / My account, gold theme (ap1 / ap2).
/// Dashboard: 5 counters + "manage content" tiles. Teacher: teacher account, change password, delete account.
/// Students: search, class filter, and on every card active / inactive, student code (generate, copy, new code), delete with confirmation.
/// Content: add buttons, class list (add / delete), all chapters / lessons / videos / books / files with delete. My account: email + change password.
/// Like Android, the add sheets repeat the teacher's on purpose, so TeacherShell stays untouched. Same data keys as every other side.</summary>
public class AdminShell : UserControl
{
    const string GlyphFolder = "\uE8B7", GlyphVideo = "\uE714", GlyphGear = "\uE713", GlyphGrade = "\uE7BE", GlyphKey = "\uE192", GlyphUser = "\uE77B";

    readonly string _email;
    readonly string _name;
    readonly ContentControl _host = new();
    string _tag = "home";
    bool _sub;
    int _gradeSel;       // 0 = all classes, otherwise 1-based index into Store.Grades()
    string _query = "";

    static Style S(string key) => (Style)Application.Current.FindResource(key);
    static string T(string key, params object[] a) => Strings.T(key, a);

    public AdminShell()
    {
        // MainWindow.Route() only opens this screen for a valid admin session.
        _email = Store.Admin()?.Email ?? Store.Session()?.Email ?? "";
        _name = _email.Contains('@') ? _email[.._email.IndexOf('@')] : _email;

        var grid = new Grid();
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(264) });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

        // ---- sidebar (start edge) ----
        var side = new DockPanel { Margin = new Thickness(14) };
        var brand = new TextBlock { Text = "منصة الإبداع", FontSize = 20, FontWeight = FontWeights.Bold };
        brand.SetResourceReference(TextBlock.ForegroundProperty, "tx");
        var top = new StackPanel { Margin = new Thickness(6, 8, 6, 18) };
        top.Children.Add(brand);
        DockPanel.SetDock(top, Dock.Top);
        side.Children.Add(top);

        var bottom = new StackPanel();
        var disc = new Grid { Width = 40, Height = 40, Margin = new Thickness(0, 0, 10, 0), VerticalAlignment = VerticalAlignment.Center };
        var bg = new Ellipse();
        bg.SetResourceReference(Shape.FillProperty, "p1");
        disc.Children.Add(bg);
        var initial = new TextBlock
        {
            Text = string.IsNullOrEmpty(_name) ? "?" : _name[..1].ToUpperInvariant(), FontSize = 16, FontWeight = FontWeights.Bold,
            HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center
        };
        initial.SetResourceReference(TextBlock.ForegroundProperty, "white");
        disc.Children.Add(initial);
        DockPanel.SetDock(disc, Dock.Left);
        var who = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
        who.Children.Add(new TextBlock { Text = _name, Style = S("H2"), TextTrimming = TextTrimming.CharacterEllipsis });
        who.Children.Add(new TextBlock { Text = T("role_admin_label"), Style = S("Muted") });
        var userLine = new DockPanel();
        userLine.Children.Add(disc);
        userLine.Children.Add(who);
        bottom.Children.Add(new Border { Style = S("Card"), Padding = new Thickness(12), Margin = new Thickness(0, 0, 0, 8), Child = userLine });

        var lang = new Button { Style = S("SideButton"), Content = Prefs.Ar ? "English" : "العربية" };
        lang.Click += (_, _) => { Prefs.Ar = !Prefs.Ar; MainWindow.Instance.Reload(); };
        var theme = new Button { Style = S("SideButton"), Content = T(Prefs.Dark ? "light" : "dark") };
        theme.Click += (_, _) => { Prefs.Dark = !Prefs.Dark; MainWindow.Instance.Reload(); };
        var logout = new Button { Style = S("SideButton"), Content = T("logout") };
        logout.Click += (_, _) => { Store.ClearSession(); ServerSync.SignOut(); MainWindow.Instance.ShowLogin(); };
        bottom.Children.Add(lang);
        bottom.Children.Add(theme);
        bottom.Children.Add(logout);
        DockPanel.SetDock(bottom, Dock.Bottom);
        side.Children.Add(bottom);

        var nav = new StackPanel();
        RadioButton home = null;
        void Nav(string glyph, string key, string tag)
        {
            var row = new StackPanel { Orientation = Orientation.Horizontal };
            row.Children.Add(new TextBlock { FontFamily = new FontFamily("Segoe MDL2 Assets"), Text = glyph, FontSize = 18, Margin = new Thickness(0, 0, 12, 0) });
            row.Children.Add(new TextBlock { Text = T(key) });
            var rb = new RadioButton { Style = S("NavButton"), GroupName = "anav", Tag = tag, Content = row };
            rb.Checked += (_, _) => Show(tag);
            // clicking the tab you are already on while a sub-screen is open brings you back to it
            rb.Click += (_, _) => { if (_sub) Show(tag); };
            nav.Children.Add(rb);
            if (tag == "home") home = rb;
        }
        Nav("\uE80F", "tab_dashboard", "home");
        Nav(GlyphUser, "tab_teacher", "teacher");
        Nav("\uE716", "tab_students", "students");
        Nav(GlyphFolder, "tab_content", "content");
        Nav(GlyphKey, "tab_profile", "profile");
        side.Children.Add(nav);

        var sideBorder = new Border { BorderThickness = new Thickness(0, 0, 1, 0), Child = side };
        sideBorder.SetResourceReference(Border.BackgroundProperty, "bar");
        sideBorder.SetResourceReference(Border.BorderBrushProperty, "bd");
        Grid.SetColumn(sideBorder, 0);
        grid.Children.Add(sideBorder);

        var scroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Padding = new Thickness(28, 24, 28, 24), Content = _host };
        Grid.SetColumn(scroll, 1);
        grid.Children.Add(scroll);
        Content = grid;

        home.IsChecked = true;   // after the host exists, so Show() has somewhere to put the page
    }

    // ------------------------------------------------------------------ routing

    void Show(string tag)
    {
        _sub = false;
        _tag = tag ?? "home";
        _host.Content = _tag switch
        {
            "teacher" => TeacherTab(),
            "students" => StudentsTab(),
            "content" => ContentTab(),
            "profile" => AccountTab(),
            _ => DashboardTab(),
        };
    }

    /// <summary>Rebuilds the tab on screen (counters and lists follow the data, like Android's refresh()).</summary>
    void Refresh() => Show(_tag);

    void ShowSub(UserControl page) { _sub = true; _host.Content = page; }

    void Back() { if (_sub) Show(_tag); }

    // ------------------------------------------------------------------ small builders

    static StackPanel PageOf(string titleKey)
    {
        var p = new StackPanel();
        p.Children.Add(new TextBlock { Text = T(titleKey), Style = S("H1"), Margin = new Thickness(0, 0, 0, 16) });
        return p;
    }

    static Border Info(string small, string title, string sub)
    {
        var p = new StackPanel();
        if (!string.IsNullOrEmpty(small)) p.Children.Add(new TextBlock { Text = small, Style = S("Muted") });
        p.Children.Add(new TextBlock { Text = title, Style = S("H2") });
        if (!string.IsNullOrEmpty(sub)) p.Children.Add(new TextBlock { Text = sub, Style = S("Muted"), Margin = new Thickness(0, 2, 0, 0) });
        return new Border { Style = S("Card"), Child = p };
    }

    static Border Stat(int n, string labelKey, string brush)
    {
        var num = new TextBlock { Text = n.ToString(CultureInfo.InvariantCulture), FontSize = 30, FontWeight = FontWeights.Bold };
        num.SetResourceReference(TextBlock.ForegroundProperty, brush);
        var p = new StackPanel();
        p.Children.Add(num);
        p.Children.Add(new TextBlock { Text = T(labelKey), Style = S("Muted") });
        return new Border { Style = S("Card"), Margin = new Thickness(0, 0, 10, 14), Child = p };
    }

    static Border Tile(string glyph, string labelKey, Action click)
    {
        var icon = new TextBlock { FontFamily = new FontFamily("Segoe MDL2 Assets"), Text = glyph, FontSize = 26, HorizontalAlignment = HorizontalAlignment.Center };
        icon.SetResourceReference(TextBlock.ForegroundProperty, "p1");
        var p = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center };
        p.Children.Add(icon);
        p.Children.Add(new TextBlock { Text = T(labelKey), Style = S("H2"), FontSize = 14, TextWrapping = TextWrapping.Wrap, TextAlignment = TextAlignment.Center, Margin = new Thickness(0, 8, 0, 0) });
        var b = new Border { Style = S("Card"), Margin = new Thickness(0, 0, 10, 10), Cursor = Cursors.Hand, Child = p };
        b.MouseLeftButtonUp += (_, _) => click();
        return b;
    }

    static string DateText(long at) =>
        DateTimeOffset.FromUnixTimeMilliseconds(at).LocalDateTime.ToString("yyyy/MM/dd", CultureInfo.InvariantCulture);

    Button Trash(Action delete, string name, string warnKey) =>
        Ui.TrashButton(() => Ui.Confirm(T(warnKey, name), "delete", () => { delete(); Refresh(); }));

    UIElement ContentActions(bool withGrade)
    {
        var g = new UniformGrid
        {
            Columns = 3,
            Children =
            {
                Tile(GlyphFolder, "act_chapter", AddChapterSheet),
                Tile(Ui.GlyphPlay, "act_lesson", AddLessonSheet),
                Tile(GlyphVideo, "act_video", AddVideoSheet),
                Tile(Ui.GlyphBook, "act_book", () => AddDocSheet("book")),
                Tile(Ui.GlyphFile, "act_file", () => AddDocSheet("file")),
            }
        };
        if (withGrade) g.Children.Add(Tile(GlyphGrade, "act_grade", AddGradeSheet));
        return g;
    }

    // ------------------------------------------------------------------ dashboard

    UIElement DashboardTab()
    {
        var p = PageOf("tab_dashboard");
        AddAlerts(p);   // release 56: sign-in alerts first (only the main admin gets rows from the server)
        p.Children.Add(new UniformGrid
        {
            Columns = 3,
            Children =
            {
                Stat(Store.Students().Count, "stat_students", "p1"),
                Stat(Store.Grades().Count, "stat_classes", "p2"),
                Stat(Store.Chapters().Count, "stat_chapters", "gold"),
                Stat(Store.Lessons().Count, "stat_lessons", "p1"),
                Stat(Store.Docs().Count, "stat_files", "p2"),
            }
        });
        p.Children.Add(Ui.Heading(T("manage_content")));
        p.Children.Add(ContentActions(false));
        return p;
    }

    // ------------------------------------------------------------------ teacher

    UIElement TeacherTab()
    {
        var p = PageOf("tab_teacher");
        var t = Store.Teacher();
        if (t == null)
        {
            p.Children.Add(Ui.Empty("adm_no_teacher", "adm_no_teacher_sub"));
            AddStaff(p);
            return p;
        }
        var teacherEmail = t.Value.Email;
        var name = Store.TeacherName();
        if (name.Length == 0) name = teacherEmail.Contains('@') ? teacherEmail[..teacherEmail.IndexOf('@')] : teacherEmail;
        p.Children.Add(Info(T("role_teacher_label"), name, null));
        p.Children.Add(Info(T("email_label"), teacherEmail, null));
        p.Children.Add(Primary(T("adm_change_pw"), 16, (_, _) => ChangeTeacherPwSheet(teacherEmail)));
        var del = new Button { Style = S("LinkButton"), Content = T("adm_delete_teacher"), HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 14, 0, 0) };
        del.SetResourceReference(Control.ForegroundProperty, "err");
        del.Click += (_, _) => Ui.Confirm(T("confirm_delete_teacher"), "delete", () => { Store.DeleteTeacher(); Refresh(); });
        p.Children.Add(del);
        AddStaff(p);
        return p;
    }

    // ------------------------------------------------------------------ release 56: server accounts + sign-in alerts (the server decides every right)

    static Border Badge(string text, string brush)
    {
        var tb = new TextBlock { Text = text, FontSize = 11, FontWeight = FontWeights.SemiBold, Margin = new Thickness(8, 2, 8, 2) };
        tb.SetResourceReference(TextBlock.ForegroundProperty, brush);
        var b = new Border { CornerRadius = new CornerRadius(10), BorderThickness = new Thickness(1), Margin = new Thickness(0, 0, 8, 0), VerticalAlignment = VerticalAlignment.Center, Child = tb };
        b.SetResourceReference(Border.BorderBrushProperty, brush);
        return b;
    }

    Button RemoveButton(Action click)
    {
        var b = new Button { Style = S("LinkButton"), Content = T("adm_remove") };
        b.SetResourceReference(Control.ForegroundProperty, "err");
        b.Click += (_, _) => click();
        return b;
    }

    /// <summary>"Teacher and admin accounts on the server" (staff_list). Teacher: any admin removes. Admin: only the main admin removes.</summary>
    async void AddStaff(StackPanel p)
    {
        p.Children.Add(Ui.Heading(T("adm_staff_title")));
        if (AdminControl.IsMain) p.Children.Add(Primary(T("adm_newcode"), 4, (_, _) => NewAdminCodeSheet()));   // release 57
        var box = new StackPanel();
        p.Children.Add(box);
        if (!Remote.Enabled || !Remote.SignedIn) { box.Children.Add(new TextBlock { Text = T("adm_staff_fail"), Style = S("Muted") }); return; }
        var list = await AdminControl.StaffAsync();
        box.Children.Clear();
        if (list == null) { box.Children.Add(new TextBlock { Text = T("adm_staff_fail"), Style = S("Muted") }); return; }
        if (list.Count == 0) { box.Children.Add(new TextBlock { Text = T("adm_staff_empty"), Style = S("Muted") }); return; }
        var me = Remote.UserId;
        foreach (var m in list)
        {
            var isMe = me.Length > 0 && string.Equals(m.Id, me, StringComparison.OrdinalIgnoreCase);
            var trailing = new List<UIElement>();
            if (m.Removed) trailing.Add(Badge(T("adm_removed_badge"), "err"));
            if (isMe) trailing.Add(Badge(T("adm_you_badge"), "p1"));
            if (m.Main) trailing.Add(Badge(T("adm_main_badge"), "gold"));
            var canRemove = !m.Removed && !m.Main && !isMe && (m.Role == "teacher" || AdminControl.IsMain);
            if (canRemove)
            {
                var who = string.IsNullOrEmpty(m.Name) ? m.Email : m.Name;
                var member = m;
                trailing.Add(RemoveButton(() => Ui.Confirm(T(member.Role == "admin" ? "confirm_remove_admin" : "confirm_remove_teacher", who), "adm_remove", async () =>
                {
                    var ok = await AdminControl.RemoveAsync(member.Id);
                    if (ok) { Ui.Notice(T("adm_removed")); Refresh(); } else Ui.Notice(T("err_remove_fail"));
                })));
            }
            var role = T(m.Role == "admin" ? "role_admin_label" : "role_teacher_label");
            var row = Ui.Row(GlyphUser, string.IsNullOrEmpty(m.Name) ? m.Email : m.Name, role + " · " + m.Email, trailing);
            row.Margin = new Thickness(0, 0, 0, 8);
            box.Children.Add(row);
        }
    }

    /// <summary>Release 57, main admin only: asks the server for a one-time code (valid for one new admin, 7 days) and shows it to copy.</summary>
    async void NewAdminCodeSheet()
    {
        var code = await AdminControl.NewCodeAsync();
        if (code == null) { Ui.Notice(T("adm_newcode_fail")); return; }
        Ui.Sheet(T("adm_newcode"), (c, w) =>
        {
            c.Children.Add(new TextBlock { Text = T("adm_newcode_note"), Style = S("Muted"), Margin = new Thickness(0, 10, 0, 0), TextWrapping = TextWrapping.Wrap });
            var big = new TextBlock
            {
                Text = code, FontFamily = new FontFamily("Consolas"), FontSize = 26, FontWeight = FontWeights.Bold,
                TextAlignment = TextAlignment.Center, FlowDirection = FlowDirection.LeftToRight
            };
            big.SetResourceReference(TextBlock.ForegroundProperty, "tx");
            var box = new Border { CornerRadius = new CornerRadius(12), Padding = new Thickness(14, 18, 14, 18), Margin = new Thickness(0, 12, 0, 0), Child = big };
            box.SetResourceReference(Border.BackgroundProperty, "field");
            c.Children.Add(box);
            var info = new TextBlock { Style = S("Muted"), Margin = new Thickness(0, 10, 0, 0), TextWrapping = TextWrapping.Wrap, Visibility = Visibility.Collapsed };
            c.Children.Add(Primary(T("stu_copy"), 14, (_, _) =>
            {
                try { Clipboard.SetText(big.Text); Say(info, "stu_copied"); }
                catch { }
            }));
            c.Children.Add(info);
            var close = new Button { Style = S("LinkButton"), Content = T("close"), HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 12, 0, 0) };
            close.Click += (_, _) => w.Close();
            c.Children.Add(close);
        });
    }

    /// <summary>"Sign-in alerts" card (events). The server returns an empty list to anyone but the main admin, so there is no local check.</summary>
    async void AddAlerts(StackPanel p)
    {
        var box = new StackPanel();
        p.Children.Add(box);
        if (!Remote.Enabled || !Remote.SignedIn) return;
        var list = await AdminControl.EventsAsync();
        if (list == null || list.Count == 0) return;
        box.Children.Add(Ui.Heading(T("alerts_title")));
        foreach (var e in list)
        {
            var ev = e;
            var when = ev.At == DateTime.MinValue ? "" : ev.At.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture);
            var row = Ui.Row(GlyphUser, AdminControl.AlertText(ev), ev.Email + (when.Length > 0 ? " · " + when : ""), new UIElement[]
            {
                RemoveButton(() => Ui.Confirm(T(ev.Role == "admin" ? "confirm_remove_admin" : "confirm_remove_teacher", string.IsNullOrEmpty(ev.Name) ? ev.Email : ev.Name), "adm_remove", async () =>
                {
                    var ok = await AdminControl.RemoveAsync(ev.UserId);
                    if (ok) { Ui.Notice(T("adm_removed")); Refresh(); } else Ui.Notice(T("err_remove_fail"));
                }))
            });
            row.Margin = new Thickness(0, 0, 0, 8);
            box.Children.Add(row);
        }
        var mark = new Button { Style = S("LinkButton"), Content = T("alerts_mark_read"), HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 4, 0, 14) };
        mark.Click += async (_, _) => { await AdminControl.MarkSeenAsync(); Refresh(); };
        box.Children.Add(mark);
    }

    void ChangeTeacherPwSheet(string teacherEmail) =>
        Ui.Sheet(T("adm_change_pw"), (c, w) =>
        {
            var pw = PwField(c, "hint_new_password");
            var err = ErrLine(c);
            c.Children.Add(Primary(T("done"), 16, (_, _) =>
            {
                if (pw.Password.Length < 6) { Say(err, "err_teacher_short"); return; }
                Store.SetTeacher(teacherEmail, pw.Password, name: Store.TeacherName()); // keep the teacher's name
                w.Close(); Ui.Notice(T("pw_changed"));
            }));
            c.Children.Add(Cancel(w));
        });

    // ------------------------------------------------------------------ students

    UIElement StudentsTab()
    {
        var p = PageOf("tab_students");
        if (Store.Students().Count == 0)
        {
            p.Children.Add(Ui.Empty("empty_students", "empty_students_sub"));
            return p;
        }
        var grades = Store.Grades();
        if (_gradeSel > grades.Count) _gradeSel = 0;

        p.Children.Add(new TextBlock { Text = T("hint_search"), Style = S("Muted"), Margin = new Thickness(0, 0, 0, 4) });
        var search = new TextBox { Style = S("Field"), Text = _query, Margin = new Thickness(0, 0, 0, 12) };
        p.Children.Add(search);

        var list = new UniformGrid { Columns = 2 };
        void Fill()
        {
            list.Children.Clear();
            var q = _query.Trim().ToLowerInvariant();
            var grade = _gradeSel > 0 && _gradeSel <= grades.Count ? grades[_gradeSel - 1] : null;
            var shown = Store.Students().Where(s =>
                (grade == null || s.Grade == grade) &&
                (q.Length == 0 || s.Name.ToLowerInvariant().Contains(q) || s.Email.ToLowerInvariant().Contains(q))).ToList();
            if (shown.Count == 0)
            {
                // an UniformGrid cell is half the width, so the empty message gets the first cell only
                list.Children.Add(Ui.Empty("empty_search", "empty_search_sub"));
                return;
            }
            foreach (var s in shown) list.Children.Add(StudentCard(s, Fill));
        }

        search.TextChanged += (_, _) => { _query = search.Text; Fill(); };

        var chips = new WrapPanel { Margin = new Thickness(0, 0, 0, 8) };
        var names = new List<string> { T("all") };
        names.AddRange(grades);
        for (var i = 0; i < names.Count; i++)
        {
            var idx = i;
            var rb = new RadioButton { Style = S("Chip"), GroupName = "agrade", Content = names[i], IsChecked = i == _gradeSel };
            rb.Checked += (_, _) => { _gradeSel = idx; Fill(); };
            chips.Children.Add(rb);
        }
        p.Children.Add(chips);
        p.Children.Add(list);
        Fill();
        return p;
    }

    /// <summary>One student: class, name, email, then active switch, code and delete. <paramref name="changed"/> rebuilds the list.</summary>
    Border StudentCard(NexoraEdu.Core.Student s, Action changed)
    {
        var p = new StackPanel();
        p.Children.Add(new TextBlock { Text = s.Grade, Style = S("Muted") });
        p.Children.Add(new TextBlock { Text = s.Name, Style = S("H2"), TextTrimming = TextTrimming.CharacterEllipsis });
        p.Children.Add(new TextBlock { Text = s.Email, Style = S("Muted"), Margin = new Thickness(0, 2, 0, 0), TextTrimming = TextTrimming.CharacterEllipsis });

        var row = new DockPanel { Margin = new Thickness(0, 12, 0, 0) };
        var trash = Ui.TrashButton(() => Ui.Confirm(T("confirm_delete_student", s.Name), "delete", async () =>
        {
            // release 58: also remove the student on the server (no network = nothing is deleted, so it can be retried; refused = this account is not a real admin there, only the local copy goes)
            if (Remote.Enabled && Remote.SignedIn)
            {
                var code = await AdminControl.RemoveStudentAsync(s.Email);
                if (code <= 0 || code >= 500) { Ui.Notice(T("err_remove_fail")); return; }
            }
            Store.DeleteStudent(s.Email); changed();
        }));
        DockPanel.SetDock(trash, Dock.Right);   // end side (mirrors in Arabic)
        row.Children.Add(trash);

        var chips = new WrapPanel { VerticalAlignment = VerticalAlignment.Center };
        var active = new RadioButton { Style = S("Chip"), GroupName = "a" + Guid.NewGuid().ToString("N"), Content = T(s.Active ? "stu_active" : "stu_inactive"), IsChecked = s.Active };
        active.Click += (_, _) => { Store.SetStudentActive(s.Email, !s.Active); changed(); };
        chips.Children.Add(active);

        var code = new RadioButton { Style = S("Chip"), GroupName = "a" + Guid.NewGuid().ToString("N"), Content = s.Code.Length == 0 ? T("stu_code_new") : s.Code, IsChecked = false };
        if (s.Code.Length > 0)
        {
            code.FontFamily = new FontFamily("Consolas");
            code.FontWeight = FontWeights.Bold;
            code.FlowDirection = FlowDirection.LeftToRight;
        }
        code.Click += (_, _) => { code.IsChecked = false; CodeSheet(s.Email, changed); };
        chips.Children.Add(code);
        row.Children.Add(chips);
        p.Children.Add(row);

        return new Border { Style = S("Card"), Margin = new Thickness(0, 0, 10, 10), Child = p };
    }

    /// <summary>Makes a code the first time, then shows it (copy / new code).</summary>
    void CodeSheet(string studentEmail, Action changed)
    {
        var st = Store.FindStudent(studentEmail);
        if (st == null) return;
        var code = st.Code;
        if (code.Length == 0) { code = Store.NewStudentCode(studentEmail); changed(); }
        Ui.Sheet(T("stu_code_title"), (c, w) =>
        {
            c.Children.Add(new TextBlock { Text = T("stu_code_note"), Style = S("Muted"), Margin = new Thickness(0, 10, 0, 0), TextWrapping = TextWrapping.Wrap });
            var big = new TextBlock
            {
                Text = code, FontFamily = new FontFamily("Consolas"), FontSize = 26, FontWeight = FontWeights.Bold,
                TextAlignment = TextAlignment.Center, FlowDirection = FlowDirection.LeftToRight
            };
            big.SetResourceReference(TextBlock.ForegroundProperty, "tx");
            var box = new Border { CornerRadius = new CornerRadius(12), Padding = new Thickness(14, 18, 14, 18), Margin = new Thickness(0, 12, 0, 0), Child = big };
            box.SetResourceReference(Border.BackgroundProperty, "field");
            c.Children.Add(box);

            var info = new TextBlock { Style = S("Muted"), Margin = new Thickness(0, 10, 0, 0), TextWrapping = TextWrapping.Wrap, Visibility = Visibility.Collapsed };
            c.Children.Add(Primary(T("stu_copy"), 14, (_, _) =>
            {
                try { Clipboard.SetText(big.Text); Say(info, "stu_copied"); }
                catch { }
            }));
            c.Children.Add(info);

            var regen = new Button { Style = S("LinkButton"), Content = T("stu_code_regen"), HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 12, 0, 0) };
            regen.Click += (_, _) => { big.Text = Store.NewStudentCode(studentEmail); info.Visibility = Visibility.Collapsed; changed(); };
            c.Children.Add(regen);

            var close = new Button { Style = S("LinkButton"), Content = T("close"), HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 10, 0, 0) };
            close.Click += (_, _) => w.Close();
            c.Children.Add(close);
        });
    }

    // ------------------------------------------------------------------ content

    UIElement ContentTab()
    {
        var p = PageOf("tab_content");
        p.Children.Add(ContentActions(true));

        p.Children.Add(Ui.Heading(T("classes_title")));
        var grades = Store.Grades();
        var students = Store.Students();
        foreach (var gr in grades)
        {
            var g = gr;
            p.Children.Add(Ui.Row(GlyphGrade, g, T("students_count", students.Count(s => s.Grade == g)),
                new UIElement[] { Trash(() => Store.SaveGrades(Store.Grades().Where(x => x != g).ToList()), g, "confirm_delete_grade") }));
        }

        var chapters = Store.Chapters();
        var lessons = Store.Lessons();
        var docs = Store.Docs();
        if (chapters.Count == 0 && lessons.Count == 0 && docs.Count == 0)
        {
            p.Children.Add(Ui.Empty("empty_content", "empty_content_sub"));
            return p;
        }

        var videos = lessons.Where(l => l.ChapterId.Length == 0).ToList();
        if (videos.Count > 0)
        {
            p.Children.Add(Ui.Heading(T("videos")));
            foreach (var l in videos) p.Children.Add(LessonRow(l));
        }

        if (chapters.Count > 0) p.Children.Add(Ui.Heading(T("chapters_title")));
        foreach (var ch in chapters)
        {
            var c = ch;
            var ls = lessons.Where(l => l.ChapterId == c.Id).ToList();
            p.Children.Add(Ui.Row(GlyphFolder, c.Title, T("lessons_count", ls.Count),
                new UIElement[] { Trash(() => Store.DeleteChapter(c.Id), c.Title, "confirm_delete_chapter") }));
            foreach (var l in ls) p.Children.Add(LessonRow(l));
        }

        var books = docs.Where(d => d.Kind == "book").ToList();
        if (books.Count > 0)
        {
            p.Children.Add(Ui.Heading(T("books_title")));
            foreach (var d in books) p.Children.Add(DocRow(d));
        }
        var files = docs.Where(d => d.Kind == "file").ToList();
        if (files.Count > 0)
        {
            p.Children.Add(Ui.Heading(T("files_title")));
            foreach (var d in files) p.Children.Add(DocRow(d));
        }
        return p;
    }

    UIElement LessonRow(Lesson l) =>
        Ui.Row(Ui.GlyphPlay, l.Title, !Store.HasVideo(l) ? T("no_video_yet") : l.Src == "up" ? T("lesson_video_upload") : "YouTube",
            new UIElement[] { Trash(() => Store.SaveLessons(Store.Lessons().Where(x => x.Id != l.Id).ToList()), l.Title, "confirm_delete") },
            () => Ui.OpenLesson(l, null));   // the admin's viewing does not go into any student's history

    UIElement DocRow(Doc d) =>
        Ui.Row(d.Kind == "book" ? Ui.GlyphBook : Ui.GlyphFile, d.Title, DateText(d.At),
            new UIElement[] { Trash(() => Store.DeleteDoc(d.Id), d.Title, "confirm_delete") },
            () => OpenDoc(d));

    void OpenDoc(Doc d)
    {
        var path = Store.DocFile(d.Id);
        if (!File.Exists(path)) { Ui.Notice(T("err_no_file")); return; }
        ShowSub(new PdfReaderPage(Back, d.Title, path));
    }

    // ------------------------------------------------------------------ my account

    UIElement AccountTab()
    {
        var p = PageOf("tab_profile");
        p.Children.Add(Info(T("role_admin_label"), _name, null));
        p.Children.Add(Info(T("email_label"), _email, null));
        p.Children.Add(Primary(T("adm_change_pw"), 16, (_, _) => ChangeMyPwSheet()));
        p.Children.Add(Primary(T("adm_storage"), 12, (_, _) => StorageSheet()));
        p.Children.Add(new Border { Height = 14 });
        p.Children.Add(Ui.Row(GlyphGear, T("settings"), null, null, Ui.OpenSettings));
        return p;
    }

    void ChangeMyPwSheet() =>
        Ui.Sheet(T("adm_change_pw"), (c, w) =>
        {
            var old = PwField(c, "hint_current_password");
            var neu = PwField(c, "hint_new_password");
            var err = ErrLine(c);
            c.Children.Add(Primary(T("done"), 16, (_, _) =>
            {
                var a = Store.Admin();
                if (a == null) return;
                if (old.Password.Length == 0 || neu.Password.Length == 0) { Say(err, "err_enter_creds"); return; }
                if (a.Value.PwHash != Store.Hash(old.Password)) { Say(err, "err_pw_wrong"); return; }
                if (neu.Password.Length < 6) { Say(err, "err_teacher_short"); return; }
                Store.SetAdmin(a.Value.Email, neu.Password);
                w.Close(); Ui.Notice(T("pw_changed"));
            }));
            c.Children.Add(Cancel(w));
        });

    // ------------------------------------------------------------------ storage (display only; the admin edits name, limit, on/off and order)
    // No R2 key, endpoint, bucket or size cap is known here: the server decides and refuses what is not allowed.

    static string StorageBytes(long b) => b >= (1L << 30)
        ? ((double)b / (1L << 30)).ToString("0.00", CultureInfo.InvariantCulture) + " GB"
        : ((double)b / (1L << 20)).ToString("0", CultureInfo.InvariantCulture) + " MB";

    static string StorageGb(long b)
    {
        var v = (double)b / (1L << 30);
        return v == Math.Floor(v) ? ((long)v).ToString(CultureInfo.InvariantCulture) : v.ToString("0.00", CultureInfo.InvariantCulture);
    }

    /// <summary>Arabic-Indic digits and the Arabic decimal mark -> plain digits and ".".</summary>
    static string LatinNumber(string s)
    {
        var o = new System.Text.StringBuilder();
        foreach (var ch in (s ?? "").Trim())
        {
            if (ch >= '\u0660' && ch <= '\u0669') o.Append((char)('0' + (ch - '\u0660')));
            else if (ch == '\u066B' || ch == ',' || ch == '\u060C') o.Append('.');
            else o.Append(ch);
        }
        return o.ToString();
    }

    void StorageSheet() => Ui.Sheet(T("adm_storage"), (c, w) => StorageList(c, w));

    async void StorageList(StackPanel c, Window w)
    {
        c.Children.Clear();
        if (!Remote.Enabled)
        {
            c.Children.Add(new TextBlock { Text = T("st_not_ready"), Style = S("Muted"), TextWrapping = TextWrapping.Wrap });
            return;
        }
        var wait = new ProgressBar { IsIndeterminate = true, Height = 6, Margin = new Thickness(0, 16, 0, 0), BorderThickness = new Thickness(0) };
        wait.SetResourceReference(ProgressBar.ForegroundProperty, "p1");
        wait.SetResourceReference(ProgressBar.BackgroundProperty, "field");
        c.Children.Add(wait);
        var list = await Remote.StoragesAsync();
        if (!w.IsVisible) return;
        c.Children.Clear();
        if (list == null)
        {
            var e = new TextBlock { Text = T("st_load_fail"), Style = S("Muted"), TextWrapping = TextWrapping.Wrap };
            e.SetResourceReference(TextBlock.ForegroundProperty, "err");
            c.Children.Add(e);
            c.Children.Add(Primary(T("st_retry"), 12, (_, _) => StorageList(c, w)));
            return;
        }
        if (list.Count == 0)
        {
            c.Children.Add(new TextBlock { Text = T("st_empty"), Style = S("H2"), TextWrapping = TextWrapping.Wrap });
            c.Children.Add(new TextBlock { Text = T("st_empty_sub"), Style = S("Muted"), TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 4, 0, 0) });
        }
        foreach (var s in list) c.Children.Add(StorageRow(c, w, s));
    }

    Border StorageRow(StackPanel c, Window w, Remote.StorageInfo s)
    {
        var p = new StackPanel();
        var head = new DockPanel();
        var tag = new TextBlock { Text = T(s.Active ? "st_on" : "st_off"), Style = S("Muted"), FontWeight = FontWeights.Bold, VerticalAlignment = VerticalAlignment.Center };
        if (!s.Active) tag.SetResourceReference(TextBlock.ForegroundProperty, "err");
        DockPanel.SetDock(tag, Dock.Right);   // end side (mirrors in Arabic)
        head.Children.Add(tag);
        head.Children.Add(new TextBlock { Text = s.Name, Style = S("H2"), TextTrimming = TextTrimming.CharacterEllipsis });
        p.Children.Add(head);
        var bar = new ProgressBar { Height = 10, Minimum = 0, Maximum = 100, BorderThickness = new Thickness(0), Margin = new Thickness(0, 10, 0, 0), Value = s.Fraction * 100 };
        bar.SetResourceReference(ProgressBar.ForegroundProperty, "p1");
        bar.SetResourceReference(ProgressBar.BackgroundProperty, "field");
        p.Children.Add(bar);
        p.Children.Add(new TextBlock { Text = T("st_used_fmt", StorageBytes(s.UsedBytes + s.ReservedBytes), StorageBytes(s.LimitBytes)), Style = S("Muted"), Margin = new Thickness(0, 8, 0, 0) });
        if (s.ReservedBytes > 0)
            p.Children.Add(new TextBlock { Text = T("st_reserved_fmt", StorageBytes(s.ReservedBytes)), Style = S("Muted"), Margin = new Thickness(0, 2, 0, 0) });
        var card = new Border { Style = S("Card"), Child = p, Cursor = Cursors.Hand };   // default Card margin, like every other card
        card.MouseLeftButtonUp += (_, _) => StorageForm(c, w, s);
        return card;
    }

    void StorageForm(StackPanel c, Window w, Remote.StorageInfo s)
    {
        c.Children.Clear();
        var name = Field(c, "st_name_hint"); name.Text = s.Name;
        var limit = Field(c, "st_limit_hint", true); limit.Text = StorageGb(s.LimitBytes);
        var order = Field(c, "st_order_hint", true); order.Text = s.SortOrder.ToString(CultureInfo.InvariantCulture);
        c.Children.Add(new TextBlock { Text = T("st_switch"), Style = S("Muted"), Margin = new Thickness(0, 14, 0, 4) });
        var active = s.Active;
        var sw = new RadioButton { Style = S("Chip"), GroupName = "a" + Guid.NewGuid().ToString("N"), Content = T(active ? "st_on" : "st_off"), IsChecked = active };
        sw.Click += (_, _) => { active = !active; sw.IsChecked = active; sw.Content = T(active ? "st_on" : "st_off"); };
        c.Children.Add(new WrapPanel { Children = { sw } });
        var err = ErrLine(c);
        var busy = false;
        c.Children.Add(Primary(T("done"), 16, async (_, _) =>
        {
            if (busy) return;
            var n = name.Text.Trim();
            if (n.Length == 0) { Say(err, "err_title"); return; }
            if (!double.TryParse(LatinNumber(limit.Text), NumberStyles.Float, CultureInfo.InvariantCulture, out var gb) || gb <= 0) { Say(err, "st_bad_limit"); return; }
            var o = int.TryParse(LatinNumber(order.Text), NumberStyles.Integer, CultureInfo.InvariantCulture, out var oi) ? oi : s.SortOrder;
            busy = true;
            var ok = await Remote.UpdateStorageAsync(s with { Name = n, LimitBytes = (long)(gb * (1L << 30)), SortOrder = o, Active = active });
            busy = false;
            if (ok) { Ui.Notice(T("st_saved")); StorageList(c, w); }
            else Say(err, "st_save_fail");
        }));
        var back = new Button { Style = S("LinkButton"), Content = T("cancel"), HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 10, 0, 0) };
        back.Click += (_, _) => StorageList(c, w);
        c.Children.Add(back);
    }

    // ------------------------------------------------------------------ add sheets (same as the teacher's, plus class)

    static TextBox Field(StackPanel c, string hintKey, bool ltr = false)
    {
        c.Children.Add(new TextBlock { Text = T(hintKey), Style = S("Muted"), Margin = new Thickness(0, 10, 0, 4) });
        var tb = new TextBox { Style = S("Field") };
        if (ltr) tb.FlowDirection = FlowDirection.LeftToRight;
        c.Children.Add(tb);
        return tb;
    }

    static PasswordBox PwField(StackPanel c, string hintKey)
    {
        c.Children.Add(new TextBlock { Text = T(hintKey), Style = S("Muted"), Margin = new Thickness(0, 10, 0, 4) });
        var pb = new PasswordBox { Style = S("PassField"), FlowDirection = FlowDirection.LeftToRight };
        c.Children.Add(pb);
        return pb;
    }

    /// <summary>Error line inside a sheet (Android shows a toast; here it stays in the sheet).</summary>
    static TextBlock ErrLine(StackPanel c)
    {
        var e = new TextBlock { Style = S("Muted"), Margin = new Thickness(0, 10, 0, 0), TextWrapping = TextWrapping.Wrap, Visibility = Visibility.Collapsed };
        e.SetResourceReference(TextBlock.ForegroundProperty, "err");
        c.Children.Add(e);
        return e;
    }

    static void Say(TextBlock e, string key) { e.Text = T(key); e.Visibility = Visibility.Visible; }

    static Button Primary(string text, int top, RoutedEventHandler click)
    {
        var b = new Button { Style = S("PrimaryButton"), Content = text, Margin = new Thickness(0, top, 0, 0) };
        b.Click += click;
        return b;
    }

    static Button Cancel(Window w)
    {
        var b = new Button { Style = S("LinkButton"), Content = T("cancel"), HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 10, 0, 0) };
        b.Click += (_, _) => w.Close();
        return b;
    }

    static string YoutubeId(string url) => Store.YoutubeId(url);

    void AddGradeSheet() =>
        Ui.Sheet(T("act_grade"), (c, w) =>
        {
            var name = Field(c, "hint_grade");
            var err = ErrLine(c);
            c.Children.Add(Primary(T("add"), 16, (_, _) =>
            {
                var n = name.Text.Trim();
                if (n.Length == 0) { Say(err, "err_title"); return; }
                var all = Store.Grades();
                if (all.Any(g => g == n)) { Say(err, "err_grade_exists"); return; }
                all.Add(n);
                Store.SaveGrades(all);
                w.Close(); Refresh();
            }));
            c.Children.Add(Cancel(w));
        });

    void AddChapterSheet() =>
        Ui.Sheet(T("act_chapter"), (c, w) =>
        {
            var title = Field(c, "hint_title");
            var err = ErrLine(c);
            c.Children.Add(Primary(T("add"), 16, (_, _) =>
            {
                var t = title.Text.Trim();
                if (t.Length == 0) { Say(err, "err_title"); return; }
                var all = Store.Chapters();
                all.Add(new Chapter { Id = Store.NewId(), Title = t });
                Store.SaveChapters(all);
                w.Close(); Refresh();
            }));
            c.Children.Add(Cancel(w));
        });

    void AddLessonSheet()
    {
        var chapters = Store.Chapters();
        if (chapters.Count == 0) { Ui.Notice(T("err_add_chapter_first")); return; }
        Ui.Sheet(T("act_lesson"), (c, w) =>
        {
            var sel = 0;
            var title = Field(c, "hint_title");
            c.Children.Add(new TextBlock { Text = T("pick_chapter"), Style = S("Muted"), Margin = new Thickness(0, 14, 0, 0) });
            var chips = new WrapPanel { Margin = new Thickness(0, 8, 0, 0) };
            for (var i = 0; i < chapters.Count; i++)
            {
                var idx = i;
                var rb = new RadioButton { Style = S("Chip"), GroupName = "achapter", Content = chapters[i].Title, IsChecked = i == 0 };
                rb.Checked += (_, _) => sel = idx;
                chips.Children.Add(rb);
            }
            c.Children.Add(chips);
            var url = Field(c, "hint_youtube_optional", true);
            var err = ErrLine(c);
            c.Children.Add(Primary(T("add"), 16, (_, _) =>
            {
                var t = title.Text.Trim();
                if (t.Length == 0) { Say(err, "err_title"); return; }
                var raw = url.Text.Trim();
                var yt = raw.Length == 0 ? "" : YoutubeId(raw);
                if (raw.Length > 0 && yt.Length == 0) { Say(err, "err_bad_link"); return; }
                var all = Store.Lessons();
                all.Add(new Lesson { Id = Store.NewId(), ChapterId = chapters[sel].Id, Title = t, Yt = yt, At = Store.Now() });
                Store.SaveLessons(all);
                w.Close(); Refresh();
            }));
            c.Children.Add(Cancel(w));
        });
    }

    void AddVideoSheet() =>
        Ui.Sheet(T("act_video"), (c, w) =>
        {
            var title = Field(c, "hint_title");
            var url = Field(c, "hint_youtube", true);
            var err = ErrLine(c);
            c.Children.Add(Primary(T("add"), 16, (_, _) =>
            {
                var t = title.Text.Trim();
                if (t.Length == 0) { Say(err, "err_title"); return; }
                var yt = YoutubeId(url.Text);
                if (yt.Length == 0) { Say(err, "err_bad_link"); return; }
                var all = Store.Lessons();
                all.Add(new Lesson { Id = Store.NewId(), ChapterId = "", Title = t, Yt = yt, At = Store.Now() });
                Store.SaveLessons(all);
                w.Close(); Refresh();
            }));
            c.Children.Add(Cancel(w));
        });

    void AddDocSheet(string kind) =>
        Ui.Sheet(T(kind == "book" ? "act_book" : "act_file"), (c, w) =>
        {
            string picked = null;
            var busy = false;
            var title = Field(c, "hint_title");
            var chosen = new TextBlock { Style = S("Muted"), Margin = new Thickness(0, 4, 0, 0) };
            var choose = new Button { Style = S("LinkButton"), Content = T("choose_pdf"), HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 8, 0, 0) };
            choose.Click += (_, _) =>
            {
                var dlg = new Microsoft.Win32.OpenFileDialog { Filter = "PDF|*.pdf|All files|*.*" };
                if (dlg.ShowDialog(w) != true) return;
                picked = dlg.FileName;
                chosen.Text = T("pdf_selected");
            };
            c.Children.Add(choose);
            c.Children.Add(chosen);
            var err = ErrLine(c);
            c.Children.Add(Primary(T("add"), 12, async (_, _) =>
            {
                var t = title.Text.Trim();
                if (t.Length == 0) { Say(err, "err_title"); return; }
                if (picked == null) { Say(err, "err_pick_pdf"); return; }
                if (busy) return;
                busy = true;
                Say(err, "saving");
                var id = Store.NewId();
                var src = picked;
                try
                {
                    var dst = Store.DocFile(id);
                    Directory.CreateDirectory(System.IO.Path.GetDirectoryName(dst)!);
                    await Task.Run(() => File.Copy(src, dst, true));
                    var all = Store.Docs();
                    all.Add(new Doc { Id = id, Title = t, Kind = kind, At = Store.Now() });
                    Store.SaveDocs(all);
                    w.Close(); Refresh();
                }
                catch
                {
                    try { File.Delete(Store.DocFile(id)); } catch { }
                    Say(err, "err_copy");
                }
                finally { busy = false; }
            }));
            c.Children.Add(Cancel(w));
        });
}
