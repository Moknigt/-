using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using NexoraEdu.Core;

namespace NexoraEdu.Views;

/// <summary>Release 56: the Windows "notification" for the main admin. Windows has no push, so while the app is open a small topmost card appears
/// at the bottom corner for about 8 seconds (same text as the Android notification). Needs no extra package.</summary>
public static class AlertToast
{
    public static void Show(List<AdminControl.Event> fresh)
    {
        if (fresh == null || fresh.Count == 0) return;
        var text = fresh.Count == 1 ? AdminControl.AlertText(fresh[0]) : Strings.T("notif_many", fresh.Count);
        var title = new TextBlock { Text = Strings.T("notif_title"), FontWeight = FontWeights.Bold, FontSize = 14, Margin = new Thickness(0, 0, 0, 4) };
        var body = new TextBlock { Text = text, TextWrapping = TextWrapping.Wrap, FontSize = 13 };
        title.SetResourceReference(TextBlock.ForegroundProperty, "gold");
        body.SetResourceReference(TextBlock.ForegroundProperty, "tx");
        var panel = new StackPanel { Margin = new Thickness(16, 12, 16, 14) };
        panel.Children.Add(title);
        panel.Children.Add(body);
        var card = new Border { CornerRadius = new CornerRadius(14), BorderThickness = new Thickness(1), Child = panel };
        card.SetResourceReference(Border.BackgroundProperty, "bar");
        card.SetResourceReference(Border.BorderBrushProperty, "bd");
        var w = new Window
        {
            Width = 340, SizeToContent = SizeToContent.Height, WindowStyle = WindowStyle.None, AllowsTransparency = true, Background = Brushes.Transparent,
            ShowInTaskbar = false, Topmost = true, ShowActivated = false, ResizeMode = ResizeMode.NoResize,
            FlowDirection = Prefs.Ar ? FlowDirection.RightToLeft : FlowDirection.LeftToRight, Content = card
        };
        w.Loaded += (_, _) =>
        {
            var a = SystemParameters.WorkArea;
            w.Left = a.Right - w.ActualWidth - 16; w.Top = a.Bottom - w.ActualHeight - 16;
        };
        w.MouseLeftButtonUp += (_, _) => { MainWindow.Instance?.Activate(); w.Close(); };
        var t = new DispatcherTimer { Interval = TimeSpan.FromSeconds(8) };
        t.Tick += (_, _) => { t.Stop(); try { w.Close(); } catch { } };
        w.Show();
        t.Start();
        Sfx.Play(Sfx.S.Notice);
    }
}
