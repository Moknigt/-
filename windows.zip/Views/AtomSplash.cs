using System.Diagnostics;
using System.Windows;
using System.Windows.Media;

namespace NexoraEdu.Views;

/// <summary>
/// Entry animation drawn with WPF DrawingContext (port of Android SplashView.kt / iPhone AtomSplash.swift), in 3 steps:
///   STEP 1 (done here): twinkling dust + dust that is pulled together and forms the rounded square of the icon, glow, solid square, sheen.
///   STEP 2 (done here): a second set of white / gold dust (260 on the flask lines + 7 per bubble + 14 golden nucleus) starts INSIDE the square and gathers on the flask lines;
///                       the real flask is then traced line by line over the dust (main lines 2.3, the two orbits 1.6), then the two bubbles and the golden nucleus; small bubbles keep rising.
///   STEP 3 (done here): the "transformation" at BURST (2950..3950): a shine band over the square, two rings that grow and fade, 48 sparks (white / gold)
///                       and a 7% pulse of the whole icon (also reported through PulseChanged so the XAML icon tile pulses with it).
/// The timeline is written for 4300 ms (same numbers as Android) and played 1.3x faster.
/// </summary>
public sealed class AtomSplash : FrameworkElement
{
    sealed class P
    {
        public double Sx, Sy, Tx, Ty, Delay, Dur, R, Swirl, Seed;
        public Color Color;
    }

    /// <summary>A flask line as a polyline in the 64 x 64 art units, with cumulative lengths (our own PathMeasure).</summary>
    sealed class Line
    {
        public Point[] Pts;
        public double[] Cum;
        public double Len;
    }

    /// <summary>Speed of the timeline: real ms * Speed = timeline ms.</summary>
    public const double Speed = 1.3;

    // timeline (ms, in the TIMELINE scale = Android numbers)
    const double SolidIn = 1100, SolidOut = 1750, SqFade = 1550, SqFadeEnd = 2100;
    const double FlaskIn = 2350, FlaskFull = 2950, FlFadeEnd = 3250;
    const double Burst = 2950, BurstEnd = 3950;
    static readonly Color Gold = Color.FromRgb(0xF5, 0xC4, 0x51);

    readonly Random _rnd = new(11);
    readonly Stopwatch _clock = new();
    readonly Dictionary<long, Brush> _brushes = new();
    P[] _square = Array.Empty<P>();
    P[] _flask = Array.Empty<P>();
    double[][] _stars = Array.Empty<double[]>();   // x (0..1), y (0..1), size, phase
    double _cx, _cy, _size;
    Color _c1 = Colors.Cyan, _c2 = Colors.Blue;
    Brush _sqBrush, _sheenBrush, _haloBrush;
    // flask artwork, same 64 x 64 units as ic_flask.xml / Android SplashView.buildArt()
    readonly List<Line> _mainLines = new();   // width 2.3
    readonly List<Line> _thinLines = new();   // width 1.6 (the two orbits)
    static readonly double[][] Bubbles = { new[] { 32.0, 19.0, 1.7 }, new[] { 33.5, 14.0, 1.1 } };   // x, y, r
    Pen _penMain, _penThin, _penB1, _penB2;   // frozen once, never created per frame
    double[][] _sparks = Array.Empty<double[]>();   // angle, speed, size, seed
    readonly Dictionary<long, Pen> _pens = new();   // ring pens, cached by colour + alpha (32 steps) + width
    readonly ScaleTransform _bumpXf = new();        // reused every frame (pulse)
    readonly TranslateTransform _shineXf = new();   // reused every frame (shine band)
    Brush _shineBrush;
    Geometry _squareClip;
    double _lastBump = 1;
    Transform _flaskXf;                        // art units -> element pixels (frozen once)
    bool _ready, _hooked;
    double _t;

    /// <summary>Raised when the pulse factor of the whole icon changes (1 = no pulse, up to 1.07). The XAML icon tile follows it.</summary>
    public event Action<double> PulseChanged;

    public AtomSplash()
    {
        IsHitTestVisible = false;
        BuildArt();
        _penMain = MakePen(2.3); _penThin = MakePen(1.6); _penB1 = MakePen(1.5); _penB2 = MakePen(1.3);
    }

    /// <summary>Center (in this element's pixels) and side of the icon square; the two accent colours. Starts the clock.</summary>
    public void Begin(Point center, double side, Color c1, Color c2)
    {
        _cx = center.X; _cy = center.Y; _size = side; _c1 = c1; _c2 = c2;
        double left = _cx - _size / 2, top = _cy - _size / 2;
        _sqBrush = Freeze(new LinearGradientBrush(c1, c2, new Point(0, 0), new Point(1, 1)));
        _sheenBrush = Freeze(new LinearGradientBrush(Color.FromArgb(0x40, 255, 255, 255), Color.FromArgb(0, 255, 255, 255), new Point(0, 0), new Point(0, 1)));
        _haloBrush = Freeze(new RadialGradientBrush(new GradientStopCollection
        {
            new GradientStop(Color.FromArgb(0x66, c1.R, c1.G, c1.B), 0),
            new GradientStop(Color.FromArgb(0x22, c2.R, c2.G, c2.B), 0.55),
            new GradientStop(Color.FromArgb(0, c2.R, c2.G, c2.B), 1),
        }));
        _bumpXf.CenterX = _cx; _bumpXf.CenterY = _cy;
        _shineBrush = Freeze(new LinearGradientBrush(new GradientStopCollection
        {
            new GradientStop(Color.FromArgb(0, 255, 255, 255), 0),
            new GradientStop(Color.FromArgb(0x66, 255, 255, 255), 0.5),
            new GradientStop(Color.FromArgb(0, 255, 255, 255), 1),
        }, 0) { MappingMode = BrushMappingMode.Absolute, StartPoint = new Point(0, top), EndPoint = new Point(_size * 0.5, top + _size * 0.5) });
        _squareClip = new RectangleGeometry(new Rect(left, top, _size, _size), _size * 0.27, _size * 0.27);
        _squareClip.Freeze();
        BuildSquare();
        BuildFlask();
        _stars = Enumerable.Range(0, 40).Select(_ => new[] { _rnd.NextDouble(), _rnd.NextDouble(), 0.6 + _rnd.NextDouble() * 1.4, _rnd.NextDouble() * 6.28 }).ToArray();
        _sparks = Enumerable.Range(0, 48).Select(_ => new[] { _rnd.NextDouble() * 2 * Math.PI, 0.55 + _rnd.NextDouble() * 0.9, 1 + _rnd.NextDouble() * 1.6, _rnd.NextDouble() }).ToArray();
        _ready = true;
        _clock.Restart();
        if (!_hooked) { CompositionTarget.Rendering += Tick; _hooked = true; }
    }

    public void Stop()
    {
        if (_hooked) { CompositionTarget.Rendering -= Tick; _hooked = false; }
        _clock.Stop();
    }

    void Tick(object sender, EventArgs e)
    {
        _t = _clock.Elapsed.TotalMilliseconds * Speed;
        var bump = Bump(_t);
        if (bump != _lastBump) { _lastBump = bump; PulseChanged?.Invoke(bump); }
        InvalidateVisual();
    }

    /// <summary>The whole icon gives a small pulse (up to +7%) during the first 500 ms of the burst.</summary>
    static double Bump(double t) => t >= Burst && t <= Burst + 500 ? 1 + 0.07 * Math.Sin((t - Burst) / 500 * Math.PI) : 1;

    Pen RingPen(Color c, double alpha, double width)
    {
        int a = (int)Math.Clamp(alpha * 31 + 0.5, 0, 31);
        long key = ((long)c.R << 40) | ((long)c.G << 32) | ((long)c.B << 24) | ((long)a << 8) | (long)(width * 10);
        if (!_pens.TryGetValue(key, out var p))
        {
            p = new Pen(new SolidColorBrush(Color.FromArgb((byte)(a * 255 / 31), c.R, c.G, c.B)), width);
            p.Brush.Freeze();
            p.Freeze();
            _pens[key] = p;
        }
        return p;
    }

    static Brush Freeze(Brush b) { b.Freeze(); return b; }

    static Color Mix(Color a, Color b, double f)
    {
        var k = Math.Clamp(f, 0, 1);
        return Color.FromRgb((byte)(a.R + (b.R - a.R) * k), (byte)(a.G + (b.G - a.G) * k), (byte)(a.B + (b.B - a.B) * k));
    }

    static double Smooth(double x) { var k = Math.Clamp(x, 0, 1); return k * k * (3 - 2 * k); }

    /// <summary>A frozen solid brush, cached (colour + alpha in 32 steps) so nothing is allocated every frame.</summary>
    Brush Solid(Color c, double alpha)
    {
        int a = (int)Math.Clamp(alpha * 31 + 0.5, 0, 31);
        long key = ((long)c.R << 24) | ((long)c.G << 16) | ((long)c.B << 8) | (uint)a;
        if (!_brushes.TryGetValue(key, out var b))
        {
            b = Freeze(new SolidColorBrush(Color.FromArgb((byte)(a * 255 / 31), c.R, c.G, c.B)));
            _brushes[key] = b;
        }
        return b;
    }

    // ------------------------------------------------------------------ build

    static bool InsideRound(double x, double y, double left, double top, double size, double rad)
    {
        var px = Math.Clamp(x, left + rad, left + size - rad);
        var py = Math.Clamp(y, top + rad, top + size - rad);
        return Math.Sqrt((x - px) * (x - px) + (y - py) * (y - py)) <= rad + 0.5;
    }

    void BuildSquare()
    {
        double w = Math.Max(ActualWidth, 1), h = Math.Max(ActualHeight, 1);
        double left = _cx - _size / 2, top = _cy - _size / 2, rad = _size * 0.27;
        var list = new List<P>();
        const int n = 650;
        // the colour of a dot follows its place on the diagonal: 16 steps (keeps the brush cache small)
        while (list.Count < n)
        {
            double x, y;
            if (list.Count % 100 < 35)   // 35% on the outline (crisp edges), the rest fills the inside
            {
                var per = 4 * _size;
                var s = _rnd.NextDouble() * per;
                if (s < _size) { x = left + s; y = top; }
                else if (s < 2 * _size) { s -= _size; x = left + _size; y = top + s; }
                else if (s < 3 * _size) { s -= 2 * _size; x = left + _size - s; y = top + _size; }
                else { s -= 3 * _size; x = left; y = top + _size - s; }
                if (!InsideRound(x, y, left, top, _size, rad)) continue;
            }
            else
            {
                x = left + _rnd.NextDouble() * _size;
                y = top + _rnd.NextDouble() * _size;
                if (!InsideRound(x, y, left, top, _size, rad)) continue;
            }
            var diag = Math.Round(((x - left) + (y - top)) / (2 * _size) * 15) / 15;
            list.Add(new P
            {
                Sx = _rnd.NextDouble() * w, Sy = _rnd.NextDouble() * h, Tx = x, Ty = y,
                Delay = _rnd.NextDouble() * 600, Dur = 850 + _rnd.NextDouble() * 300,
                R = 0.9 + _rnd.NextDouble() * 1.1, Color = Mix(_c1, _c2, diag),
                Swirl = (_rnd.NextDouble() - 0.5) * 170, Seed = _rnd.NextDouble(),
            });
        }
        _square = list.ToArray();
    }

    static Pen MakePen(double w)
    {
        var p = new Pen(Brushes.White, w) { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round, LineJoin = PenLineJoin.Round };
        p.Freeze();
        return p;
    }

    static Line MakeLine(List<Point> pts)
    {
        var cum = new double[pts.Count];
        for (int i = 1; i < pts.Count; i++)
            cum[i] = cum[i - 1] + Math.Sqrt((pts[i].X - pts[i - 1].X) * (pts[i].X - pts[i - 1].X) + (pts[i].Y - pts[i - 1].Y) * (pts[i].Y - pts[i - 1].Y));
        return new Line { Pts = pts.ToArray(), Cum = cum, Len = cum[^1] };
    }

    /// <summary>Quadratic curve from the last point of the list through control c to e (14 steps).</summary>
    static void AddQuad(List<Point> l, Point c, Point e)
    {
        var p0 = l[^1];
        for (int i = 1; i <= 14; i++)
        {
            double t = i / 14.0, u = 1 - t;
            l.Add(new Point(u * u * p0.X + 2 * u * t * c.X + t * t * e.X, u * u * p0.Y + 2 * u * t * c.Y + t * t * e.Y));
        }
    }

    /// <summary>Point at [dist] along the line.</summary>
    static Point At(Line ln, double dist)
    {
        dist = Math.Clamp(dist, 0, ln.Len);
        int i = Array.BinarySearch(ln.Cum, dist);
        if (i < 0) i = ~i;
        if (i <= 0) return ln.Pts[0];
        double seg = ln.Cum[i] - ln.Cum[i - 1];
        double f = seg > 0 ? (dist - ln.Cum[i - 1]) / seg : 0;
        Point a = ln.Pts[i - 1], b = ln.Pts[i];
        return new Point(a.X + (b.X - a.X) * f, a.Y + (b.Y - a.Y) * f);
    }

    /// <summary>The flask lines (same shapes as Android buildArt): rim, body, liquid wave, two orbits.</summary>
    void BuildArt()
    {
        _mainLines.Add(MakeLine(new List<Point> { new(24, 9), new(40, 9) }));
        var body = new List<Point> { new(28, 9), new(28, 24), new(12.5, 51.5) };
        AddQuad(body, new Point(9.5, 57), new Point(16, 57));
        body.Add(new Point(48, 57));
        AddQuad(body, new Point(54.5, 57), new Point(51.5, 51.5));
        body.Add(new Point(36, 24)); body.Add(new Point(36, 9));
        _mainLines.Add(MakeLine(body));
        var wave = new List<Point> { new(18, 42) };
        AddQuad(wave, new Point(25, 38), new Point(32, 42));
        AddQuad(wave, new Point(39, 46), new Point(46, 42));
        _mainLines.Add(MakeLine(wave));
        foreach (var deg in new[] { -30.0, 30.0 })   // the two orbits: an 8.5 x 3 oval turned around (32, 49)
        {
            double rad = deg * Math.PI / 180, cs = Math.Cos(rad), sn = Math.Sin(rad);
            var o = new List<Point>();
            for (int i = 0; i <= 48; i++)
            {
                double th = i / 48.0 * 2 * Math.PI, dx = 8.5 * Math.Cos(th), dy = 3 * Math.Sin(th);
                o.Add(new Point(32 + dx * cs - dy * sn, 49 + dx * sn + dy * cs));
            }
            _thinLines.Add(MakeLine(o));
        }
    }

    P FlaskParticle(double x, double y, Color color, double r)
    {
        // starts somewhere inside the square, so the dust seems to gather "inside the icon"
        return new P
        {
            Sx = _cx + (_rnd.NextDouble() - 0.5) * _size * 0.95, Sy = _cy + (_rnd.NextDouble() - 0.5) * _size * 0.95,
            Tx = x, Ty = y, Delay = 1400 + _rnd.NextDouble() * 450, Dur = 600 + _rnd.NextDouble() * 250,
            R = r, Color = color, Swirl = (_rnd.NextDouble() - 0.5) * 60, Seed = _rnd.NextDouble(),
        };
    }

    void BuildFlask()
    {
        double s = _size * 0.654 / 64;   // same proportion as the 68 px flask inside the 104 px icon
        double ox = _cx - 32 * s, oy = _cy - 32 * s;
        var xf = new MatrixTransform(s, 0, 0, s, ox, oy);
        xf.Freeze();
        _flaskXf = xf;

        var all = _mainLines.Concat(_thinLines).ToList();
        double sum = all.Sum(l => l.Len);
        const int total = 260;
        var list = new List<P>();
        foreach (var ln in all)
        {
            int cnt = Math.Max((int)(total * ln.Len / sum), 8);
            for (int k = 0; k < cnt; k++)
            {
                var pt = At(ln, ln.Len * (k + _rnd.NextDouble() * 0.6) / cnt);
                list.Add(FlaskParticle(ox + pt.X * s, oy + pt.Y * s, Colors.White, 0.85 + _rnd.NextDouble() * 0.6));
            }
        }
        foreach (var b in Bubbles)   // 7 dots on the outline of each bubble
            for (int k = 0; k < 7; k++)
            {
                var a = k / 7.0 * 2 * Math.PI;
                list.Add(FlaskParticle(ox + (b[0] + Math.Cos(a) * b[2]) * s, oy + (b[1] + Math.Sin(a) * b[2]) * s, Colors.White, 0.8));
            }
        for (int k = 0; k < 14; k++)   // the golden nucleus
        {
            var a = _rnd.NextDouble() * 2 * Math.PI;
            var r2 = _rnd.NextDouble() * 2.3;
            list.Add(FlaskParticle(ox + (32 + Math.Cos(a) * r2) * s, oy + (49 + Math.Sin(a) * r2) * s, Gold, 1.1));
        }
        _flask = list.ToArray();
    }

    // ------------------------------------------------------------------ draw

    void DrawParticles(DrawingContext dc, P[] arr, double now, bool fadeIn, double alphaMul)
    {
        if (alphaMul <= 0.01) return;
        foreach (var p in arr)
        {
            var pr = Math.Clamp((now - p.Delay) / p.Dur, 0, 1);
            var e = 1 - Math.Pow(1 - pr, 3);
            var x = p.Sx + (p.Tx - p.Sx) * e;
            var y = p.Sy + (p.Ty - p.Sy) * e;
            double dx = p.Tx - p.Sx, dy = p.Ty - p.Sy;
            var len = Math.Max(Math.Sqrt(dx * dx + dy * dy), 1);
            if (pr <= 0)   // waiting: float around where it started
            {
                x += Math.Sin(now * 0.0021 + p.Seed * 6.28) * 7;
                y += Math.Cos(now * 0.0017 + p.Seed * 6.28) * 7;
            }
            else if (pr < 1)   // flying: a curved path, not a straight line
            {
                var bend = p.Swirl * 4 * pr * (1 - pr);
                x += -dy / len * bend;
                y += dx / len * bend;
            }
            else   // arrived: tiny shimmer
            {
                x += Math.Sin(now * 0.006 + p.Seed * 6.28) * 0.7;
                y += Math.Cos(now * 0.005 + p.Seed * 6.28) * 0.7;
            }
            var a = alphaMul;
            if (fadeIn) a *= Smooth((now - (p.Delay - 250)) / 250);
            if (a <= 0.01) continue;
            dc.DrawEllipse(Solid(p.Color, a * 60 / 255), null, new Point(x, y), p.R * 2.4, p.R * 2.4);
            if (pr > 0 && pr < 1)   // a short fading tail behind every flying dot
            {
                for (int k = 1; k <= 2; k++)
                {
                    var pk = Math.Max(pr - k * 0.05, 0);
                    var ek = 1 - Math.Pow(1 - pk, 3);
                    var bend2 = p.Swirl * 4 * pk * (1 - pk);
                    var tx2 = p.Sx + dx * ek - dy / len * bend2;
                    var ty2 = p.Sy + dy * ek + dx / len * bend2;
                    var r2 = p.R * (1 - k * 0.2);
                    dc.DrawEllipse(Solid(p.Color, a * (95 - k * 28) / 255), null, new Point(tx2, ty2), r2, r2);
                }
            }
            dc.DrawEllipse(Solid(p.Color, a), null, new Point(x, y), p.R, p.R);
        }
    }

    /// <summary>Draws the first [frac] (0..1) of the line, as short round-capped segments (no geometry is created).</summary>
    static void Trace(DrawingContext dc, Pen pen, Line ln, double frac)
    {
        double target = ln.Len * frac;
        if (target <= 0) return;
        for (int i = 1; i < ln.Pts.Length; i++)
        {
            if (ln.Cum[i - 1] >= target) break;
            Point p0 = ln.Pts[i - 1], p1 = ln.Pts[i];
            if (ln.Cum[i] > target)
            {
                double f = (target - ln.Cum[i - 1]) / (ln.Cum[i] - ln.Cum[i - 1]);
                p1 = new Point(p0.X + (p1.X - p0.X) * f, p0.Y + (p1.Y - p0.Y) * f);
            }
            dc.DrawLine(pen, p0, p1);
        }
    }

    /// <summary>[alpha] 0..1 = how much of the flask is drawn: the lines are traced one by one, then the bubbles and the nucleus appear.</summary>
    void DrawFlask(DrawingContext dc, double alpha, double now)
    {
        dc.PushTransform(_flaskXf);
        dc.PushOpacity(Math.Min(alpha * 3, 1));
        foreach (var ln in _mainLines) Trace(dc, _penMain, ln, alpha);
        foreach (var ln in _thinLines) Trace(dc, _penThin, ln, alpha);
        dc.Pop();
        var tail = Math.Clamp((alpha - 0.6) / 0.4, 0, 1);
        if (tail > 0)
        {
            dc.PushOpacity(tail);
            foreach (var b in Bubbles)
                dc.DrawEllipse(null, b[2] > 1.5 ? _penB1 : _penB2, new Point(b[0], b[1]), b[2], b[2]);
            dc.Pop();
            dc.DrawEllipse(Solid(Gold, tail), null, new Point(32, 49), 2.4, 2.4);   // the golden nucleus
        }
        // small bubbles keep rising inside the flask once it is complete
        if (now > FlaskFull)
        {
            var f = Math.Clamp((now - FlaskFull) / 700, 0, 1);
            for (int i = 0; i < 5; i++)
            {
                var ph = ((now - FlaskFull) * 0.0009 + i * 0.2) % 1;
                var bx = 32 + Math.Sin(ph * 12.56 + i) * (1.2 + i * 0.5) * (0.4 + 0.6 * (1 - ph));
                var by = 54 - ph * 26;
                var r = 0.9 + (i % 3) * 0.35;
                dc.DrawEllipse(Solid(Colors.White, (1 - ph) * 170 * f / 255), null, new Point(bx, by), r, r);
            }
        }
        dc.Pop();
    }

    protected override void OnRender(DrawingContext dc)
    {
        if (!_ready) return;
        var bump = Bump(_t);
        if (bump != 1)
        {
            _bumpXf.ScaleX = bump; _bumpXf.ScaleY = bump;
            dc.PushTransform(_bumpXf);
            DrawAll(dc, _t);
            dc.Pop();
        }
        else DrawAll(dc, _t);
    }

    void DrawAll(DrawingContext dc, double now)
    {
        double w = ActualWidth, h = ActualHeight;

        // twinkling background dust
        var sa = 1 - Smooth((now - FlFadeEnd) / 700) * 0.6;
        foreach (var st in _stars)
        {
            var tw = 0.5 + 0.5 * Math.Sin(now * 0.0032 + st[3]);
            var col = st[3] > 3.1 ? _c1 : Colors.White;
            dc.DrawEllipse(Solid(col, tw * sa * 120 / 255), null, new Point(st[0] * w, st[1] * h + Math.Sin(now * 0.0007 + st[3]) * 6), st[2], st[2]);
        }

        double left = _cx - _size / 2, top = _cy - _size / 2, rad = _size * 0.27;
        var rect = new Rect(left, top, _size, _size);

        // soft glow behind the square, then the solid icon square (fades in while the dust arrives)
        var solid = Smooth((now - SolidIn) / (SolidOut - SolidIn));
        if (solid > 0)
        {
            var pulse = 0.85 + 0.15 * Math.Sin(now * 0.004);
            var haloR = _size * 1.15;
            dc.PushOpacity(Math.Clamp(solid * pulse, 0, 1));
            dc.DrawEllipse(_haloBrush, null, new Point(_cx, _cy), haloR, haloR);
            dc.Pop();

            var sc = 1 + 0.05 * (1 - solid);
            dc.PushTransform(new ScaleTransform(sc, sc, _cx, _cy));
            dc.PushOpacity(solid);
            dc.DrawRoundedRectangle(_sqBrush, null, rect, rad, rad);
            // glass sheen on the top half
            dc.DrawRoundedRectangle(_sheenBrush, null, new Rect(left, top, _size, _size * 0.5), rad, rad);
            dc.Pop();
            dc.Pop();
        }

        // square dust (fades out while the solid square takes over)
        DrawParticles(dc, _square, now, false, 1 - Smooth((now - SqFade) / (SqFadeEnd - SqFade)));

        // flask dust (starts inside the square), then the real flask is traced over it
        var real = Smooth((now - FlaskIn) / (FlaskFull - FlaskIn));
        DrawParticles(dc, _flask, now, true, 1 - Smooth((now - FlaskFull) / (FlFadeEnd - FlaskFull)));
        if (real > 0) DrawFlask(dc, real, now);

        // the "transformation": a shine over the icon + two rings + sparks
        if (now >= Burst && now <= BurstEnd)
        {
            var k = (now - Burst) / (BurstEnd - Burst);
            // shine band (clipped to the rounded square)
            dc.PushClip(_squareClip);
            var bx = left - _size * 0.6 + _size * 2.2 * Smooth(k);
            _shineXf.X = bx;
            dc.PushTransform(_shineXf);
            dc.DrawRectangle(_shineBrush, null, new Rect(left - bx, top, _size, _size));
            dc.Pop();
            dc.Pop();
            // two rings that grow and fade
            dc.DrawEllipse(null, RingPen(_c1, (1 - k) * 200 / 255, 2), new Point(_cx, _cy), _size * (0.55 + 0.9 * Smooth(k)), _size * (0.55 + 0.9 * Smooth(k)));
            var k2 = Math.Clamp((now - Burst - 220) / (BurstEnd - Burst), 0, 1);
            if (k2 > 0 && k2 < 1)
            {
                var r2 = _size * (0.5 + 1.2 * Smooth(k2));
                dc.DrawEllipse(null, RingPen(_c2, (1 - k2) * 160 / 255, 1.5), new Point(_cx, _cy), r2, r2);
            }
            // 48 sparks (white and gold) flying outwards
            foreach (var sp0 in _sparks)
            {
                var sp = Math.Clamp(k - sp0[3] * 0.15, 0, 1);
                var dist = _size * (0.5 + sp0[1] * 0.9 * (1 - (1 - sp) * (1 - sp)));
                var a = 1 - sp;
                var r = sp0[2] * (1 - sp * 0.5);
                dc.DrawEllipse(Solid(sp0[3] > 0.5 ? Gold : Colors.White, a * 230 / 255), null, new Point(_cx + Math.Cos(sp0[0]) * dist, _cy + Math.Sin(sp0[0]) * dist), r, r);
            }
        }
    }
}
