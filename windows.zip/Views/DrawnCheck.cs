using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace NexoraEdu.Views;

/// <summary>
/// Port of the Android DrawnCheck (Widgets.kt): a rounded box that fills with the accent gradient while the tick is drawn stroke by stroke,
/// and the box gives a small bounce. The owner (LoginView) toggles it; the fill brush is the shared accent gradient, so the teacher purple follows.
/// </summary>
public sealed class DrawnCheck : FrameworkElement
{
    public static readonly DependencyProperty ProgressProperty = DependencyProperty.Register(
        nameof(Progress), typeof(double), typeof(DrawnCheck),
        new FrameworkPropertyMetadata(0.0, FrameworkPropertyMetadataOptions.AffectsRender));

    /// <summary>0 = empty box, 1 = filled box with the whole tick.</summary>
    public double Progress
    {
        get => (double)GetValue(ProgressProperty);
        set => SetValue(ProgressProperty, value);
    }

    /// <summary>Accent gradient (box fill and the border once ticked). Shared with the other accent parts of the screen.</summary>
    public Brush Accent { get; set; } = Brushes.Teal;

    /// <summary>Colour of the empty box border.</summary>
    public Brush Off { get; set; } = Brushes.Gray;

    public bool IsChecked { get; private set; }

    /// <summary>Raised when the user (or SetChecked with notify) changes the state.</summary>
    public event Action<bool> Changed;

    readonly ScaleTransform _scale = new(1, 1);

    public DrawnCheck()
    {
        Width = 26;
        Height = 26;
        RenderTransformOrigin = new Point(0.5, 0.5);
        RenderTransform = _scale;
        IsHitTestVisible = false;   // the row around it takes the click
        SnapsToDevicePixels = false;
    }

    public void SetChecked(bool v, bool animate, bool notify = true)
    {
        if (v == IsChecked && !animate) { Progress = v ? 1 : 0; return; }
        IsChecked = v;
        var target = v ? 1.0 : 0.0;
        BeginAnimation(ProgressProperty, null);
        if (!animate)
        {
            Progress = target;
        }
        else
        {
            BeginAnimation(ProgressProperty, new DoubleAnimation(Progress, target, TimeSpan.FromMilliseconds(v ? 360 : 220))
            {
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut },
            });
            if (v)
            {
                _scale.BeginAnimation(ScaleTransform.ScaleXProperty, null);
                _scale.BeginAnimation(ScaleTransform.ScaleYProperty, null);
                var bounce = new BackEase { EasingMode = EasingMode.EaseOut, Amplitude = 2.2 };
                _scale.BeginAnimation(ScaleTransform.ScaleXProperty, new DoubleAnimation(0.82, 1, TimeSpan.FromMilliseconds(380)) { EasingFunction = bounce });
                _scale.BeginAnimation(ScaleTransform.ScaleYProperty, new DoubleAnimation(0.82, 1, TimeSpan.FromMilliseconds(380)) { EasingFunction = bounce });
            }
        }
        if (notify)
        {
            Core.Sfx.Play(v ? Core.Sfx.S.On : Core.Sfx.S.Off);
            Changed?.Invoke(v);
        }
    }

    public void Toggle() => SetChecked(!IsChecked, true);

    protected override void OnRender(DrawingContext dc)
    {
        var w = ActualWidth;
        var h = ActualHeight;
        var s = Math.Min(w, h);
        if (s <= 0) return;
        var ox = (w - s) / 2;
        var oy = (h - s) / 2;
        var p = Progress;
        const double stroke = 2.0;
        var inset = stroke / 2 + 1;
        var rect = new Rect(ox + inset, oy + inset, s - 2 * inset, s - 2 * inset);
        const double r = 8;

        // fill grows in (alpha = p * 1.7, capped)
        var fillA = Math.Min(1, p * 1.7);
        if (fillA > 0)
        {
            dc.PushOpacity(fillA);
            dc.DrawRoundedRectangle(Accent, null, rect, r, r);
            dc.Pop();
        }
        // border: grey box, the accent colour takes over as the tick is drawn
        dc.DrawRoundedRectangle(null, new Pen(Off, stroke), rect, r, r);
        var borderA = Math.Min(1, p * 1.4);
        if (borderA > 0)
        {
            dc.PushOpacity(borderA);
            dc.DrawRoundedRectangle(null, new Pen(Accent, stroke), rect, r, r);
            dc.Pop();
        }

        // the tick: two strokes, drawn one after the other
        var t = Math.Clamp((p - 0.3) / 0.7, 0, 1);
        if (t <= 0) return;
        var a = new Point(ox + s * 0.27, oy + s * 0.53);
        var b = new Point(ox + s * 0.43, oy + s * 0.69);
        var c = new Point(ox + s * 0.74, oy + s * 0.35);
        var l1 = (b - a).Length;
        var l2 = (c - b).Length;
        var dist = t * (l1 + l2);
        var pen = new Pen(Brushes.White, 2.2) { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round, LineJoin = PenLineJoin.Round };
        var g = new StreamGeometry();
        using (var gc = g.Open())
        {
            gc.BeginFigure(a, false, false);
            if (dist <= l1)
            {
                gc.LineTo(a + (b - a) * (dist / l1), true, true);
            }
            else
            {
                gc.LineTo(b, true, true);
                gc.LineTo(b + (c - b) * ((dist - l1) / l2), true, true);
            }
        }
        g.Freeze();
        dc.DrawGeometry(null, pen, g);
    }
}
