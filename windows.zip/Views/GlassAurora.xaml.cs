using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace NexoraEdu.Views;

/// <summary>The drifting colour orbs behind the splash and the sign-in screen. Positions follow the size of the window.</summary>
public partial class GlassAurora : UserControl
{
    public GlassAurora()
    {
        InitializeComponent();
        Loaded += (_, _) =>
        {
            Drift(MoveA, 70, 50, 6.5);
            Drift(MoveB, -80, -60, 7.5);
            Drift(MoveC, -50, 70, 5.5);
        };
        SizeChanged += (_, e) =>
        {
            Canvas.SetLeft(OrbB, e.NewSize.Width - OrbB.Width * 0.62);
            Canvas.SetTop(OrbB, e.NewSize.Height - OrbB.Height * 0.55);
            Canvas.SetLeft(OrbC, e.NewSize.Width - OrbC.Width * 0.7);
        };
    }

    static void Drift(TranslateTransform t, double dx, double dy, double seconds)
    {
        DoubleAnimation Make(double to) => new(0, to, TimeSpan.FromSeconds(seconds))
        {
            AutoReverse = true,
            RepeatBehavior = RepeatBehavior.Forever,
            EasingFunction = new SineEase { EasingMode = EasingMode.EaseInOut },
        };
        t.BeginAnimation(TranslateTransform.XProperty, Make(dx));
        t.BeginAnimation(TranslateTransform.YProperty, Make(dy));
    }
}
