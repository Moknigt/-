using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace NexoraEdu.Views;

/// <summary>The drifting colour orbs behind the splash and the sign-in screen. Positions follow the size of the window.</summary>
public partial class GlassAurora : UserControl
{
    public GlassAurora()
    {
        InitializeComponent();
        // stronger glow in the dark theme, softer in the light one (Android AuroraView: 0x66 dark / 0x40 light)
        var dark = Core.Prefs.Dark;
        OrbA.Opacity = dark ? 0.5 : 0.34;
        OrbB.Opacity = dark ? 0.46 : 0.30;
        OrbC.Opacity = dark ? 0.36 : 0.26;
        Haze.Opacity = dark ? 0.55 : 0.22;
        Loaded += (_, _) =>
        {
            Drift(MoveA, 70, 50, 6.5);
            Drift(MoveB, -80, -60, 7.5);
            Drift(MoveC, -50, 70, 5.5);
        };
        SizeChanged += (_, e) =>
        {
            Canvas.SetLeft(OrbB, e.NewSize.Width - OrbB.Width * 0.62);
            Canvas.SetTop(OrbB, e.NewSize.Height - OrbB.Height * 0.55);
            Canvas.SetLeft(OrbC, e.NewSize.Width - OrbC.Width * 0.7);
        };
    }

    static void Drift(TranslateTransform t, double dx, double dy, double seconds)
    {
        DoubleAnimation Make(double to) => new(0, to, TimeSpan.FromSeconds(seconds))
        {
            AutoReverse = true,
            RepeatBehavior = RepeatBehavior.Forever,
            EasingFunction = new SineEase { EasingMode = EasingMode.EaseInOut },
        };
        t.BeginAnimation(TranslateTransform.XProperty, Make(dx));
        t.BeginAnimation(TranslateTransform.YProperty, Make(dy));
    }
}
