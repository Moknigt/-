using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace NexoraEdu.Views;

/// <summary>
/// The side bar of the student / teacher / admin shells: frosted glass (fog + glass gradient + sheen), flush with the window edge on the outer side
/// and rounded on the inner side (towards the page). The corners are written for the left-to-right layout and mirror by themselves in Arabic.
/// On load it slides in from the edge and its tabs follow one after the other (not replayed after a language / theme change).
/// </summary>
[ContentProperty(nameof(Body))]
public sealed class GlassSidebar : Grid
{
    const double Radius = 28;
    UIElement _body;
    bool _played;

    public UIElement Body
    {
        get => _body;
        set
        {
            if (_body != null) Children.Remove(_body);
            _body = value;
            if (value != null) Children.Add(value);
        }
    }

    static LinearGradientBrush Mask(Point a, Point b, params (double Off, byte Alpha)[] stops)
    {
        var g = new LinearGradientBrush { StartPoint = a, EndPoint = b };
        foreach (var (o, al) in stops) g.GradientStops.Add(new GradientStop(Color.FromArgb(al, 0, 0, 0), o));
        return g;
    }

    Border Layer(string brushKey, Brush mask = null, double opacity = 1)
    {
        var b = new Border { CornerRadius = new CornerRadius(0, Radius, Radius, 0), IsHitTestVisible = false, OpacityMask = mask, Opacity = opacity };
        b.SetResourceReference(Border.BackgroundProperty, brushKey);
        return b;
    }

    public GlassSidebar()
    {
        var tt = new TranslateTransform();
        RenderTransform = tt;

        // fog: the screen colour, a little see-through so the orbs behind glow softly
        Children.Add(Layer("bg1", null, 0.62));
        Children.Add(Layer("glass_lo"));
        Children.Add(Layer("glass_hi", Mask(new Point(0, 0), new Point(1, 1), (0, 255), (1, 0))));
        Children.Add(Layer("sheen", Mask(new Point(0, 0), new Point(0, 1), (0, 255), (0.45, 0), (1, 0))));
        // thin edge on the rounded side only (top, inner side, bottom); the window-edge side stays open
        var edge = new Border { CornerRadius = new CornerRadius(0, Radius, Radius, 0), BorderThickness = new Thickness(0, 1, 1, 1), IsHitTestVisible = false };
        edge.SetResourceReference(Border.BorderBrushProperty, "bd");
        Children.Add(edge);

        Loaded += (_, _) =>
        {
            if (_played) return;
            _played = true;
            if (LoginView.Reloading) return;
            var ease = new CubicEase { EasingMode = EasingMode.EaseOut };
            Opacity = 0;
            BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(420)));
            tt.BeginAnimation(TranslateTransform.XProperty, new DoubleAnimation(-70, 0, TimeSpan.FromMilliseconds(480)) { EasingFunction = ease });
            var i = 0;
            foreach (var rb in Descendants<RadioButton>(this))
            {
                var m = new TranslateTransform();
                rb.RenderTransform = m;
                rb.Opacity = 0;
                var delay = TimeSpan.FromMilliseconds(180 + 60 * i++);
                rb.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(360)) { BeginTime = delay });
                m.BeginAnimation(TranslateTransform.XProperty, new DoubleAnimation(-22, 0, TimeSpan.FromMilliseconds(420)) { BeginTime = delay, EasingFunction = ease });
            }
        };
    }

    static IEnumerable<T> Descendants<T>(DependencyObject root) where T : DependencyObject
    {
        var n = VisualTreeHelper.GetChildrenCount(root);
        for (var k = 0; k < n; k++)
        {
            var c = VisualTreeHelper.GetChild(root, k);
            if (c is T t) yield return t;
            foreach (var d in Descendants<T>(c)) yield return d;
        }
    }
}
