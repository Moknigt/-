using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using System.Windows.Threading;
using NexoraEdu.Core;

namespace NexoraEdu.Views;

/// <summary>
/// Student sign-in and sign-up (port of the student part of LoginActivity.submit, same checks, same order, same error texts).
/// Hidden admin entry: hold the logo 7 s (cancelled by lifting the button or leaving the logo). Teacher sign-in / first-time account (Student | Teacher switch) lands on the teacher placeholder until the teacher side exists.
/// Look and motion are the Android / iPhone sign-in screen: glass card, floating logo, sliding Student | Teacher indicator that blends to purple,
/// icon fields with hints, "create a new account" with the drawn tick (the extra fields grow in one after the other), wiggling lock, blinking eye.
/// </summary>
public partial class LoginView : UserControl
{
    /// <summary>True while MainWindow.Reload rebuilds this screen (language / theme change): the entrance animation is not played again.</summary>
    public static bool Reloading;

    bool _signup;
    bool _admin;
    bool _teacher;
    readonly DispatcherTimer _hold = new() { Interval = TimeSpan.FromMilliseconds(7000) };
    readonly List<string> _grades = Store.Grades();

    // the accent, shared by the indicator, logo tile, main button and tick; blended to purple for the teacher
    readonly LinearGradientBrush _h = MakeGrad(new Point(0, 0), new Point(1, 0));
    readonly LinearGradientBrush _d = MakeGrad(new Point(0, 0), new Point(1, 1));
    readonly DropShadowEffect _glowLogo = new() { BlurRadius = 28, ShadowDepth = 8, Direction = 270, Opacity = 0.5, Color = Colors.Transparent };
    readonly DropShadowEffect _glowBtn = new() { BlurRadius = 18, ShadowDepth = 5, Direction = 270, Opacity = 0.45, Color = Colors.Transparent };
    readonly SolidColorBrush _fgStudent = new(Colors.White);
    readonly SolidColorBrush _fgTeacher = new(Colors.White);
    readonly Dictionary<FrameworkElement, int> _rowTok = new();
    bool _introDone;

    static LinearGradientBrush MakeGrad(Point from, Point to)
    {
        var g = new LinearGradientBrush { StartPoint = from, EndPoint = to };
        g.GradientStops.Add(new GradientStop(Colors.Transparent, 0));
        g.GradientStops.Add(new GradientStop(Colors.Transparent, 1));
        return g;
    }

    Color C(string key) => ((SolidColorBrush)FindResource(key)).Color;

    public LoginView()
    {
        InitializeComponent();

        LogoTile.Background = _d;
        LogoTile.Effect = _glowLogo;
        Ind.Background = _h;
        BtnGo.Background = _h;
        BtnGo.Effect = _glowBtn;
        SignCheck.Accent = _h;
        SignCheck.Off = (Brush)FindResource("mut");
        RoleStudent.Foreground = _fgStudent;
        RoleTeacher.Foreground = _fgTeacher;
        _fgStudent.Color = Colors.White;
        _fgTeacher.Color = C("tx");

        foreach (var g in _grades)
            GradePanel.Children.Add(new RadioButton { Style = (Style)FindResource("GlassChip"), GroupName = "grade", Content = g });
        if (GradePanel.Children.Count > 0) ((RadioButton)GradePanel.Children[0]).IsChecked = true;

        _hold.Tick += (_, _) => { _hold.Stop(); OpenAdmin(); };
        Unloaded += (_, _) => { _hold.Stop(); LogoMove.BeginAnimation(TranslateTransform.YProperty, null); };

        // "create a new account" + drawn tick: ticking it grows the card
        SignCheck.Changed += on => { _signup = on; Refresh(true); };

        RoleStudent.IsChecked = true;
        LangBtn.Content = Prefs.Ar ? "English" : "العربية";
        ThemeBtn.Content = Strings.T(Prefs.Dark ? "light" : "dark");
        TintRole(false);
        Refresh(false);

        // glass entrance (not replayed after a language / theme change): the logo pops in, the card slides up
        var intro = !Reloading;
        if (intro)
        {
            LogoHold.Opacity = 0;
            LogoScale.ScaleX = LogoScale.ScaleY = 0.6;
            Card.Opacity = 0;
            CardMove.Y = 46;
        }
        Loaded += (_, _) =>
        {
            if (_introDone) return;
            _introDone = true;
            MoveSeg(false);
            StartFloat();
            if (intro) PlayIntro();
        };
    }

    // ---------------------------------------------------------------- motion

    /// <summary>The logo keeps floating gently (6 px up and down, 2.6 s).</summary>
    void StartFloat()
    {
        LogoMove.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(0, -6, TimeSpan.FromMilliseconds(2600))
        {
            AutoReverse = true,
            RepeatBehavior = RepeatBehavior.Forever,
            EasingFunction = new SineEase { EasingMode = EasingMode.EaseInOut },
        });
    }

    void PlayIntro()
    {
        var pop = new BackEase { EasingMode = EasingMode.EaseOut, Amplitude = 1.4 };
        var logoDur = TimeSpan.FromMilliseconds(520);
        var start = TimeSpan.FromMilliseconds(60);
        LogoScale.BeginAnimation(ScaleTransform.ScaleXProperty, new DoubleAnimation(0.6, 1, logoDur) { BeginTime = start, EasingFunction = pop });
        LogoScale.BeginAnimation(ScaleTransform.ScaleYProperty, new DoubleAnimation(0.6, 1, logoDur) { BeginTime = start, EasingFunction = pop });
        LogoHold.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, logoDur) { BeginTime = start });

        var ease = new CubicEase { EasingMode = EasingMode.EaseOut };
        var cardStart = TimeSpan.FromMilliseconds(200);
        var cardDur = TimeSpan.FromMilliseconds(520);
        Card.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, cardDur) { BeginTime = cardStart, EasingFunction = ease });
        CardMove.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(46, 0, cardDur) { BeginTime = cardStart, EasingFunction = ease });
    }

    /// <summary>Blends a colour property to a new colour (or sets it at once when ms is 0). Works on brushes, gradient stops and effects.</summary>
    static void AnimColor(Animatable target, DependencyProperty prop, Color to, int ms)
    {
        var cur = (Color)target.GetValue(prop);
        target.BeginAnimation(prop, null);
        target.SetValue(prop, to);
        if (ms > 0 && cur != to)
            target.BeginAnimation(prop, new ColorAnimation(cur, to, TimeSpan.FromMilliseconds(ms)));
    }

    /// <summary>Teacher = purple (indicator, tick, main button, glow); student = the normal accent. Blends smoothly (300 ms).</summary>
    void TintRole(bool animate)
    {
        var ms = animate ? 300 : 0;
        var a = C("p1");
        var b = C("p2");
        foreach (var g in new[] { _h, _d })
        {
            AnimColor(g.GradientStops[0], GradientStop.ColorProperty, a, ms);
            AnimColor(g.GradientStops[1], GradientStop.ColorProperty, b, ms);
        }
        AnimColor(_glowLogo, DropShadowEffect.ColorProperty, a, ms);
        AnimColor(_glowBtn, DropShadowEffect.ColorProperty, a, ms);
    }

    void SegGrid_SizeChanged(object sender, SizeChangedEventArgs e) => MoveSeg(false);

    /// <summary>The one accent indicator slides (with a tiny overshoot) while the two labels cross-fade; same in LTR and RTL.</summary>
    void MoveSeg(bool animate)
    {
        var w = Math.Max(0, SegGrid.ActualWidth / 2);
        var x = _teacher ? w : 0;
        var cur = IndMove.X;
        Ind.Width = w;
        IndMove.BeginAnimation(TranslateTransform.XProperty, null);
        IndMove.X = x;
        if (animate && w > 0 && cur != x)
            IndMove.BeginAnimation(TranslateTransform.XProperty, new DoubleAnimation(cur, x, TimeSpan.FromMilliseconds(360))
            {
                EasingFunction = new BackEase { EasingMode = EasingMode.EaseOut, Amplitude = 0.6 },
            });
        var ms = animate ? 280 : 0;
        AnimColor(_fgStudent, SolidColorBrush.ColorProperty, _teacher ? C("tx") : Colors.White, ms);
        AnimColor(_fgTeacher, SolidColorBrush.ColorProperty, _teacher ? Colors.White : C("tx"), ms);
    }

    /// <summary>An extra field row grows in (height, top margin, fade, small slide) after [delay] ms, or folds away. Fixed height [h], top margin [m].</summary>
    void AnimateRow(FrameworkElement v, bool show, int delay, double h, double m, bool animate)
    {
        var tok = _rowTok.TryGetValue(v, out var old) ? old + 1 : 1;
        _rowTok[v] = tok;
        if (v.RenderTransform is not TranslateTransform tt)
        {
            tt = new TranslateTransform();
            v.RenderTransform = tt;
        }
        var cur = v.Visibility == Visibility.Collapsed ? 0 : Math.Clamp(v.Height / h, 0, 1);

        void Clear()
        {
            v.BeginAnimation(HeightProperty, null);
            v.BeginAnimation(MarginProperty, null);
            v.BeginAnimation(OpacityProperty, null);
            tt.BeginAnimation(TranslateTransform.YProperty, null);
        }
        void Final()
        {
            Clear();
            v.Height = h;
            v.Margin = new Thickness(0, show ? m : 0, 0, 0);
            v.Opacity = 1;
            tt.Y = 0;
            v.Visibility = show ? Visibility.Visible : Visibility.Collapsed;
        }

        var to = show ? 1.0 : 0.0;
        Clear();
        if (!animate || cur == to) { Final(); return; }

        // start state (also what is shown during the delay)
        v.Height = h * cur;
        v.Margin = new Thickness(0, m * cur, 0, 0);
        v.Opacity = cur;
        tt.Y = (cur - 1) * 8;
        v.Visibility = Visibility.Visible;

        var dur = TimeSpan.FromMilliseconds(380);
        var begin = TimeSpan.FromMilliseconds(delay);
        var ease = new CubicEase { EasingMode = EasingMode.EaseOut };
        DoubleAnimation Da(double f, double t) => new(f, t, dur) { BeginTime = begin, EasingFunction = ease };
        var ha = Da(h * cur, h * to);
        ha.Completed += (_, _) => { if (_rowTok.TryGetValue(v, out var now) && now == tok) Final(); };
        v.BeginAnimation(HeightProperty, ha);
        v.BeginAnimation(MarginProperty, new ThicknessAnimation(new Thickness(0, m * cur, 0, 0), new Thickness(0, m * to, 0, 0), dur) { BeginTime = begin, EasingFunction = ease });
        v.BeginAnimation(OpacityProperty, Da(cur, to));
        tt.BeginAnimation(TranslateTransform.YProperty, Da((cur - 1) * 8, (to - 1) * 8));
    }

    /// <summary>The lock shakes a little (on focus / wrong password), turning around its bottom edge.</summary>
    static void Wiggle(RotateTransform r)
    {
        var a = new DoubleAnimationUsingKeyFrames { Duration = TimeSpan.FromMilliseconds(460) };
        for (var i = 0; i <= 24; i++)
        {
            var t = i / 24.0;
            a.KeyFrames.Add(new LinearDoubleKeyFrame(Math.Sin(t * Math.PI * 4) * 14 * (1 - t), KeyTime.FromTimeSpan(TimeSpan.FromMilliseconds(460 * t))));
        }
        r.BeginAnimation(RotateTransform.AngleProperty, a);
    }

    void Pass1_Focus(object sender, KeyboardFocusChangedEventArgs e) { if (!_eyeBusy) Wiggle(Lock1Rot); }
    void Pass2_Focus(object sender, KeyboardFocusChangedEventArgs e) { if (!_eyeBusy) Wiggle(Lock2Rot); }

    // ---------------------------------------------------------------- state

    /// <summary>Hints sit inside the fields (like Android): shown only while the field is empty.</summary>
    void UpdateHints()
    {
        if (HPass2 == null || PassBox2 == null) return;   // still building
        HCode.Visibility = CodeBox.Text.Length == 0 ? Visibility.Visible : Visibility.Collapsed;
        HName.Visibility = NameBox.Text.Length == 0 ? Visibility.Visible : Visibility.Collapsed;
        HEmail.Visibility = EmailBox.Text.Length == 0 ? Visibility.Visible : Visibility.Collapsed;
        HPhone.Visibility = PhoneBox.Text.Length == 0 ? Visibility.Visible : Visibility.Collapsed;
        HPass.Visibility = PassBox.Password.Length == 0 ? Visibility.Visible : Visibility.Collapsed;
        HPass2.Visibility = PassBox2.Password.Length == 0 ? Visibility.Visible : Visibility.Collapsed;
    }

    void Refresh(bool animate = true)
    {
        animate = animate && IsLoaded;
        ErrorText.Visibility = Visibility.Collapsed;
        PhoneError.Visibility = Visibility.Collapsed;
        var setup = _admin && Store.Admin() == null;
        var teacher = _teacher && !_admin;
        var up = _signup && !_teacher && !_admin;
        var tup = _signup && teacher; // teacher creating a new account (name, required phone, confirm password)
        Seg.Visibility = _admin ? Visibility.Collapsed : Visibility.Visible;
        if (_admin)
        {
            Title.Text = Strings.T(setup ? "title_admin_setup" : "title_admin");
            Subtitle.Text = Strings.T(setup ? "sub_admin_setup" : "sub_admin");
        }
        else if (teacher)
        {
            Title.Text = Strings.T("title_teacher");
            Subtitle.Text = Strings.T("sub_teacher");
        }
        else
        {
            Title.Text = Strings.T(up ? "title_signup" : "title_signin");
            Subtitle.Text = Strings.T(up ? "sub_signup" : "sub_signin");
        }
        // registration code: only while a teacher account is still to be created; release 57: the admin sets up the account with an activation code too
        HCode.Text = Strings.T(_admin ? "adm_code_hint" : "hint_tcode");
        var showCode = setup || (teacher && (_signup || Store.Teacher() == null));
        var showName = up || tup;
        var showPass2 = setup || up || tup;
        var showPhone = up || tup;
        var showGrade = up && _grades.Count > 0;
        // the extra fields appear one after the other, top to bottom (same delays as Android)
        AnimateRow(FCode, showCode, 0, 52, 14, animate);
        AnimateRow(FName, showName, 0, 52, 14, animate);
        AnimateRow(FPass2, showPass2, showName ? 70 : 0, 52, 14, animate);
        AnimateRow(FPhone, showPhone, showName ? 140 : 70, 52, 14, animate);
        AnimateRow(FGrade, showGrade, 210, 84, 14, animate);
        NoGrades.Visibility = up && _grades.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
        TeacherHint.Visibility = teacher && !_signup && Store.Teacher() == null ? Visibility.Visible : Visibility.Collapsed;
        BtnGo.Content = Strings.T(up || tup || setup ? "btn_signup" : "btn_signin");
        SignRow.Visibility = _admin ? Visibility.Collapsed : Visibility.Visible;
        AltRow.Visibility = _admin ? Visibility.Visible : Visibility.Collapsed;
        AltText.Text = "";
        AltLink.Content = Strings.T("back");
        UpdateHints();
    }

    void Role_Checked(object sender, RoutedEventArgs e)
    {
        _teacher = ReferenceEquals(sender, RoleTeacher);
        Accents.Role = _teacher ? "teacher" : "student";   // the teacher side of the sign-in is purple
        App.ApplyTheme(Prefs.Dark);
        MainWindow.Instance?.RefreshBackground();   // the whole-app background follows the role colour
        TintRole(IsLoaded);
        MoveSeg(IsLoaded);
        Refresh(true);
    }

    // ---- hidden admin entry: no hint of any kind while holding ----
    void Logo_Down(object sender, MouseButtonEventArgs e)
    {
        _hold.Stop();
        _hold.Start();
    }

    void Logo_Up(object sender, MouseEventArgs e) => _hold.Stop();

    void OpenAdmin()
    {
        if (_admin) return;
        _admin = true;
        _signup = false;
        SignCheck.SetChecked(false, false, false);
        ClearFields();
        Refresh(true);
    }

    void CloseAdmin()
    {
        _admin = false;
        ClearFields();
        Refresh(true);
    }

    void ClearFields()
    {
        NameBox.Text = EmailBox.Text = PhoneBox.Text = CodeBox.Text = "";
        PassBox.Password = PassBox2.Password = "";
        UpdateHints();
    }

    void Fail(string key)
    {
        Sfx.Play(Sfx.S.Error);
        ErrorText.Text = Strings.T(key);
        ErrorText.Visibility = Visibility.Visible;
        Wiggle(Lock1Rot);
        if (FPass2.Visibility == Visibility.Visible) Wiggle(Lock2Rot);
        Shake();
    }

    void Shake()
    {
        // shake the card, like the Android version (380 ms)
        var a = new DoubleAnimationUsingKeyFrames { Duration = TimeSpan.FromMilliseconds(380) };
        foreach (var (ms, v) in new (int, double)[] { (0, 0), (60, -18), (130, 18), (200, -12), (260, 12), (320, -6), (380, 0) })
            a.KeyFrames.Add(new LinearDoubleKeyFrame(v, KeyTime.FromTimeSpan(TimeSpan.FromMilliseconds(ms))));
        CardMove.BeginAnimation(TranslateTransform.XProperty, a);
    }

    void Clear_Changed(object sender, RoutedEventArgs e)
    {
        if (ErrorText != null) ErrorText.Visibility = Visibility.Collapsed;
        UpdateHints();
    }

    // ---- phone (student sign-up): required, checked by PhoneRules, the message is written under the field ----
    void ShowPhoneError(string key)
    {
        if (key == null) { PhoneError.Visibility = Visibility.Collapsed; return; }
        PhoneError.Text = Strings.T(key);
        PhoneError.Visibility = Visibility.Visible;
    }

    void Phone_Changed(object sender, RoutedEventArgs e)
    {
        Clear_Changed(sender, e);
        if (PhoneError != null) PhoneError.Visibility = Visibility.Collapsed;
    }

    void Phone_LostFocus(object sender, RoutedEventArgs e)
    {
        // leaving the field with something typed shows what is wrong with the number
        if (FPhone.Visibility == Visibility.Visible && PhoneBox.Text.Trim().Length > 0) ShowPhoneError(PhoneRules.ErrorKey(PhoneBox.Text));
    }

    void FailPhone(string key)
    {
        Sfx.Play(Sfx.S.Error);
        ShowPhoneError(key);
        Shake();
        PhoneBox.Focus();
    }

    // ---- eye: show / hide the password (works on both password fields, like Android); it blinks while the picture is swapped ----
    bool _passVisible, _syncing, _eyeBusy;

    void Eye_Click(object sender, RoutedEventArgs e)
    {
        if (_eyeBusy) return;
        _eyeBusy = true;
        var shut = new DoubleAnimation(1, 0.08, TimeSpan.FromMilliseconds(110)) { EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut } };
        shut.Completed += (_, _) =>
        {
            ToggleEye();
            var open = new DoubleAnimation(0.08, 1, TimeSpan.FromMilliseconds(260)) { EasingFunction = new BackEase { EasingMode = EasingMode.EaseOut, Amplitude = 1.8 } };
            open.Completed += (_, _) => _eyeBusy = false;
            EyeScale.BeginAnimation(ScaleTransform.ScaleYProperty, open);
        };
        EyeScale.BeginAnimation(ScaleTransform.ScaleYProperty, shut);
    }

    void ToggleEye()
    {
        _passVisible = !_passVisible;
        var had = PassText.IsKeyboardFocused || PassBox.IsKeyboardFocused;
        _syncing = true;
        PassText.Text = PassBox.Password;
        PassText2.Text = PassBox2.Password;
        _syncing = false;
        PassText.Visibility = PassText2.Visibility = _passVisible ? Visibility.Visible : Visibility.Collapsed;
        PassBox.Visibility = PassBox2.Visibility = _passVisible ? Visibility.Collapsed : Visibility.Visible;
        EyeOn.Visibility = _passVisible ? Visibility.Collapsed : Visibility.Visible;
        EyeOff.Visibility = _passVisible ? Visibility.Visible : Visibility.Collapsed;
        if (had)
        {
            if (_passVisible) { PassText.Focus(); PassText.CaretIndex = PassText.Text.Length; }
            else PassBox.Focus();
        }
    }

    void Pass_Changed(object sender, RoutedEventArgs e)
    {
        if (!_syncing && PassText != null && PassText2 != null)
        {
            _syncing = true;
            PassText.Text = PassBox.Password;
            PassText2.Text = PassBox2.Password;
            _syncing = false;
        }
        Clear_Changed(sender, e);
    }

    void PassText_Changed(object sender, TextChangedEventArgs e)
    {
        if (!_syncing && PassBox != null && PassBox2 != null)
        {
            _syncing = true;
            PassBox.Password = PassText.Text;
            PassBox2.Password = PassText2.Text;
            _syncing = false;
        }
        Clear_Changed(sender, e);
    }

    // ---- "create a new account": the whole row is the click target (the tick itself does not take clicks) ----
    void SignRow_Up(object sender, MouseButtonEventArgs e)
    {
        SignRow.Focus();
        SignCheck.Toggle();
    }

    void SignRow_Key(object sender, KeyEventArgs e)
    {
        if (e.Key != Key.Space) return;
        SignCheck.Toggle();
        e.Handled = true;
    }

    void Alt_Click(object sender, RoutedEventArgs e)
    {
        if (_admin) CloseAdmin();   // the "back" link exists only in the admin screen
    }

    void Lang_Click(object sender, RoutedEventArgs e)
    {
        Prefs.Ar = !Prefs.Ar;
        MainWindow.Instance.Reload();
    }

    void Theme_Click(object sender, RoutedEventArgs e)
    {
        Prefs.Dark = !Prefs.Dark;
        MainWindow.Instance.Reload();
    }

    bool _busy;

    /// <summary>Release 53: an account is created only when the server accepted it first (needs internet). ok creates the local account.</summary>

    /// <summary>
    /// Release 64: the number must be proven before the account is made. WhatsApp opens with a ready message, the student sends it from HIS number,
    /// the server answers with a 6-digit code in the chat, the student types it in the sheet, and only then <paramref name="then"/> runs.
    /// Without a server (Remote.Enabled false) or with OtpConfig.PhoneOtpEnabled false it runs at once.
    /// </summary>
    void AskPhoneCode(string phone, Action then)
    {
        PhoneVerifier.Clear();
        if (!OtpView.Show(phone, () => PhoneVerifier.SendAsync(phone), PhoneVerifier.OpenWhatsApp, code => PhoneVerifier.CheckAsync(phone, code), then))
            then();
    }

    async void Online(string role, string email, string pass, string name, string phone, string grade, string code, Action ok)
    {
        if (_busy) return;
        _busy = true;
        var err = await ServerSync.RegisterAsync(role, email, pass, name, phone, grade, code);
        _busy = false;
        if (err == null) ok(); else Fail(err);
    }

    void Go_Click(object sender, RoutedEventArgs e)
    {
        var email = EmailBox.Text.Trim().ToLowerInvariant();
        var pass = PassBox.Password;

        if (_admin)
        {
            if (email.Length == 0 || pass.Length == 0) { Fail("err_enter_creds"); return; }
            var a = Store.Admin();
            if (a == null)
            {
                if (!email.Contains('@')) { Fail("err_enter_creds"); return; }
                if (pass.Length < 6) { Fail("err_teacher_short"); return; }
                if (pass != PassBox2.Password) { Fail("err_pw_mismatch"); return; }
                // release 57: the server decides first (first admin = main, the others need a one-time code); then the local admin is made
                Online("admin", email, pass, "", "", "", CodeBox.Text, () =>
                {
                    Store.SetAdmin(email, pass);
                    Sfx.Play(Sfx.S.Success); Store.SetSession("admin", email);
                    MainWindow.Instance.ShowAdmin();
                });
                return;
            }
            else if (a.Value.Email != email || a.Value.PwHash != Store.Hash(pass)) { Fail("err_bad_login"); return; }
            Sfx.Play(Sfx.S.Success); Store.SetSession("admin", email);
            ServerSync.Mirror("admin", email, pass);
            MainWindow.Instance.ShowAdmin();
            return;
        }

        if (_teacher)
        {
            if (email.Length == 0 || pass.Length == 0) { Fail("err_enter_creds"); return; }
            var t = Store.Teacher();
            if (_signup)
            {
                // teacher sign-up (same checks and order as Android): code, name, password 6+, confirm, required phone
                if (!email.Contains('@')) { Fail("err_enter_creds"); return; }
                if (t != null) { Fail("err_teacher_exists"); return; }
                var key = TeacherCode.ErrorKey(TeacherCode.Verify(CodeBox.Text));
                if (key != null) { Fail(key); return; }
                var tName = NameBox.Text.Trim();
                if (tName.Length == 0) { Fail("err_name_required"); return; }
                if (pass.Length < 6) { Fail("err_teacher_short"); return; }
                if (pass != PassBox2.Password) { Fail("err_pw_mismatch"); return; }
                // phone: required, checked by PhoneRules (same as the student sign-up)
                var tPhoneKey = PhoneRules.ErrorKey(PhoneBox.Text);
                ShowPhoneError(tPhoneKey);
                if (tPhoneKey != null) { FailPhone(tPhoneKey); return; }
                var tPhone = PhoneRules.Normalize(PhoneBox.Text);
                var tCode = CodeBox.Text;
                AskPhoneCode(tPhone, () => Online("teacher", email, pass, tName, tPhone, "", tCode, () =>
                {
                    Store.SetTeacher(email, pass, tPhone, tName);
                    TeacherCode.MarkUsed(tCode);
                    Sfx.Play(Sfx.S.Success); Store.SetSession("teacher", email);
                    MainWindow.Instance.ShowTeacher();
                }));
                return;
            }
            else if (t == null)
            {
                if (!email.Contains('@')) { Fail("err_enter_creds"); return; }
                var codeKey = TeacherCode.ErrorKey(TeacherCode.Verify(CodeBox.Text));
                if (codeKey != null) { Fail(codeKey); return; }
                if (pass.Length < 6) { Fail("err_teacher_short"); return; }
                var tCode = CodeBox.Text;
                Online("teacher", email, pass, "", "", "", tCode, () =>
                {
                    Store.SetTeacher(email, pass);
                    TeacherCode.MarkUsed(tCode);
                    Sfx.Play(Sfx.S.Success); Store.SetSession("teacher", email);
                    MainWindow.Instance.ShowTeacher();
                });
                return;
            }
            else if (t.Value.Email != email || t.Value.PwHash != Store.Hash(pass)) { Fail("err_bad_login"); return; }
            Sfx.Play(Sfx.S.Success); Store.SetSession("teacher", email);
            ServerSync.Mirror("teacher", email, pass);
            MainWindow.Instance.ShowTeacher();
            return;
        }

        if (!_signup)
        {
            if (email.Length == 0 || pass.Length == 0) { Fail("err_enter_creds"); return; }
            var s = Store.FindStudent(email);
            if (s == null || s.PwHash != Store.Hash(pass)) { Fail("err_bad_login"); return; }
            Sfx.Play(Sfx.S.Success); Store.SetSession("student", email);
            ServerSync.Mirror("student", email, pass);
            MainWindow.Instance.ShowStudent();
            return;
        }

        var name = NameBox.Text.Trim();
        // phone: required, checked by PhoneRules; the message goes under the field (also when something else is missing too)
        var phoneKey = PhoneRules.ErrorKey(PhoneBox.Text);
        ShowPhoneError(phoneKey);
        if (name.Length == 0 || !email.Contains('@') || pass.Length < 6 || _grades.Count == 0)
        { Fail("err_fill_all"); return; }
        if (phoneKey != null) { FailPhone(phoneKey); return; }
        if (pass != PassBox2.Password) { Fail("err_pw_mismatch"); return; }
        var phone = PhoneRules.Normalize(PhoneBox.Text);

        var all = Store.Students();
        if (all.Any(x => x.Email == email)) { Fail("err_email_used"); return; }

        var grade = GradePanel.Children.OfType<RadioButton>().FirstOrDefault(r => r.IsChecked == true)?.Content as string ?? _grades[0];
        var pwHash = Store.Hash(pass);
        void CreateAccount() => Online("student", email, pass, name, phone, grade, "", () =>
        {
            all.Add(new Core.Student { Name = name, Phone = phone, Email = email, PwHash = pwHash, Grade = grade });
            Store.SaveStudents(all);
            Sfx.Play(Sfx.S.Success); Store.SetSession("student", email);
            MainWindow.Instance.ShowStudent();
        });

        AskPhoneCode(phone, CreateAccount);
    }
}
