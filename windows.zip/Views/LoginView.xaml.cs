using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using NexoraEdu.Core;

namespace NexoraEdu.Views;

/// <summary>
/// Student sign-in and sign-up (port of the student part of LoginActivity.submit, same checks, same order, same error texts).
/// Hidden admin entry: hold the logo 7 s (cancelled by lifting the button or leaving the logo). Teacher sign-in / first-time account (Student | Teacher switch) lands on the teacher placeholder until the teacher side exists.
/// </summary>
public partial class LoginView : UserControl
{
    bool _signup;
    bool _admin;
    bool _teacher;
    readonly DispatcherTimer _hold = new() { Interval = TimeSpan.FromMilliseconds(7000) };
    readonly List<string> _grades = Store.Grades();
    static bool _introPlayed;

    public LoginView()
    {
        InitializeComponent();
        foreach (var g in _grades)
            GradePanel.Children.Add(new RadioButton { Style = (Style)FindResource("Chip"), GroupName = "grade", Content = g });
        if (GradePanel.Children.Count > 0) ((RadioButton)GradePanel.Children[0]).IsChecked = true;

        _hold.Tick += (_, _) => { _hold.Stop(); OpenAdmin(); };
        Unloaded += (_, _) => _hold.Stop();

        RoleStudent.IsChecked = true;
        LangBtn.Content = Prefs.Ar ? "English" : "العربية";
        ThemeBtn.Content = Strings.T(Prefs.Dark ? "light" : "dark");
        Refresh();

        // glass entrance: the card rises and fades in (only the first time, not after a language / theme change)
        if (!_introPlayed)
        {
            _introPlayed = true;
            Card.Opacity = 0;
            var tt = new System.Windows.Media.TranslateTransform(0, 40);
            Card.RenderTransform = tt;
            Loaded += (_, _) =>
            {
                var ease = new CubicEase { EasingMode = EasingMode.EaseOut };
                Card.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(600)) { EasingFunction = ease });
                tt.BeginAnimation(System.Windows.Media.TranslateTransform.YProperty, new DoubleAnimation(40, 0, TimeSpan.FromMilliseconds(650)) { EasingFunction = ease });
            };
        }
    }

    void Refresh()
    {
        ErrorText.Visibility = Visibility.Collapsed;
        PhoneError.Visibility = Visibility.Collapsed;
        var setup = _admin && Store.Admin() == null;
        var teacher = _teacher && !_admin;
        var up = _signup && !_teacher && !_admin;
        var tup = _signup && teacher; // teacher creating a new account (name, required phone, confirm password)
        Seg.Visibility = _admin ? Visibility.Collapsed : Visibility.Visible;
        if (_admin)
        {
            Title.Text = Strings.T(setup ? "title_admin_setup" : "title_admin");
            Subtitle.Text = Strings.T(setup ? "sub_admin_setup" : "sub_admin");
        }
        else if (teacher)
        {
            Title.Text = Strings.T("title_teacher");
            Subtitle.Text = Strings.T("sub_teacher");
        }
        else
        {
            Title.Text = Strings.T(up ? "title_signup" : "title_signin");
            Subtitle.Text = Strings.T(up ? "sub_signup" : "sub_signin");
        }
        // registration code: only while a teacher account is still to be created; release 57: the admin sets up the account with an activation code too
        CodeLabel.Text = Strings.T(_admin ? "adm_code_hint" : "hint_tcode");
        FCode.Visibility = setup || (teacher && (_signup || Store.Teacher() == null)) ? Visibility.Visible : Visibility.Collapsed;
        FName.Visibility = FPhone.Visibility = up || tup ? Visibility.Visible : Visibility.Collapsed;
        PhoneLabel.Text = Strings.T("hint_phone"); // phone is required for students and teachers
        FPass2.Visibility = setup || up || tup ? Visibility.Visible : Visibility.Collapsed;
        FGrade.Visibility = up && _grades.Count > 0 ? Visibility.Visible : Visibility.Collapsed;
        NoGrades.Visibility = up && _grades.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
        TeacherHint.Visibility = teacher && !_signup && Store.Teacher() == null ? Visibility.Visible : Visibility.Collapsed;
        BtnGo.Content = Strings.T(up || tup || setup ? "btn_signup" : "btn_signin");
        AltRow.Visibility = Visibility.Visible;
        AltText.Text = _admin ? "" : Strings.T(_signup ? "q_have_account" : "q_new_here");
        AltLink.Content = Strings.T(_admin ? "back" : _signup ? "btn_signin" : "btn_signup");
    }

    void Role_Checked(object sender, RoutedEventArgs e)
    {
        _teacher = ReferenceEquals(sender, RoleTeacher);
        Accents.Role = _teacher ? "teacher" : "student";   // the teacher side of the sign-in is purple
        App.ApplyTheme(Prefs.Dark);
        _signup = false;
        Refresh();
    }

    // ---- hidden admin entry: no hint of any kind while holding ----
    void Logo_Down(object sender, MouseButtonEventArgs e)
    {
        _hold.Stop();
        _hold.Start();
    }

    void Logo_Up(object sender, MouseEventArgs e) => _hold.Stop();

    void OpenAdmin()
    {
        if (_admin) return;
        _admin = true;
        _signup = false;
        ClearFields();
        Refresh();
    }

    void CloseAdmin()
    {
        _admin = false;
        ClearFields();
        Refresh();
    }

    void ClearFields()
    {
        NameBox.Text = EmailBox.Text = PhoneBox.Text = CodeBox.Text = "";
        PassBox.Password = PassBox2.Password = "";
    }

    void Fail(string key)
    {
        Sfx.Play(Sfx.S.Error);
        ErrorText.Text = Strings.T(key);
        ErrorText.Visibility = Visibility.Visible;
        Shake();
    }

    void Shake()
    {
        // shake the card, like the Android version (380 ms)
        var tt = new System.Windows.Media.TranslateTransform();
        Card.RenderTransform = tt;
        var a = new DoubleAnimationUsingKeyFrames { Duration = TimeSpan.FromMilliseconds(380) };
        foreach (var (ms, v) in new (int, double)[] { (0, 0), (60, -18), (130, 18), (200, -12), (260, 12), (320, -6), (380, 0) })
            a.KeyFrames.Add(new LinearDoubleKeyFrame(v, KeyTime.FromTimeSpan(TimeSpan.FromMilliseconds(ms))));
        tt.BeginAnimation(System.Windows.Media.TranslateTransform.XProperty, a);
    }

    void Clear_Changed(object sender, RoutedEventArgs e)
    {
        if (ErrorText != null) ErrorText.Visibility = Visibility.Collapsed;
    }

    // ---- phone (student sign-up): required, checked by PhoneRules, the message is written under the field ----
    void ShowPhoneError(string key)
    {
        if (key == null) { PhoneError.Visibility = Visibility.Collapsed; return; }
        PhoneError.Text = Strings.T(key);
        PhoneError.Visibility = Visibility.Visible;
    }

    void Phone_Changed(object sender, RoutedEventArgs e)
    {
        Clear_Changed(sender, e);
        if (PhoneError != null) PhoneError.Visibility = Visibility.Collapsed;
    }

    void Phone_LostFocus(object sender, RoutedEventArgs e)
    {
        // leaving the field with something typed shows what is wrong with the number
        if (FPhone.Visibility == Visibility.Visible && PhoneBox.Text.Trim().Length > 0) ShowPhoneError(PhoneRules.ErrorKey(PhoneBox.Text));
    }

    void FailPhone(string key)
    {
        Sfx.Play(Sfx.S.Error);
        ShowPhoneError(key);
        Shake();
        PhoneBox.Focus();
    }

    // ---- eye: show / hide the password (works on both password fields, like Android) ----
    bool _passVisible, _syncing;

    void Eye_Click(object sender, RoutedEventArgs e)
    {
        _passVisible = !_passVisible;
        var had = PassText.IsKeyboardFocused || PassBox.IsKeyboardFocused;
        _syncing = true;
        PassText.Text = PassBox.Password;
        PassText2.Text = PassBox2.Password;
        _syncing = false;
        PassText.Visibility = PassText2.Visibility = _passVisible ? Visibility.Visible : Visibility.Collapsed;
        PassBox.Visibility = PassBox2.Visibility = _passVisible ? Visibility.Collapsed : Visibility.Visible;
        EyeOn.Visibility = _passVisible ? Visibility.Collapsed : Visibility.Visible;
        EyeOff.Visibility = _passVisible ? Visibility.Visible : Visibility.Collapsed;
        if (had)
        {
            if (_passVisible) { PassText.Focus(); PassText.CaretIndex = PassText.Text.Length; }
            else PassBox.Focus();
        }
    }

    void Pass_Changed(object sender, RoutedEventArgs e)
    {
        if (!_syncing && PassText != null && PassText2 != null)
        {
            _syncing = true;
            PassText.Text = PassBox.Password;
            PassText2.Text = PassBox2.Password;
            _syncing = false;
        }
        Clear_Changed(sender, e);
    }

    void PassText_Changed(object sender, TextChangedEventArgs e)
    {
        if (!_syncing && PassBox != null && PassBox2 != null)
        {
            _syncing = true;
            PassBox.Password = PassText.Text;
            PassBox2.Password = PassText2.Text;
            _syncing = false;
        }
        Clear_Changed(sender, e);
    }

    void Alt_Click(object sender, RoutedEventArgs e)
    {
        if (_admin) { CloseAdmin(); return; }
        _signup = !_signup;
        Refresh();
    }

    void Lang_Click(object sender, RoutedEventArgs e)
    {
        Prefs.Ar = !Prefs.Ar;
        MainWindow.Instance.Reload();
    }

    void Theme_Click(object sender, RoutedEventArgs e)
    {
        Prefs.Dark = !Prefs.Dark;
        MainWindow.Instance.Reload();
    }

    bool _busy;

    /// <summary>Release 53: an account is created only when the server accepted it first (needs internet). ok creates the local account.</summary>
    async void Online(string role, string email, string pass, string name, string phone, string grade, string code, Action ok)
    {
        if (_busy) return;
        _busy = true;
        var err = await ServerSync.RegisterAsync(role, email, pass, name, phone, grade, code);
        _busy = false;
        if (err == null) ok(); else Fail(err);
    }

    void Go_Click(object sender, RoutedEventArgs e)
    {
        var email = EmailBox.Text.Trim().ToLowerInvariant();
        var pass = PassBox.Password;

        if (_admin)
        {
            if (email.Length == 0 || pass.Length == 0) { Fail("err_enter_creds"); return; }
            var a = Store.Admin();
            if (a == null)
            {
                if (!email.Contains('@')) { Fail("err_enter_creds"); return; }
                if (pass.Length < 6) { Fail("err_teacher_short"); return; }
                if (pass != PassBox2.Password) { Fail("err_pw_mismatch"); return; }
                // release 57: the server decides first (first admin = main, the others need a one-time code); then the local admin is made
                Online("admin", email, pass, "", "", "", CodeBox.Text, () =>
                {
                    Store.SetAdmin(email, pass);
                    Sfx.Play(Sfx.S.Success); Store.SetSession("admin", email);
                    MainWindow.Instance.ShowAdmin();
                });
                return;
            }
            else if (a.Value.Email != email || a.Value.PwHash != Store.Hash(pass)) { Fail("err_bad_login"); return; }
            Sfx.Play(Sfx.S.Success); Store.SetSession("admin", email);
            ServerSync.Mirror("admin", email, pass);
            MainWindow.Instance.ShowAdmin();
            return;
        }

        if (_teacher)
        {
            if (email.Length == 0 || pass.Length == 0) { Fail("err_enter_creds"); return; }
            var t = Store.Teacher();
            if (_signup)
            {
                // teacher sign-up (same checks and order as Android): code, name, password 6+, confirm, required phone
                if (!email.Contains('@')) { Fail("err_enter_creds"); return; }
                if (t != null) { Fail("err_teacher_exists"); return; }
                var key = TeacherCode.ErrorKey(TeacherCode.Verify(CodeBox.Text));
                if (key != null) { Fail(key); return; }
                var tName = NameBox.Text.Trim();
                if (tName.Length == 0) { Fail("err_name_required"); return; }
                if (pass.Length < 6) { Fail("err_teacher_short"); return; }
                if (pass != PassBox2.Password) { Fail("err_pw_mismatch"); return; }
                // phone: required, checked by PhoneRules (same as the student sign-up)
                var tPhoneKey = PhoneRules.ErrorKey(PhoneBox.Text);
                ShowPhoneError(tPhoneKey);
                if (tPhoneKey != null) { FailPhone(tPhoneKey); return; }
                var tPhone = PhoneRules.Normalize(PhoneBox.Text);
                var tCode = CodeBox.Text;
                Online("teacher", email, pass, tName, tPhone, "", tCode, () =>
                {
                    Store.SetTeacher(email, pass, tPhone, tName);
                    TeacherCode.MarkUsed(tCode);
                    Sfx.Play(Sfx.S.Success); Store.SetSession("teacher", email);
                    MainWindow.Instance.ShowTeacher();
                });
                return;
            }
            else if (t == null)
            {
                if (!email.Contains('@')) { Fail("err_enter_creds"); return; }
                var codeKey = TeacherCode.ErrorKey(TeacherCode.Verify(CodeBox.Text));
                if (codeKey != null) { Fail(codeKey); return; }
                if (pass.Length < 6) { Fail("err_teacher_short"); return; }
                var tCode = CodeBox.Text;
                Online("teacher", email, pass, "", "", "", tCode, () =>
                {
                    Store.SetTeacher(email, pass);
                    TeacherCode.MarkUsed(tCode);
                    Sfx.Play(Sfx.S.Success); Store.SetSession("teacher", email);
                    MainWindow.Instance.ShowTeacher();
                });
                return;
            }
            else if (t.Value.Email != email || t.Value.PwHash != Store.Hash(pass)) { Fail("err_bad_login"); return; }
            Sfx.Play(Sfx.S.Success); Store.SetSession("teacher", email);
            ServerSync.Mirror("teacher", email, pass);
            MainWindow.Instance.ShowTeacher();
            return;
        }

        if (!_signup)
        {
            if (email.Length == 0 || pass.Length == 0) { Fail("err_enter_creds"); return; }
            var s = Store.FindStudent(email);
            if (s == null || s.PwHash != Store.Hash(pass)) { Fail("err_bad_login"); return; }
            Sfx.Play(Sfx.S.Success); Store.SetSession("student", email);
            ServerSync.Mirror("student", email, pass);
            MainWindow.Instance.ShowStudent();
            return;
        }

        var name = NameBox.Text.Trim();
        // phone: required, checked by PhoneRules; the message goes under the field (also when something else is missing too)
        var phoneKey = PhoneRules.ErrorKey(PhoneBox.Text);
        ShowPhoneError(phoneKey);
        if (name.Length == 0 || !email.Contains('@') || pass.Length < 6 || _grades.Count == 0)
        { Fail("err_fill_all"); return; }
        if (phoneKey != null) { FailPhone(phoneKey); return; }
        if (pass != PassBox2.Password) { Fail("err_pw_mismatch"); return; }
        var phone = PhoneRules.Normalize(PhoneBox.Text);

        var all = Store.Students();
        if (all.Any(x => x.Email == email)) { Fail("err_email_used"); return; }

        var grade = GradePanel.Children.OfType<RadioButton>().FirstOrDefault(r => r.IsChecked == true)?.Content as string ?? _grades[0];
        var pwHash = Store.Hash(pass);
        void CreateAccount() => Online("student", email, pass, name, phone, grade, "", () =>
        {
            all.Add(new Core.Student { Name = name, Phone = phone, Email = email, PwHash = pwHash, Grade = grade });
            Store.SaveStudents(all);
            Sfx.Play(Sfx.S.Success); Store.SetSession("student", email);
            MainWindow.Instance.ShowStudent();
        });

        // code check (hidden while OtpConfig.PhoneOtpEnabled is false: Show returns false and the account is created as before)
        if (OtpConfig.PhoneOtpEnabled) PhoneVerifier.Send(phone);
        if (!OtpView.Show(phone, code => PhoneVerifier.Check(phone, code), () => PhoneVerifier.Send(phone), CreateAccount))
            CreateAccount();
    }
}
