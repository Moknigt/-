using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using NexoraEdu.Core;
using NexoraEdu.Views.Student;

namespace NexoraEdu.Views;

/// <summary>Phone verification settings. The OTP screen and everything that depends on it stays hidden while <see cref="PhoneOtpEnabled"/> is false.</summary>
public static class OtpConfig
{
    /// <summary>Master switch (release 64: ON). false = <see cref="OtpView.Show"/> does nothing and sign-up works exactly as before. Also off while no server is set (Remote.Enabled).</summary>
    public static readonly bool PhoneOtpEnabled = true;
    public const int CodeLength = 6;
    public const int ResendSeconds = 60;
}

/// <summary>
/// The code entry screen (a sheet like the other ones): 6 boxes, a wrong-code state and a resend link that counts down for real.
/// It does not send or check anything itself: <c>send</c> starts a request (the student then writes first on WhatsApp; called once when the sheet opens
/// and again on "new request"), <c>openWa</c> reopens the WhatsApp chat of the current request, <c>verify</c> decides if the code is right.
/// <see cref="Show"/> returns false (and shows nothing) while <see cref="OtpConfig.PhoneOtpEnabled"/> is false or there is no server.
/// </summary>
public static class OtpView
{
    static Brush B(string key) => (Brush)Application.Current.FindResource(key);
    static Style S(string key) => (Style)Application.Current.FindResource(key);

    public static bool Show(string phone, Func<Task<OtpResult>> send, Action openWa, Func<string, Task<OtpResult>> verify, Action onVerified, Action onCancel = null)
    {
        if (!OtpConfig.PhoneOtpEnabled || !Remote.Enabled) return false;

        var verified = false;
        var wrong = false;
        var checking = false;
        var closed = false;
        var left = OtpConfig.ResendSeconds;
        var timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };

        Ui.Sheet(Strings.T("otp_title"), (c, w) =>
        {
            var sub = new TextBlock { Text = Strings.T("otp_sub", phone), TextWrapping = TextWrapping.Wrap, FontSize = 13, Margin = new Thickness(0, -6, 0, 0) };
            sub.SetResourceReference(TextBlock.ForegroundProperty, "mut");
            c.Children.Add(sub);

            // the digits always run left to right, also in Arabic
            var row = new UniformGrid { Columns = OtpConfig.CodeLength, FlowDirection = FlowDirection.LeftToRight, Margin = new Thickness(0, 22, 0, 0), RenderTransform = new TranslateTransform() };
            var boxes = new List<Border>();
            for (var i = 0; i < OtpConfig.CodeLength; i++)
            {
                var digit = new TextBlock { FontSize = 22, FontWeight = FontWeights.Bold, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
                digit.SetResourceReference(TextBlock.ForegroundProperty, "tx");
                var box = new Border { Height = 54, Margin = new Thickness(4, 0, 4, 0), CornerRadius = new CornerRadius(14), BorderThickness = new Thickness(1), Child = digit, Cursor = Cursors.IBeam };
                box.SetResourceReference(Border.BackgroundProperty, "field");
                boxes.Add(box);
                row.Children.Add(box);
            }
            c.Children.Add(row);

            // one real (invisible) input: it keeps typing, paste and the code in one place; the boxes only show it
            var input = new TextBox { MaxLength = OtpConfig.CodeLength, Width = 1, Height = 1, Opacity = 0 };
            c.Children.Add(input);
            foreach (var b in boxes) b.MouseLeftButtonDown += (_, _) => input.Focus();

            var message = new TextBlock { FontSize = 13, HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 14, 0, 0), Visibility = Visibility.Collapsed };
            c.Children.Add(message);

            var go = new Button { Style = S("PrimaryButton"), Content = Strings.T("otp_verify"), Margin = new Thickness(0, 18, 0, 0) };
            c.Children.Add(go);

            var openWaBtn = new Button { Style = S("LinkButton"), Content = Strings.T("otp_open_wa"), HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 6, 0, 0) };
            openWaBtn.Click += (_, _) => openWa();
            c.Children.Add(openWaBtn);

            var resend = new Button { Style = S("LinkButton"), HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 2, 0, 0) };
            c.Children.Add(resend);

            void SetMessage(string text, bool error)
            {
                message.Visibility = text == null ? Visibility.Collapsed : Visibility.Visible;
                message.Text = text ?? "";
                message.SetResourceReference(TextBlock.ForegroundProperty, error ? "err" : "mut");
            }

            // boxes show the typed digits; the next empty box is outlined in the accent colour, all boxes turn red after a wrong code
            void PaintBoxes()
            {
                var code = input.Text;
                for (var i = 0; i < boxes.Count; i++)
                {
                    ((TextBlock)boxes[i].Child).Text = i < code.Length ? code[i].ToString() : "";
                    var active = input.IsKeyboardFocused && i == Math.Min(code.Length, OtpConfig.CodeLength - 1);
                    boxes[i].SetResourceReference(Border.BorderBrushProperty, wrong ? "err" : active ? "p1" : "bd");
                    boxes[i].BorderThickness = new Thickness(wrong || active ? 2 : 1);
                }
                var full = code.Length == OtpConfig.CodeLength;
                go.IsEnabled = full && !checking;
                go.Opacity = full ? 1 : 0.45;
            }

            void PaintResend()
            {
                resend.IsEnabled = left == 0;
                resend.Content = left > 0 ? Strings.T("otp_resend_in", $"{left / 60:00}:{left % 60:00}") : Strings.T("otp_resend");
            }

            void Shake()
            {
                var a = new DoubleAnimationUsingKeyFrames { Duration = TimeSpan.FromMilliseconds(360) };
                double t = 0;
                foreach (var v in new double[] { -16, 16, -10, 10, -5, 0 })
                {
                    t += 60;
                    a.KeyFrames.Add(new LinearDoubleKeyFrame(v, KeyTime.FromTimeSpan(TimeSpan.FromMilliseconds(t))));
                }
                ((TranslateTransform)row.RenderTransform).BeginAnimation(TranslateTransform.XProperty, a);
            }

            async void Submit()
            {
                var code = input.Text;
                if (code.Length < OtpConfig.CodeLength || checking) return;
                checking = true;
                PaintBoxes();
                var res = await verify(code);
                checking = false;
                if (closed) return;
                if (res == OtpResult.Ok)
                {
                    verified = true;
                    Sfx.Play(Sfx.S.Success);
                    w.Close();
                    onVerified();
                }
                else
                {
                    wrong = res == OtpResult.Wrong;
                    Sfx.Play(Sfx.S.Error);
                    SetMessage(Strings.T(res switch
                    {
                        OtpResult.Wrong => "otp_err_wrong",
                        OtpResult.Net => "otp_err_net",
                        OtpResult.Expired => "otp_err_expired",
                        OtpResult.Locked => "otp_err_locked",
                        OtpResult.Waiting => "otp_err_waiting",
                        _ => "otp_err_send",
                    }), true);
                    PaintBoxes();
                    Shake();
                }
            }

            // asks the server for a request; first = the sheet just opened (no "sent again" line)
            async void RequestCode(bool first)
            {
                var res = await send();
                if (closed) return;
                switch (res)
                {
                    case OtpResult.Ok: if (!first) SetMessage(Strings.T("otp_sent_again"), false); break;
                    case OtpResult.Soon: SetMessage(Strings.T("otp_err_soon"), true); break;
                    case OtpResult.Limit: SetMessage(Strings.T("otp_err_limit"), true); break;
                    case OtpResult.Net: SetMessage(Strings.T("otp_err_net"), true); left = 0; timer.Stop(); PaintResend(); break;
                    default: SetMessage(Strings.T("otp_err_send"), true); left = 0; timer.Stop(); PaintResend(); break;   // failed: a new request is open at once
                }
            }

            void StartTimer()
            {
                left = OtpConfig.ResendSeconds;
                timer.Stop();
                timer.Start();
                PaintResend();
            }

            input.TextChanged += (_, _) =>
            {
                var digits = new string(input.Text.Where(char.IsDigit).ToArray());
                if (digits != input.Text) { input.Text = digits; input.CaretIndex = digits.Length; return; }
                if (wrong) { wrong = false; SetMessage(null, false); }
                PaintBoxes();
            };
            input.PreviewKeyDown += (_, e) => { if (e.Key == Key.Enter) { Submit(); e.Handled = true; } };
            input.GotKeyboardFocus += (_, _) => PaintBoxes();
            input.LostKeyboardFocus += (_, _) => PaintBoxes();
            go.Click += (_, _) => Submit();
            resend.Click += (_, _) =>
            {
                if (left > 0) return;
                wrong = false;
                input.Text = "";
                SetMessage(null, false);
                StartTimer();
                PaintBoxes();
                RequestCode(false);
            };

            timer.Tick += (_, _) =>
            {
                if (left > 0) left--;
                if (left == 0) timer.Stop();
                PaintResend();
            };

            var cancel = new Button { Style = S("LinkButton"), Content = Strings.T("cancel"), HorizontalAlignment = HorizontalAlignment.Center };
            cancel.Click += (_, _) => w.Close();
            c.Children.Add(cancel);

            PaintBoxes();
            StartTimer();
            RequestCode(true);
            w.Loaded += (_, _) => input.Focus();
        }, () =>
        {
            closed = true;
            timer.Stop();
            if (!verified) onCancel?.Invoke();
        });
        return true;
    }
}
