using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using System.Windows.Shapes;
using NexoraEdu.Core;
using NexoraEdu.Views.Student;

namespace NexoraEdu.Views;

/// <summary>Full-screen settings (same layout as the Android and iPhone ones): profile card, language, appearance, colours
/// (a live preview bar + round swatches), log out. Built in code; MainWindow shows it over the current screen.</summary>
public class SettingsPage : UserControl
{
    static Style S(string key) => (Style)Application.Current.FindResource(key);

    public SettingsPage(bool animate)
    {
        Focusable = true;
        KeyDown += (_, e) => { if (e.Key == Key.Escape) MainWindow.Instance.CloseSettings(); };
        Loaded += (_, _) => Focus();

        var root = new Grid();
        root.Background = AppBackground.Make();   // the theme colour tinted with the accent chosen below
        root.Children.Add(new GlassAurora());

        var col = new StackPanel { MaxWidth = 640, HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(28, 20, 28, 40) };

        // header: back + title
        var head = new DockPanel { Margin = new Thickness(0, 0, 0, 18) };
        var back = new Button
        {
            Style = S("SideButton"), Content = Prefs.Ar ? "\uE76C" : "\uE76B", FontFamily = new FontFamily("Segoe MDL2 Assets"),
            FontSize = 18, Padding = new Thickness(12, 8, 12, 8), ToolTip = Strings.T("back"), Margin = new Thickness(0, 0, 14, 0)
        };
        back.Click += (_, _) => MainWindow.Instance.CloseSettings();
        DockPanel.SetDock(back, Dock.Left);
        head.Children.Add(back);
        head.Children.Add(new TextBlock { Text = Strings.T("settings"), Style = S("H1"), VerticalAlignment = VerticalAlignment.Center });
        col.Children.Add(head);

        // profile card
        var (name, sub) = Who();
        var prof = new DockPanel();
        var av = new Grid { Width = 56, Height = 56, Margin = new Thickness(0, 0, 14, 0) };
        var disc = new Ellipse();
        disc.SetResourceReference(Shape.FillProperty, "p1");
        av.Children.Add(disc);
        var ini = new TextBlock
        {
            Text = string.IsNullOrEmpty(name) ? "?" : name.Substring(0, 1).ToUpperInvariant(), FontSize = 22, FontWeight = FontWeights.Bold,
            HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center
        };
        ini.SetResourceReference(TextBlock.ForegroundProperty, "white");
        av.Children.Add(ini);
        DockPanel.SetDock(av, Dock.Left);
        prof.Children.Add(av);
        var who = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
        who.Children.Add(new TextBlock { Text = name, Style = S("H2"), FontSize = 18 });
        who.Children.Add(new TextBlock { Text = sub, Style = S("Muted") });
        prof.Children.Add(who);
        col.Children.Add(Card(prof, 16));

        // language
        col.Children.Add(Label(Strings.T("language"), 26));
        col.Children.Add(Card(Ui.Segments("set_lang", "العربية", "English", Prefs.Ar,
            ar => { Prefs.Ar = ar; MainWindow.Instance.Reload(); }), 14));

        // appearance
        col.Children.Add(Label(Strings.T("appearance"), 22));
        col.Children.Add(Card(Ui.Segments("set_theme", Strings.T("dark"), Strings.T("light"), Prefs.Dark,
            dark => { Prefs.Dark = dark; MainWindow.Instance.Reload(); }), 14));

        // colours
        col.Children.Add(Label(Strings.T("th_title"), 22));
        col.Children.Add(Card(Colours(), 14));

        var logout = new Button { Style = S("PrimaryButton"), Content = Strings.T("logout"), Margin = new Thickness(0, 32, 0, 0) };
        logout.Click += (_, _) => { Store.ClearSession(); ServerSync.SignOut(); MainWindow.Instance.ShowLogin(); };
        col.Children.Add(logout);

        root.Children.Add(new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Content = col });
        Content = root;

        // the blocks rise one after the other (light touch)
        if (animate)
        {
            var ease = new CubicEase { EasingMode = EasingMode.EaseOut };
            for (var i = 0; i < col.Children.Count; i++)
            {
                var el = col.Children[i];
                var m = new TranslateTransform(0, 18);
                el.RenderTransform = m;
                el.Opacity = 0;
                var at = TimeSpan.FromMilliseconds(60 + 45 * i);
                el.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(320)) { BeginTime = at });
                m.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(18, 0, TimeSpan.FromMilliseconds(380)) { BeginTime = at, EasingFunction = ease });
            }
        }

        if (animate)
        {
            var move = new TranslateTransform(0, 36);
            RenderTransform = move;
            Opacity = 0;
            BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(300)));
            move.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(36, 0, TimeSpan.FromMilliseconds(340))
            { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut } });
        }
    }

    static (string Name, string Sub) Who()
    {
        if (Accents.Role == "teacher")
        {
            var t = Store.Teacher();
            var n = Store.TeacherName();
            return (string.IsNullOrEmpty(n) ? (t?.Email ?? "").Split('@')[0] : n, Strings.T("role_teacher"));
        }
        if (Accents.Role == "admin") return (((Store.Admin()?.Email) ?? "").Split('@')[0], Store.Admin()?.Email ?? "");
        var me = Store.CurrentStudent();
        return (me?.Name ?? "", Strings.T("grade_label") + ": " + (me?.Grade ?? ""));
    }

    static TextBlock Label(string text, double top)
    {
        var t = new TextBlock { Text = text, Style = S("Muted"), FontWeight = FontWeights.Bold, Margin = new Thickness(4, top, 0, 10) };
        return t;
    }

    static Border Card(UIElement child, double pad) => new Border { Style = S("Card"), Padding = new Thickness(pad), Child = child };

    /// <summary>Live preview bar with the chosen name + round gradient swatches. Picking one rebuilds the app with the new colours.</summary>
    static UIElement Colours()
    {
        var box = new StackPanel();
        var (pa, pb) = Accents.Colors(Prefs.Accent);
        var preview = new Border
        {
            Height = 64, CornerRadius = new CornerRadius(18), Background = new LinearGradientBrush(pa, pb, 0),
            Child = new TextBlock
            {
                Text = Accents.Name(Prefs.Accent), Foreground = Brushes.White, FontSize = 18, FontWeight = FontWeights.Bold,
                HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center
            }
        };
        preview.Effect = new DropShadowEffect { Color = pa, BlurRadius = 26, ShadowDepth = 6, Direction = 270, Opacity = 0.45 };
        box.Children.Add(preview);

        var grid = new System.Windows.Controls.Primitives.UniformGrid { Columns = 6, Margin = new Thickness(0, 14, 0, 0) };
        foreach (var id in Accents.Ids)
        {
            var (a, b) = Accents.Colors(id);
            var on = id == Prefs.Accent;
            var cell = new Grid { Height = 62, Cursor = Cursors.Hand, Background = Brushes.Transparent, ToolTip = Accents.Name(id) };
            cell.Children.Add(new Ellipse { Width = 50, Height = 50, Fill = new LinearGradientBrush(a, b, 45) });
            var ring = new Ellipse { Width = 58, Height = 58, StrokeThickness = on ? 3 : 0, Fill = Brushes.Transparent };
            ring.SetResourceReference(Shape.StrokeProperty, "tx");
            cell.Children.Add(ring);
            if (on) cell.Children.Add(new TextBlock
            {
                Text = "\u2713", Foreground = Brushes.White, FontSize = 18, FontWeight = FontWeights.Bold,
                HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center
            });
            var pop = new ScaleTransform(1, 1);
            cell.RenderTransform = pop;
            cell.RenderTransformOrigin = new Point(0.5, 0.5);
            void Scale(double to, int ms)
            {
                var an = new DoubleAnimation(to, TimeSpan.FromMilliseconds(ms)) { EasingFunction = new BackEase { EasingMode = EasingMode.EaseOut, Amplitude = 0.8 } };
                pop.BeginAnimation(ScaleTransform.ScaleXProperty, an);
                pop.BeginAnimation(ScaleTransform.ScaleYProperty, an);
            }
            cell.MouseEnter += (_, _) => Scale(1.1, 160);
            cell.MouseLeave += (_, _) => Scale(1, 200);
            var pick = id;
            cell.MouseLeftButtonUp += (_, _) =>
            {
                if (pick == Prefs.Accent) return;
                Sfx.Play(Sfx.S.Select);
                Prefs.Accent = pick;
                MainWindow.Instance.Reload();
            };
            grid.Children.Add(cell);
        }
        box.Children.Add(grid);
        return box;
    }
}
