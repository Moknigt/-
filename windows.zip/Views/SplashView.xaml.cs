using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using NexoraEdu.Core;

namespace NexoraEdu.Views;

/// <summary>
/// Entry animation (click or any key skips): the colour orbs glow up, dust (AtomSplash) is pulled together into the icon square,
/// a second set of white / gold dust draws the flask over it (traced line by line, bubbles, golden nucleus), then the name fades in. Then MainWindow.Route().
/// The Android / iPhone "atoms" entry in 3 steps: 69 dust -> square, 70 dust -> flask (no glyph fade-in), 71 = step 3: shine, two rings, 48 sparks and a 7% pulse at the burst,
/// then the name and tagline, total 3.3 s.
/// </summary>
public partial class SplashView : UserControl
{
    const int TotalMs = 3300;   // the 4300 ms timeline of AtomSplash played 1.3x faster = 3.3 s; the burst ends at 3.04 s
    // name / tagline: the Android moments (2950 and 3300 on the timeline) converted to real time
    static readonly int BrandAt = (int)(2950 / AtomSplash.Speed), TagAt = (int)(3300 / AtomSplash.Speed);
    readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromMilliseconds(TotalMs) };
    bool _routed;

    public SplashView()
    {
        InitializeComponent();
        Brand.Text = Strings.T("app_name");
        Tag.Text = Strings.T("tagline");
        Loaded += (_, _) =>
        {
            Sfx.Play(Sfx.S.Splash);
            // wait one layout pass so the icon has its place, then start the dust on its centre
            Dispatcher.BeginInvoke(DispatcherPriority.Loaded, new Action(() =>
            {
                var c = Icon.TransformToVisual(Atom).Transform(new Point(Icon.ActualWidth / 2, Icon.ActualHeight / 2));
                Atom.Begin(c, Icon.ActualWidth, Accent("p1"), Accent("p2"));
            }));
            Atom.PulseChanged += k => { IconScale.ScaleX = k; IconScale.ScaleY = k; };   // the tile pulses with the burst (7%)
            Play();
            _timer.Tick += (_, _) => Go();
            _timer.Start();
            Focus();
        };
        Unloaded += (_, _) => { _timer.Stop(); Atom.Stop(); };
        MouseLeftButtonDown += (_, _) => Go();
        KeyDown += (_, _) => Go();
    }

    static DoubleAnimation A(double from, double to, int ms, int delay = 0, IEasingFunction ease = null) => new(from, to, TimeSpan.FromMilliseconds(ms))
    {
        BeginTime = TimeSpan.FromMilliseconds(delay),
        EasingFunction = ease ?? new CubicEase { EasingMode = EasingMode.EaseOut },
        FillBehavior = FillBehavior.HoldEnd,
    };

    static Color Accent(string key) => Application.Current.FindResource(key) is SolidColorBrush b ? b.Color : Colors.DeepSkyBlue;

    void Play()
    {
        Aurora.BeginAnimation(OpacityProperty, A(0, 1, 800));

        // the dust has built the square by about 1.3 s (real time); the plain tile fades in exactly over it (no glyph any more:
        // the flask is drawn by AtomSplash, from 1.8 s, which sits above the tile).
        Icon.BeginAnimation(OpacityProperty, A(0, 1, 450, 1300));

        // name and tagline appear while the burst is finishing (same moments and 450 ms as Android)
        Brand.BeginAnimation(OpacityProperty, A(0, 1, 450, BrandAt));
        BrandMove.BeginAnimation(TranslateTransform.YProperty, A(14, 0, 450, BrandAt));
        Tag.BeginAnimation(OpacityProperty, A(0, 1, 450, TagAt));
    }

    void Go()
    {
        if (_routed) return;
        _routed = true;
        Sfx.Stop(Sfx.S.Splash);
        _timer.Stop();
        MainWindow.Instance.Route();
    }
}
