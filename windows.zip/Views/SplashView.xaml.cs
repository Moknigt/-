using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using NexoraEdu.Core;

namespace NexoraEdu.Views;

/// <summary>
/// Entry animation (about 2.6 s, click or any key skips): the colour orbs glow up, the icon alone pops in, then the name fades in.
/// No glass plate and no beads around the icon. Then MainWindow.Route().
/// </summary>
public partial class SplashView : UserControl
{
    const int TotalMs = 2600;
    readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromMilliseconds(TotalMs) };
    bool _routed;

    public SplashView()
    {
        InitializeComponent();
        Brand.Text = Strings.T("app_name");
        Tag.Text = Strings.T("tagline");
        Loaded += (_, _) =>
        {
            Sfx.Play(Sfx.S.Splash);
            Play();
            _timer.Tick += (_, _) => Go();
            _timer.Start();
            Focus();
        };
        Unloaded += (_, _) => _timer.Stop();
        MouseLeftButtonDown += (_, _) => Go();
        KeyDown += (_, _) => Go();
    }

    static DoubleAnimation A(double from, double to, int ms, int delay = 0, IEasingFunction ease = null) => new(from, to, TimeSpan.FromMilliseconds(ms))
    {
        BeginTime = TimeSpan.FromMilliseconds(delay),
        EasingFunction = ease ?? new CubicEase { EasingMode = EasingMode.EaseOut },
        FillBehavior = FillBehavior.HoldEnd,
    };

    void Play()
    {
        var pop = new BackEase { EasingMode = EasingMode.EaseOut, Amplitude = 0.7 };

        Aurora.BeginAnimation(OpacityProperty, A(0, 1, 800));

        // the icon pops in
        Icon.BeginAnimation(OpacityProperty, A(0, 1, 300, 350));
        IconScale.BeginAnimation(ScaleTransform.ScaleXProperty, A(0.4, 1, 650, 350, pop));
        IconScale.BeginAnimation(ScaleTransform.ScaleYProperty, A(0.4, 1, 650, 350, pop));

        // name and tagline
        Brand.BeginAnimation(OpacityProperty, A(0, 1, 600, 1000));
        BrandMove.BeginAnimation(TranslateTransform.YProperty, A(14, 0, 600, 1000));
        Tag.BeginAnimation(OpacityProperty, A(0, 1, 600, 1200));
    }

    void Go()
    {
        if (_routed) return;
        _routed = true;
        Sfx.Stop(Sfx.S.Splash);
        _timer.Stop();
        MainWindow.Instance.Route();
    }
}
