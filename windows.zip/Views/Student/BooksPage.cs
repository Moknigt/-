using System.Windows.Controls;
using NexoraEdu.Core;

namespace NexoraEdu.Views.Student;

/// <summary>Books screen (port of StudentActivity.booksScreen): books, then files. Read-only list for now (opening a PDF comes with the PDF reader).</summary>
public class BooksPage : UserControl
{
    public BooksPage(StudentShell shell, Core.Student me)
    {
        var root = new StackPanel();
        root.Children.Add(Ui.Header(Strings.T("books_title"), -1, shell.Back));

        var docs = Store.Docs();
        if (docs.Count == 0) root.Children.Add(Ui.Empty("empty_books", "empty_books_sub"));
        foreach (var d in docs.Where(d => d.Kind == "book"))
            root.Children.Add(Ui.Row(Ui.GlyphBook, d.Title, null, Ui.FavButtons("book", d.Id, me.Email), () => Ui.OpenDoc(shell, d)));

        var files = docs.Where(d => d.Kind == "file").ToList();
        if (files.Count > 0)
        {
            root.Children.Add(Ui.Heading(Strings.T("files_title")));
            foreach (var d in files) root.Children.Add(Ui.Row(Ui.GlyphFile, d.Title, null, Ui.FavButtons("file", d.Id, me.Email), () => Ui.OpenDoc(shell, d)));
        }
        Content = root;
    }
}
