using System.Windows;
using System.Windows.Controls;
using NexoraEdu.Core;

namespace NexoraEdu.Views.Student;

/// <summary>One personal collection (port of StudentActivity.collection): "fav" | "later" | "imp", with the type filter chips
/// (shown only when the collection holds more than one type). Each row has a trash button that removes it from the collection (same as Android: no confirmation).</summary>
public class CollectionPage : UserControl
{
    /// <summary>Turns saved keys ("type|id") into rows; keys of deleted content are skipped (same as Android resolve()).</summary>
    public static List<(string Type, string Title, Doc Doc)> Resolve(string email, string coll) =>
        ResolveKeyed(email, coll).Select(x => (x.Type, x.Title, x.Doc)).ToList();

    /// <summary>Same as <see cref="Resolve"/> but also returns the saved key, which the trash button needs.</summary>
    static List<(string Key, string Type, string Title, Doc Doc)> ResolveKeyed(string email, string coll)
    {
        var lessons = Store.PublishedLessons();
        var docs = Store.Docs();
        var list = new List<(string, string, string, Doc)>();
        foreach (var key in Store.Collection(email, coll))
        {
            var type = key.Contains('|') ? key[..key.IndexOf('|')] : key;
            var id = key.Contains('|') ? key[(key.IndexOf('|') + 1)..] : "";
            switch (type)
            {
                case "lesson":
                case "video":
                    var l = lessons.FirstOrDefault(x => x.Id == id);
                    if (l != null) list.Add((key, type, l.Title, null));
                    break;
                case "book":
                case "file":
                    var d = docs.FirstOrDefault(x => x.Id == id);
                    if (d != null) list.Add((key, type, d.Title, d));
                    break;
            }
        }
        return list;
    }

    readonly StudentShell _shell;
    readonly Core.Student _me;
    readonly string _coll;
    string _filter = "all";   // like Android's typeFilter; kept while rows are removed

    public CollectionPage(StudentShell shell, Core.Student me, string coll)
    {
        _shell = shell; _me = me; _coll = coll;
        Render();
    }

    /// <summary>Builds the whole screen again (Android's refresh()): header count, chips and rows follow the data.</summary>
    void Render()
    {
        var items = ResolveKeyed(_me.Email, _coll);
        var kinds = items.Select(i => i.Type).Distinct().ToList();
        if (_filter != "all" && !kinds.Contains(_filter)) _filter = "all";   // the last row of that type was removed

        var root = new StackPanel();
        root.Children.Add(Ui.Header(Strings.T("coll_" + _coll), items.Count, _shell.Back));

        if (kinds.Count > 1)
        {
            var chips = new WrapPanel { Margin = new Thickness(0, 0, 0, 8) };
            void AddChip(string kind, string label)
            {
                var rb = new RadioButton
                {
                    Style = (Style)FindResource("Chip"), GroupName = "collfilter", Content = label,
                    IsChecked = kind == _filter
                };
                rb.Checked += (_, _) => { if (_filter != kind) { _filter = kind; Render(); } };
                chips.Children.Add(rb);
            }
            AddChip("all", Strings.T("all"));
            foreach (var k in kinds) AddChip(k, Ui.TypeName(k));
            root.Children.Add(chips);
        }

        var list = new StackPanel();
        var shown = items.Where(i => _filter == "all" || i.Type == _filter).ToList();
        foreach (var (key, type, title, doc) in shown)
        {
            var k = key;
            var trash = Ui.TrashButton(() => { Store.ToggleIn(_me.Email, _coll, k); Render(); });
            Action open = null;
            if (doc != null) open = () => Ui.OpenDoc(_shell, doc);
            else
            {
                var lid = k.Contains('|') ? k[(k.IndexOf('|') + 1)..] : "";
                open = () => { Ui.OpenLesson(Store.Lessons().FirstOrDefault(x => x.Id == lid), _me.Email); };
            }
            list.Children.Add(Ui.Row(Ui.GlyphOf(type), title, Ui.TypeName(type), new UIElement[] { trash }, open));
        }
        if (shown.Count == 0) list.Children.Add(Ui.Empty("nothing_here", "nothing_here_sub"));
        root.Children.Add(list);
        Content = root;
    }
}
