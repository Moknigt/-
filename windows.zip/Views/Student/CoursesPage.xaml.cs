using System.Windows;
using System.Windows.Controls;
using NexoraEdu.Core;

namespace NexoraEdu.Views.Student;

/// <summary>Courses (port of StudentActivity.study): standalone videos, collapsible chapters with progress, books, files.
/// Read-only for now (opening a video / PDF comes with the player and the PDF reader).</summary>
public partial class CoursesPage : UserControl
{
    // Which chapters are open; kept while the app runs (Android keeps it in openChapters).
    static readonly HashSet<string> OpenChapters = new();

    public CoursesPage(Core.Student me, StudentShell shell)
    {
        InitializeComponent();
        var lessons = Store.PublishedLessons();
        var chapters = Store.Chapters();
        var docs = Store.Docs();
        var seen = Store.History(me.Email).ToHashSet();

        if (lessons.Count == 0 && chapters.Count == 0 && docs.Count == 0)
        {
            EmptyCard.Visibility = Visibility.Visible;
            return;
        }

        UIElement LessonRow(Lesson l)
        {
            var sub = Ui.LessonSub(l, me.Email, seen.Contains(l.Id));
            return Ui.Row(Ui.GlyphPlay, l.Title, sub, Ui.FavButtons(l.ChapterId.Length == 0 ? "video" : "lesson", l.Id, me.Email),
                () => { Ui.OpenLesson(l, me.Email); shell.Refresh(); });
        }

        var videos = lessons.Where(l => l.ChapterId.Length == 0).ToList();
        if (videos.Count > 0)
        {
            Body.Children.Add(Ui.Heading(Strings.T("videos")));
            foreach (var l in videos) Body.Children.Add(LessonRow(l));
        }

        if (chapters.Count > 0) Body.Children.Add(Ui.Heading(Strings.T("chapters_title")));
        foreach (var ch in chapters)
        {
            var ls = lessons.Where(l => l.ChapterId == ch.Id).ToList();
            var done = ls.Count(l => seen.Contains(l.Id));

            var title = new TextBlock { Text = ch.Title, Style = (Style)FindResource("H2") };
            var chev = new TextBlock
            {
                FontFamily = new System.Windows.Media.FontFamily("Segoe MDL2 Assets"), FontSize = 14,
                VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(8, 0, 8, 0)
            };
            chev.SetResourceReference(TextBlock.ForegroundProperty, "mut");
            var top = new DockPanel();
            DockPanel.SetDock(chev, Dock.Right);   // end side of the card (mirrors in Arabic)
            top.Children.Add(chev);
            top.Children.Add(title);

            var bar = new ProgressBar
            {
                Height = 10, Minimum = 0, Maximum = 100, BorderThickness = new Thickness(0), Margin = new Thickness(0, 10, 0, 0),
                Value = ls.Count == 0 ? 0 : 100.0 * done / ls.Count
            };
            bar.SetResourceReference(ProgressBar.ForegroundProperty, "p1");
            bar.SetResourceReference(ProgressBar.BackgroundProperty, "field");

            var inner = new StackPanel();
            inner.Children.Add(top);
            inner.Children.Add(new TextBlock { Text = Strings.T("lessons_done_of", done, ls.Count), Style = (Style)FindResource("Muted"), Margin = new Thickness(0, 2, 0, 0) });
            inner.Children.Add(bar);

            var head = new Border { Style = (Style)FindResource("Card"), Child = inner, Cursor = System.Windows.Input.Cursors.Hand };

            var box = new StackPanel();
            foreach (var l in ls) box.Children.Add(LessonRow(l));

            void Sync()
            {
                var open = OpenChapters.Contains(ch.Id);
                box.Visibility = open ? Visibility.Visible : Visibility.Collapsed;
                chev.Text = open ? "\uE70E" : "\uE70D";   // chevron up / down
            }
            Sync();
            head.MouseLeftButtonUp += (_, _) =>
            {
                if (!OpenChapters.Remove(ch.Id)) OpenChapters.Add(ch.Id);
                Sync();
            };

            Body.Children.Add(head);
            Body.Children.Add(box);
        }

        var books = docs.Where(d => d.Kind == "book").ToList();
        if (books.Count > 0)
        {
            Body.Children.Add(Ui.Heading(Strings.T("books_title")));
            foreach (var d in books) Body.Children.Add(Ui.Row(Ui.GlyphBook, d.Title, null, Ui.FavButtons("book", d.Id, me.Email), () => Ui.OpenDoc(shell, d)));
        }
        var files = docs.Where(d => d.Kind == "file").ToList();
        if (files.Count > 0)
        {
            Body.Children.Add(Ui.Heading(Strings.T("files_title")));
            foreach (var d in files) Body.Children.Add(Ui.Row(Ui.GlyphFile, d.Title, null, Ui.FavButtons("file", d.Id, me.Email), () => Ui.OpenDoc(shell, d)));
        }
    }
}
