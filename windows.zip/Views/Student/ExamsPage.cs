using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NexoraEdu.Core;

namespace NexoraEdu.Views.Student;

/// <summary>Student Exams tab (release 13). Two chips: Exams and Homework.
/// Exams: the official-exams average, then every exam with its last result; tapping one starts it (one question at a time,
/// previous / next, submit), shows the result with a review of the answers, and saves it (key "results").
/// Homework: every homework with its status (not submitted / waiting / graded n of 10); tapping one opens it:
/// the teacher's note, the grade and note if graded, and a form with a text answer + one photo (key "subs", photos in data\hw).</summary>
public class ExamsPage : UserControl
{
    const string GlyphExam = "\uE73E", GlyphHw = "\uE70F";
    static string _tab = "exams";   // kept so Back from a homework returns to the Homework chip

    readonly Core.Student _me;
    readonly StudentShell _shell;

    static Style S(string key) => (Style)Application.Current.FindResource(key);
    static string T(string key, params object[] a) => Strings.T(key, a);

    public ExamsPage(Core.Student me, StudentShell shell)
    {
        _me = me; _shell = shell;
        Content = Build();
    }

    UIElement Build()
    {
        var p = new StackPanel();
        p.Children.Add(new TextBlock { Text = T("tab_exams"), Style = S("H1"), Margin = new Thickness(0, 0, 0, 16) });

        var chips = new WrapPanel { Margin = new Thickness(0, 0, 0, 14) };
        void Chip(string tag, string key)
        {
            var rb = new RadioButton { Style = S("Chip"), GroupName = "stexam", Content = T(key), IsChecked = _tab == tag };
            rb.Checked += (_, _) => { if (_tab != tag) { _tab = tag; Content = Build(); } };
            chips.Children.Add(rb);
        }
        Chip("exams", "ex_exams");
        Chip("homework", "ex_homework");
        p.Children.Add(chips);

        if (_tab == "homework") HomeworkList(p); else ExamList(p);
        return p;
    }

    // ------------------------------------------------------------------ exams

    void ExamList(StackPanel p)
    {
        var avg = Store.OfficialAverage(_me.Email);
        var card = new StackPanel();
        card.Children.Add(new TextBlock { Text = T("ex_official_avg"), Style = S("Muted") });
        var val = new TextBlock { Text = avg == null ? T("ex_no_avg") : avg + "%", FontSize = avg == null ? 14 : 30, FontWeight = FontWeights.Bold };
        val.SetResourceReference(TextBlock.ForegroundProperty, avg == null ? "mut" : "p1");
        card.Children.Add(val);
        p.Children.Add(new Border { Style = S("Card"), Margin = new Thickness(0, 0, 0, 14), Child = card });

        var list = Store.Exams();
        if (list.Count == 0) { p.Children.Add(Ui.Empty("empty_exams", "empty_exams_sub")); return; }
        foreach (var e in list.OrderByDescending(x => x.At))
        {
            var ex = e;
            var last = Store.LastResult(_me.Email, ex.Id);
            var sub = T(ex.Official ? "ex_official" : "ex_training") + "  •  " + T("ex_questions_count", ex.Qids.Count) + "  •  "
                      + (last == null ? T("ex_not_taken") : T("ex_last_result", last.Score) + "%");
            p.Children.Add(Ui.Row(GlyphExam, ex.Title, sub, null, () => Start(ex)));
        }
    }

    void Start(Exam e)
    {
        var bank = Store.Questions();
        var qs = e.Qids.Select(id => bank.FirstOrDefault(q => q.Id == id)).Where(q => q != null && q.Options.Count >= 2).ToList();
        if (qs.Count == 0) { Ui.Notice(T("ex_empty_questions")); return; }
        _shell.ShowSub(new ExamRunPage(_shell, _me, e, qs));
    }

    // ------------------------------------------------------------------ homework

    void HomeworkList(StackPanel p)
    {
        var list = Store.HomeworkAll();
        if (list.Count == 0) { p.Children.Add(Ui.Empty("ex_empty_hw", "ex_empty_hw_sub")); return; }
        foreach (var h in list.OrderByDescending(x => x.At))
        {
            var hw = h;
            var s = Store.SubmissionOf(hw.Id, _me.Email);
            var status = s == null ? T("hw_status_none") : s.Grade >= 0 ? T("hw_status_graded", s.Grade) : T("hw_status_sent");
            p.Children.Add(Ui.Row(GlyphHw, hw.Title, status, null, () => _shell.ShowSub(new HomeworkPage(_shell, _me, hw))));
        }
    }

    internal static Border OptionCard(string text, bool on, Action click)
    {
        var tb = new TextBlock { Text = text, Style = S("Body"), TextWrapping = TextWrapping.Wrap };
        var b = new Border
        {
            Style = S("Card"), Cursor = System.Windows.Input.Cursors.Hand, Padding = new Thickness(14, 12, 14, 12),
            Margin = new Thickness(0, 0, 0, 8), Child = tb, BorderThickness = new Thickness(on ? 2 : 1)
        };
        if (on) b.SetResourceReference(Border.BorderBrushProperty, "p1");
        b.MouseLeftButtonUp += (_, _) => { Sfx.Play(Sfx.S.Select); click(); };
        return b;
    }
}

/// <summary>Taking one exam: one question at a time. Nothing is saved until the student submits.</summary>
class ExamRunPage : UserControl
{
    readonly StudentShell _shell;
    readonly Core.Student _me;
    readonly Exam _exam;
    readonly List<Question> _qs;
    readonly int[] _pick;   // chosen option per question, -1 = none
    int _i;

    static Style S(string key) => (Style)Application.Current.FindResource(key);
    static string T(string key, params object[] a) => Strings.T(key, a);

    public ExamRunPage(StudentShell shell, Core.Student me, Exam exam, List<Question> qs)
    {
        _shell = shell; _me = me; _exam = exam; _qs = qs;
        _pick = Enumerable.Repeat(-1, qs.Count).ToArray();
        ShowQuestion();
    }

    void ShowQuestion()
    {
        var q = _qs[_i];
        var root = new StackPanel();
        root.Children.Add(Ui.Header(_exam.Title, -1, _shell.Back));
        root.Children.Add(new TextBlock { Text = T("ex_question_of", _i + 1, _qs.Count), Style = S("Muted"), Margin = new Thickness(0, 0, 0, 8) });
        root.Children.Add(new Border
        {
            Style = S("Card"), Margin = new Thickness(0, 0, 0, 12),
            Child = new TextBlock { Text = q.Text, Style = S("H2"), TextWrapping = TextWrapping.Wrap }
        });
        for (var k = 0; k < q.Options.Count; k++)
        {
            var idx = k;
            root.Children.Add(ExamsPage.OptionCard(q.Options[k], _pick[_i] == k, () => { _pick[_i] = idx; ShowQuestion(); }));
        }

        var nav = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 14, 0, 0) };
        var prev = new Button { Style = S("SideButton"), Content = T("ex_prev"), IsEnabled = _i > 0, Padding = new Thickness(18, 8, 18, 8), Margin = new Thickness(0, 0, 10, 0) };
        prev.Click += (_, _) => { _i--; ShowQuestion(); };
        nav.Children.Add(prev);
        var last = _i == _qs.Count - 1;
        var next = new Button { Style = S("PrimaryButton"), Content = T(last ? "ex_submit" : "ex_next"), Padding = new Thickness(22, 8, 22, 8) };
        next.Click += (_, _) =>
        {
            if (!last) { _i++; ShowQuestion(); return; }
            if (_pick.Any(x => x < 0)) Ui.Confirm(T("ex_unanswered"), "ex_submit", Finish); else Finish();
        };
        nav.Children.Add(next);
        root.Children.Add(nav);
        Content = root;
    }

    void Finish()
    {
        var total = _qs.Count;
        var correct = _qs.Where((q, i) => _pick[i] == q.Answer).Count();
        var score = correct * 100 / total;
        Store.AddResult(new Result { ExamId = _exam.Id, Email = _me.Email, Score = score, Correct = correct, Total = total, At = Store.Now() });
        Sfx.Play(score >= 50 ? Sfx.S.Pass : Sfx.S.Fail);
        ShowResult(correct, total, score);
    }

    void ShowResult(int correct, int total, int score)
    {
        var root = new StackPanel();
        root.Children.Add(Ui.Header(T("ex_result_title"), -1, _shell.Back));

        var big = new TextBlock { Text = score + "%", FontSize = 48, FontWeight = FontWeights.Bold, HorizontalAlignment = HorizontalAlignment.Center };
        big.SetResourceReference(TextBlock.ForegroundProperty, "p1");
        var box = new StackPanel();
        box.Children.Add(big);
        box.Children.Add(new TextBlock { Text = T("ex_result_line", correct, total), Style = S("H2"), HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 4, 0, 0) });
        root.Children.Add(new Border { Style = S("Card"), Margin = new Thickness(0, 0, 0, 14), Child = box });

        var again = new Button { Style = S("PrimaryButton"), Content = T("ex_retake"), HorizontalAlignment = HorizontalAlignment.Left, Padding = new Thickness(22, 10, 22, 10) };
        again.Click += (_, _) => _shell.ShowSub(new ExamRunPage(_shell, _me, _exam, _qs));
        root.Children.Add(again);

        root.Children.Add(Ui.Heading(T("ex_review")));
        for (var i = 0; i < _qs.Count; i++)
        {
            var q = _qs[i];
            var ok = _pick[i] == q.Answer;
            var p = new StackPanel();
            p.Children.Add(new TextBlock { Text = q.Text, Style = S("H2"), TextWrapping = TextWrapping.Wrap });
            var mine = new TextBlock
            {
                Text = T("ex_your_answer") + ": " + (_pick[i] < 0 ? "—" : q.Options[_pick[i]]),
                Style = S("Body"), TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 6, 0, 0)
            };
            mine.SetResourceReference(TextBlock.ForegroundProperty, ok ? "p1" : "err");
            p.Children.Add(mine);
            if (!ok)
                p.Children.Add(new TextBlock
                {
                    Text = T("ex_right_answer") + ": " + q.Options[q.Answer], Style = S("Muted"), TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 2, 0, 0)
                });
            root.Children.Add(new Border { Style = S("Card"), Margin = new Thickness(0, 0, 0, 8), Child = p });
        }
        Content = root;
    }
}

/// <summary>One homework: the teacher's note, the grade (if graded) and the answer form (text + one photo).</summary>
class HomeworkPage : UserControl
{
    static Style S(string key) => (Style)Application.Current.FindResource(key);
    static string T(string key, params object[] a) => Strings.T(key, a);

    public HomeworkPage(StudentShell shell, Core.Student me, Homework hw)
    {
        var old = Store.SubmissionOf(hw.Id, me.Email);
        var root = new StackPanel();
        root.Children.Add(Ui.Header(hw.Title, -1, shell.Back));

        if (hw.Note.Length > 0)
        {
            var n = new StackPanel();
            n.Children.Add(new TextBlock { Text = T("hw_note"), Style = S("Muted") });
            n.Children.Add(new TextBlock { Text = hw.Note, Style = S("Body"), TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 2, 0, 0) });
            root.Children.Add(new Border { Style = S("Card"), Margin = new Thickness(0, 0, 0, 12), Child = n });
        }

        // status + the teacher's feedback
        var st = new StackPanel();
        var status = new TextBlock
        {
            Text = old == null ? T("hw_status_none") : old.Grade >= 0 ? T("hw_status_graded", old.Grade) : T("hw_status_sent"),
            Style = S("H2")
        };
        status.SetResourceReference(TextBlock.ForegroundProperty, old == null ? "mut" : old.Grade >= 0 ? "p1" : "gold");
        st.Children.Add(status);
        if (old != null && old.Grade >= 0 && old.Note.Length > 0)
            st.Children.Add(new TextBlock { Text = T("hw_teacher_note") + ": " + old.Note, Style = S("Muted"), TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 4, 0, 0) });
        root.Children.Add(new Border { Style = S("Card"), Margin = new Thickness(0, 0, 0, 12), Child = st });

        // answer form
        root.Children.Add(new TextBlock { Text = T("hw_your_answer"), Style = S("Muted"), Margin = new Thickness(0, 4, 0, 4) });
        var text = new TextBox
        {
            Style = S("Field"), AcceptsReturn = true, TextWrapping = TextWrapping.Wrap, MinHeight = 120,
            VerticalContentAlignment = VerticalAlignment.Top, Text = old?.Text ?? ""
        };
        root.Children.Add(text);

        var photoName = old?.Photo ?? "";   // the saved photo that stays unless it is removed / replaced
        string picked = null;               // a new photo chosen in this form
        var photoBox = new StackPanel { Margin = new Thickness(0, 10, 0, 0) };
        var err = new TextBlock { Style = S("Muted"), Margin = new Thickness(0, 10, 0, 0), TextWrapping = TextWrapping.Wrap, Visibility = Visibility.Collapsed };
        err.SetResourceReference(TextBlock.ForegroundProperty, "err");

        void DrawPhoto()
        {
            photoBox.Children.Clear();
            if (picked != null)
                photoBox.Children.Add(new TextBlock { Text = T("hw_photo_selected"), Style = S("Muted"), Margin = new Thickness(0, 0, 0, 6) });
            else if (photoName.Length > 0)
            {
                var img = Photos.Load(photoName);
                if (img != null)
                    photoBox.Children.Add(new System.Windows.Controls.Image { Source = img, MaxHeight = 220, Stretch = Stretch.Uniform, HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 0, 0, 6) });
                else
                    photoBox.Children.Add(new TextBlock { Text = T("hw_photo_missing"), Style = S("Muted"), Margin = new Thickness(0, 0, 0, 6) });
            }
            var row = new StackPanel { Orientation = Orientation.Horizontal };
            var choose = new Button { Style = S("LinkButton"), Content = T("hw_choose_photo"), Margin = new Thickness(0, 0, 16, 0) };
            choose.Click += (_, _) =>
            {
                var dlg = new Microsoft.Win32.OpenFileDialog { Filter = "Images|*.jpg;*.jpeg;*.png;*.bmp;*.gif|All files|*.*" };
                if (dlg.ShowDialog() != true) return;
                picked = dlg.FileName;
                DrawPhoto();
            };
            row.Children.Add(choose);
            if (picked != null || photoName.Length > 0)
            {
                var remove = new Button { Style = S("LinkButton"), Content = T("hw_remove_photo") };
                remove.Click += (_, _) => { picked = null; photoName = ""; DrawPhoto(); };
                row.Children.Add(remove);
            }
            photoBox.Children.Add(row);
        }
        DrawPhoto();
        root.Children.Add(photoBox);
        root.Children.Add(err);

        var submit = new Button
        {
            Style = S("PrimaryButton"), Content = T(old == null ? "hw_submit" : "hw_resubmit"),
            HorizontalAlignment = HorizontalAlignment.Left, Padding = new Thickness(22, 10, 22, 10), Margin = new Thickness(0, 16, 0, 0)
        };
        submit.Click += (_, _) =>
        {
            void Fail(string key) { err.Text = T(key); err.Visibility = Visibility.Visible; }
            var answer = text.Text.Trim();
            if (answer.Length == 0 && picked == null && photoName.Length == 0) { Fail("hw_err_empty"); return; }

            var keep = photoName;
            if (picked != null)
            {
                var saved = Photos.SaveHomework(picked);
                if (saved == null) { Fail("hw_err_photo"); return; }
                keep = saved;
            }
            // the old photo goes away when it was replaced or removed
            if (old != null && old.Photo.Length > 0 && old.Photo != keep) Store.DeletePhotoFile(old.Photo);

            Store.PutSubmission(new Submission { HwId = hw.Id, Email = me.Email, Text = answer, Photo = keep, Grade = -1, Note = "", At = Store.Now() });
            Sfx.Play(Sfx.S.Success);
            shell.Back();   // rebuilds the tab: the row shows the new status
        };
        root.Children.Add(submit);
        Content = root;
    }
}
