using System.Windows;
using System.Windows.Controls;
using NexoraEdu.Core;

namespace NexoraEdu.Views.Student;

/// <summary>Watch history (port of StudentActivity.historyScreen): watched lessons newest first + "clear history" with a confirmation.</summary>
public class HistoryPage : UserControl
{
    public HistoryPage(StudentShell shell, Core.Student me)
    {
        var all = Store.PublishedLessons();
        var lessons = Store.History(me.Email).Select(id => all.FirstOrDefault(l => l.Id == id)).Where(l => l != null).ToList();

        var root = new StackPanel();
        root.Children.Add(Ui.Header(Strings.T("history_title"), lessons.Count, shell.Back));

        if (lessons.Count == 0)
        {
            root.Children.Add(Ui.Empty("no_history", "no_history_sub"));
            Content = root;
            return;
        }

        var clear = new Button
        {
            Style = (Style)FindResource("LinkButton"), Content = Strings.T("clear_history"),
            HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 0, 0, 14)
        };
        clear.SetResourceReference(Control.ForegroundProperty, "err");
        clear.Click += (_, _) => Ui.Confirm(Strings.T("confirm_clear_history"), "clear_history", () =>
        {
            Store.ClearHistory(me.Email);
            shell.ShowSub(new HistoryPage(shell, me));
        });
        root.Children.Add(clear);

        foreach (var l in lessons)
        {
            var lesson = l;
            root.Children.Add(Ui.Row(Ui.GlyphPlay, l.Title, null, null,
                () => { Ui.OpenLesson(lesson, me.Email); shell.ShowSub(new HistoryPage(shell, me)); }));
        }
        Content = root;
    }
}
