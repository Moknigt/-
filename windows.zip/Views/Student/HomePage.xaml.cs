using System.Windows;
using System.Windows.Controls;
using NexoraEdu.Core;

namespace NexoraEdu.Views.Student;

/// <summary>Student home (port of StudentActivity.home): greeting, study progress (overall + per chapter), counters, continue studying,
/// shortcuts (courses / books / favourites) and the latest content. Read-only for now.</summary>
public partial class HomePage : UserControl
{
    readonly Core.Student _me;
    readonly StudentShell _shell;

    public HomePage(Core.Student me, StudentShell shell)
    {
        InitializeComponent();
        _me = me;
        _shell = shell;

        var lessons = Store.PublishedLessons();
        var chapters = Store.Chapters();
        var docs = Store.Docs();
        var hist = Store.History(me.Email);
        var seenIds = hist.ToHashSet();
        var seen = hist.Distinct().Count(id => lessons.Any(l => l.Id == id));

        Hello.Text = Strings.T("welcome") + " " + me.Name;
        foreach (var announcement in Store.Announcements().OrderByDescending(a => a.At).Take(5))
        {
            var card = new StackPanel();
            card.Children.Add(new TextBlock { Text = announcement.Title, Style = (Style)FindResource("H2") });
            if (!string.IsNullOrWhiteSpace(announcement.Text))
                card.Children.Add(new TextBlock { Text = announcement.Text, Style = (Style)FindResource("Muted"), TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 5, 0, 0) });
            card.Children.Add(new TextBlock { Text = DateTimeOffset.FromUnixTimeMilliseconds(announcement.At).LocalDateTime.ToString("yyyy/MM/dd"), Style = (Style)FindResource("Muted"), Margin = new Thickness(0, 5, 0, 0) });
            Announcements.Children.Add(new Border { Style = (Style)FindResource("Card"), Child = card });
        }
        if (Announcements.Children.Count > 0) Announcements.Children.Insert(0, Ui.Heading(Strings.T("ann_title")));

        Progress.Value = lessons.Count == 0 ? 0 : 100.0 * seen / lessons.Count;
        ProgressText.Text = Strings.T("lessons_done_of", seen, lessons.Count);
        ChaptersNum.Text = chapters.Count.ToString();
        LessonsNum.Text = lessons.Count.ToString();
        BooksNum.Text = docs.Count.ToString();

        // one thin bar per chapter that has lessons
        foreach (var ch in chapters)
        {
            var ls = lessons.Where(l => l.ChapterId == ch.Id).ToList();
            if (ls.Count == 0) continue;
            ChapterBars.Children.Add(new TextBlock { Text = ch.Title, Style = (Style)FindResource("Muted"), Margin = new Thickness(0, 12, 0, 4) });
            var bar = new ProgressBar
            {
                Height = 4, Minimum = 0, Maximum = 100, BorderThickness = new Thickness(0),
                Value = 100.0 * ls.Count(l => seenIds.Contains(l.Id)) / ls.Count
            };
            bar.SetResourceReference(ProgressBar.ForegroundProperty, "p1");
            bar.SetResourceReference(ProgressBar.BackgroundProperty, "field");
            ChapterBars.Children.Add(bar);
        }

        var last = hist.Select(id => lessons.FirstOrDefault(l => l.Id == id)).FirstOrDefault(l => l != null);
        LastLesson.Text = last != null ? last.Title : Strings.T("pick_lesson_hint");
        if (last != null)
        {
            ResumeBtn.Visibility = Visibility.Visible;
            ResumeBtn.Click += (_, _) => { Ui.OpenLesson(last, me.Email); shell.Refresh(); };
        }

        FavCount.Text = CollectionPage.Resolve(me.Email, "fav").Count.ToString();

        // latest content
        var newLessons = lessons.OrderByDescending(l => l.At).Take(2).ToList();
        var byNew = docs.OrderByDescending(d => d.At).ToList();
        var newBooks = byNew.Where(d => d.Kind == "book").Take(2).ToList();
        var newFiles = byNew.Where(d => d.Kind == "file").Take(2).ToList();
        if (newLessons.Count + newBooks.Count + newFiles.Count == 0) return;

        Latest.Children.Add(Ui.Heading(Strings.T("latest_content")));
        foreach (var l in newLessons)
        {
            var sub = Ui.LessonSub(l, me.Email, seenIds.Contains(l.Id));
            var lesson = l;
            Latest.Children.Add(Ui.Row(Ui.GlyphPlay, l.Title, sub, Ui.FavButtons(l.ChapterId.Length == 0 ? "video" : "lesson", l.Id, me.Email),
                () => { Ui.OpenLesson(lesson, me.Email); shell.Refresh(); }));
        }
        foreach (var d in newBooks) Latest.Children.Add(Ui.Row(Ui.GlyphBook, d.Title, null, Ui.FavButtons("book", d.Id, me.Email), () => Ui.OpenDoc(shell, d)));
        foreach (var d in newFiles) Latest.Children.Add(Ui.Row(Ui.GlyphFile, d.Title, null, Ui.FavButtons("file", d.Id, me.Email), () => Ui.OpenDoc(shell, d)));
    }

    void TileCourses_Click(object sender, RoutedEventArgs e) => _shell.GoCourses();
    void TileBooks_Click(object sender, RoutedEventArgs e) => _shell.ShowSub(new BooksPage(_shell, _me));
    void TileFav_Click(object sender, RoutedEventArgs e) => _shell.ShowSub(new CollectionPage(_shell, _me, "fav"));
}
