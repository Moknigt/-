using System.Windows;
using System.Windows.Controls;
using NexoraEdu.Core;

namespace NexoraEdu.Views.Student;

/// <summary>My notes (port of StudentActivity.notesScreen): write a note, list of notes newest first, delete a note.</summary>
public class NotesPage : UserControl
{
    public NotesPage(StudentShell shell, Core.Student me)
    {
        var list = Store.Notes(me.Email);
        var root = new StackPanel();
        root.Children.Add(Ui.Header(Strings.T("notes_title"), list.Count, shell.Back));

        var box = new TextBox
        {
            Style = (Style)FindResource("Field"), AcceptsReturn = true, TextWrapping = TextWrapping.Wrap,
            MinHeight = 90, VerticalContentAlignment = VerticalAlignment.Top
        };
        var add = new Button { Style = (Style)FindResource("PrimaryButton"), Content = Strings.T("add_note"), Margin = new Thickness(0, 12, 0, 0) };
        add.Click += (_, _) =>
        {
            var t = box.Text.Trim();
            if (t.Length == 0) return;
            var l = Store.Notes(me.Email);
            l.Insert(0, new Note { Text = t, Date = DateTime.Now.ToString("yyyy/MM/dd", System.Globalization.CultureInfo.InvariantCulture) });
            Store.SaveNotes(me.Email, l);
            shell.ShowSub(new NotesPage(shell, me));
        };

        var form = new StackPanel();
        form.Children.Add(new TextBlock { Text = Strings.T("note_hint"), Style = (Style)FindResource("Muted"), Margin = new Thickness(0, 0, 0, 8) });
        form.Children.Add(box);
        form.Children.Add(add);
        root.Children.Add(new Border { Style = (Style)FindResource("Card"), Child = form });

        if (list.Count == 0)
            root.Children.Add(new TextBlock { Text = Strings.T("no_notes"), Style = (Style)FindResource("Muted"), Margin = new Thickness(0, 6, 0, 0) });

        for (var i = 0; i < list.Count; i++)
        {
            var index = i;
            root.Children.Add(Ui.Row(Ui.GlyphNote, list[i].Text, list[i].Date, new UIElement[]
            {
                Ui.TrashButton(() =>
                {
                    var l = Store.Notes(me.Email);
                    if (index < l.Count) l.RemoveAt(index);
                    Store.SaveNotes(me.Email, l);
                    shell.ShowSub(new NotesPage(shell, me));
                })
            }));
        }
        Content = root;
    }
}
