using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Windows.Data.Pdf;
using Windows.Storage;
using Windows.Storage.Streams;
using NexoraEdu.Core;

namespace NexoraEdu.Views.Student;

/// <summary>Simple in-app PDF reader, one page at a time (port of PdfActivity), built on Windows.Data.Pdf.
/// The file is %APPDATA%\NEXORA EDU\data\docs\&lt;id&gt;.pdf (Android: filesDir/docs/&lt;id&gt;.pdf).</summary>
public class PdfReaderPage : UserControl
{
    readonly StackPanel _root = new();
    readonly System.Windows.Controls.Image _image = new() { Stretch = Stretch.Uniform, MaxWidth = 900, HorizontalAlignment = HorizontalAlignment.Center };
    readonly TextBlock _label = new() { HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
    PdfDocument _doc;
    int _page;
    bool _busy;

    public PdfReaderPage(StudentShell shell, string title, string path) : this(shell.Back, title, path) { }

    /// <param name="back">What the Back button does (the student shell and the teacher shell each have their own).</param>
    public PdfReaderPage(Action back, string title, string path)
    {
        _label.SetResourceReference(TextBlock.ForegroundProperty, "mut");
        _root.Children.Add(Ui.Header(title, -1, back));

        // white sheet behind the page image
        var sheet = new Border { Background = Brushes.White, CornerRadius = new CornerRadius(8), Child = _image, HorizontalAlignment = HorizontalAlignment.Center };
        _root.Children.Add(sheet);

        // "previous" sits at the start edge (right in Arabic), "next" at the end edge; page numbers still go 1 -> N
        var prev = new Button { Style = (Style)FindResource("SideButton"), Content = Strings.T("pdf_prev"), Padding = new Thickness(20, 8, 20, 8) };
        var next = new Button { Style = (Style)FindResource("PrimaryButton"), Content = Strings.T("pdf_next"), Padding = new Thickness(20, 8, 20, 8) };
        prev.Click += async (_, _) => await ShowAsync(_page - 1);
        next.Click += async (_, _) => await ShowAsync(_page + 1);
        DockPanel.SetDock(prev, Dock.Left);
        DockPanel.SetDock(next, Dock.Right);
        var bar = new DockPanel { Margin = new Thickness(0, 16, 0, 0), LastChildFill = true };
        bar.Children.Add(prev);
        bar.Children.Add(next);
        bar.Children.Add(_label);
        _root.Children.Add(bar);

        Content = _root;
        Loaded += async (_, _) => await OpenAsync(path);
    }

    async Task OpenAsync(string path)
    {
        if (_doc != null) return;
        try
        {
            var file = await StorageFile.GetFileFromPathAsync(path);
            _doc = await PdfDocument.LoadFromFileAsync(file);
        }
        catch
        {
            _root.Children.Clear();
            _root.Children.Add(Ui.Heading(Strings.T("err_no_file")));
            return;
        }
        await ShowAsync(0);
    }

    async Task ShowAsync(int i)
    {
        if (_doc == null || _doc.PageCount == 0 || _busy) return;
        _busy = true;
        try
        {
            _page = Math.Clamp(i, 0, (int)_doc.PageCount - 1);
            using var pg = _doc.GetPage((uint)_page);
            using var ms = new InMemoryRandomAccessStream();
            await pg.RenderToStreamAsync(ms, new PdfPageRenderOptions { DestinationWidth = 1100 });
            ms.Seek(0);
            var bmp = new BitmapImage();
            bmp.BeginInit();
            bmp.CacheOption = BitmapCacheOption.OnLoad;
            bmp.StreamSource = ms.AsStream();
            bmp.EndInit();
            bmp.Freeze();
            _image.Source = bmp;
            _label.Text = (_page + 1) + " / " + _doc.PageCount;
            ScrollToTop();
        }
        finally { _busy = false; }
    }

    // the page area of the shell is a ScrollViewer: every new page starts at the top (Android: scroll.scrollTo(0, 0))
    void ScrollToTop()
    {
        DependencyObject p = this;
        while (p != null && p is not ScrollViewer) p = VisualTreeHelper.GetParent(p);
        (p as ScrollViewer)?.ScrollToTop();
    }
}
