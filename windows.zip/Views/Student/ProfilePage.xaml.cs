using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using NexoraEdu.Core;

namespace NexoraEdu.Views.Student;

/// <summary>Profile (port of StudentActivity.profile): student data + counters of the personal collections.</summary>
public partial class ProfilePage : UserControl
{
    public ProfilePage(Core.Student me, StudentShell shell)
    {
        InitializeComponent();
        void Link(System.Windows.FrameworkElement el, Func<UserControl> make)
        {
            el.Cursor = System.Windows.Input.Cursors.Hand;
            el.MouseLeftButtonUp += (_, _) => shell.ShowSub(make());
        }
        Link(FavText, () => new CollectionPage(shell, me, "fav"));
        Link(LaterText, () => new CollectionPage(shell, me, "later"));
        Link(ImpText, () => new CollectionPage(shell, me, "imp"));
        Link(NotesText, () => new NotesPage(shell, me));
        Link(HistText, () => new HistoryPage(shell, me));
        SettingsText.Cursor = System.Windows.Input.Cursors.Hand;
        SettingsText.MouseLeftButtonUp += (_, _) => Ui.OpenSettings();   // sheet, like the Android gear tile
        SettingsText.Text = Strings.T("settings");
        BuildAvatar(me, shell);
        NameText.Text = me.Name;
        EmailText.Text = me.Email;
        PhoneText.Text = me.Phone;
        GradeText.Text = Strings.T("grade_label") + ": " + me.Grade;
        EditProfileButton.Content = Strings.T("acc_edit_profile");

        FavText.Text = Strings.T("coll_fav") + ": " + Store.Collection(me.Email, "fav").Count;
        LaterText.Text = Strings.T("coll_later") + ": " + Store.Collection(me.Email, "later").Count;
        ImpText.Text = Strings.T("coll_imp") + ": " + Store.Collection(me.Email, "imp").Count;
        NotesText.Text = Strings.T("notes_title") + ": " + Store.Notes(me.Email).Count;
        HistText.Text = Strings.T("history_title") + ": " + Store.History(me.Email).Count;
    }

    void EditProfile_Click(object sender, RoutedEventArgs e)
    {
        Ui.Sheet(Strings.T("acc_edit_profile"), (c, w) =>
        {
            TextBox AddField(string label, string value, bool ltr = false)
            {
                c.Children.Add(new TextBlock { Text = label, Style = (Style)FindResource("Muted"), Margin = new Thickness(0, 8, 0, 4) });
                var box = new TextBox { Style = (Style)FindResource("Field"), Text = value };
                if (ltr) box.FlowDirection = FlowDirection.LeftToRight;
                c.Children.Add(box); return box;
            }
            var name = AddField(Strings.T("acc_edit_name"), Store.CurrentStudent()?.Name ?? "");
            var phone = AddField(Strings.T("acc_edit_phone"), Store.CurrentStudent()?.Phone ?? "", true);
            var grade = new ComboBox { Padding = new Thickness(12, 8, 12, 8), ItemsSource = Store.Grades(), IsEditable = true, Text = Store.CurrentStudent()?.Grade ?? "", Margin = new Thickness(0, 8, 0, 0), IsEnabled = false };   // release 66: shown only, a student cannot change his class
            c.Children.Add(grade);
            c.Children.Add(new TextBlock { Text = Strings.T("current_password"), Style = (Style)FindResource("Muted"), Margin = new Thickness(0, 8, 0, 4) });
            var current = new PasswordBox { Padding = new Thickness(12, 9, 12, 9), FlowDirection = FlowDirection.LeftToRight };
            c.Children.Add(current);
            c.Children.Add(new TextBlock { Text = Strings.T("acc_change_pw"), Style = (Style)FindResource("Muted"), Margin = new Thickness(0, 8, 0, 4) });
            var next = new PasswordBox { Padding = new Thickness(12, 9, 12, 9), FlowDirection = FlowDirection.LeftToRight };
            c.Children.Add(next);
            var error = new TextBlock { Style = (Style)FindResource("Muted"), Margin = new Thickness(0, 8, 0, 0), Visibility = Visibility.Collapsed };
            error.SetResourceReference(TextBlock.ForegroundProperty, "err"); c.Children.Add(error);
            var save = new Button { Style = (Style)FindResource("PrimaryButton"), Content = Strings.T("btn_save"), Margin = new Thickness(0, 12, 0, 0) };
            save.Click += (_, _) =>
            {
                if (string.IsNullOrWhiteSpace(name.Text)) { error.Text = Strings.T("err_title"); error.Visibility = Visibility.Visible; return; }
                var student = Store.CurrentStudent();
                if (student == null) { w.Close(); return; }
                if (next.Password.Length > 0 && !Store.ChangeStudentPassword(student.Email, current.Password, next.Password))
                { error.Text = Strings.T("err_wrong_password"); error.Visibility = Visibility.Visible; return; }
                Store.UpdateStudentProfile(student.Email, name.Text, phone.Text, student.Grade);   // release 66: the class stays as it is
                w.Close(); MainWindow.Instance.Reload();
            };
            c.Children.Add(save);
            var cancel = new Button { Style = (Style)FindResource("LinkButton"), Content = Strings.T("cancel"), HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 8, 0, 0) };
            cancel.Click += (_, _) => w.Close(); c.Children.Add(cancel);
        });
    }

    /// <summary>Round profile photo (or the first letter) with change / remove links (same as Android avatarBlock).</summary>
    void BuildAvatar(Core.Student me, StudentShell shell)
    {
        AvatarPanel.Children.Clear();
        var photo = Avatar.Load(me.Email);

        var disc = new Grid { Width = 96, Height = 96, HorizontalAlignment = HorizontalAlignment.Center };
        var bg = new Ellipse();
        bg.SetResourceReference(Shape.FillProperty, "p1");
        disc.Children.Add(bg);
        if (photo == null)
        {
            var initial = new TextBlock
            {
                Text = string.IsNullOrEmpty(me.Name) ? "?" : me.Name.Substring(0, 1).ToUpperInvariant(),
                FontSize = 38, FontWeight = FontWeights.Bold,
                HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center
            };
            initial.SetResourceReference(TextBlock.ForegroundProperty, "white");
            disc.Children.Add(initial);
        }
        else
        {
            disc.Children.Add(new Ellipse { Fill = new ImageBrush(photo) { Stretch = Stretch.UniformToFill } });
        }
        AvatarPanel.Children.Add(disc);

        var change = new Button
        {
            Style = (Style)FindResource("LinkButton"), Content = Strings.T(photo == null ? "add_photo" : "change_photo"),
            HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 10, 0, 0)
        };
        change.Click += (_, _) => Pick(me, shell);
        AvatarPanel.Children.Add(change);

        if (photo != null)
        {
            var remove = new Button
            {
                Style = (Style)FindResource("LinkButton"), Content = Strings.T("remove_photo"),
                HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 6, 0, 0)
            };
            remove.SetResourceReference(Control.ForegroundProperty, "err");
            remove.Click += (_, _) => Ui.Confirm(Strings.T("confirm_remove_photo"), "remove_photo", () =>
            {
                Avatar.Delete(me.Email);
                shell.RefreshAvatar();
                BuildAvatar(me, shell);
            });
            AvatarPanel.Children.Add(remove);
        }
    }

    void Pick(Core.Student me, StudentShell shell)
    {
        var dlg = new Microsoft.Win32.OpenFileDialog
        {
            Filter = "Images|*.jpg;*.jpeg;*.png;*.bmp;*.gif;*.tif;*.tiff|All files|*.*"
        };
        if (dlg.ShowDialog() != true) return;
        if (!Avatar.Save(me.Email, dlg.FileName)) { Ui.Notice(Strings.T("err_photo")); return; }
        shell.RefreshAvatar();
        BuildAvatar(me, shell);
    }
}
