using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NexoraEdu.Core;

namespace NexoraEdu.Views.Student;

/// <summary>The frame every student page lives in (port of ShellActivity + StudentActivity tabs): sidebar + page area.</summary>
public partial class StudentShell : UserControl
{
    readonly Core.Student _me;

    public StudentShell()
    {
        InitializeComponent();

        // MainWindow.Route() only opens this screen for a valid student session.
        _me = Store.CurrentStudent() ?? new Core.Student();
        UserName.Text = _me.Name;
        UserGrade.Text = Strings.T("grade_label") + ": " + _me.Grade;
        RefreshAvatar();
        LangBtn.Content = Prefs.Ar ? "English" : "العربية";
        ThemeBtn.Content = Strings.T(Prefs.Dark ? "light" : "dark");

        NavHome.IsChecked = true;   // after InitializeComponent, so PageHost exists when Checked fires
    }

    /// <summary>Round photo (or the first letter) in the sidebar card; called after the photo changes in the profile.</summary>
    public void RefreshAvatar()
    {
        var photo = Avatar.Load(_me.Email);
        AvatarInitial.Text = string.IsNullOrEmpty(_me.Name) ? "?" : _me.Name.Substring(0, 1).ToUpperInvariant();
        AvatarPhoto.Fill = photo == null ? null : new ImageBrush(photo) { Stretch = Stretch.UniformToFill };
        AvatarPhoto.Visibility = photo == null ? Visibility.Collapsed : Visibility.Visible;
    }

    string _tag = "home";   // the tab on screen (or behind the open sub-screen)
    bool _sub;              // a sub-screen (books, favourites, notes, history...) is open

    void Show(string tag)
    {
        _sub = false;
        _tag = tag ?? "home";
        PageHost.Content = _tag switch
        {
            "courses" => new CoursesPage(_me, this),
            "exams" => new ExamsPage(_me, this),
            "profile" => new ProfilePage(_me, this),
            _ => new HomePage(_me, this),
        };
    }

    void Nav_Checked(object sender, RoutedEventArgs e)
    {
        if (PageHost == null || sender is not RadioButton rb) return;
        Show(rb.Tag as string);
    }

    // Clicking the tab you are already on while a sub-screen is open brings you back to that tab.
    void Nav_Click(object sender, RoutedEventArgs e)
    {
        if (_sub && sender is RadioButton rb) Show(rb.Tag as string);
    }

    public void GoCourses() => NavCourses.IsChecked = true;

    /// <summary>Rebuilds the tab on screen so the "watched" marks, progress bars and the Home counters follow the history.</summary>
    public void Refresh() => Show(_tag);

    public void ShowSub(UserControl page)
    {
        _sub = true;
        PageHost.Content = page;
    }

    /// <summary>Back from a sub-screen: the tab is rebuilt, so counters and heart marks are up to date (like Android's render()).</summary>
    public void Back()
    {
        if (_sub) Show(_tag);
    }

    void Logout_Click(object sender, RoutedEventArgs e)
    {
        Store.ClearSession();
        ServerSync.SignOut();
        MainWindow.Instance.ShowLogin();
    }

    void Lang_Click(object sender, RoutedEventArgs e)
    {
        Prefs.Ar = !Prefs.Ar;
        MainWindow.Instance.Reload();
    }

    void Theme_Click(object sender, RoutedEventArgs e)
    {
        Prefs.Dark = !Prefs.Dark;
        MainWindow.Instance.Reload();
    }
}
