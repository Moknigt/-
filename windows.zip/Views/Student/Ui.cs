using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Path = System.Windows.Shapes.Path;
using NexoraEdu.Core;

namespace NexoraEdu.Views.Student;

/// <summary>Small helpers that build the same rows / headings / sheets as the Android ShellActivity (itemRow, heading, addTop, sheet, confirm) from code.</summary>
static class Ui
{
    static Style S(string key) => (Style)Application.Current.FindResource(key);
    static Brush B(string key) => (Brush)Application.Current.FindResource(key);

    public static TextBlock Heading(string text) =>
        new() { Text = text, Style = S("H2"), Margin = new Thickness(0, 6, 0, 10) };

    /// <summary>One list row: icon + title + optional small line, optional buttons at the end (port of itemRow).</summary>
    public static Border Row(string glyph, string title, string sub, IEnumerable<UIElement> trailing = null, Action onClick = null)
    {
        var icon = new TextBlock
        {
            FontFamily = new FontFamily("Segoe MDL2 Assets"), Text = glyph, FontSize = 20,
            VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(6, 0, 12, 0)
        };
        icon.SetResourceReference(TextBlock.ForegroundProperty, "p1");

        var text = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
        text.Children.Add(new TextBlock { Text = title, Style = S("H2") });
        if (!string.IsNullOrEmpty(sub))
            text.Children.Add(new TextBlock { Text = sub, Style = S("Muted"), Margin = new Thickness(0, 2, 0, 0) });

        var start = new StackPanel { Orientation = Orientation.Horizontal };
        start.Children.Add(icon);
        start.Children.Add(text);

        var line = new DockPanel();
        if (trailing != null)
        {
            var end = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
            foreach (var t in trailing) end.Children.Add(t);
            DockPanel.SetDock(end, Dock.Right);   // end side of the row (mirrors in Arabic)
            line.Children.Add(end);
        }
        line.Children.Add(start);
        var card = new Border { Style = S("Card"), Padding = new Thickness(14, 10, 14, 10), Child = line };
        if (onClick != null)
        {
            card.Cursor = Cursors.Hand;
            card.MouseLeftButtonUp += (_, _) => onClick();   // buttons inside the row (heart, bookmark, trash) handle their own click first
        }
        return card;
    }

    /// <summary>Back button + title (port of addTop). Used at the top of sub-screens.</summary>
    public static UIElement Header(string title, int count, Action back)
    {
        var bar = new DockPanel { Margin = new Thickness(0, 0, 0, 16), LastChildFill = true };
        var btn = new Button { Style = S("SideButton"), Content = Strings.T("back"), Padding = new Thickness(14, 6, 14, 6) };
        btn.Click += (_, _) => back();
        DockPanel.SetDock(btn, Dock.Left);
        bar.Children.Add(btn);
        bar.Children.Add(new TextBlock
        {
            Text = count >= 0 ? title + " (" + count + ")" : title, Style = S("H1"),
            VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(14, 0, 14, 0)
        });
        return bar;
    }

    public static Border Empty(string titleKey, string subKey)
    {
        var p = new StackPanel();
        p.Children.Add(new TextBlock { Text = Strings.T(titleKey), Style = S("H2") });
        p.Children.Add(new TextBlock { Text = Strings.T(subKey), Style = S("Muted"), Margin = new Thickness(0, 6, 0, 0) });
        return new Border { Style = S("Card"), Child = p };
    }

    public const string GlyphPlay = "\uE768", GlyphBook = "\uE8F1", GlyphFile = "\uE7C3", GlyphNote = "\uE70F";
    public static string GlyphOf(string kind) => kind switch { "book" => GlyphBook, "file" => GlyphFile, _ => GlyphPlay };

    public static string TypeName(string kind) => Strings.T(kind switch
    {
        "lesson" => "type_lesson", "video" => "type_video", "book" => "type_book", _ => "type_file"
    });

    // ---------------------------------------------------------------- icons (same shapes as ic_heart / ic_mark / ic_trash on Android)
    const string HeartD = "M20.8,4.6 A5.5,5.5 0 0 0 13,4.6 L12,5.7 L11,4.6 A5.5,5.5 0 0 0 3.2,12.4 L4.2,13.5 L12,21.2 L19.8,13.5 L20.8,12.4 A5.5,5.5 0 0 0 20.8,4.6 Z";
    const string MarkD = "M6,3 L18,3 A1,1 0 0 1 19,4 L19,21 L12,17 L5,21 L5,4 A1,1 0 0 1 6,3 Z";
    const string TrashD = "M4,7 L20,7 M10,11 L10,17 M14,11 L14,17 M6,7 L7,20 L17,20 L18,7 M9,7 L9,4 L15,4 L15,7";

    static Path Icon(string data) => new()
    {
        Data = Geometry.Parse(data), Stretch = Stretch.Uniform, Width = 18, Height = 18, StrokeThickness = 2,
        StrokeLineJoin = PenLineJoin.Round, StrokeStartLineCap = PenLineCap.Round, StrokeEndLineCap = PenLineCap.Round
    };

    static Button IconBtn(Path icon, Action click)
    {
        var b = new Button { Style = S("IconButton"), Content = icon };
        b.Click += (_, _) => click();
        return b;
    }

    public static Button TrashButton(Action click)
    {
        var p = Icon(TrashD);
        p.Stroke = B("mut");
        return IconBtn(p, click);
    }

    static string CollName(string c) => Strings.T("coll_" + c);
    static string CollGlyph(string c) => c switch { "fav" => "\uEB51", "later" => "\uE823", _ => "\uE734" };

    /// <summary>Heart (favourites) and bookmark (review later / important) buttons for one item (port of favButtons).
    /// <paramref name="type"/> = lesson | video | book | file.</summary>
    public static List<UIElement> FavButtons(string type, string id, string email)
    {
        var key = type + "|" + id;
        var heart = Icon(HeartD);
        var mark = Icon(MarkD);

        void Paint(Path p, bool on, string onBrush)
        {
            p.Stroke = B(on ? onBrush : "mut");
            p.Fill = on ? B(onBrush) : Brushes.Transparent;
        }
        void Sync()
        {
            Paint(heart, Store.IsIn(email, "fav", key), "err");
            Paint(mark, Store.IsIn(email, "later", key) || Store.IsIn(email, "imp", key), "p1");
        }
        Sync();

        var heartBtn = IconBtn(heart, () => { Store.ToggleIn(email, "fav", key); Sync(); });
        var markBtn = IconBtn(mark, () =>
        {
            Sheet(Strings.T("save_to"), (c, w) =>
            {
                foreach (var coll in new[] { "fav", "later", "imp" })
                {
                    var name = new TextBlock { Text = CollName(coll), Style = S("H2"), VerticalAlignment = VerticalAlignment.Center };
                    var ic = new TextBlock
                    {
                        FontFamily = new FontFamily("Segoe MDL2 Assets"), Text = CollGlyph(coll), FontSize = 18,
                        VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(4, 0, 10, 0)
                    };
                    ic.SetResourceReference(TextBlock.ForegroundProperty, "mut");
                    var content = new StackPanel { Orientation = Orientation.Horizontal };
                    content.Children.Add(ic);
                    content.Children.Add(name);

                    var cb = new CheckBox { Content = content, IsChecked = Store.IsIn(email, coll, key), Margin = new Thickness(0, 8, 0, 8), VerticalContentAlignment = VerticalAlignment.Center };
                    var c0 = coll;
                    void Flip(bool on) { if (on != Store.IsIn(email, c0, key)) Store.ToggleIn(email, c0, key); }
                    cb.Checked += (_, _) => Flip(true);
                    cb.Unchecked += (_, _) => Flip(false);
                    c.Children.Add(cb);
                }
                var done = new Button { Style = S("LinkButton"), Content = Strings.T("done"), HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 12, 0, 0) };
                done.Click += (_, _) => w.Close();
                c.Children.Add(done);
            }, Sync);
        });
        return new List<UIElement> { heartBtn, markBtn };
    }

    // ---------------------------------------------------------------- sheet + confirm (port of sheet() / confirm())
    public static void Sheet(string title, Action<StackPanel, Window> build, Action closed = null, Func<Window, UIElement> titleEnd = null, bool quiet = false)
    {
        var owner = Application.Current.MainWindow;
        var w = new Window
        {
            Owner = owner, WindowStartupLocation = WindowStartupLocation.CenterOwner,
            WindowStyle = WindowStyle.None, ResizeMode = ResizeMode.NoResize, AllowsTransparency = true,
            Background = Brushes.Transparent, SizeToContent = SizeToContent.Height, Width = 420, ShowInTaskbar = false,
            FlowDirection = owner?.FlowDirection ?? FlowDirection.LeftToRight
        };
        var content = new StackPanel();
        var titleText = new TextBlock { Text = title, Style = S("H2"), FontSize = 18, VerticalAlignment = VerticalAlignment.Center };
        if (titleEnd == null)
        {
            titleText.Margin = new Thickness(0, 0, 0, 12);
            content.Children.Add(titleText);
        }
        else
        {
            var head = new DockPanel { Margin = new Thickness(0, 0, 0, 12) };
            var end = titleEnd(w);
            DockPanel.SetDock(end, Dock.Right);   // end side (mirrors in Arabic)
            head.Children.Add(end);
            head.Children.Add(titleText);
            content.Children.Add(head);
        }
        var card = new Border { CornerRadius = new CornerRadius(18), Padding = new Thickness(22), BorderThickness = new Thickness(1), Margin = new Thickness(8), Child = content };
        card.SetResourceReference(Border.BackgroundProperty, "sheet");
        card.SetResourceReference(Border.BorderBrushProperty, "bd");
        w.Content = card;
        w.KeyDown += (_, e) => { if (e.Key == Key.Escape) w.Close(); };
        if (closed != null) w.Closed += (_, _) => closed();
        build(content, w);
        if (!quiet) { Sfx.Play(Sfx.S.Open); w.Closed += (_, _) => Sfx.Play(Sfx.S.Close); }
        w.ShowDialog();
    }

    /// <summary>A message with a Done link (Android shows these as toasts).</summary>
    public static void Notice(string message)
    {
        Sfx.ForToast(message);   // a message is a toast on Android: its own sound, no sheet sounds
        Sheet(message, (c, w) =>
        {
            var ok = new Button { Style = S("LinkButton"), Content = Strings.T("done"), HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 4, 0, 0) };
            ok.Click += (_, _) => w.Close();
            c.Children.Add(ok);
        }, null, null, true);
    }

    /// <summary>Opens a lesson (port of ShellActivity.openVideo): no video -> err_no_video; otherwise the lesson goes to the watch history.
    /// The video opens in the in-app player (<see cref="VideoWindow"/>).</summary>
    public static void OpenLesson(Lesson l, string email)
    {
        if (l == null) return;
        if (!Store.HasVideo(l)) { Notice(Strings.T("err_no_video")); return; }
        if (email != null && !Access.CanView(email, l)) { Paywall(l, email); return; }   // students only; the teacher side passes null
        if (email != null) Store.AddHistory(email, l.Id);
        if (l.Src == "up") new UploadVideoWindow(l.Title, Store.VideoFile(l.Id)).ShowDialog();
        else new VideoWindow(l.Title, l.Yt).ShowDialog();   // closes back to the same tab; the caller refreshes it (watched marks, progress)
    }

    /// <summary>Locked lesson: shows what it costs. Online payment is a skeleton (see Payments in Core/Access.cs).</summary>
    public static void Paywall(Lesson l, string email) =>
        Sheet(Strings.T("locked_title"), (c, w) =>
        {
            Sfx.Play(Sfx.S.Locked);
            c.Children.Add(new TextBlock { Text = Strings.T("locked_sub"), Style = S("Muted"), TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 8, 0, 0) });
            void Buy(string target, int amount)
            {
                w.Close();
                if (!Payments.Start(target, amount, email, () => { })) Notice(Strings.T("pay_soon"));
            }
            var cp = Store.CoursePrice(l);
            if (cp > 0)
            {
                var b = new Button { Style = S("PrimaryButton"), Content = Strings.T("pay_course", cp), Margin = new Thickness(0, 16, 0, 0) };
                b.Click += (_, _) => Buy("c:" + l.ChapterId, cp); c.Children.Add(b);
            }
            if (l.Price > 0)
            {
                var b = new Button { Style = S("PrimaryButton"), Content = Strings.T("pay_video", l.Price), Margin = new Thickness(0, 10, 0, 0) };
                b.Click += (_, _) => Buy("l:" + l.Id, l.Price); c.Children.Add(b);
            }
            var no = new Button { Style = S("LinkButton"), Content = Strings.T("cancel"), HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 14, 0, 0) };
            no.Click += (_, _) => w.Close(); c.Children.Add(no);
        });

    /// <summary>Student row subtitle: no video / locked with its price / watched / nothing.</summary>
    public static string LessonSub(Lesson l, string email, bool seen) =>
        !Store.HasVideo(l) ? Strings.T("no_video_yet")
        : !Access.CanView(email, l) ? Strings.T("locked_badge", Strings.T("price_egp", Access.ShownPrice(l)))
        : seen ? Strings.T("watched") : null;

    /// <summary>Opens a book / file in the PDF reader; a missing file gives the same message as Android (err_no_file).</summary>
    public static void OpenDoc(StudentShell shell, Doc d)
    {
        var path = Store.DocFile(d.Id);
        if (!File.Exists(path)) { Notice(Strings.T("err_no_file")); return; }
        shell.ShowSub(new PdfReaderPage(shell, d.Title, path));
    }

    /// <summary>"Are you sure?" sheet: a big button with <paramref name="yesKey"/> and a Cancel link.</summary>
    public static void Confirm(string message, string yesKey, Action onYes) =>
        Sheet(message, (c, w) =>
        {
            var yes = new Button { Style = S("PrimaryButton"), Content = Strings.T(yesKey) };
            yes.Click += (_, _) => { w.Close(); if (yesKey == "delete") Sfx.Play(Sfx.S.Delete); onYes(); };
            c.Children.Add(yes);
            var no = new Button { Style = S("LinkButton"), Content = Strings.T("cancel"), HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 14, 0, 0) };
            no.Click += (_, _) => w.Close();
            c.Children.Add(no);
        });

    // ---------------------------------------------------------------- settings sheet (port of ShellActivity.openSettings)
    /// <summary>Two-option switch (like Android's seg_bg / seg_item). <paramref name="onPick"/> runs only when the other side is picked.</summary>
    public static UIElement Segments(string group, string left, string right, bool leftOn, Action<bool> onPick)
    {
        var row = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 8, 0, 0) };
        RadioButton Make(string text, bool on, bool isLeft)
        {
            var rb = new RadioButton { Style = S("Chip"), GroupName = group, Content = text, IsChecked = on, MinWidth = 120 };
            rb.Checked += (_, _) => { if (isLeft != leftOn) onPick(isLeft); };
            return rb;
        }
        row.Children.Add(Make(left, leftOn, true));
        row.Children.Add(Make(right, !leftOn, false));
        return row;
    }

    /// <summary>Opens the full-screen settings page (profile, language, appearance, colours, log out).</summary>
    public static void OpenSettings() => MainWindow.Instance.OpenSettings();

    /// <summary>Themes sheet: rounded gradient tiles, 2 per row, each with its name; the picked one is ringed and ticked. Picking rebuilds the screen with the new colours.</summary>
    public static void OpenThemes()
    {
        Sheet(Strings.T("th_title"), (c, w) =>
        {
            var grid = new System.Windows.Controls.Primitives.UniformGrid { Columns = 2, Margin = new Thickness(0, 4, 0, 0) };
            foreach (var id in Accents.Ids)
            {
                var (a, b) = Accents.Colors(id);
                var on = id == Prefs.Accent;
                var inner = new Grid();
                inner.Children.Add(new TextBlock
                {
                    Text = Accents.Name(id), Foreground = Brushes.White, FontWeight = FontWeights.Bold, FontSize = 15,
                    HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center
                });
                if (on) inner.Children.Add(new TextBlock
                {
                    Text = "\u2713", Foreground = Brushes.White, FontWeight = FontWeights.Bold, FontSize = 14,
                    HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0, 6, 10, 0)
                });
                var tile = new Border
                {
                    Height = 64, CornerRadius = new CornerRadius(18), Margin = new Thickness(5), Cursor = Cursors.Hand,
                    BorderThickness = new Thickness(on ? 3 : 0),
                    Background = new LinearGradientBrush(a, b, 45), Child = inner
                };
                tile.SetResourceReference(Border.BorderBrushProperty, "tx");
                var pick = id;
                tile.MouseLeftButtonUp += (_, _) =>
                {
                    w.Close();
                    if (pick != Prefs.Accent) { Prefs.Accent = pick; MainWindow.Instance.Reload(); }
                };
                grid.Children.Add(tile);
            }
            c.Children.Add(grid);

            var close = new Button { Style = S("LinkButton"), Content = Strings.T("close"), HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 10, 0, 0) };
            close.Click += (_, _) => w.Close();
            c.Children.Add(close);
        });
    }
}
