using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace NexoraEdu.Views.Student;

/// <summary>
/// Player for a video file uploaded to the platform (release 35). SKELETON: MediaElement + play/pause + a position slider.
/// TODO: the same controls as <see cref="VideoWindow"/> (skip 5/10/15/30 s, speed 0.5x-2x, resume position, full screen, error + retry).
/// TODO(server): stream from the server URL (HTTPS, protected) instead of the local file.
/// </summary>
public class UploadVideoWindow : Window
{
    readonly MediaElement _media = new() { LoadedBehavior = MediaState.Manual, UnloadedBehavior = MediaState.Manual, Stretch = Stretch.Uniform };
    readonly Slider _seek = new() { Minimum = 0, Margin = new Thickness(12, 0, 12, 0) };
    readonly System.Windows.Threading.DispatcherTimer _tick = new() { Interval = TimeSpan.FromMilliseconds(400) };
    bool _playing = true, _dragging;

    public UploadVideoWindow(string title, string file)
    {
        Title = title; Width = 1100; Height = 680; Background = Brushes.Black; WindowStartupLocation = WindowStartupLocation.CenterOwner;
        var grid = new Grid();
        grid.RowDefinitions.Add(new RowDefinition());
        grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        _media.Source = new Uri(file);
        _media.MediaOpened += (_, _) => _seek.Maximum = _media.NaturalDuration.HasTimeSpan ? _media.NaturalDuration.TimeSpan.TotalSeconds : 0;
        _media.MouseLeftButtonUp += (_, _) => Toggle();
        grid.Children.Add(_media);
        var bar = new DockPanel { Margin = new Thickness(0, 6, 0, 8) };
        var play = new Button { Content = "⏯", Width = 44, Margin = new Thickness(12, 0, 0, 0) };
        play.Click += (_, _) => Toggle();
        DockPanel.SetDock(play, Dock.Left); bar.Children.Add(play); bar.Children.Add(_seek);
        Grid.SetRow(bar, 1); grid.Children.Add(bar);
        Content = grid;
        _seek.PreviewMouseDown += (_, _) => _dragging = true;
        _seek.PreviewMouseUp += (_, _) => { _media.Position = TimeSpan.FromSeconds(_seek.Value); _dragging = false; };
        _tick.Tick += (_, _) => { if (!_dragging) _seek.Value = _media.Position.TotalSeconds; };
        Loaded += (_, _) => { _media.Play(); _tick.Start(); };
        Closed += (_, _) => { _tick.Stop(); _media.Stop(); _media.Close(); };
        KeyDown += (_, e) => { if (e.Key == Key.Space) Toggle(); if (e.Key == Key.Escape) Close(); };
    }

    void Toggle() { NexoraEdu.Core.Sfx.Play(_playing ? NexoraEdu.Core.Sfx.S.Pause : NexoraEdu.Core.Sfx.S.Play); if (_playing) _media.Pause(); else _media.Play(); _playing = !_playing; }
}
