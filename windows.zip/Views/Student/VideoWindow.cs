using System.Globalization;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.Wpf;
using NexoraEdu.Core;

namespace NexoraEdu.Views.Student;

/// <summary>Resume position, speed and skip length of the player (port of the "nexora_video" prefs of VideoActivity).
/// File: %APPDATA%\NEXORA EDU\data\nexora_video.json</summary>
static class VideoPrefs
{
    static JsonObject _o;
    static string FilePath => System.IO.Path.Combine(Store.DataDir, "nexora_video.json");

    static JsonObject O()
    {
        if (_o != null) return _o;
        try { _o = JsonNode.Parse(File.ReadAllText(FilePath)) as JsonObject; } catch { }
        return _o ??= new JsonObject();
    }

    static void Save()
    {
        try { Directory.CreateDirectory(Store.DataDir); File.WriteAllText(FilePath, O().ToJsonString()); } catch { }
    }

    public static long Pos(string vid) => (long?)O()["pos_" + vid] ?? 0;
    public static void SetPos(string vid, long v) { O()["pos_" + vid] = v; Save(); }
    public static void ClearPos(string vid) { if (O().Remove("pos_" + vid)) Save(); }
    public static double Rate { get => (double?)O()["rate"] ?? 1.0; set { O()["rate"] = value; Save(); } }
    public static int Step { get => (int?)O()["step"] ?? 10; set { O()["step"] = value; Save(); } }
}

/// <summary>In-app lesson player (port of VideoActivity). The video is a YouTube video drawn by the YouTube IFrame player inside a
/// WebView2 (its own controls are hidden); play / pause, skip, seek bar, speed, full screen and resume position are WPF controls.
/// A WebView2 cannot be drawn over, so the controls sit under the video and the double-click zones / flash live inside the page.</summary>
public class VideoWindow : Window
{
    static readonly double[] Rates = { 0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0 };
    static readonly string[] RateLabels = { "0.5x", "0.75x", "1x", "1.25x", "1.5x", "1.75x", "2x" };
    static readonly int[] Steps = { 5, 10, 15, 30 };
    static readonly CultureInfo Inv = CultureInfo.InvariantCulture;
    const string Host = "nexora.player";

    readonly string _vid;
    readonly int _startAt;
    double _cur, _dur, _rate = 1, _want = 1;
    int _state = -2, _lastState = -2, _step = 10;
    bool _dragging, _full, _gotState, _polling;
    DateTime _openedAt = DateTime.UtcNow, _lastSave = DateTime.MinValue, _lastActive = DateTime.UtcNow;
    WindowState _prevState = WindowState.Normal;

    readonly WebView2 _web = new() { DefaultBackgroundColor = System.Drawing.Color.Black };
    readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromMilliseconds(400) };
    readonly Border _header, _settings, _error;
    readonly StackPanel _controls;
    readonly Button _play, _full2, _rew, _fwd, _rateBtn;
    readonly Slider _seek = new() { Minimum = 0, Maximum = 1000, IsMoveToPointEnabled = true, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(10, 0, 10, 0) };
    readonly TextBlock _curTxt = new() { VerticalAlignment = VerticalAlignment.Center, MinWidth = 48 };
    readonly TextBlock _totTxt = new() { VerticalAlignment = VerticalAlignment.Center, MinWidth = 48, TextAlignment = TextAlignment.Right };
    readonly List<RadioButton> _rateChips = new(), _stepChips = new();

    static Style S(string key) => (Style)Application.Current.FindResource(key);

    public VideoWindow(string title, string ytId)
    {
        _vid = new string((ytId ?? "").Where(c => char.IsAsciiLetterOrDigit(c) || c == '_' || c == '-').ToArray());
        var owner = Application.Current.MainWindow;
        Owner = owner;
        FlowDirection = owner?.FlowDirection ?? FlowDirection.LeftToRight;
        Title = title;
        Width = 1000; Height = 660; MinWidth = 640; MinHeight = 440;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
        SetResourceReference(BackgroundProperty, "bg1");

        var saved = VideoPrefs.Pos(_vid);
        _startAt = saved > 5 ? (int)saved : 0;
        _want = VideoPrefs.Rate;
        var rateIdx = Array.FindIndex(Rates, r => Math.Abs(r - _want) < 0.01);
        if (rateIdx < 0) { rateIdx = 2; _want = 1.0; }
        _step = VideoPrefs.Step;
        if (!Steps.Contains(_step)) _step = 10;

        var root = new Grid();
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

        // ---- header: back + title (+ resume info) ----
        var head = new DockPanel { Margin = new Thickness(14, 10, 14, 10) };
        var back = new Button { Style = S("SideButton"), Content = Strings.T("back"), Padding = new Thickness(14, 6, 14, 6) };
        back.Click += (_, _) => Close();
        DockPanel.SetDock(back, Dock.Left);
        head.Children.Add(back);
        var titles = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(12, 0, 12, 0) };
        titles.Children.Add(new TextBlock { Text = title, Style = S("H2"), TextTrimming = TextTrimming.CharacterEllipsis });
        if (_startAt > 0)
            titles.Children.Add(new TextBlock { Text = Strings.T("resume_info", Fmt(_startAt)), Style = S("Muted"), Margin = new Thickness(0, 2, 0, 0) });
        head.Children.Add(titles);
        _header = new Border { Child = head };
        Grid.SetRow(_header, 0);
        root.Children.Add(_header);

        // ---- video + error ----
        var errText = new TextBlock { Text = Strings.T("player_error"), Style = S("H2"), TextWrapping = TextWrapping.Wrap, TextAlignment = TextAlignment.Center, MaxWidth = 460 };
        _error = new Border { Child = errText, Background = Brushes.Black, Visibility = Visibility.Collapsed, Cursor = Cursors.Hand, Padding = new Thickness(24) };
        errText.Foreground = Brushes.White;
        _error.MouseLeftButtonUp += (_, _) => Retry();
        errText.HorizontalAlignment = HorizontalAlignment.Center;
        errText.VerticalAlignment = VerticalAlignment.Center;
        var video = new Grid { Background = Brushes.Black };
        video.Children.Add(_web);
        video.Children.Add(_error);
        Grid.SetRow(video, 1);
        root.Children.Add(video);

        // ---- settings panel (speed, skip length, restart) ----
        var sp = new StackPanel();
        sp.Children.Add(new TextBlock { Text = Strings.T("speed_title"), Style = S("Muted") });
        var speedRow = new WrapPanel { Margin = new Thickness(0, 8, 0, 0) };
        for (var i = 0; i < Rates.Length; i++)
        {
            var idx = i;
            var rb = new RadioButton { Style = S("Chip"), GroupName = "vrate", Content = RateLabels[i], IsChecked = i == rateIdx, MinWidth = 64 };
            rb.Checked += (_, _) => SetRate(idx);
            _rateChips.Add(rb); speedRow.Children.Add(rb);
        }
        sp.Children.Add(speedRow);
        sp.Children.Add(new TextBlock { Text = Strings.T("skip_step"), Style = S("Muted"), Margin = new Thickness(0, 12, 0, 0) });
        var stepRow = new WrapPanel { Margin = new Thickness(0, 8, 0, 0) };
        foreach (var v in Steps)
        {
            var n = v;
            var rb = new RadioButton { Style = S("Chip"), GroupName = "vstep", Content = Strings.T("sec_fmt", n), IsChecked = n == _step, MinWidth = 64 };
            rb.Checked += (_, _) => SetStep(n);
            _stepChips.Add(rb); stepRow.Children.Add(rb);
        }
        sp.Children.Add(stepRow);
        var restart = new Button { Style = S("SideButton"), Content = Strings.T("restart"), HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 12, 0, 0) };
        restart.Click += (_, _) =>
        {
            Js("nx.seek(0);nx.play()");
            VideoPrefs.ClearPos(_vid);
            _settings.Visibility = Visibility.Collapsed;
        };
        sp.Children.Add(restart);
        _settings = new Border { Child = sp, Padding = new Thickness(20, 14, 20, 14), BorderThickness = new Thickness(0, 1, 0, 0), Visibility = Visibility.Collapsed };
        _settings.SetResourceReference(Border.BackgroundProperty, "sheet");
        _settings.SetResourceReference(Border.BorderBrushProperty, "bd");
        Grid.SetRow(_settings, 2);
        root.Children.Add(_settings);

        // ---- controls (left-to-right like every media player) ----
        Button Glyph(string g, string tip, double size = 18) => new()
        {
            Style = S("SideButton"), FontFamily = new FontFamily("Segoe MDL2 Assets"), Content = g, FontSize = size,
            Padding = new Thickness(12, 8, 12, 8), ToolTip = tip
        };
        Button Text(string t, string tip) => new() { Style = S("SideButton"), Content = t, FontSize = 15, FontWeight = FontWeights.Bold, Padding = new Thickness(12, 8, 12, 8), ToolTip = tip };

        _rew = Text("-" + _step, Strings.T("rewind_10"));
        _fwd = Text("+" + _step, Strings.T("forward_10"));
        _play = Glyph("", Strings.T("play_pause"), 22);
        _rateBtn = Text(RateLabels[rateIdx], Strings.T("settings_title"));
        _full2 = Glyph("", Strings.T("fullscreen"));
        _rew.Click += (_, _) => Skip(-_step);
        _fwd.Click += (_, _) => Skip(_step);
        _play.Click += (_, _) => TogglePlay();
        _rateBtn.Click += (_, _) => _settings.Visibility = _settings.Visibility == Visibility.Visible ? Visibility.Collapsed : Visibility.Visible;
        _full2.Click += (_, _) => SetFull(!_full);

        var seekRow = new DockPanel { Margin = new Thickness(0, 0, 0, 4) };
        DockPanel.SetDock(_curTxt, Dock.Left);
        DockPanel.SetDock(_totTxt, Dock.Right);
        seekRow.Children.Add(_curTxt);
        seekRow.Children.Add(_totTxt);
        seekRow.Children.Add(_seek);
        _curTxt.SetResourceReference(TextBlock.ForegroundProperty, "tx");
        _totTxt.SetResourceReference(TextBlock.ForegroundProperty, "mut");
        _seek.ValueChanged += (_, _) => { if (_dragging && _dur > 0) _curTxt.Text = Fmt(_dur * _seek.Value / 1000.0); };
        _seek.PreviewMouseLeftButtonDown += (_, _) => _dragging = true;
        // Slider marks the mouse-up as handled, so listen with handledEventsToo.
        _seek.AddHandler(UIElement.MouseLeftButtonUpEvent, new MouseButtonEventHandler((_, _) =>
        {
            if (!_dragging) return;
            _dragging = false;
            if (_dur > 0) { _cur = _dur * _seek.Value / 1000.0; Js("nx.seek(" + _cur.ToString("0.###", Inv) + ")"); }
        }), true);

        var btnRow = new DockPanel();
        DockPanel.SetDock(_full2, Dock.Right);
        DockPanel.SetDock(_rateBtn, Dock.Right);
        btnRow.Children.Add(_full2);
        btnRow.Children.Add(_rateBtn);
        var mid = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Center };
        mid.Children.Add(_rew); mid.Children.Add(_play); mid.Children.Add(_fwd);
        btnRow.Children.Add(mid);

        _controls = new StackPanel { FlowDirection = FlowDirection.LeftToRight, Margin = new Thickness(20, 10, 20, 12) };
        _controls.Children.Add(seekRow);
        _controls.Children.Add(btnRow);
        Grid.SetRow(_controls, 3);
        root.Children.Add(_controls);
        Content = root;

        // ---- window events ----
        PreviewKeyDown += (_, e) =>
        {
            if (e.Key == Key.Escape && _full) { SetFull(false); e.Handled = true; }
            else if (e.Key == Key.F11) { SetFull(!_full); e.Handled = true; }
        };
        MouseMove += (_, _) => Activity();
        _timer.Tick += (_, _) => { Poll(); AutoHide(); };
        Loaded += async (_, _) => await InitAsync();
        Closing += (_, _) =>
        {
            SavePos();
            _timer.Stop();
            try { _web.Dispose(); } catch { }
        };
    }

    // ------------------------------------------------------------------ web player

    const string PageHtml = """
<!doctype html><html><head><meta charset='utf-8'><style>
html,body{margin:0;height:100%;background:#000;overflow:hidden}
#pl{position:absolute;left:0;top:0;width:100%;height:100%;border:0}
#ov{position:absolute;left:0;top:0;width:100%;height:100%;z-index:5;outline:none}
#fl{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);z-index:6;display:none;color:#fff;font:700 30px sans-serif;background:rgba(0,0,0,.55);padding:10px 22px;border-radius:14px;pointer-events:none}
</style><script src='https://www.youtube.com/iframe_api'></script></head>
<body><div id='pl'></div><div id='ov' tabindex='0'></div><div id='fl'></div><script>
var q=new URLSearchParams(location.search),vid=(q.get('v')||'').replace(/[^A-Za-z0-9_-]/g,''),start=parseInt(q.get('t')||'0')||0;
var p=null,st=-2,ft=null;
function post(m){try{window.chrome.webview.postMessage(m)}catch(x){}}
function onYouTubeIframeAPIReady(){p=new YT.Player('pl',{host:'https://www.youtube-nocookie.com',width:'100%',height:'100%',videoId:vid,
playerVars:{controls:0,rel:0,playsinline:1,modestbranding:1,fs:0,iv_load_policy:3,disablekb:1,autoplay:1,start:start,origin:location.origin},
events:{onStateChange:function(e){st=e.data},onError:function(e){st=-100-e.data}}});}
window.nx={s:function(){if(!p)return '';var t=0,d=0,r=1;try{t=p.getCurrentTime();d=p.getDuration();r=p.getPlaybackRate()}catch(x){}return [t,d,st,r].join(',')},
play:function(){try{p.playVideo()}catch(x){}},pause:function(){try{p.pauseVideo()}catch(x){}},
seek:function(t){try{p.seekTo(t,true)}catch(x){}},rate:function(r){try{p.setPlaybackRate(r)}catch(x){}},
flash:function(t){var f=document.getElementById('fl');f.textContent=t;f.style.display='block';clearTimeout(ft);ft=setTimeout(function(){f.style.display='none'},600)}};
var ov=document.getElementById('ov'),ct=null,lm=0;
ov.addEventListener('click',function(){if(ct){clearTimeout(ct);ct=null;return}ct=setTimeout(function(){ct=null;post('tap')},250)});
ov.addEventListener('dblclick',function(e){if(ct){clearTimeout(ct);ct=null}post(e.clientX<ov.clientWidth/2?'back':'fwd')});
ov.addEventListener('mousemove',function(){var n=Date.now();if(n-lm>300){lm=n;post('move')}});
document.addEventListener('keydown',function(e){var k=e.key;if(k==' '||k=='ArrowLeft'||k=='ArrowRight'||k=='f'||k=='F'||k=='Escape'){e.preventDefault();post('key:'+(k==' '?'Space':k))}});
</script></body></html>
""";

    string PageUrl(int start) => $"https://{Host}/player.html?v={_vid}&t={start}";

    async Task InitAsync()
    {
        if (_vid.Length == 0) { ShowError(); return; }
        try
        {
            var data = System.IO.Path.Combine(Store.DataDir, "player");
            Directory.CreateDirectory(data);
            File.WriteAllText(System.IO.Path.Combine(data, "player.html"), PageHtml);
            var env = await CoreWebView2Environment.CreateAsync(null, System.IO.Path.Combine(Store.DataDir, "webview"),
                new CoreWebView2EnvironmentOptions("--autoplay-policy=no-user-gesture-required"));
            await _web.EnsureCoreWebView2Async(env);
            var c = _web.CoreWebView2;
            c.Settings.AreDefaultContextMenusEnabled = false;
            c.Settings.AreDevToolsEnabled = false;
            c.Settings.IsStatusBarEnabled = false;
            c.Settings.IsZoomControlEnabled = false;
            c.Settings.IsPasswordAutosaveEnabled = false;
            c.Settings.IsGeneralAutofillEnabled = false;
            c.NewWindowRequested += (_, e) => e.Handled = true;
            c.WebMessageReceived += (_, e) => OnMessage(e.TryGetWebMessageAsString());
            c.SetVirtualHostNameToFolderMapping(Host, data, CoreWebView2HostResourceAccessKind.Allow);
            _openedAt = DateTime.UtcNow;
            c.Navigate(PageUrl(_startAt));
            _timer.Start();
        }
        catch
        {
            ShowError();   // WebView2 runtime missing or the page could not start
        }
    }

    void OnMessage(string m)
    {
        switch (m)
        {
            case "tap": case "key:Space": TogglePlay(); break;
            case "back": case "key:ArrowLeft": Skip(m == "back" || m == "key:ArrowLeft" ? -_step : _step); break;
            case "fwd": case "key:ArrowRight": Skip(_step); break;
            case "key:f": case "key:F": SetFull(!_full); break;
            case "key:Escape": if (_full) SetFull(false); break;
            case "move": Activity(); break;
        }
    }

    void Js(string code)
    {
        try { _web.CoreWebView2?.ExecuteScriptAsync(code); } catch { }
    }

    async void Poll()
    {
        if (_web.CoreWebView2 == null || _polling) return;
        _polling = true;
        try
        {
            var raw = await _web.CoreWebView2.ExecuteScriptAsync("window.nx?window.nx.s():''");
            var p = (JsonSerializer.Deserialize<string>(raw) ?? "").Split(',');
            if (p.Length < 4)
            {
                if (!_gotState && (DateTime.UtcNow - _openedAt).TotalSeconds > 12) ShowError();
                return;
            }
            _cur = double.TryParse(p[0], NumberStyles.Float, Inv, out var a) ? a : 0;
            _dur = double.TryParse(p[1], NumberStyles.Float, Inv, out var b) ? b : 0;
            _state = int.TryParse(p[2], NumberStyles.Integer, Inv, out var s) ? s : -2;
            _rate = double.TryParse(p[3], NumberStyles.Float, Inv, out var r) ? r : 1;
            _gotState = true;
            Render();
        }
        catch { }
        finally { _polling = false; }
    }

    void Render()
    {
        if (_state <= -100) { ShowError(); return; }
        _error.Visibility = Visibility.Collapsed;
        _web.Visibility = Visibility.Visible;
        var playing = _state == 1;
        _play.Content = playing ? "" : "";
        if (!_dragging)
        {
            _seek.Value = _dur > 0 ? _cur / _dur * 1000 : 0;
            _curTxt.Text = Fmt(_cur);
        }
        _totTxt.Text = Fmt(_dur);
        if (playing && Math.Abs(_rate - _want) > 0.01) Js("nx.rate(" + _want.ToString(Inv) + ")");
        if (_state != _lastState)
        {
            if (_state == 0) { VideoPrefs.ClearPos(_vid); _controls.Visibility = Visibility.Visible; }
            _lastState = _state;
        }
        var now = DateTime.UtcNow;
        if (playing && _cur > 5 && (now - _lastSave).TotalSeconds > 5)
        {
            _lastSave = now;
            SavePos();
        }
    }

    void ShowError()
    {
        _web.Visibility = Visibility.Collapsed;   // a WebView2 would cover the message otherwise
        _error.Visibility = Visibility.Visible;
    }

    void Retry()
    {
        if (_web.CoreWebView2 == null) { _error.Visibility = Visibility.Collapsed; _web.Visibility = Visibility.Visible; _ = InitAsync(); return; }
        _error.Visibility = Visibility.Collapsed;
        _web.Visibility = Visibility.Visible;
        _gotState = false; _state = -2;
        _openedAt = DateTime.UtcNow;
        _web.CoreWebView2.Navigate(PageUrl(_cur > 5 ? (int)_cur : _startAt));
    }

    void SavePos()
    {
        if (_vid.Length == 0) return;
        var nearEnd = _dur > 0 && _cur > _dur - 10;
        if (_cur > 5 && _state != 0 && !nearEnd) VideoPrefs.SetPos(_vid, (long)_cur);
        else if (nearEnd || _state == 0) VideoPrefs.ClearPos(_vid);
    }

    // ------------------------------------------------------------------ controls

    void TogglePlay()
    {
        Sfx.Play(_state == 1 ? Sfx.S.Pause : Sfx.S.Play);
        if (_state == 1) Js("nx.pause()");
        else if (_state == 0) Js("nx.seek(0);nx.play()");
        else Js("nx.play()");
        Activity();
    }

    void Skip(double d)
    {
        var max = _dur > 0 ? _dur : double.MaxValue;
        var t = Math.Clamp(_cur + d, 0, max);
        _cur = t;
        Sfx.Play(Sfx.S.Skip);
        Js("nx.seek(" + t.ToString("0.###", Inv) + ")");
        Js("nx.flash('" + (d < 0 ? "-" : "+") + _step + "')");
        Activity();
    }

    void SetRate(int i)
    {
        if (i < 0 || i >= Rates.Length) return;
        _want = Rates[i];
        VideoPrefs.Rate = _want;
        _rateBtn.Content = RateLabels[i];
        Js("nx.rate(" + _want.ToString(Inv) + ")");
    }

    void SetStep(int v)
    {
        _step = v;
        VideoPrefs.Step = v;
        _rew.Content = "-" + v;
        _fwd.Content = "+" + v;
    }

    void SetFull(bool on)
    {
        if (on == _full) return;
        Sfx.Play(Sfx.S.Tab);
        _full = on;
        _header.Visibility = on ? Visibility.Collapsed : Visibility.Visible;
        if (on) _settings.Visibility = Visibility.Collapsed;
        _full2.Content = on ? "" : "";
        if (on)
        {
            _prevState = WindowState == WindowState.Maximized ? WindowState.Maximized : WindowState.Normal;
            WindowState = WindowState.Normal;
            WindowStyle = WindowStyle.None;
            ResizeMode = ResizeMode.NoResize;
            WindowState = WindowState.Maximized;
        }
        else
        {
            WindowStyle = WindowStyle.SingleBorderWindow;
            ResizeMode = ResizeMode.CanResize;
            WindowState = _prevState;
        }
        Activity();
    }

    /// <summary>Mouse / key activity: shows the controls again (in full screen they hide after 3 s while playing).</summary>
    void Activity()
    {
        _lastActive = DateTime.UtcNow;
        _controls.Visibility = Visibility.Visible;
    }

    void AutoHide()
    {
        if (_full && _state == 1 && !_dragging && _settings.Visibility != Visibility.Visible && (DateTime.UtcNow - _lastActive).TotalSeconds > 3)
            _controls.Visibility = Visibility.Collapsed;
    }

    static string Fmt(double t)
    {
        var s = double.IsNaN(t) || t < 0 ? 0 : (int)t;
        var h = s / 3600; var m = s % 3600 / 60; var sec = s % 60;
        return h > 0 ? $"{h}:{m:00}:{sec:00}" : $"{m}:{sec:00}";
    }
}
