using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NexoraEdu.Core;
using NexoraEdu.Views.Student;

namespace NexoraEdu.Views.Teacher;

/// <summary>Teacher Exams tab (release 13): three sections chosen by chips - Exams, Question bank, Homework.
/// Exams: create from the bank (official / practice), delete, tap an exam to see the students' latest results.
/// Questions: multiple choice (2-4 options, one right answer, optional chapter), delete (also removed from exams).
/// Homework: title + note, delete, tap one to read the students' answers (text + photo) and grade them out of 10 with a note.
/// Same keys as Android Store.kt (questions, exams, results, homework, subs).</summary>
public partial class TeacherShell
{
    const string GlyphQuestion = "\uE897", GlyphExam = "\uE73E", GlyphHw = "\uE70F";
    string _exTab = "exams";

    static string Cut(string s, int n) => s.Length <= n ? s : s[..n].TrimEnd() + "…";

    // ------------------------------------------------------------------ the tab

    UIElement ExamsTabReal()
    {
        var p = PageOf("tab_exams");
        var chips = new WrapPanel { Margin = new Thickness(0, 0, 0, 14) };
        void Chip(string tag, string key)
        {
            var rb = new RadioButton { Style = S("Chip"), GroupName = "extab", Content = T(key), IsChecked = _exTab == tag };
            rb.Checked += (_, _) => { if (_exTab != tag) { _exTab = tag; Refresh(); } };
            chips.Children.Add(rb);
        }
        Chip("exams", "ex_exams");
        Chip("questions", "ex_questions");
        Chip("homework", "ex_homework");
        p.Children.Add(chips);

        switch (_exTab)
        {
            case "questions": QuestionsSection(p); break;
            case "homework": HomeworkSection(p); break;
            default: ExamsSection(p); break;
        }
        return p;
    }

    static Button AddBtn(string key, Action click)
    {
        var b = new Button { Style = S("PrimaryButton"), Content = T(key), HorizontalAlignment = HorizontalAlignment.Left, Padding = new Thickness(22, 10, 22, 10), Margin = new Thickness(0, 0, 0, 14) };
        b.Click += (_, _) => click();
        return b;
    }

    static RadioButton MakeChip(string group, string text, bool on, Action pick)
    {
        var rb = new RadioButton { Style = S("Chip"), GroupName = group, Content = text, IsChecked = on };
        rb.Checked += (_, _) => pick();
        return rb;
    }

    /// <summary>Text field with a literal label (Field() takes a string key).</summary>
    static TextBox LField(StackPanel c, string label, bool multi = false)
    {
        c.Children.Add(new TextBlock { Text = label, Style = S("Muted"), Margin = new Thickness(0, 10, 0, 4) });
        var tb = new TextBox { Style = S("Field") };
        if (multi) { tb.AcceptsReturn = true; tb.TextWrapping = TextWrapping.Wrap; tb.MinHeight = 80; tb.VerticalContentAlignment = VerticalAlignment.Top; }
        c.Children.Add(tb);
        return tb;
    }

    static Border Wrapped(string small, string text)
    {
        var p = new StackPanel();
        if (!string.IsNullOrEmpty(small)) p.Children.Add(new TextBlock { Text = small, Style = S("Muted") });
        p.Children.Add(new TextBlock { Text = text, Style = S("Body"), TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 2, 0, 0) });
        return new Border { Style = S("Card"), Child = p };
    }

    // ------------------------------------------------------------------ questions

    void QuestionsSection(StackPanel p)
    {
        p.Children.Add(AddBtn("ex_add_question", () => Ask(AddQuestionSheet)));
        var list = Store.Questions();
        if (list.Count == 0) { p.Children.Add(Ui.Empty("ex_empty_questions", "ex_empty_questions_sub")); return; }
        var chapters = Store.Chapters();
        foreach (var q in list)
        {
            var qq = q;
            var right = qq.Answer >= 0 && qq.Answer < qq.Options.Count ? qq.Options[qq.Answer] : "";
            var sub = T("ex_right_answer") + ": " + Cut(right, 40);
            var ch = chapters.FirstOrDefault(c => c.Id == qq.Chapter)?.Title;
            if (!string.IsNullOrEmpty(ch)) sub += "  •  " + ch;
            p.Children.Add(Ui.Row(GlyphQuestion, Cut(qq.Text, 80), sub,
                new UIElement[] { Trash(() => Store.DeleteQuestion(qq.Id), "", "ex_confirm_delete_question") }));
        }
    }

    void AddQuestionSheet() =>
        Ui.Sheet(T("ex_add_question"), (c, w) =>
        {
            var text = LField(c, T("ex_question_text"), true);

            var chapters = Store.Chapters();
            var selChapter = "";
            if (chapters.Count > 0)
            {
                c.Children.Add(new TextBlock { Text = T("ex_chapter_optional"), Style = S("Muted"), Margin = new Thickness(0, 12, 0, 0) });
                var chips = new WrapPanel { Margin = new Thickness(0, 8, 0, 0) };
                chips.Children.Add(MakeChip("qch", T("ex_no_chapter"), true, () => selChapter = ""));
                foreach (var ch in chapters)
                {
                    var id = ch.Id;
                    chips.Children.Add(MakeChip("qch", ch.Title, false, () => selChapter = id));
                }
                c.Children.Add(chips);
            }

            var opts = new TextBox[4];
            for (var i = 0; i < 4; i++) opts[i] = LField(c, T("ex_option_n", i + 1));

            c.Children.Add(new TextBlock { Text = T("ex_correct"), Style = S("Muted"), Margin = new Thickness(0, 12, 0, 0) });
            var correct = 0;
            var right = new WrapPanel { Margin = new Thickness(0, 8, 0, 0) };
            for (var i = 0; i < 4; i++)
            {
                var idx = i;
                right.Children.Add(MakeChip("qright", (i + 1).ToString(CultureInfo.InvariantCulture), i == 0, () => correct = idx));
            }
            c.Children.Add(right);

            var err = ErrLine(c);
            c.Children.Add(Primary(T("add"), 16, (_, _) =>
            {
                var qt = text.Text.Trim();
                if (qt.Length == 0) { Say(err, "ex_err_question"); return; }
                var filled = Enumerable.Range(0, 4).Where(i => opts[i].Text.Trim().Length > 0).ToList();
                if (filled.Count < 2) { Say(err, "ex_err_options"); return; }
                var at = filled.IndexOf(correct);   // position of the right option once the empty ones are dropped
                if (at < 0) { Say(err, "ex_err_correct"); return; }
                var all = Store.Questions();
                all.Add(new Question
                {
                    Id = Store.NewId(), Text = qt, Chapter = selChapter,
                    Options = filled.Select(i => opts[i].Text.Trim()).ToList(), Answer = at
                });
                Store.SaveQuestions(all);
                w.Close(); Refresh();
            }));
            c.Children.Add(Cancel(w));
        });

    // ------------------------------------------------------------------ exams

    void ExamsSection(StackPanel p)
    {
        p.Children.Add(AddBtn("ex_add_exam", () => Ask(AddExamSheet)));
        var list = Store.Exams();
        if (list.Count == 0) { p.Children.Add(Ui.Empty("empty_exams", "empty_exams_sub")); return; }
        foreach (var e in list.OrderByDescending(x => x.At))
        {
            var ex = e;
            var sub = T(ex.Official ? "ex_official" : "ex_training") + "  •  " + T("ex_questions_count", ex.Qids.Count) + "  •  " + DateText(ex.At);
            p.Children.Add(Ui.Row(GlyphExam, ex.Title, sub,
                new UIElement[] { Trash(() => Store.DeleteExam(ex.Id), ex.Title, "ex_confirm_delete_exam") },
                () => ExamResultsSheet(ex)));
        }
    }

    void AddExamSheet()
    {
        var bank = Store.Questions();
        if (bank.Count == 0) { Ui.Notice(T("ex_err_add_questions_first")); return; }
        Ui.Sheet(T("ex_add_exam"), (c, w) =>
        {
            var title = Field(c, "hint_title");
            var official = false;
            var kind = new WrapPanel { Margin = new Thickness(0, 12, 0, 0) };
            kind.Children.Add(MakeChip("exkind", T("ex_training"), true, () => official = false));
            kind.Children.Add(MakeChip("exkind", T("ex_official"), false, () => official = true));
            c.Children.Add(kind);

            c.Children.Add(new TextBlock { Text = T("ex_pick_questions"), Style = S("Muted"), Margin = new Thickness(0, 14, 0, 6) });
            var box = new StackPanel();
            var checks = new List<(CheckBox Box, Question Q)>();
            foreach (var q in bank)
            {
                var cb = new CheckBox
                {
                    Content = new TextBlock { Text = Cut(q.Text, 70), TextWrapping = TextWrapping.Wrap, MaxWidth = 330 },
                    Margin = new Thickness(0, 4, 0, 4), VerticalContentAlignment = VerticalAlignment.Center
                };
                checks.Add((cb, q));
                box.Children.Add(cb);
            }
            c.Children.Add(new ScrollViewer { MaxHeight = 240, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Content = box });

            var err = ErrLine(c);
            c.Children.Add(Primary(T("add"), 16, (_, _) =>
            {
                var t = title.Text.Trim();
                if (t.Length == 0) { Say(err, "err_title"); return; }
                var ids = checks.Where(x => x.Box.IsChecked == true).Select(x => x.Q.Id).ToList();
                if (ids.Count == 0) { Say(err, "ex_err_no_questions"); return; }
                var all = Store.Exams();
                all.Add(new Exam { Id = Store.NewId(), Title = t, Official = official, Qids = ids, At = Store.Now() });
                Store.SaveExams(all);
                w.Close(); Refresh();
            }));
            c.Children.Add(Cancel(w));
        });
    }

    /// <summary>Latest result of every student who took the exam, best first.</summary>
    void ExamResultsSheet(Exam e) =>
        Ui.Sheet(e.Title, (c, w) =>
        {
            var rows = Store.Students()
                .Select(s => (S: s, R: Store.LastResult(s.Email, e.Id)))
                .Where(x => x.R != null)
                .OrderByDescending(x => x.R.Score)
                .ToList();
            if (rows.Count == 0)
                c.Children.Add(new TextBlock { Text = T("ex_no_results"), Style = S("Muted"), Margin = new Thickness(0, 0, 0, 6) });
            var list = new StackPanel();
            foreach (var (s, r) in rows)
            {
                var score = new TextBlock { Text = r.Score + "%", Style = S("H2"), VerticalAlignment = VerticalAlignment.Center };
                score.SetResourceReference(TextBlock.ForegroundProperty, "p1");
                DockPanel.SetDock(score, Dock.Right);
                var who = new StackPanel();
                who.Children.Add(new TextBlock { Text = s.Name, Style = S("H2"), TextTrimming = TextTrimming.CharacterEllipsis });
                who.Children.Add(new TextBlock { Text = T("ex_result_line", r.Correct, r.Total) + "  •  " + DateText(r.At), Style = S("Muted") });
                var line = new DockPanel { Margin = new Thickness(0, 6, 0, 6) };
                line.Children.Add(score);
                line.Children.Add(who);
                list.Children.Add(line);
            }
            c.Children.Add(new ScrollViewer { MaxHeight = 320, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Content = list });
            var close = new Button { Style = S("LinkButton"), Content = T("close"), HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 10, 0, 0) };
            close.Click += (_, _) => w.Close();
            c.Children.Add(close);
        });

    // ------------------------------------------------------------------ homework

    void HomeworkSection(StackPanel p)
    {
        p.Children.Add(AddBtn("ex_add_homework", () => Ask(AddHomeworkSheet)));
        var list = Store.HomeworkAll();
        if (list.Count == 0) { p.Children.Add(Ui.Empty("ex_empty_hw", "ex_empty_hw_teacher_sub")); return; }
        var subs = Store.Submissions();
        foreach (var h in list.OrderByDescending(x => x.At))
        {
            var hw = h;
            var mine = subs.Where(s => s.HwId == hw.Id).ToList();
            var sub = T("hw_submissions") + ": " + mine.Count;
            var open = mine.Count(s => s.Grade < 0);
            if (open > 0) sub += "  •  " + T("hw_ungraded") + ": " + open;
            p.Children.Add(Ui.Row(GlyphHw, hw.Title, sub,
                new UIElement[] { Trash(() => Store.DeleteHomework(hw.Id), hw.Title, "ex_confirm_delete_hw") },
                () => OpenHomework(hw)));
        }
    }

    void AddHomeworkSheet() =>
        Ui.Sheet(T("ex_add_homework"), (c, w) =>
        {
            var title = LField(c, T("hw_hint_title"));
            var note = LField(c, T("hw_hint_note"), true);
            var err = ErrLine(c);
            c.Children.Add(Primary(T("add"), 16, (_, _) =>
            {
                var t = title.Text.Trim();
                if (t.Length == 0) { Say(err, "err_title"); return; }
                var all = Store.HomeworkAll();
                all.Add(new Homework { Id = Store.NewId(), Title = t, Note = note.Text.Trim(), At = Store.Now() });
                Store.SaveHomework(all);
                w.Close(); Refresh();
            }));
            c.Children.Add(Cancel(w));
        });

    /// <summary>The students' answers to one homework (sub-screen): text, photo, status, and a button to grade.</summary>
    void OpenHomework(Homework h)
    {
        var p = new StackPanel();
        var subs = Store.Submissions().Where(s => s.HwId == h.Id).OrderBy(s => s.At).ToList();
        p.Children.Add(Ui.Header(h.Title, subs.Count, Back));
        if (h.Note.Length > 0) p.Children.Add(Wrapped(T("hw_note"), h.Note));
        if (subs.Count == 0)
            p.Children.Add(new TextBlock { Text = T("hw_no_submissions"), Style = S("Muted"), Margin = new Thickness(0, 6, 0, 0) });
        foreach (var s in subs) p.Children.Add(SubmissionCard(h, s));
        ShowSub(new UserControl { Content = p });
    }

    UIElement SubmissionCard(Homework h, Submission s)
    {
        var name = Store.FindStudent(s.Email)?.Name ?? s.Email;
        var p = new StackPanel();
        p.Children.Add(new TextBlock { Text = name, Style = S("H2") });
        p.Children.Add(new TextBlock { Text = s.Email + "  •  " + DateText(s.At), Style = S("Muted") });
        if (s.Text.Length > 0)
            p.Children.Add(new TextBlock { Text = s.Text, Style = S("Body"), TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 8, 0, 0) });
        if (s.Photo.Length > 0)
        {
            var img = Photos.Load(s.Photo);
            if (img != null)
                p.Children.Add(new System.Windows.Controls.Image
                {
                    Source = img, MaxHeight = 260, Stretch = Stretch.Uniform, HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 8, 0, 0)
                });
            else
                p.Children.Add(new TextBlock { Text = T("hw_photo_missing"), Style = S("Muted"), Margin = new Thickness(0, 8, 0, 0) });
        }

        var status = new TextBlock
        {
            Text = s.Grade >= 0 ? T("hw_status_graded", s.Grade) : T("hw_status_sent"),
            Style = S("H2"), FontSize = 14, Margin = new Thickness(0, 10, 0, 0)
        };
        status.SetResourceReference(TextBlock.ForegroundProperty, s.Grade >= 0 ? "p1" : "gold");
        p.Children.Add(status);
        if (s.Grade >= 0 && s.Note.Length > 0)
            p.Children.Add(new TextBlock { Text = T("hw_teacher_note") + ": " + s.Note, Style = S("Muted"), TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 2, 0, 0) });

        var grade = new Button { Style = S("LinkButton"), Content = T("hw_save_grade"), HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 8, 0, 0) };
        grade.Click += (_, _) => GradeSheet(h, s);
        p.Children.Add(grade);
        return new Border { Style = S("Card"), Child = p };
    }

    void GradeSheet(Homework h, Submission s) =>
        Ui.Sheet(T("hw_save_grade"), (c, w) =>
        {
            var g = LField(c, T("hw_grade_label"));
            g.FlowDirection = FlowDirection.LeftToRight;
            if (s.Grade >= 0) g.Text = s.Grade.ToString(CultureInfo.InvariantCulture);
            var note = LField(c, T("hw_grade_note"), true);
            note.Text = s.Note;
            var err = ErrLine(c);
            c.Children.Add(Primary(T("hw_save_grade"), 16, (_, _) =>
            {
                if (!int.TryParse(g.Text.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out var n) || n < 0 || n > 10)
                { Say(err, "hw_err_grade"); return; }
                s.Grade = n;
                s.Note = note.Text.Trim();
                Store.PutSubmission(s);
                w.Close();
                OpenHomework(h);   // redraw the answers with the new grade
            }));
            c.Children.Add(Cancel(w));
        });
}
