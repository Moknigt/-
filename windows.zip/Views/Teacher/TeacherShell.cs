using System.Globalization;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using NexoraEdu.Core;
using NexoraEdu.Views.Student;

namespace NexoraEdu.Views.Teacher;

/// <summary>Teacher side (port of TeacherActivity): sidebar with Home / Students / Content / Exams / Profile.
/// Home: counters + "manage content" tiles. Students: read-only list. Content: videos, chapters with their lessons, books, files
/// with add sheets (chapter, lesson, YouTube video, PDF book, PDF file) and delete with confirmation. Exams: questions / exams / homework (TeacherShell.Exams.cs).
/// Data keys are the same as the student side (chapters, lessons, docs) so what the teacher adds shows up for students.</summary>
public partial class TeacherShell : UserControl
{
    const string GlyphFolder = "", GlyphVideo = "", GlyphGear = "";

    readonly string _email;
    readonly ContentControl _host = new();
    string _tag = "home";
    bool _sub;

    static Style S(string key) => (Style)Application.Current.FindResource(key);
    static string T(string key, params object[] a) => Strings.T(key, a);

    public TeacherShell()
    {
        // MainWindow.Route() only opens this screen for a valid teacher session.
        _email = Store.Teacher()?.Email ?? Store.Session()?.Email ?? "";
        var name = Store.TeacherName().Length > 0 ? Store.TeacherName() : _email.Contains('@') ? _email[.._email.IndexOf('@')] : _email;

        var grid = new Grid();
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(264) });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

        // ---- sidebar (start edge) ----
        var side = new DockPanel { Margin = new Thickness(14) };
        var brand = new TextBlock { Text = "منصة الإبداع", FontSize = 20, FontWeight = FontWeights.Bold };
        brand.SetResourceReference(TextBlock.ForegroundProperty, "tx");
        var top = new StackPanel { Margin = new Thickness(6, 8, 6, 18) };
        top.Children.Add(brand);
        DockPanel.SetDock(top, Dock.Top);
        side.Children.Add(top);

        var bottom = new StackPanel();
        var disc = new Grid { Width = 40, Height = 40, Margin = new Thickness(0, 0, 10, 0), VerticalAlignment = VerticalAlignment.Center };
        var bg = new Ellipse();
        bg.SetResourceReference(Shape.FillProperty, "p1");
        disc.Children.Add(bg);
        var initial = new TextBlock
        {
            Text = string.IsNullOrEmpty(name) ? "?" : name[..1].ToUpperInvariant(), FontSize = 16, FontWeight = FontWeights.Bold,
            HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center
        };
        initial.SetResourceReference(TextBlock.ForegroundProperty, "white");
        disc.Children.Add(initial);
        DockPanel.SetDock(disc, Dock.Left);
        var who = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
        who.Children.Add(new TextBlock { Text = name, Style = S("H2"), TextTrimming = TextTrimming.CharacterEllipsis });
        who.Children.Add(new TextBlock { Text = T("role_teacher_label"), Style = S("Muted") });
        var userLine = new DockPanel();
        userLine.Children.Add(disc);
        userLine.Children.Add(who);
        bottom.Children.Add(new Border { Style = S("Card"), Padding = new Thickness(12), Margin = new Thickness(0, 0, 0, 8), Child = userLine });

        var lang = new Button { Style = S("SideButton"), Content = Prefs.Ar ? "English" : "العربية" };
        lang.Click += (_, _) => { Prefs.Ar = !Prefs.Ar; MainWindow.Instance.Reload(); };
        var theme = new Button { Style = S("SideButton"), Content = T(Prefs.Dark ? "light" : "dark") };
        theme.Click += (_, _) => { Prefs.Dark = !Prefs.Dark; MainWindow.Instance.Reload(); };
        var logout = new Button { Style = S("SideButton"), Content = T("logout") };
        logout.Click += (_, _) => { Store.ClearSession(); ServerSync.SignOut(); MainWindow.Instance.ShowLogin(); };
        bottom.Children.Add(lang);
        bottom.Children.Add(theme);
        bottom.Children.Add(logout);
        DockPanel.SetDock(bottom, Dock.Bottom);
        side.Children.Add(bottom);

        var nav = new StackPanel();
        RadioButton home = null;
        void Nav(string glyph, string key, string tag)
        {
            var row = new StackPanel { Orientation = Orientation.Horizontal };
            row.Children.Add(new TextBlock { FontFamily = new FontFamily("Segoe MDL2 Assets"), Text = glyph, FontSize = 18, Margin = new Thickness(0, 0, 12, 0) });
            row.Children.Add(new TextBlock { Text = T(key) });
            var rb = new RadioButton { Style = S("NavButton"), GroupName = "tnav", Tag = tag, Content = row };
            rb.Checked += (_, _) => Show(tag);
            // clicking the tab you are already on while a sub-screen is open brings you back to it
            rb.Click += (_, _) => { if (_sub) Show(tag); };
            nav.Children.Add(rb);
            if (tag == "home") home = rb;
        }
        Nav("", "tab_home", "home");
        Nav("", "tab_students", "students");
        Nav(GlyphFolder, "tab_content", "content");
        Nav("", "tab_exams", "exams");
        Nav("", "tab_profile", "profile");
        side.Children.Add(nav);

        var sideBorder = new Border { BorderThickness = new Thickness(0, 0, 1, 0), Child = side };
        sideBorder.SetResourceReference(Border.BackgroundProperty, "bar");
        sideBorder.SetResourceReference(Border.BorderBrushProperty, "bd");
        Grid.SetColumn(sideBorder, 0);
        grid.Children.Add(sideBorder);

        var scroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Padding = new Thickness(28, 24, 28, 24), Content = _host };
        Grid.SetColumn(scroll, 1);
        grid.Children.Add(scroll);
        Content = grid;

        home.IsChecked = true;   // after the host exists, so Show() has somewhere to put the page
    }

    // ------------------------------------------------------------------ routing

    void Show(string tag)
    {
        _sub = false;
        _tag = tag ?? "home";
        _host.Content = _tag switch
        {
            "students" => StudentsTab(),
            "content" => ContentTab(),
            "exams" => ExamsTab(),
            "profile" => ProfileTab(),
            _ => HomeTab(),
        };
    }

    /// <summary>Rebuilds the tab on screen (counters and lists follow the data, like Android's refresh()).</summary>
    void Refresh() => Show(_tag);

    void ShowSub(UserControl page) { _sub = true; _host.Content = page; }

    void Back() { if (_sub) Show(_tag); }

    // ------------------------------------------------------------------ small builders

    static StackPanel PageOf(string titleKey)
    {
        var p = new StackPanel();
        p.Children.Add(new TextBlock { Text = T(titleKey), Style = S("H1"), Margin = new Thickness(0, 0, 0, 16) });
        return p;
    }

    static Border Info(string small, string title, string sub)
    {
        var p = new StackPanel();
        if (!string.IsNullOrEmpty(small)) p.Children.Add(new TextBlock { Text = small, Style = S("Muted") });
        p.Children.Add(new TextBlock { Text = title, Style = S("H2") });
        if (!string.IsNullOrEmpty(sub)) p.Children.Add(new TextBlock { Text = sub, Style = S("Muted"), Margin = new Thickness(0, 2, 0, 0) });
        return new Border { Style = S("Card"), Child = p };
    }

    static Border Stat(int n, string labelKey, string brush)
    {
        var num = new TextBlock { Text = n.ToString(CultureInfo.InvariantCulture), FontSize = 30, FontWeight = FontWeights.Bold };
        num.SetResourceReference(TextBlock.ForegroundProperty, brush);
        var p = new StackPanel();
        p.Children.Add(num);
        p.Children.Add(new TextBlock { Text = T(labelKey), Style = S("Muted") });
        return new Border { Style = S("Card"), Margin = new Thickness(0, 0, 10, 14), Child = p };
    }

    static Border Tile(string glyph, string labelKey, Action click)
    {
        var icon = new TextBlock { FontFamily = new FontFamily("Segoe MDL2 Assets"), Text = glyph, FontSize = 26, HorizontalAlignment = HorizontalAlignment.Center };
        icon.SetResourceReference(TextBlock.ForegroundProperty, "p1");
        var p = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center };
        p.Children.Add(icon);
        p.Children.Add(new TextBlock { Text = T(labelKey), Style = S("H2"), FontSize = 14, TextWrapping = TextWrapping.Wrap, TextAlignment = TextAlignment.Center, Margin = new Thickness(0, 8, 0, 0) });
        var b = new Border { Style = S("Card"), Margin = new Thickness(0, 0, 10, 10), Cursor = Cursors.Hand, Child = p };
        b.MouseLeftButtonUp += (_, _) => click();
        return b;
    }

    static string DateText(long at) =>
        DateTimeOffset.FromUnixTimeMilliseconds(at).LocalDateTime.ToString("yyyy/MM/dd", CultureInfo.InvariantCulture);

    Button Trash(Action delete, string name, string warnKey) =>
        Ui.TrashButton(() => Ui.Confirm(T(warnKey, name), "delete", () => { delete(); Refresh(); }));

    UIElement ContentTiles() => new UniformGrid
    {
        Columns = 3,
        Children =
        {
            Tile(GlyphFolder, "act_chapter", AddChapterSheet),
            Tile(Ui.GlyphPlay, "act_lesson", AddLessonSheet),
            Tile(GlyphVideo, "act_video", AddVideoSheet),
            Tile(Ui.GlyphBook, "act_book", () => AddDocSheet("book")),
            Tile(Ui.GlyphFile, "act_file", () => AddDocSheet("file")),
            Tile("", "act_classes", ClassesScreen),
        }
    };

    // ------------------------------------------------------------------ tabs

    UIElement HomeTab()
    {
        var p = PageOf("tab_home");
        p.Children.Add(new UniformGrid
        {
            Columns = 2,
            Children =
            {
                Stat(Store.Students().Count, "stat_students", "p1"),
                Stat(Store.Grades().Count, "stat_classes", "p2"),
                Stat(Store.Chapters().Count, "stat_chapters", "gold"),
                Stat(Store.Lessons().Count, "stat_lessons", "p1"),
                Stat(Store.Exams().Count, "ex_exams", "p2"),
                Stat(Store.Ungraded(), "hw_ungraded", "gold"),
            }
        });
        p.Children.Add(Ui.Heading(T("manage_content")));
        p.Children.Add(ContentTiles());
        return p;
    }

    UIElement StudentsTab()
    {
        var p = PageOf("tab_students");
        var all = Store.Students();
        var search = new TextBox { Style = S("Field"), Margin = new Thickness(0, 0, 0, 10), ToolTip = "Search by name or email" };
        var grade = new ComboBox { Padding = new Thickness(12, 8, 12, 8), Margin = new Thickness(0, 0, 0, 10), ItemsSource = new[] { T("all_classes") }.Concat(Store.Grades()).ToList(), SelectedIndex = 0 };
        var state = new ComboBox { Padding = new Thickness(12, 8, 12, 8), Margin = new Thickness(0, 0, 0, 10), ItemsSource = new[] { T("all_status"), T("active"), T("inactive") }, SelectedIndex = 0 };
        var listHost = new StackPanel();
        void Render()
        {
            listHost.Children.Clear();
            var q = search.Text.Trim(); var g = grade.SelectedIndex <= 0 ? null : grade.SelectedItem?.ToString();
            var status = state.SelectedIndex;
            var rows = all.Where(x => (q.Length == 0 || x.Name.Contains(q, StringComparison.OrdinalIgnoreCase) || x.Email.Contains(q, StringComparison.OrdinalIgnoreCase))
                && (g == null || x.Grade == g) && (status == 0 || (status == 1 ? x.Active : !x.Active))).ToList();
            if (rows.Count == 0) { listHost.Children.Add(Ui.Empty("empty_students", "empty_students_sub")); return; }
            foreach (var st in rows)
            {
                var student = st;
                var actions = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
                var active = new CheckBox { Content = T("active"), IsChecked = student.Active, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(8, 0, 8, 0) };
                active.Checked += (_, _) => { Store.SetStudentActive(student.Email, true); student.Active = true; };
                active.Unchecked += (_, _) => { Store.SetStudentActive(student.Email, false); student.Active = false; };
                actions.Children.Add(active);
                var code = new Button { Style = S("LinkButton"), Content = string.IsNullOrWhiteSpace(student.Code) ? T("stu_code_new") : student.Code, Margin = new Thickness(4, 0, 4, 0) };
                code.Click += (_, _) =>
                {
                    if (string.IsNullOrWhiteSpace(student.Code)) { student.Code = Store.NewStudentCode(student.Email); code.Content = student.Code; }
                    Clipboard.SetText(student.Code); Ui.Notice(T("copied"));
                };
                actions.Children.Add(code);
                var regen = new Button { Style = S("LinkButton"), Content = T("stu_code_regen") };
                regen.Click += (_, _) => Ui.Confirm(T("stu_regen_confirm"), "stu_code_regen", () => { student.Code = Store.NewStudentCode(student.Email); code.Content = student.Code; Clipboard.SetText(student.Code); });
                actions.Children.Add(regen);
                var edit = new Button { Style = S("LinkButton"), Content = T("act_edit") };
                edit.Click += (_, _) => EditStudentSheet(student);
                actions.Children.Add(edit);
                actions.Children.Add(Ui.TrashButton(() => Ui.Confirm(T("confirm_delete_student", student.Name), "delete", () => { Store.DeleteStudent(student.Email); Refresh(); })));
                var row = Ui.Row("", student.Name, student.Email + "  •  " + student.Grade, new UIElement[] { actions }, () => ShowSub(StudentDetails(student)));
                listHost.Children.Add(row);
            }
        }
        search.TextChanged += (_, _) => Render(); grade.SelectionChanged += (_, _) => Render(); state.SelectionChanged += (_, _) => Render();
        p.Children.Add(search); p.Children.Add(grade); p.Children.Add(state); p.Children.Add(listHost); Render();
        return p;
    }

    UIElement StudentDetails(Student st)
    {
        var p = new StackPanel();
        p.Children.Add(Ui.Header(st.Name, -1, Back));
        p.Children.Add(Info(T("email_label"), st.Email, st.Phone));
        p.Children.Add(Info(T("grade_label"), st.Grade, st.Active ? T("active") : T("inactive")));
        p.Children.Add(Info(T("stu_code_title"), st.Code, null));
        var visibleLessons = Store.PublishedLessons();
        var total = visibleLessons.Count;
        var watched = Store.History(st.Email).Distinct().Count(id => visibleLessons.Any(l => l.Id == id));
        p.Children.Add(Info(T("study_progress"), total == 0 ? "0%" : (100 * watched / total) + "%", T("lessons_done_of", watched, total)));
        p.Children.Add(Ui.Heading(T("paid_content")));
        var openBtn = new Button { Style = S("PrimaryButton"), Content = T("grant_open"), HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 0, 0, 8) };
        openBtn.Click += (_, _) => GrantSheet(st);
        p.Children.Add(openBtn);
        foreach (var g in Store.Grants().Where(x => x.Email == st.Email))
        {
            var gg = g;
            p.Children.Add(Ui.Row("", TargetName(gg.Target), ModeName(gg.Mode),
                new UIElement[] { Trash(() => Store.RevokeAccess(gg.Target, st.Email), TargetName(gg.Target), "confirm_delete") }));
        }
        var glog = Store.GrantLog().Where(x => x.Email == st.Email).OrderByDescending(x => x.At).ToList();
        if (glog.Count > 0)
        {
            p.Children.Add(Ui.Heading(T("grant_log")));
            foreach (var g in glog) p.Children.Add(Info(TargetName(g.Target), T("grant_log_row", ModeName(g.Mode), g.By, DateText(g.At)), null));
        }
        var results = Store.Results().Where(x => x.Email == st.Email).OrderByDescending(x => x.At).ToList();
        p.Children.Add(Ui.Heading(T("ex_results")));
        if (results.Count == 0) p.Children.Add(Ui.Empty("empty_results", "empty_results_sub"));
        foreach (var r in results) p.Children.Add(Info(DateText(r.At), Store.ExamById(r.ExamId)?.Title ?? r.ExamId, r.Score + "%  •  " + r.Correct + "/" + r.Total));
        var subs = Store.Submissions().Where(x => x.Email == st.Email).OrderByDescending(x => x.At).ToList();
        p.Children.Add(Ui.Heading(T("hw_title")));
        if (subs.Count == 0) p.Children.Add(Ui.Empty("empty_homework", "empty_homework_sub"));
        foreach (var sub in subs) p.Children.Add(Info(sub.Grade < 0 ? T("hw_pending") : T("hw_graded"), Store.HomeworkAll().FirstOrDefault(x => x.Id == sub.HwId)?.Title ?? sub.HwId, sub.Grade < 0 ? sub.Text : sub.Grade + "/10  •  " + sub.Note));
        return p;
    }

    void EditStudentSheet(Student student)
    {
        Ui.Sheet(T("act_edit"), (c, w) =>
        {
            var name = Field(c, "name_label"); name.Text = student.Name;
            var phone = Field(c, "phone_label"); phone.Text = student.Phone;
            var grade = new ComboBox { Padding = new Thickness(12, 8, 12, 8), ItemsSource = Store.Grades(), Margin = new Thickness(0, 8, 0, 0), IsEditable = true, Text = student.Grade };
            c.Children.Add(grade);
            var err = ErrLine(c);
            c.Children.Add(Primary(T("save"), 14, (_, _) =>
            {
                if (name.Text.Trim().Length == 0) { Say(err, "err_title"); return; }
                Store.UpdateStudentProfile(student.Email, name.Text, phone.Text, grade.Text);
                w.Close(); Refresh();
            })); c.Children.Add(Cancel(w));
        });
    }

    // Exams tab (questions, exams, homework): TeacherShell.Exams.cs
    UIElement ExamsTab() => ExamsTabReal();

    void ClassesScreen()
    {
        var p = new StackPanel();
        p.Children.Add(Ui.Header(T("classes_title"), Store.Grades().Count, Back));
        var add = new Button { Style = S("PrimaryButton"), Content = T("act_grade"), HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 0, 0, 12) };
        add.Click += (_, _) => AddGradeSheet(); p.Children.Add(add);
        var students = Store.Students();
        foreach (var grade in Store.Grades())
        {
            var g = grade;
            var edit = new Button { Style = S("LinkButton"), Content = T("act_edit") };
            edit.Click += (_, _) => Ui.Sheet(T("act_edit"), (c, w) =>
            {
                var field = Field(c, "hint_grade"); field.Text = g;
                c.Children.Add(Primary(T("save"), 12, (_, _) => { if (string.IsNullOrWhiteSpace(field.Text)) return; var list = Store.Grades(); var i = list.IndexOf(g); if (i >= 0) list[i] = field.Text.Trim(); Store.SaveGrades(list); w.Close(); ClassesScreen(); })); c.Children.Add(Cancel(w));
            });
            var remove = Ui.TrashButton(() => Ui.Confirm(T("confirm_delete_grade", g), "delete", () => { Store.SaveGrades(Store.Grades().Where(x => x != g).ToList()); ClassesScreen(); }));
            p.Children.Add(Ui.Row("", g, T("students_count", students.Count(x => x.Grade == g)), new UIElement[] { edit, remove }));
        }
        _sub = true; _host.Content = p;
    }

    void AddGradeSheet()
    {
        Ui.Sheet(T("act_grade"), (c, w) =>
        {
            var field = Field(c, "hint_grade"); var err = ErrLine(c);
            c.Children.Add(Primary(T("add"), 12, (_, _) =>
            {
                var value = field.Text.Trim(); var list = Store.Grades();
                if (value.Length == 0) { Say(err, "err_title"); return; }
                if (list.Contains(value)) { Say(err, "err_grade_exists"); return; }
                Store.SaveGrades(list.Append(value).ToList()); w.Close(); ClassesScreen();
            })); c.Children.Add(Cancel(w));
        });
    }

    UIElement ProfileTab()
    {
        var p = PageOf("tab_profile");
        var name = Store.TeacherName().Length > 0 ? Store.TeacherName() : _email.Contains('@') ? _email[.._email.IndexOf('@')] : _email;
        p.Children.Add(Info(T("role_teacher_label"), name, null));
        p.Children.Add(Info(T("email_label"), _email, null));
        p.Children.Add(Ui.Row(GlyphGear, T("settings"), null, null, Ui.OpenSettings));
        return p;
    }

    UIElement ContentTab()
    {
        var p = PageOf("tab_content");
        p.Children.Add(ContentTiles());
        var annHeader = new DockPanel { Margin = new Thickness(0, 14, 0, 8) };
        var addAnn = new Button { Style = S("PrimaryButton"), Content = T("act_announce"), Padding = new Thickness(14, 6, 14, 6), HorizontalAlignment = HorizontalAlignment.Right };
        addAnn.Click += (_, _) => AnnouncementSheet(null);
        DockPanel.SetDock(addAnn, Dock.Right); annHeader.Children.Add(addAnn);
        annHeader.Children.Add(Ui.Heading(T("ann_title"))); p.Children.Add(annHeader);
        foreach (var ann in Store.Announcements().OrderByDescending(a => a.At))
        {
            var a = ann;
            var editAnn = new Button { Style = S("LinkButton"), Content = T("act_edit") };
            editAnn.Click += (_, _) => AnnouncementSheet(a);
            p.Children.Add(Ui.Row(Ui.GlyphNote, a.Title, a.Text, new UIElement[] { editAnn, Ui.TrashButton(() => Ui.Confirm(T("confirm_delete", a.Title), "delete", () => { Store.SaveAnnouncements(Store.Announcements().Where(x => x.Id != a.Id).ToList()); Refresh(); })) }));
        }

        var chapters = Store.Chapters();
        var lessons = Store.Lessons();
        var docs = Store.Docs();
        if (chapters.Count == 0 && lessons.Count == 0 && docs.Count == 0)
        {
            p.Children.Add(Ui.Empty("empty_content", "empty_content_sub"));
            return p;
        }

        var videos = lessons.Where(l => l.ChapterId.Length == 0).ToList();
        if (videos.Count > 0)
        {
            p.Children.Add(Ui.Heading(T("videos")));
            foreach (var l in videos) p.Children.Add(LessonRow(l));
        }

        if (chapters.Count > 0) p.Children.Add(Ui.Heading(T("chapters_title")));
        foreach (var ch in chapters)
        {
            var c = ch;
            var ls = lessons.Where(l => l.ChapterId == c.Id).ToList();
            var editChapter = new Button { Style = S("LinkButton"), Content = T("act_rename") };
            editChapter.Click += (_, _) => EditChapterSheet(c);
            var priceChapter = new Button { Style = S("LinkButton"), Content = T("course_price") + (c.Price > 0 ? " • " + T("price_egp", c.Price) : "") };
            priceChapter.Click += (_, _) => CoursePriceSheet(c);
            var upChapter = new Button { Style = S("LinkButton"), Content = "↑" }; upChapter.Click += (_, _) => MoveChapter(c, -1);
            var downChapter = new Button { Style = S("LinkButton"), Content = "↓" }; downChapter.Click += (_, _) => MoveChapter(c, 1);
            p.Children.Add(Ui.Row(GlyphFolder, c.Title, T("lessons_count", ls.Count),
                new UIElement[] { priceChapter, editChapter, upChapter, downChapter, Trash(() => Store.DeleteChapter(c.Id), c.Title, "confirm_delete_chapter") }));
            foreach (var l in ls) p.Children.Add(LessonRow(l));
        }

        var books = docs.Where(d => d.Kind == "book").ToList();
        if (books.Count > 0)
        {
            p.Children.Add(Ui.Heading(T("books_title")));
            foreach (var d in books) p.Children.Add(DocRow(d));
        }
        var files = docs.Where(d => d.Kind == "file").ToList();
        if (files.Count > 0)
        {
            p.Children.Add(Ui.Heading(T("files_title")));
            foreach (var d in files) p.Children.Add(DocRow(d));
        }
        return p;
    }

    UIElement LessonRow(Lesson l)
    {
        var edit = new Button { Style = S("LinkButton"), Content = T("act_edit") };
        edit.Click += (_, _) => EditLessonSheet(l);
        var toggle = new CheckBox { Content = T(l.Published ? "lesson_published" : "lesson_hidden"), IsChecked = l.Published, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(5, 0, 5, 0) };
        toggle.Checked += (_, _) => { var all = Store.Lessons(); all.First(x => x.Id == l.Id).Published = true; Store.SaveLessons(all); Refresh(); };
        toggle.Unchecked += (_, _) => { var all = Store.Lessons(); all.First(x => x.Id == l.Id).Published = false; Store.SaveLessons(all); Refresh(); };
        var up = new Button { Style = S("LinkButton"), Content = "↑" }; up.Click += (_, _) => MoveLesson(l, -1);
        var down = new Button { Style = S("LinkButton"), Content = "↓" }; down.Click += (_, _) => MoveLesson(l, 1);
        var actions = new UIElement[] { edit, toggle, up, down, Trash(() => Store.DeleteLesson(l.Id), l.Title, "confirm_delete") };
        var row = Ui.Row(Ui.GlyphPlay, l.Title, (!Store.HasVideo(l) ? T("no_video_yet") : l.Src == "up" ? T("lesson_video_upload") : "YouTube") + " • " + (l.Price > 0 ? T("price_egp", l.Price) : T("free")) + " • " + T(l.Published ? "lesson_published" : "lesson_hidden"), actions,
            () => Ui.OpenLesson(l, null));
        if (!l.Published) row.Opacity = .65;
        return row;
    }

    void MoveLesson(Lesson lesson, int direction)
    {
        var all = Store.Lessons();
        var same = all.Where(x => x.ChapterId == lesson.ChapterId).ToList();
        var index = same.FindIndex(x => x.Id == lesson.Id); var target = index + direction;
        if (index < 0 || target < 0 || target >= same.Count) return;
        var a = all.IndexOf(same[index]); var b = all.IndexOf(same[target]);
        (all[a], all[b]) = (all[b], all[a]); Store.SaveLessons(all); Refresh();
    }

    void EditChapterSheet(Chapter chapter)
    {
        Ui.Sheet(T("act_edit"), (c, w) =>
        {
            var title = Field(c, "hint_title"); title.Text = chapter.Title;
            c.Children.Add(Primary(T("save"), 14, (_, _) => { if (string.IsNullOrWhiteSpace(title.Text)) return; var all = Store.Chapters(); all.First(x => x.Id == chapter.Id).Title = title.Text.Trim(); Store.SaveChapters(all); w.Close(); Refresh(); }));
            c.Children.Add(Cancel(w));
        });
    }

    void EditLessonSheet(Lesson lesson)
    {
        var chapters = Store.Chapters();
        Ui.Sheet(T("act_edit"), (c, w) =>
        {
            var title = Field(c, "hint_title"); title.Text = lesson.Title;
            var url = Field(c, "hint_youtube_link", true); url.Text = lesson.Yt;
            if (lesson.Src == "up") url.Visibility = Visibility.Collapsed;   // uploaded video: only title, chapter and price change here
            var pick = new ComboBox { Padding = new Thickness(12, 8, 12, 8), ItemsSource = chapters.Select(x => x.Title).ToList(), Margin = new Thickness(0, 8, 0, 0), SelectedIndex = chapters.FindIndex(x => x.Id == lesson.ChapterId) };
            c.Children.Add(pick);
            var pf = new VForm(); PriceForm(c, pf, lesson.Price);
            var err = ErrLine(c);
            c.Children.Add(Primary(T("save"), 14, (_, _) =>
            {
                if (string.IsNullOrWhiteSpace(title.Text)) { Say(err, "err_title"); return; }
                if (PriceOf(pf) is not int price) { Say(err, "err_price"); return; }
                var yt = lesson.Src == "up" ? "" : YoutubeId(url.Text); if (lesson.Src != "up" && url.Text.Trim().Length > 0 && yt.Length == 0) { Say(err, "err_bad_link"); return; }
                var all = Store.Lessons(); var item = all.First(x => x.Id == lesson.Id); item.Title = title.Text.Trim(); item.Yt = yt; item.Price = price;
                if (pick.SelectedIndex >= 0) item.ChapterId = chapters[pick.SelectedIndex].Id;
                Store.SaveLessons(all); w.Close(); Refresh();
            })); c.Children.Add(Cancel(w));
        });
    }

    UIElement DocRow(Doc d)
    {
        var rename = new Button { Style = S("LinkButton"), Content = T("act_rename") };
        rename.Click += (_, _) => Ui.Sheet(T("act_rename"), (c, w) =>
        {
            var title = Field(c, "hint_title"); title.Text = d.Title;
            c.Children.Add(Primary(T("save"), 12, (_, _) => { if (string.IsNullOrWhiteSpace(title.Text)) return; var all = Store.Docs(); all.First(x => x.Id == d.Id).Title = title.Text.Trim(); Store.SaveDocs(all); w.Close(); Refresh(); })); c.Children.Add(Cancel(w));
        });
        var up = new Button { Style = S("LinkButton"), Content = "↑" }; up.Click += (_, _) => MoveDoc(d, -1);
        var down = new Button { Style = S("LinkButton"), Content = "↓" }; down.Click += (_, _) => MoveDoc(d, 1);
        return Ui.Row(d.Kind == "book" ? Ui.GlyphBook : Ui.GlyphFile, d.Title, DateText(d.At),
            new UIElement[] { rename, up, down, Trash(() => Store.DeleteDoc(d.Id), d.Title, "confirm_delete") },
            () => OpenDoc(d));
    }

    void MoveChapter(Chapter chapter, int direction)
    {
        var all = Store.Chapters(); var index = all.FindIndex(x => x.Id == chapter.Id); var target = index + direction;
        if (index < 0 || target < 0 || target >= all.Count) return;
        (all[index], all[target]) = (all[target], all[index]); Store.SaveChapters(all); Refresh();
    }

    void MoveDoc(Doc doc, int direction)
    {
        var all = Store.Docs(); var same = all.Where(x => x.Kind == doc.Kind).ToList();
        var index = same.FindIndex(x => x.Id == doc.Id); var target = index + direction;
        if (index < 0 || target < 0 || target >= same.Count) return;
        var a = all.IndexOf(same[index]); var b = all.IndexOf(same[target]);
        (all[a], all[b]) = (all[b], all[a]); Store.SaveDocs(all); Refresh();
    }

    void OpenDoc(Doc d)
    {
        var path = Store.DocFile(d.Id);
        if (!File.Exists(path)) { Ui.Notice(T("err_no_file")); return; }
        ShowSub(new PdfReaderPage(Back, d.Title, path));
    }

    // ------------------------------------------------------------------ add sheets

    static TextBox Field(StackPanel c, string hintKey, bool ltr = false)
    {
        c.Children.Add(new TextBlock { Text = T(hintKey), Style = S("Muted"), Margin = new Thickness(0, 10, 0, 4) });
        var tb = new TextBox { Style = S("Field") };
        if (ltr) tb.FlowDirection = FlowDirection.LeftToRight;
        c.Children.Add(tb);
        return tb;
    }

    /// <summary>Error line inside a sheet (Android shows a toast; here it stays in the sheet).</summary>
    static TextBlock ErrLine(StackPanel c)
    {
        var e = new TextBlock { Style = S("Muted"), Margin = new Thickness(0, 10, 0, 0), TextWrapping = TextWrapping.Wrap, Visibility = Visibility.Collapsed };
        e.SetResourceReference(TextBlock.ForegroundProperty, "err");
        c.Children.Add(e);
        return e;
    }

    static void Say(TextBlock e, string key) { e.Text = T(key); e.Visibility = Visibility.Visible; }

    static Button Primary(string text, int top, RoutedEventHandler click)
    {
        var b = new Button { Style = S("PrimaryButton"), Content = text, Margin = new Thickness(0, top, 0, 0) };
        b.Click += click;
        return b;
    }

    static Button Cancel(Window w)
    {
        var b = new Button { Style = S("LinkButton"), Content = T("cancel"), HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 10, 0, 0) };
        b.Click += (_, _) => w.Close();
        return b;
    }

    static string YoutubeId(string url) => Store.YoutubeId(url);

    void AnnouncementSheet(Announcement existing)
    {
        Ui.Sheet(T(existing == null ? "act_announce" : "act_edit"), (c, w) =>
        {
            var title = Field(c, "hint_title"); title.Text = existing?.Title ?? "";
            var body = Field(c, "hint_ann_text"); body.AcceptsReturn = true; body.TextWrapping = TextWrapping.Wrap; body.MinHeight = 90; body.Text = existing?.Text ?? "";
            var err = ErrLine(c);
            c.Children.Add(Primary(T(existing == null ? "add" : "save"), 14, (_, _) =>
            {
                if (string.IsNullOrWhiteSpace(title.Text)) { Say(err, "err_title"); return; }
                var all = Store.Announcements();
                if (existing == null) all.Add(new Announcement { Id = Store.NewId(), Title = title.Text.Trim(), Text = body.Text.Trim(), At = Store.Now() });
                else { var a = all.First(x => x.Id == existing.Id); a.Title = title.Text.Trim(); a.Text = body.Text.Trim(); }
                Store.SaveAnnouncements(all); w.Close(); Refresh();
            })); c.Children.Add(Cancel(w));
        });
    }

    void AddChapterSheet() =>
        Ui.Sheet(T("act_chapter"), (c, w) =>
        {
            var title = Field(c, "hint_title");
            var err = ErrLine(c);
            c.Children.Add(Primary(T("add"), 16, (_, _) =>
            {
                var t = title.Text.Trim();
                if (t.Length == 0) { Say(err, "err_title"); return; }
                var all = Store.Chapters();
                all.Add(new Chapter { Id = Store.NewId(), Title = t });
                Store.SaveChapters(all);
                w.Close(); Refresh();
            }));
            c.Children.Add(Cancel(w));
        });

    // ---------- release 35: video source (YouTube link / upload) + price ----------
    sealed class VForm { public int Src; public string Picked; public bool Paid; public TextBox Url, Price; public string Thumb = "", LastYt = ""; }

    /// <summary>"YouTube link / Upload video" chips + the link field or the file picker. A pasted link imports the title + thumbnail.</summary>
    void SourceForm(StackPanel c, VForm f, TextBox title, bool optionalLink, Window w)
    {
        var chips = new WrapPanel { Margin = new Thickness(0, 12, 0, 0) };
        var rbYt = new RadioButton { Style = S("Chip"), GroupName = "vsrc", Content = T("src_youtube"), IsChecked = true };
        var rbUp = new RadioButton { Style = S("Chip"), GroupName = "vsrc", Content = T("src_upload") };
        chips.Children.Add(rbYt); chips.Children.Add(rbUp); c.Children.Add(chips);
        var url = Field(c, optionalLink ? "hint_youtube_optional" : "hint_youtube", true); f.Url = url;
        var chosen = new TextBlock { Style = S("Muted"), Margin = new Thickness(0, 4, 0, 0), Visibility = Visibility.Collapsed };
        var choose = new Button { Style = S("LinkButton"), Content = T("choose_video"), HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 8, 0, 0), Visibility = Visibility.Collapsed };
        choose.Click += (_, _) =>
        {
            var dlg = new Microsoft.Win32.OpenFileDialog { Filter = "Video|*.mp4;*.mov;*.mkv;*.avi;*.webm;*.m4v|All files|*.*" };
            if (dlg.ShowDialog(w) != true) return;
            f.Picked = dlg.FileName; chosen.Text = T("video_selected"); chosen.Visibility = Visibility.Visible;
        };
        c.Children.Add(choose); c.Children.Add(chosen);
        void Show()
        {
            url.Visibility = f.Src == 0 ? Visibility.Visible : Visibility.Collapsed;
            choose.Visibility = f.Src == 1 ? Visibility.Visible : Visibility.Collapsed;
            if (f.Src == 0) chosen.Visibility = Visibility.Collapsed; else if (f.Picked != null) chosen.Visibility = Visibility.Visible;
        }
        rbYt.Checked += (_, _) => { f.Src = 0; Show(); };
        rbUp.Checked += (_, _) => { f.Src = 1; Show(); };
        url.TextChanged += async (_, _) =>
        {
            var id = YoutubeId(url.Text);
            if (id.Length == 0 || id == f.LastYt) return;
            f.LastYt = id;
            var info = await YtMeta.FetchAsync(id);
            if (info == null) { Ui.Notice(T("yt_import_fail")); return; }
            f.Thumb = info.Thumb;
            if (string.IsNullOrWhiteSpace(title.Text)) title.Text = info.Title;
        };
    }

    /// <summary>"Free / Paid" chips + the price field.</summary>
    void PriceForm(StackPanel c, VForm f, int current)
    {
        var chips = new WrapPanel { Margin = new Thickness(0, 10, 0, 0) };
        var rbFree = new RadioButton { Style = S("Chip"), GroupName = "vprice", Content = T("free"), IsChecked = current == 0 };
        var rbPaid = new RadioButton { Style = S("Chip"), GroupName = "vprice", Content = T("paid"), IsChecked = current > 0 };
        chips.Children.Add(rbFree); chips.Children.Add(rbPaid); c.Children.Add(chips);
        var pf = Field(c, "price_hint", true); f.Price = pf; f.Paid = current > 0;
        if (current > 0) pf.Text = current.ToString();
        pf.Visibility = f.Paid ? Visibility.Visible : Visibility.Collapsed;
        rbFree.Checked += (_, _) => { f.Paid = false; pf.Visibility = Visibility.Collapsed; };
        rbPaid.Checked += (_, _) => { f.Paid = true; pf.Visibility = Visibility.Visible; };
    }

    /// <summary>0 = free, > 0 = the price, null = paid but the number is missing.</summary>
    static int? PriceOf(VForm f)
    {
        if (!f.Paid) return 0;
        return int.TryParse(f.Price.Text.Trim(), out var n) && n > 0 ? n : null;
    }

    bool _vbusy;

    async void SubmitLesson(VForm f, string chapterId, string t, TextBlock err, Window w)
    {
        if (t.Length == 0) { Say(err, "err_title"); return; }
        if (PriceOf(f) is not int price) { Say(err, "err_price"); return; }
        if (f.Src == 1)
        {
            if (f.Picked == null) { Say(err, "err_pick_video"); return; }
            if (_vbusy) return;
            _vbusy = true; Say(err, "saving");
            var id = Store.NewId(); var src = f.Picked;
            try
            {
                var dst = Store.VideoFile(id);   // TODO(server): upload to the platform server (resumable, with progress) instead of copying locally
                Directory.CreateDirectory(System.IO.Path.GetDirectoryName(dst)!);
                await Task.Run(() => File.Copy(src, dst, true));
                var all = Store.Lessons();
                all.Add(new Lesson { Id = id, ChapterId = chapterId, Title = t, Yt = "", Src = "up", Price = price, At = Store.Now() });
                Store.SaveLessons(all);
                w.Close(); Refresh();
            }
            catch { try { File.Delete(Store.VideoFile(id)); } catch { } Say(err, "err_copy"); }
            finally { _vbusy = false; }
            return;
        }
        var raw = f.Url.Text.Trim();
        var yt = raw.Length == 0 ? "" : YoutubeId(raw);
        if ((raw.Length > 0 && yt.Length == 0) || (chapterId.Length == 0 && yt.Length == 0)) { Say(err, "err_bad_link"); return; }
        var list = Store.Lessons();
        list.Add(new Lesson { Id = Store.NewId(), ChapterId = chapterId, Title = t, Yt = yt, Price = price, Thumb = f.Thumb, At = Store.Now() });
        Store.SaveLessons(list);
        w.Close(); Refresh();
    }

    void AddLessonSheet()
    {
        var chapters = Store.Chapters();
        if (chapters.Count == 0) { Ui.Notice(T("err_add_chapter_first")); return; }
        Ui.Sheet(T("act_lesson"), (c, w) =>
        {
            var sel = 0; var f = new VForm();
            var title = Field(c, "hint_title");
            c.Children.Add(new TextBlock { Text = T("pick_chapter"), Style = S("Muted"), Margin = new Thickness(0, 14, 0, 0) });
            var chips = new WrapPanel { Margin = new Thickness(0, 8, 0, 0) };
            for (var i = 0; i < chapters.Count; i++)
            {
                var idx = i;
                var rb = new RadioButton { Style = S("Chip"), GroupName = "tchapter", Content = chapters[i].Title, IsChecked = i == 0 };
                rb.Checked += (_, _) => sel = idx;
                chips.Children.Add(rb);
            }
            c.Children.Add(chips);
            SourceForm(c, f, title, true, w);
            PriceForm(c, f, 0);
            var err = ErrLine(c);
            c.Children.Add(Primary(T("add"), 16, (_, _) => SubmitLesson(f, chapters[sel].Id, title.Text.Trim(), err, w)));
            c.Children.Add(Cancel(w));
        });
    }

    void AddVideoSheet() =>
        Ui.Sheet(T("act_video"), (c, w) =>
        {
            var f = new VForm();
            var title = Field(c, "hint_title");
            SourceForm(c, f, title, false, w);
            PriceForm(c, f, 0);
            var err = ErrLine(c);
            c.Children.Add(Primary(T("add"), 16, (_, _) => SubmitLesson(f, "", title.Text.Trim(), err, w)));
            c.Children.Add(Cancel(w));
        });

    // ---------- release 35: opening paid content for a student (cash / free). Every opening is logged. ----------
    static string TargetName(string t) => t.StartsWith("c:")
        ? T("course_tag", Store.Chapters().FirstOrDefault(c => c.Id == t[2..])?.Title ?? "?")
        : Store.Lessons().FirstOrDefault(l => l.Id == t[2..])?.Title ?? "?";
    static string ModeName(string m) => T(m == "online" ? "grant_mode_online" : m == "cash" ? "grant_mode_cash" : "grant_mode_free");

    void GrantSheet(Student st)
    {
        var have = Store.Grants().Where(g => g.Email == st.Email).Select(g => g.Target).ToHashSet();
        var items = new List<(string Target, string Name)>();
        foreach (var c in Store.Chapters().Where(c => c.Price > 0 && !have.Contains("c:" + c.Id))) items.Add(("c:" + c.Id, T("course_tag", c.Title) + "  •  " + T("price_egp", c.Price)));
        foreach (var l in Store.Lessons().Where(l => l.Price > 0 && !have.Contains("l:" + l.Id))) items.Add(("l:" + l.Id, l.Title + "  •  " + T("price_egp", l.Price)));
        if (items.Count == 0) { Ui.Notice(T("grant_none")); return; }
        Ui.Sheet(T("grant_open"), (c, w) =>
        {
            foreach (var it in items)
            {
                var item = it;
                var b = new Button { Style = S("LinkButton"), Content = item.Name, HorizontalAlignment = HorizontalAlignment.Stretch, Margin = new Thickness(0, 6, 0, 0) };
                b.Click += (_, _) =>
                {
                    w.Close();
                    Ui.Sheet(item.Name, (c2, w2) =>
                    {
                        c2.Children.Add(Primary(T("grant_cash"), 8, (_, _) => { DoGrant(st, item.Target, "cash"); w2.Close(); }));
                        c2.Children.Add(Primary(T("grant_free"), 8, (_, _) => { DoGrant(st, item.Target, "free"); w2.Close(); }));
                        c2.Children.Add(Cancel(w2));
                    });
                };
                c.Children.Add(b);
            }
            c.Children.Add(Cancel(w));
        });
    }

    void DoGrant(Student st, string target, string mode)
    {
        Store.GrantAccess(target, st.Email, mode, Store.Teacher()?.Email ?? "teacher");
        Ui.Notice(T("grant_done")); Refresh();
    }

    void CoursePriceSheet(Chapter ch) =>
        Ui.Sheet(T("course_price"), (c, w) =>
        {
            var f = new VForm();
            PriceForm(c, f, ch.Price);
            var err = ErrLine(c);
            c.Children.Add(Primary(T("save"), 14, (_, _) =>
            {
                if (PriceOf(f) is not int p) { Say(err, "err_price"); return; }
                var all = Store.Chapters(); all.First(x => x.Id == ch.Id).Price = p; Store.SaveChapters(all);
                w.Close(); Refresh();
            }));
            c.Children.Add(Cancel(w));
        });

    void AddDocSheet(string kind) =>
        Ui.Sheet(T(kind == "book" ? "act_book" : "act_file"), (c, w) =>
        {
            string picked = null;
            var busy = false;
            var title = Field(c, "hint_title");
            var chosen = new TextBlock { Style = S("Muted"), Margin = new Thickness(0, 4, 0, 0) };
            var choose = new Button { Style = S("LinkButton"), Content = T("choose_pdf"), HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 8, 0, 0) };
            choose.Click += (_, _) =>
            {
                var dlg = new Microsoft.Win32.OpenFileDialog { Filter = "PDF|*.pdf|All files|*.*" };
                if (dlg.ShowDialog(w) != true) return;
                picked = dlg.FileName;
                chosen.Text = T("pdf_selected");
            };
            c.Children.Add(choose);
            c.Children.Add(chosen);
            var err = ErrLine(c);
            c.Children.Add(Primary(T("add"), 12, async (_, _) =>
            {
                var t = title.Text.Trim();
                if (t.Length == 0) { Say(err, "err_title"); return; }
                if (picked == null) { Say(err, "err_pick_pdf"); return; }
                if (busy) return;
                busy = true;
                Say(err, "saving");
                var id = Store.NewId();
                var src = picked;
                try
                {
                    var dst = Store.DocFile(id);
                    Directory.CreateDirectory(System.IO.Path.GetDirectoryName(dst)!);
                    await Task.Run(() => File.Copy(src, dst, true));
                    var all = Store.Docs();
                    all.Add(new Doc { Id = id, Title = t, Kind = kind, At = Store.Now() });
                    Store.SaveDocs(all);
                    w.Close(); Refresh();
                }
                catch
                {
                    try { File.Delete(Store.DocFile(id)); } catch { }
                    Say(err, "err_copy");
                }
                finally { busy = false; }
            }));
            c.Children.Add(Cancel(w));
        });
}
