; Inno Setup script - builds NexoraEdu-Setup.exe (the installer). Compiled by GitHub Actions after "dotnet publish".
#ifndef AppVersion
  #define AppVersion "0.0.0"
#endif

[Setup]
AppId={{A7D2C6B1-4F3E-4C58-9B1A-5E2D7A9C3F10}
AppName=NexoraEdu
AppVersion={#AppVersion}
AppPublisher=NexoraEdu
; The user picks the folder on the second page of the wizard.
DefaultDirName={autopf}\NexoraEdu
DisableDirPage=no
DisableProgramGroupPage=yes
DefaultGroupName=NexoraEdu
OutputDir=..\installer_out
OutputBaseFilename=NexoraEdu-Setup
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
; Default: install for the current user (no admin). The wizard offers "for all users" as a choice.
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
UninstallDisplayIcon={app}\NexoraEdu.exe
UninstallDisplayName=NexoraEdu

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Shortcuts:"

[Files]
Source: "..\out\NexoraEdu.exe"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{autoprograms}\NexoraEdu"; Filename: "{app}\NexoraEdu.exe"
Name: "{autodesktop}\NexoraEdu"; Filename: "{app}\NexoraEdu.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\NexoraEdu.exe"; Description: "Run NexoraEdu"; Flags: nowait postinstall skipifsilent
