#!/usr/bin/env python3
"""Generates Resources/strings.{ar,en}.json and Themes/Colors.{Light,Dark}.xaml from the Android res folder.
Usage: python3 tools/gen_resources.py <android>/app/src/main/res [--check]"""
import sys, os, re, json, glob
import xml.etree.ElementTree as ET

res = sys.argv[1]
check = '--check' in sys.argv
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def unesc(s):
    s = s.replace('\\n', '\n').replace("\\'", "'").replace('\\"', '"').replace('\\\\', '\\')
    n = [0]
    def pos(m): return '{%d}' % (int(m.group(1)) - 1)
    s = re.sub(r'%(\d+)\$[sd]', pos, s)
    def seq(m):
        i = n[0]; n[0] += 1; return '{%d}' % i
    return re.sub(r'%[sd]', seq, s)

def strings(folder):
    out = {}
    for f in sorted(glob.glob(os.path.join(res, folder, 'strings*.xml'))):
        for e in ET.parse(f).getroot().iter('string'):
            out[e.get('name')] = unesc(e.text or '')
    return out

def colors(folder):
    p = os.path.join(res, folder, 'colors.xml')
    if not os.path.exists(p): return {}
    return {e.get('name'): e.text.strip() for e in ET.parse(p).getroot().iter('color')}

ar = strings('values')
en = dict(ar); en.update(strings('values-en'))
light = colors('values')
dark = dict(light); dark.update(colors('values-night'))

def xaml(c):
    lines = ['<ResourceDictionary xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"',
             '                    xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml">']
    for k, v in c.items():
        lines.append('    <SolidColorBrush x:Key="%s" Color="%s"/>' % (k, v))
    lines.append('</ResourceDictionary>')
    return '\n'.join(lines) + '\n'

files = {
    'Resources/strings.ar.json': json.dumps(ar, ensure_ascii=False, indent=0, sort_keys=True),
    'Resources/strings.en.json': json.dumps(en, ensure_ascii=False, indent=0, sort_keys=True),
    'Themes/Colors.Light.xaml': xaml(light),
    'Themes/Colors.Dark.xaml': xaml(dark),
}
bad = 0
for rel, text in files.items():
    p = os.path.join(root, rel)
    if check:
        if not os.path.exists(p) or open(p, encoding='utf-8').read() != text:
            print('OUT OF DATE:', rel); bad += 1
    else:
        os.makedirs(os.path.dirname(p), exist_ok=True)
        open(p, 'w', encoding='utf-8', newline='\n').write(text)
        print('wrote', rel)
sys.exit(1 if bad else 0)
